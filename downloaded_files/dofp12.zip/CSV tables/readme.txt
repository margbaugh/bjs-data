"Drug Offenders in Federal Prison: Estimates of Characteristics Based on Linked Data     NCJ 248648"			
			
This zip archive contains tables in individual  .csv spreadsheets			
"Drug Offenders in Federal Prison: Estimates of Characteristics Based on Linked Data   NCJ 248648.  The full report including text"			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5436

		
			
			
Filename			Table title
dofp12t01.csv			"Table 1. Federally sentenced offenders in the Federal Bureau of Prisons with linked U.S. Sentencing Commission records, by primary offense category, fiscal yearend 2012"
dofp12t02.csv			"Table 2. Federally sentenced drug offenders in the Federal Bureau of Prisons with linked U.S. Sentencing Commission records, by primary drug type, fiscal yearend 2012"
dofp12t03.csv			"Table 3. Demographic characteristics of federally sentenced drug offenders in the Federal Bureau of Prisons, by drug type, fiscal yearend 2012"
dofp12t04.csv			"Table 4. Criminal history of federally sentenced drug offenders in the Federal Bureau of Prisons at fiscal yearend 2012, by drug type"
dofp12t05.csv			"Table 5. Gun involvement in the instant offense for federally sentenced drug offenders in the Federal Bureau of Prisons at fiscal yearend 2012, by drug type"
dofp12t06.csv			"Table 6. Sentences imposed for federally sentenced drug offenders in the Federal Bureau of Prisons at fiscal yearend 2012, by drug type"
dofp12t07.csv			"Table 7. Dataset construction: dataset universe and linkage rate"
dofp12t08.csv			"Table 8. Primary offense category of federally sentenced offenders in the Federal Bureau of Prisons, by linking status, fiscal yearend 2012"
dofp12t09.csv			"Table 9. Demographic characteristics of offenders in federal prison, by commitment type, fiscal yearend 2012"
dofp12t10.csv			"Table 10. Drug offense categorization of federally sentenced  offenders in the Federal Bureau of Prisons, by agency, fiscal yearend 2012"
dofp12t11.csv			"Table 11. Most serious offense of offenders in federal prison with a drug charge, fiscal yearend 2012"

