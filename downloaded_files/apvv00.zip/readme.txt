Age Patterns in Violent Victimization, 1976-2000	NCJ  190104								
									
This zip archive contains graphs in individual .wk1 spreadsheets
from Age Patterns in Violent Victimization, 1976-2000	NCJ  190104.
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/apvv00.htm 									
									
Graph	        	Title							
									
apvv00g1.wk1		Nonfatal overall violence trends by age 1976-2000							
apvv00g2.wk1		Murder by year, by summary age of victim 1976-2000, using Census populations							
