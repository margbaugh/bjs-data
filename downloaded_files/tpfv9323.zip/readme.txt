Trends and Patterns in Firearm Violence, 1993–2023 NCJ 309428	
	
This .zip archive contains tables in individual  .csv spreadsheets	
Trends and Patterns in Firearm Violence, 1993–2023 NCJ 309428.  The full report including text	
and graphics in .pdf format is available from:	
https://bjs.ojp.gov/library/publications/trends-and-patterns-firearm-violence-1993-2023	
	
This report is one in a series.  More recent editions may be available.	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Trends%20and%20Patterns%20in%20Firearm%20Violence	
	
Filenames		Table titles
tpfv9323t01.csv	Table 1. Percent of nonfatal violence involving a firearm, by type of crime, 2018–2022
tpfv9323t02.csv	Table 2. Nonfatal firearm victimization, by type of firearm, 2018–2022 
tpfv9323t03.csv	Table 3. Nonfatal firearm and nonfirearm violence against persons age 12 or older, by victim characteristics, 2018–2022
tpfv9323t04.csv	Table 4. Nonfatal firearm and nonfirearm violence, by location of crime, 2018–2022
tpfv9323t05.csv	Table 5. Nonfatal firearm and nonfirearm violence, by victim-offender relationship, 2018–2022
tpfv9323t06.csv	Table 6. Nonfatal firearm and nonfirearm violence, by injury and treatment received, 2018–2022
tpfv9323t07.csv	Table 7. Nonfatal firearm and nonfirearm violence, by reporting to police and most important reason for not reporting, 2018–2022
tpfv9323t08.csv	Table 8. Nonfatal firearm and nonfirearm victimization against persons age 12 or older reported to police, by victim characteristics, 2018–2022
tpfv9323t09.csv	Table 9. Self-protective behaviors of victims, by type of crime, 2018–2022
tpfv9323t10.csv	Table 10. Incidents of nonfatal firearm violence, by characteristics of U.S. population, offender, and victim, 2018–2022
tpfv9323t11.csv	Table 11. Percent of homicides involving a firearm, 2018–2022
tpfv9323t12.csv	Table 12. Firearm homicides against persons age 12 or older, by victim characteristics, 2018–2022
tpfv9323t13.csv	Table 13. Firearm types that inflicted fatal injuries in firearm homicide deaths, 2018–2022
tpfv9323t14.csv	Table 14. Firearm homicide incident types, 2018–2022
tpfv9323t15.csv	Table 15. Average monthly number of emergency department (ED) visits, percent change in ED visits, and visit ratios of ED visits for firearm injury, overall and by sex and age group, January 2018–December 2023
tpfv9323t16.csv	Table 16. Prevalence of gun carrying in past 12 months among U.S. high school students, 2023
	
			Figures
tpfv9323f01.csv	Figure 1. Rate of nonfatal firearm victimization per 1,000 persons age 12 or older, 1993–2023
tpfv9323f02.csv	Figure 2. Nonfatal victimizations involving the theft of a firearm, 1993–2022
tpfv9323f03.csv	Figure 3. Rate of firearm homicide, 1993–2023
tpfv9323f04.csv	Figure 4. Monthly rate of ED visits for firearm injury, overall and among males and females, January 2018–December 2023
	
			Appendix tables
tpfv9323at01.csv	Appendix Table 1. Population estimates, numbers, rates, and standard errors for figure 1: Rate of nonfatal firearm victimization per 1,000 persons age 12 or older, 1993–2023
tpfv9323at02.csv	Appendix Table 2. Standard errors for table 1: Percent of nonfatal violence involving a firearm, by type of crime, 2018–2022
tpfv9323at03.csv	Appendix Table 3. Standard errors for table 2: Nonfatal firearm victimization, by type of firearm, 2018–2022 
tpfv9323at04.csv	Appendix Table 4. Standard errors for table 3: Nonfatal firearm and nonfirearm violence against persons age 12 or older, by victim characteristics, 2018–2022
tpfv9323at05.csv	Appendix Table 5. Standard errors for table 4: Nonfatal firearm and nonfirearm violence, by location of crime, 2018–2022
tpfv9323at06.csv	Appendix Table 6. Standard errors for table 5: Nonfatal firearm and nonfirearm violence, by victim-offender relationship, 2018–2022
tpfv9323at07.csv	Appendix Table 7. Estimates and standard errors for figure 2: Nonfatal victimizations involving the theft of a firearm, 1993–2022
tpfv9323at08.csv	Appendix Table 8. Standard errors for table 6: Nonfatal firearm and nonfirearm violence, by injury and treatment received, 2018–2022
tpfv9323at09.csv	Appendix Table 9. Standard errors for table 7: Nonfatal firearm and nonfirearm violence, by reporting to police and most important reason for not reporting, 2018–2022
tpfv9323at10.csv	Appendix Table 10. Standard errors for table 8: Nonfatal firearm and nonfirearm victimization against persons age 12 or older reported to police, by victim characteristics, 2018–2022
tpfv9323at11.csv	Appendix Table 11. Standard errors for table 9: Self-protective behaviors of victims, by type of crime, 2018–2022
tpfv9323at12.csv	Appendix Table 12. Standard errors for table 10: Incidents of nonfatal firearm violence, by characteristics of U.S. population, offender, and victim, 2018–2022
tpfv9323at13.csv	Appendix Table 13. Rates and numbers for figure 3: Rate of firearm homicide, 1993–2023
tpfv9323at14.csv	Appendix Table 14. Population estimates for table 12: Firearm homicides against persons age 12 or older, by victim characteristics, 2018–2022
tpfv9323at15.csv	Appendix Table 15. Rates for figure 4: Monthly rate of ED visits for firearm injury, overall and among males and females, January 2018–December 2023