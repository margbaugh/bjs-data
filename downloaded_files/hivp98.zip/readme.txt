This file contains tables in individual spreadsheets from 
1998 National Prisoners Statistics (NPS-1).

This Zip archive, HIV in Prison 1998  NCJ   181758
contains the following tables:



hivp9801.wk1  Table 1.  Inmates in custody of State or Federal prison authorities and known to be positive for the human immunodeficiency virus, 1996-1998	
hivp9802.wk1  Table 2.  Inmates in custody of State and Federal prison authorities, by type of HIV infection or confirmed AIDS, yearend 1998	
hivp9803.wk1  Table 3.  State prison inmates known to be positive for the human immunodeficiency virus, by sex, yearend, 1998	
hivp9804.wk1  Table 4.  Number of inmate deaths in State prisons, by cause,1996-98
hivp9805.wk1  Table 5.  AIDS-related deaths of sentenced prisoners under State jurisdiction, 1998
hivp9806.wk1  Table 6.  Testing policies for the antibody to the human immunodeficiency virus, by jurisdiction, 1998
hivp9807.wk1  Table 7.  Percent of general population and inmate population with confirmed AIDS 
hivp9808.wk1  Table 8.  AIDS-related deaths as a percent of all deaths among the general and inmate populations
