Sheriffs' Offices, Procedures, Policies, and Technology, 2020 – Statistical Tables   NCJ 307234	
							
This zip archive contains tables in individual  .csv spreadsheets
Sheriffs' Offices, Procedures, Policies, and Technology, 2020 – Statistical Tables   NCJ 307234.
The full report including text and graphics in pdf format is available from:
https://bjs.ojp.gov/library/publications/sheriffs-offices-procedures-policies-and-technology-2020-statistical-tables
																				
This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to: https://bjs.ojp.gov/library/publications/list?series_filter=Sheriffs%E2%80%99%20Offices
																				
Filenames		Table titles
soppt20stt01.csv	Table 1. Percent of sheriffs’ offices that authorized less-lethal equipment, by size of office, type of equipment, and authorization level, 2020
soppt20stt02.csv	Table 2. Percent of sheriffs’ offices that authorized less-lethal techniques, by size of office, type of technique, and authorization level, 2020
soppt20stt03.csv	Table 3. Percent of sheriffs’ offices that authorized selected firearms, by duty status of officers and size of office, 2020
soppt20stt04.csv	Table 4. Percent of sheriffs’ offices that used selected types of video cameras, by size of office, 2020
soppt20stt05.csv	Table 5. Percent of sheriffs’ offices that used K-9 units and number of handlers and K-9s, by selected functions and size of office, 2020
soppt20stt06.csv	Table 6. Percent of sheriffs’ offices that required annual in-service training of nonprobationary deputies, by size of office, 2020
soppt20stt07.csv	Table 7. Percent of sheriffs’ offices with written policies or procedural directives, by selected topic and size of office, 2020
soppt20stt08.csv	Table 8. Percent of sheriffs’ offices that regularly checked immigration status in selected circumstances, 2020
soppt20stt09.csv	Table 9. Percent of sheriffs’ offices that required external investigations for selected situations, by size of office, 2020
soppt20stt10.csv	Table 10. Percent of sheriffs’ offices that engaged in selected community policing activities, by size of office, 2020
soppt20stt11.csv	Table 11. Percent of sheriffs’ offices that solicited feedback from the community for selected topics, by size of office, 2020
soppt20stt12.csv	Table 12. Percent of sheriffs’ offices with informal problem-solving partnerships or formal written agreements with selected groups, by size of office, 2020
soppt20stt13.csv	Table 13. Percent of sheriffs’ offices that used data for selected activities, by size of office, 2020
soppt20stt14.csv	Table 14. Percent of sheriffs’ offices that regularly used selected technologies, by size of office, 2020
																				
			Figures
soppt20stf01.csv	Figure 1. Percent of sheriffs’ offices that authorized selected less-lethal equipment and techniques, by authorization level, 2020
soppt20stf02.csv	Figure 2. Percent of sheriffs’ offices that used body-worn cameras, by size of office, 2016 and 2020
soppt20stf03.csv	Figure 3. Ratio of deputies to body-worn cameras in sheriffs’ offices, by size of office, 2020
soppt20stf04.csv	Figure 4. Selected reasons sheriffs’ offices did not regularly check immigration status, 2020
soppt20stf05.csv	Figure 5. Percent of sheriffs’ offices with a computerized early warning or early intervention system for monitoring problematic deputy behavior, by size of office, 2016 and 2020
soppt20stf06.csv	Figure 6. Percent of sheriffs’ offices with a civilian complaint review board or agency, by size of office, 2016 and 2020
soppt20stf07.csv	Figure 7. Percent of sheriffs’ offices that maintained a written community policing plan or conducted a citizen police academy, 2016 and 2020
soppt20stf08.csv	Figure 8. Percent of sheriffs’ offices with a website, by size of office, 2016 and 2020
soppt20stf09.csv	Figure 9. Percent of sheriffs’ offices that used social media, by size of office, 2016 and 2020
																				
			Appendix tables
soppt20stat01.csv	Appendix Table 1. Standard errors for table 1: Percent of sheriffs' offices that authorized less-lethal equipment, by size of office, type of equipment, and authorization level, 2020
soppt20stat02.csv	Appendix Table 2. Standard errors for table 2: Percent of sheriffs’ offices that authorized less-lethal techniques, by size of office, type of technique, and authorization level, 2020
soppt20stat03.csv	Appendix Table 3. Standard errors for table 3: Percent of sheriffs’ offices that authorized selected firearms, by duty status of officers and size of office, 2020
soppt20stat04.csv	Appendix Table 4. Standard errors for table 4: Percent of sheriffs’ offices that used selected types of video cameras, by size of office, 2020
soppt20stat05.csv	Appendix Table 5. Estimates and standard errors for figure 2: Percent of sheriffs’ offices that used body-worn cameras, by size of office, 2016 and 2020
soppt20stat06.csv	Appendix Table 6. Estimates and standard errors for figure 3: Ratio of deputies to body-worn cameras in sheriffs’ offices, by size of office, 2020
soppt20stat07.csv	Appendix Table 7. Standard errors for table 5: Percent of sheriffs’ offices that used K-9 units and number of handlers and K-9s, by selected functions and size of office, 2020
soppt20stat08.csv	Appendix Table 8. Standard errors for table 6: Percent of sheriffs’ offices that required annual in-service training of nonprobationary deputies, by size of office, 2020
soppt20stat09.csv	Appendix Table 9. Standard errors for table 7: Percent of sheriffs’ offices with written policies or procedural directives, by selected topic and size of office, 2020
soppt20stat10.csv	Appendix Table 10. Standard errors for table 8: Percent of sheriffs’ offices that regularly checked immigration status in selected circumstances, 2020
soppt20stat11.csv	Appendix Table 11. Estimates and standard errors for figure 4: Selected reasons sheriffs’ offices did not regularly check immigration status, 2020
soppt20stat12.csv	Appendix Table 12. Estimates and standard errors for figure 5: Percent of sheriffs’ offices with a computerized early warning or early intervention system for monitoring problematic deputy behavior, by size of office, 2016 and 2020
soppt20stat13.csv	Appendix Table 13. Estimates and standard errors for figure 6: Percent of sheriffs’ offices with a civilian complaint review board or agency, by size of office, 2016 and 2020
soppt20stat14.csv	Appendix Table 14. Standard errors for table 9: Percent of sheriffs’ offices that required external investigations for selected situations, by size of office, 2020
soppt20stat15.csv	Appendix Table 15. Standard errors for table 10: Percent of sheriffs’ offices that engaged in selected community policing activities, by size of office, 2020
soppt20stat16.csv	Appendix Table 16. Estimates and standard errors for figure 7: Percent of sheriffs’ offices that maintained a written community policing plan or conducted a citizen police academy, 2016 and 2020
soppt20stat17.csv	Appendix Table 17. Standard errors for table 11: Percent of sheriffs’ offices that solicited feedback from the community for selected topics, by size of office, 2020
soppt20stat18.csv	Appendix Table 18. Standard errors for table 12: Percent of sheriffs’ offices with informal problem-solving partnerships or formal written agreements with selected groups, by size of office, 2020
soppt20stat19.csv	Appendix Table 19. Standard errors for table 13: Percent of sheriffs’ offices that used data for selected activities, by size of office, 2020
soppt20stat20.csv	Appendix Table 20. Estimates and standard errors for figure 8: Percent of sheriffs’ offices with a website, by size of office, 2016 and 2020
soppt20stat21.csv	Appendix Table 21. Estimates and standard errors for figure 9: Percent of sheriffs’ offices that used social media, by size of office, 2016 and 2020
soppt20stat22.csv	Appendix Table 22. Standard errors for table 14: Percent of sheriffs’ offices that regularly used selected technologies, by size of office, 2020