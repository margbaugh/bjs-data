Household Poverty and Nonfatal Violent Victimization, 2008-2012		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Household Poverty and Nonfatal Violent Victimization, 2008-2012  NCJ 248384
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov//index.cfm?ty=pbdetail&iid=5137

Figures
hpnvv0812f01.csv	Figure 1. Rate of violent victimization, by household poverty level, 2008-2012
hpnvv0812f02.csv	Figure 2. Rate of violent victimization, by poverty level, 2009-2012
hpnvv0812f03.csv	Figure 3. Rate of violent victimization, by poverty level and annual household income, 2008-2012	
hpnvv0812f04.csv	Figure 4. Rate of violent victimization by poverty level and race or Hispanic origin, 2008-2012
hpnvv0812f05.csv	Figure 5. Rate of violent victimization, by poverty level and location of residence, 2008-2012
hpnvv0812f06.csv	Figure 6. Rate of violent victimization, by poverty level, race or Hispanic origin, and location of residence, 2008-2012
hpnvv0812f07.csv	Figure 7. Violent victimization reported to police by poverty level and race or Hispanic origin, 2008-2012
hpnvv0812f08.csv	Figure 8. Violent victimization reported to police, by poverty level and location of residence, 2008-2012
hpnvv0812f09.csv	Figure 9. Violent victimization reported to police, by poverty level, race or Hispanic origin and location of residence, 2008-2012

Tables
hpnvv0812t01.csv	Table 1. Average annual number and rate of violent victimization, by poverty level and type of crime, 2008-2012
hpnvv0812t02.csv	Table 2. Rate of violent victimization, by victim-offender relationship and poverty level, 2008-2012
hpnvv0812t03.csv	Table 3. Rate of violent victimization, by presence of a weapon and poverty level, 2008-2012
hpnvv0812t04.csv	Table 4. Violence reported to police, by type of crime and poverty level, 2008-2012
hpnvv0812t05.csv	Table 5. Characteristics of persons in households, by poverty level, 2008-2012

Appendix tables
hpvv0812at01.csv	Appendix table 1. Standard errors for table 1: Average annual number and rate of violent victimization, by poverty level and type of crime, 2008-2012
hpvv0812at02.csv	Appendix table 2. Estimates and standard errors for figure 2: Rate of violent victimization, by poverty level, 2009-2012
hpvv0812at03.csv	Appendix table 3. Standard errors for table 2: Rate of violent victimization, by victim-offender relationship and poverty level, 2008-2012
hpvv0812at04.csv	Appendix table 4. Estimates and standard errors for figure 3: Rate of violent victimization, by poverty level and annual household income, 2008-2012
hpvv0812at05.csv	Appendix table 5. Standard errors for table 3: Rate of violent victimization, by presence of a weapon and poverty level, 2008-2012
hpvv0812at06.csv	Appendix table 6. Estimates and standard errors for figure 4: Rate of violent victimization, by poverty level and race or Hispanic origin, 2008-2012
hpvv0812at07.csv	Appendix table 7. Estimates and standard errors for figure 5: Rate of violent victimization, by poverty level and location of residence, 2008-2012
hpvv0812at08.csv	Appendix table 8. Estimates and standard errors for figure 6: Rate of violent victimization, by poverty level, race or Hispanic origin, and location of residence, 2008-2012
hpvv0812at09.csv	Appendix table 9. Standard errors for table 4: Violence reported to police, by type of crime and poverty level, 2008-2012
hpvv0812at10.csv	Appendix table 10. Estimates and standard errors for figure 7: Violent victimization reported to police, by poverty level and race or Hispanic origin, 2008-2012
hpvv0812at11.csv	Appendix table 11. Estimates and standard errors for figure 8: Violent victimization reported to police, by poverty level and location of residence, 2008-2012
hpvv0812at12.csv	Appendix table 12. Estimates and standard errors for figure 9: Violent victimization reported to police, by poverty level, race or Hispanic origin, and location of residence 2008-2012
hpvv0812at13.csv	Appendix table 13. Standard errors for table 5: Characteristics of persons in households, by poverty level, 2008-2012