Recidivism of Sex Offenders Released from State Prison: A 9-Year Follow-Up (2005-14)   NCJ 251773	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Recidivism of Sex Offenders Released from State Prison: A 9-Year Follow-Up (2005-14)   NCJ 251773.  	
The full report including text and graphics in pdf format is available from:	
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6566
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://www.bjs.gov/index.cfm?ty=pbse&sid=44	
	
	
Filename	Table title
rsorsp9yfu0514t01.csv	Table 1. Characteristics of prisoners released in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514t02.csv	Table 2. Percent of prisoners released in 30 states in 2005 who were arrested within 9 years following release, by most serious commitment offense and types of post-release arrest charges
rsorsp9yfu0514t03.csv	Table 3. Cumulative percent of prisoners released in 30 states in 2005 who were arrested following release, by year following release and most serious commitment offense
rsorsp9yfu0514t04.csv	Table 4. Cumulative arrest percentage of prisoners released in 29 states in 2005 after serving a sentence for rape/sexual assault or assault who had an arrest that led to a conviction after release
rsorsp9yfu0514t05.csv	Table 5. Cumulative percent of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault who were arrested for rape/sexual assault after release, by age and year after release
rsorsp9yfu0514t06.csv	Table 6. Cumulative percent of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested outside the state of release, by year after release
rsorsp9yfu0514t07.csv	Table 7. Annual arrest percentage of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by prisoner characteristics
rsorsp9yfu0514t08.csv	Table 8. Annual arrest percentage of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by types of post-release arrest offenses
rsorsp9yfu0514t09.csv	Table 9. Types of offenses for which prisoners were arrested within 9 years following release in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514t10.csv	Table 10. Characteristics of male prisoners released in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514t11.csv	Table 11. Characteristics of female prisoners released in 30 states in 2005, by most serious commitment offense 
rsorsp9yfu0514t12.csv	Table 12. Cumulative arrest percentage of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested after release, by year after release
rsorsp9yfu0514t13.csv	Table 13. Cumulative arrest percentage of female prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested after release, by year after release
	
rsorsp9yfu0514f01.csv	Figure 1. Annual arrest percentage of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault
rsorsp9yfu0514f02.csv	Figure 2. Cumulative percent of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault who were arrested for rape/sexual assault after release, by age and year after release
	
rsorsp9yfu0514at01.csv	Appendix table 1. Most serious commitment offense of prisoners released in 30 states in 2005, by sex of offender
rsorsp9yfu0514at02.csv	Appendix table 2. Standard errors for appendix table 1: Most serious commitment offense of prisoners released in 30 states in 2005, by sex of offender
rsorsp9yfu0514at03.csv	Appendix table 3. Standard errors for table 1: Characteristics of prisoners released in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514at04.csv	Appendix table 4. Standard errors for table 2: Percent of prisoners released in 30 states in 2005 who were arrested within 9 years following release, by most serious commitment offense and types of post-release arrest charges
rsorsp9yfu0514at05.csv	Appendix table 5. Standard errors for table 3: Cumulative percent of prisoners released in 30 states in 2005 who were arrested following release, by year following release and most serious commitment offense
rsorsp9yfu0514at06.csv	Appendix table 6. Standard errors for table 4: Cumulative arrest percentage of prisoners released in 29 states in 2005 after serving a sentence for rape/sexual assault or assault who had an arrest that led to a conviction after release
rsorsp9yfu0514at07.csv	Appendix table 7. Standard errors for table 5 and figure 2: Cumulative percent of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault who were arrested for rape/sexual assault after release, by age and year after release
rsorsp9yfu0514at08.csv	Appendix table 8. Standard errors for table 6: Cumulative percent of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested outside the state of release, by year after release
rsorsp9yfu0514at09.csv	Appendix table 9. Standard errors for table 7: Annual arrest percentage of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by prisoner characteristics
rsorsp9yfu0514at10.csv	Appendix table 10. Standard errors for table 8: Annual arrest percentage of prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by types of post-release arrest offenses
rsorsp9yfu0514at11.csv	Appendix table 11. Standard errors for table 9: Types of offenses for which prisoners were arrested within 9 years following release in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514at12.csv	Appendix table 12. Standard errors for table 10: Characteristics of male prisoners released in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514at13.csv	Appendix table 13. Standard errors for table 11: Characteristics of female prisoners released in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514at14.csv	Appendix table 14. Standard errors for table 12: Cumulative arrest percentage of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested after release, by year after release
rsorsp9yfu0514at15.csv	Appendix table 15. Standard errors for table 13: Cumulative arrest percentage of female prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested after release, by year after release
rsorsp9yfu0514at16.csv	Appendix table 16. Percent of male prisoners released in 30 states in 2005 who were arrested within 9 years following release, by most serious commitment offense and types of post-release arrest offenses
rsorsp9yfu0514at17.csv	Appendix table 17. Cumulative percent of male prisoners released in 29 states in 2005 after serving a sentence for rape/sexual assault or assault who had an arrest that led to a conviction after release
rsorsp9yfu0514at18.csv	Appendix table 18. Cumulative percent of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault who were arrested for rape/sexual assault after release, by age and year after release 
rsorsp9yfu0514at19.csv	Appendix table 19. Cumulative percent of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested outside the state of release, by year after release
rsorsp9yfu0514at20.csv	Appendix table 20. Annual arrest percentage of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by prisoner characteristics
rsorsp9yfu0514at21.csv	Appendix table 21. Annual arrest percentage of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by types of post-release arrest offenses
rsorsp9yfu0514at22.csv	Appendix table 22. Types of offenses for which male prisoners were arrested within 9 years following release in 30 states in 2005, by most serious commitment offense
rsorsp9yfu0514at23.csv	Appendix table 23. Standard errors for appendix table 16: Percent of male prisoners released in 30 states in 2005 who were arrested within 9 years following release, by most serious commitment offense and types of post-release arrest offenses
rsorsp9yfu0514at24.csv	Appendix table 24. Standard errors for appendix table 17: Cumulative percent of male prisoners released in 29 states in 2005 after serving a sentence for rape/sexual assault or assault who had an arrest that led to a conviction after release
rsorsp9yfu0514at25.csv	Appendix table 25. Standard errors for appendix table 18: Cumulative percent of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault who were arrested for rape/sexual assault after release, by age and year after release
rsorsp9yfu0514at26.csv	Appendix table 26. Standard errors for appendix table 19: Cumulative percent of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault who were arrested outside the state of release, by year after release
rsorsp9yfu0514at27.csv	Appendix table 27. Standard errors for appendix table 20: Annual arrest percentage of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by prisoner characteristics
rsorsp9yfu0514at28.csv	Appendix table 28. Standard errors for appendix table 21: Annual arrest percentage of male prisoners released in 30 states in 2005 after serving a sentence for rape/sexual assault or assault, by types of post-release arrest offenses
rsorsp9yfu0514at29.csv	Appendix table 29. Standard errors for appendix table 22: Types of offenses for which male prisoners were arrested within 9 years following release in 30 states in 2005, by most serious commitment offense
