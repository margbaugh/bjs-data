"HIV in Prisons, 2015 - Statistical Tables, NCJ 250641			
		
This zip archive contains tables in individual .csv spreadsheets			
from "HIV in Prisons, 2015 - Statistical Tables, NCJ 250641. The full report including text			
and grahics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=6026			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to
http://www.bjs.gov/index.cfm?ty=pbse&sid=7		
			
			
			
Filename	        Title

Tables

hivp15stt01.csv	        Estimated number of prisoners who had HIV in the custody of state and federal correctional authorities, by sex, 2010�2015
	
hivp15stt02.csv		AIDS-related deaths among prisoners in the custody of state correctional authorities, by demographic characteristics, 2010�2015
	
hivp15stt03.csv		Number of jurisdictions that tested for HIV and percent of all prison admissions, by HIV testing practices during the intake process, 2011 and 2015
		
hivp15stt04.csv		Number of jurisdictions that tested prisoners for HIV while in custody, by HIV testing practices, 2011 and 2015
		
hivp15stt05.csv		Number of jurisdictions that tested for HIV and percent of all prison releases, by HIV testing practices during discharge planning, 2011 and 2015
	

Figure
	
hivp15stf01.csv		Number of prisoners who had HIV and rate of HIV per 100,000 in the custody of state and federal correctional authorities, 1991�2015

hivp15stf02.csv		Number of AIDS-related deaths and mortality rate among state prisoners, 1991�2015 


Appendix tables

hivp15stat01.csv	Estimated numbers for figure 1: Number of prisoners who had HIV and rate of HIV per 100,000 in the custody of state and federal correctional authorities, 1991�2015
		
hivp15stat02.csv	Numbers for figure 2: Number of 
AIDS-related deaths and mortality rate among state prisoners, 1991�2015
		
hivp15stat03.csv	Estimated number of prisoners who had HIV in the custody of state and federal correctional authorities, by jurisdiction, 2010�2015
		
hivp15stat04.csv	Estimated number of prisoners who had HIV in the custody of state and federal correctional authorities, by sex and jurisdiction, 2010�2015
		
hivp15stat05.csv	HIV testing and consent practices for state and federal prisoners during the intake process, by jurisdiction, 2011
		
hivp15stat06.csv	HIV testing and consent practices for state and federal prisoners during the intake process, by jurisdiction, 2015
		
hivp15stat07.csv	HIV testing practices for state and federal prisoners while in custody, by jurisdiction, 2011
		
hivp15stat08.csv	HIV testing practices for state and federal prisoners while in custody, by jurisdiction, 2015
		
hivp15stat09.csv	HIV testing practices for state and federal prisoners during discharge planning, by jurisdiction, 2011
		
hivp15stat10.csv	HIV testing practices for state and federal prisoners during discharge planning, by jurisdiction, 2015
		
hivp15stat11.csv	Number of prisoners in the custody of state and federal correctional authorities, by sex, 2010�2015

7/26/2017		