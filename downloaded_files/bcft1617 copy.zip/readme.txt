Background Checks for Firearm Transfers, 2016-2017  NCJ 254757		
		
This zip archive contains tables in individual  .csv spreadsheets for		
Background Checks for Firearm Transfers, 2016-2017  NCJ 254757. The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7246		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=13		
		
		
Filenames		Table titles
bcft1617t01.csv		Table 1. Estimated number of firearm applications and denials since the Brady Act’s effective date, 1994-2017
bcft1617t02.csv		Table 2. Firearm applications and denials, by type of checking agency and permit or check, 2016 and 2017
bcft1617t03.csv		Table 3. Firearm applications and denials reported by state agencies, by type of permit or check and jurisdiction, 2016 and 2017
bcft1617t04.csv		Table 4. Firearm applications and denials reported by local agencies, by type of permit or check and size of population served, 2016 and 2017
bcft1617t05.csv		Table 5. Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2016
bcft1617t06.csv		Table 6. Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2017
bcft1617t07.csv		Table 7. Percent change in applications, denials, and reasons for denial, 1999-2016 and 1999-2017
bcft1617t08.csv		Table 8. Bureau of Alcohol, Tobacco, Firearms and Explosives investigation of denials referred by the Federal Bureau of Investigation, 2016 and 2017 
bcft1617t09.csv		Table 9. Number of reporting agencies that participated in the Firearm Inquiry Statistics survey, 2016 and 2017
bcft1617t10.csv		Table 10. Final weights, by state and population category, 2016 and 2017
		
			Figure
bcft1617f01.csv		Figure 1. Estimated number of applications for firearm transfers and permits since the first full year of the Brady Act’s permanent provisions, 1999-2017
		
			Appendix tables
bcft1617at01.csv	Appendix table 1. Firearm applications and denials reported by state and local agencies, by jurisdiction and type of permit or check, 2016
bcft1617at02.csv	Appendix table 2. Firearm applications and denials reported by state and local agencies, by jurisdiction and type of permit or check, 2017
bcft1617at03.csv	Appendix table 3. Standard errors for table 2: Firearm applications and denials reported by local agencies, by type of permit or check, 2016 and 2017
bcft1617at04.csv	Appendix table 4. Standard errors for table 4: Firearm applications and denials reported by local agencies, by type of permit or check and size of population served, 2016 and 2017
bcft1617at05.csv	Appendix table 5. Standard errors for local agencies in tables 5 and 6: Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2016 and 2017
		
