Justice Assistance Grant (JAG) Program 2011 NCJ 237732
	
This zip archive contains tables in individual .csv spreadsheets	

Report title:  Justice Assistance Grant (JAG) Program 2011 NCJ 237732

The full report including text and graphics in .pdf format are available from:	
http://www.bjs.gov//index.cfm?ty=pbdetail&iid=4432
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=71	


Tables	
jagp12t01.csv 	Table 1. State and local allocation amounts, FY 2012
jagp12t02.csv	Table 2. Territories and District of Columbia allocations, FY 2012



Figure	
jagp12f01.csv	Figure 1: Distribution of FY 2012 JAG funds
