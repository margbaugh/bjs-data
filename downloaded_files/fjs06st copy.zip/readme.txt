Federal Justice Statistics, 2006 - Statistical Tables  NCJ 225711											
											
This zip archive contains tables in individual .csv spreadsheets from 
Federal Justice Statistics 2006 - Statistical Tables, NCJ 225711
The full report including text and graphics in pdf format are available 
from: http://www.ojp.usdoj.gov/pub/htm/fjsst/2006/fjs06st.htm
 
This report is one in a series.  More recent editions may be available. 
 To view a list of all in the series go to http://www.ojp.usdoj.gov/bjs/pubalp2.htm#fjs
											
											
											
fjs06st101.csv		Table 1.1. Suspects arrested for federal offenses and booked by U.S. Marshals Service, by offense, October 1, 2005 - September 30, 2006									
fjs06stm101.csv		Map 1.1. Suspects arrested by the Drug Enforcement Administration, by state of arrest, October 1, 2005 - September 30, 2006									
fjs06st102.csv		Table 1.2. Suspects arrested for federal offenses and booked by U.S. Marshals Service, by arresting agency, October 1, 2005 - September 30, 2006									
fjs06st103.csv		Table 1.3. Characteristics of federal arrestees booked by U.S. Marshals Service, October 1, 2005 - September 30, 2006									
fjs06st104.csv		Table 1.4. Characteristics of suspects arrested by Drug Enforcement Administration agents, by type of drug, October 1, 2005 - September 30, 2006 									
fjs06st105.csv		Table 1.5. Warrants cleared, by warrant type, October 1, 2005 - September 30, 2006									
fjs06st106.csv		Table 1.6. Time from warrant initiation to clearance, by warrant characteristics, October 1, 2005 - September 30, 2006									
fjs06st201.csv		Table 2.1. Suspects in matters received by U.S. attorneys, by offense, October 1, 2005 - September 30, 2006									
fjs06stm201.csv		Map 2.1. Suspects referred to U.S. attorneys, by federal judicial district, October 1, 2005 - September 30, 2006									
fjs06st202.csv		Table 2.2. Disposition of suspects in matters concluded, by offense, October 1, 2005 - September 30, 2006									
fjs06st203.csv		Table 2.3. Suspects in criminal matters declined by U.S. attorneys, by basis of declination, October 1, 2005 - September 30, 2006									
fjs06st301.csv		Table 3.1. Defendants released at any time prior to case disposition, by offense, October 1, 2005 - September 30, 2006									
fjs06st302.csv		Table 3.2. Defendants released at any time prior to case disposition, by defendant characteristics, October 1, 2005 - September 30, 2006									
fjs06st303.csv		Table 3.3. Behavior of federal defendants released to the community pending trial, by offense, October 1, 2005 - September 30, 2006									
fjs06st401.csv		Table 4.1. Defendants in criminal cases commenced, by offense, October 1, 2005 - September 30, 2006									
fjs06st402.csv		Table 4.2. Federal criminal case dispositions, by offense, October 1, 2005 - September 30, 2006									
fjs06st403.csv		Table 4.3. Criminal cases disposed by U.S. magistrates, by offense, October 1, 2005 - September 30, 2006									
fjs06st404.csv		Table 4.4. Characteristics of convicted offenders, October 1, 2005 - September 30, 2006									
fjs06st501.csv		Table 5.1. Sentence types for offenders sentenced in criminal cases terminated, by offense, October 1, 2005 - September 30, 2006									
fjs06st502.csv		Table 5.2. Type and length of federal sentences imposed, by offense, October 1, 2005 - September 30, 2006									
fjs06st503.csv		Table 5.3. Federal offenders sentenced to incarceration, by offender characteristics, October 1, 2005 - September 30, 2006									
fjs06st504.csv		Table 5.4. Average incarceration sentence lengths imposed, by offense and offender characteristics, October 1, 2005 - September 30, 2006									
fjs06st601.csv		Table 6.1. Criminal appeals terminated, by type of criminal case and offense, October 1, 2005 - September 30, 2006									
fjs06st602.csv		Table 6.2. Disposition of criminal appeals terminated, by offense, October 1, 2005 - September 30, 2006									
fjs06st603.csv		Table 6.3. Federal criminal appeals cases terminated on the merits, by offense, October 1, 2005 - September 30, 2006									
fjs06st701.csv		Table 7.1. Federal offenders under supervision, by offense, October 1, 2005 - September 30, 2006									
fjs06stm701.csv		Map 7.1. Defendants under federal supervision, by federal judicial district, October 1, 2005 - September 30, 2006									
fjs06st702.csv		Table 7.2. Characteristics of federal offenders under supervision, October 1, 2005 - September 30, 2006									
fjs06st703.csv		Table 7.3. Outcomes of federal probation supervision, by offense, October 1, 2005 - September 30, 2006									
fjs06st704.csv		Table 7.4. Characteristics of offenders terminating federal probation supervision, October 1, 2005 - September 30, 2006									
fjs06st705.csv		Table 7.5. Outcomes of federal supervised release, by offense, October 1, 2005 - September 30, 2006									
fjs06st706.csv		Table 7.6. Characteristics of offenders terminating federal supervised release, October 1, 2005 - September 30, 2006									
fjs06st707.csv		Table 7.7. Outcomes of federal parole, by offense, October 1, 2005 - September 30, 2006									
fjs06st708.csv		Table 7.8. Characteristics of offenders terminating federal parole, October 1, 2005 - September 30, 2006									
fjs06st709.csv		Table 7.9. Admissions and releases of federal prisoners, by offense, October 1, 2005 - September 30, 2006									
fjs06st710.csv		Table 7.10. Characteristics of the federal prison population, October 1, 2005 - September 30, 2006									
fjs06st711.csv		Table 7.11. Average time to first release and percent of sentence served, for federal prisoners released by standard methods October 1, 2005 - September 30, 2006									
fjs06st712.csv		Table 7.12. Characteristics of first releases from federal prison, by offense, all releases, October 1, 2005 - September 30, 2006									
