Correctional Populations in the United States, 2022 – Statistical Tables   NCJ 308699	
	
This zip archive contains tables in individual .csv spreadsheets	
from Correctional Populations in the United States, 2022 – Statistical Tables   NCJ 308699.	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/correctional-populations-united-states-2022-statistical-tables	
	
These statistical tables are in a series. More recent editions may be available.	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Correctional%20Populations%20in%20the%20United%20States	
	
Filenames		Table titles
cpus22stt01.csv		Table 1. Number of persons supervised by adult correctional systems in the United States, by correctional status, 2012–2022 
cpus22stt02.csv		Table 2. Composition of the adult correctional system in the United States, by correctional status, 2012 and 2022
cpus22stt03.csv		Table 3. Rate of persons supervised by adult correctional systems in the United States, by correctional status, 2012–2022
cpus22stt04.csv		Table 4. Number of persons supervised by adult correctional systems in the United States, by correctional status and sex, 2012–2022
cpus22stt05.csv		Table 5. Rate of persons supervised by adult correctional systems in the United States, by correctional status and sex, 2012–2022
cpus22stt06.csv		Table 6. Number of persons supervised by adult correctional systems in the United States, by correctional status and race or Hispanic origin, 2012–2022
cpus22stt07.csv		Table 7. Rate of persons supervised by adult correctional systems in the United States, by correctional status and race or Hispanic origin, 2012–2022
cpus22stt08.csv		Table 8. Custody counts of adults in state or federal prison or local jail in the United States, by type of facility, 2012, 2021, and 2022
cpus22stt09.csv		Table 9. Number of persons incarcerated by other adult correctional systems, 2012, 2021, and 2022
cpus22stt10.csv		Table 10. Number of persons with dual correctional statuses at yearend, by sex and race or Hispanic origin, 2012–2022
	
			Figures
cpus22stf01.csv		Figure 1. Persons under the supervision of adult correctional systems per 100,000 adult U.S. residents, 2002–2022
	
			Appendix tables
cpus22stat01.csv	Appendix table 1. Rates for figure 1: Persons under the supervision of adult correctional systems per 100,000 adult U.S. residents, 2002–2022
cpus22stat02.csv	Appendix table 2. Standard errors for local jail inmates at midyear, total incarcerated population, and total correctional population, by sex and race or Hispanic origin, 2012–2022
cpus22stat03.csv	Appendix table 3. Standard errors for rates of local jail inmates at midyear, total incarceration population, and total correctional population, by sex and race or Hispanic origin,  2012–2022
