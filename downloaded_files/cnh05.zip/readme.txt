Crime and the Nation's Households, 2005   NCJ  217198	

This zip archive contains tables in individual .csv spreadsheets
from Crime and the Nation's Households, 2005   NCJ 217198
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cnh05.htm


File Name	
		Text Tables
cnh05tt01.cvs	Text table 1.  Number and percent of crimes, 2005
cnh05tt02.cvs	Text table 2.  Number and percentage of households experiencing crime, 2005
cnh05tt03.cvs	Text table 3.  Percent of households by region in the United States, 2000 and 2005
cnh05tt04.csv	Text table 4.  Percent of households by urban, suburban or rural areas, 2005

		Figures 
cnh05f01.cvs	Figure 1.  Percent of U.S. households experiencing crime, 1994-2005
cnh05f02.cvs	Figure 2. Percent of U.S. households experiencing crime, by race and Hispanic origin, 2005
cnh05f03.cvs	Figure 3.  Percentage of U.S. households experiencing overall crime and violent crime, by number of household members, 2005
