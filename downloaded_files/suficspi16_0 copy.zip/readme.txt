Source and Use of Firearms Involved in Crimes: Survey of Prison Inmates, 2016   NCJ 251776	
	
This zip archive contains tables in individual  .csv spreadsheets	
Source and Use of Firearms Involved in Crimes: Survey of Prison Inmates, 2016   NCJ 251776.  The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6486	
	
	
	
File name		Table title
suficspi16t01.csv	Table 1. Firearm possession and use among state and federal prisoners during the offense for which they were serving time, by type of controlling offense, 2016
suficspi16t02.csv	Table 2. Among state and federal prisoners who possessed a firearm during the offense for which they were serving time, extent of firearm use, 2016
suficspi16t03.csv	Table 3. Firearm possession and use among state and federal prisoners during the offense for which they were serving time, by type of firearm, 2016
suficspi16t04.csv	Table 4. Firearm possession among state and federal prisoners during the offense for which they were serving time, by demographic characteristics, 2016
suficspi16t05.csv	Table 5. Among state and federal prisoners who had possessed a firearm during the offense for which they were serving time, sources and methods used to obtain a firearm
suficspi16t06.csv	Table 6. Among state and federal prisoners who had possessed a firearm during the offense for which they were serving time, processes used to obtain a firearm, 2016
suficspi16t07.csv	Table 7. Firearm possession and use among all state and federal prisoners during the offense for which they were serving time, by type of controlling offense and source, 2016
	
suficspi16f01.csv	Figure 1. Percent of all state and federal inmates who had possessed or used a firearm during their offense, 2016
	
suficspi16at01.csv	Appendix table 1. Standard errors for figure 1: Percent of all state and federal inmates who had possessed or used a firearm during their offense, 2016
suficspi16at02.csv	Appendix table 2. Standard errors for table 1: Firearm possession and use among state and federal prisoners during the offense for which they were serving time, by type of controlling offense, 2016
suficspi16at03.csv	Appendix table 3. Standard errors for table 2: Among state and federal prisoners who possessed a firearm during the offense for which they were serving time, extent of firearm use, 2016
suficspi16at04.csv	Appendix table 4. Standard errors for table 3: Firearm possession and use among state and federal prisoners during the offense for which they were serving time, by type of firearm, 2016
suficspi16at05.csv	Appendix table 5. Standard errors for table 4: Firearm possession among state and federal prisoners during the offense for which they were serving time, by demographic characteristics, 2016
suficspi16at06.csv	Appendix table 6. Standard errors for table 5: Among state and federal prisoners who had possessed a firearm during the offense for which they were serving time, sources and methods used to obtain a firearm
suficspi16at07.csv	Appendix table 7. Standard errors for table 6: Among state and federal prisoners who had possessed a firearm during the offense for which they were serving time, processes used to obtain a firearm, 2016
suficspi16at08.csv	Appendix table 8. Standard errors for table 7: Firearm possession and use among all state and federal prisoners during the offense for which they were serving time, by type of controlling offense and source, 2016
