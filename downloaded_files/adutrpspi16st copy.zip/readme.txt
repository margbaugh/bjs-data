Alcohol and Drug Use and Treatment Reported by Prisoners: Survey of Prison Inmates, 2016  NCJ 252641			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Alcohol and Drug Use and Treatment Reported by Prisoners: Survey of Prison Inmates, 2016  NCJ 252641.  The full report including text			
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/alcohol-and-drug-use-and-treatment-reported-prisoners-survey-prison-inmates			
			
			
Filenames		Table names		
adutrpspi16stt01.csv	Table 1. Alcohol use, drug use, and substance use disorder among state and federal prisoners, 2016		
adutrpspi16stt02.csv	Table 2. Alcohol use and alcohol use disorder among state and federal prisoners, 2016		
adutrpspi16stt03.csv	Table 3. Drug use among state and federal prisoners, 2016		
adutrpspi16stt04.csv	Table 4. Drug use among state prisoners in the 30 days prior to arrest and at the time of the offense and alcohol use at the time of the offense, by selected characteristics, 2016		
adutrpspi16stt05.csv	Table 5. Drug use among federal prisoners in the 30 days prior to arrest and at the time of the offense and alcohol use at the time of the offense, by selected characteristics, 2016		
adutrpspi16stt06.csv	Table 6. Substance use disorders among state and federal prisoners, by selected characteristics, 2016		
adutrpspi16stt07.csv	Table 7. Alcohol or drug treatment among state and federal prisoners who met the criteria for substance use disorder, 2016		
adutrpspi16stt08.csv	Table 8. Drug use among state and federal prisoners, 2004 and 2016		
adutrpspi16stt09.csv	Table 9. Drug use in the 30 days prior to arrest among state and federal prisoners, by drug type, 2004 and 2016		
			
			Figure		
adutrpspi16stf01.csv	Figure 1. Alcohol use, drug use, and substance use disorder among state and federal prisoners, 2016		
			
			Appendix tables		
adutrpspi16stat01.csv	Appendix table 1. Estimated number of state and federal prisoners, by selected characteristics, 2016		
adutrpspi16stat02.csv	Appendix table 2. Standard errors for table 6: Substance use disorders among state and federal prisoners, by selected characteristics, 2016		
			
			
			
			
			
			
