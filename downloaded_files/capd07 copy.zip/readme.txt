Crime Against People with Disabilities, 2007 NCJ 227814

This zip archive contains tables in individual .csv spreadsheets from Crime Against People with Disabilities, NCJ 227814. The full report including text and graphics in pdf format are available at: http://www.ojp.usdoj.gov/bjs/abstract/capd07.htm.          	


                        Tables		
capd07t01.csv		Table 1. Numbers and rates of violent victimization among persons with and without disabilities, by type of crime, 2007
capd07t02.csv		Table 2. Violent victimization rate for persons with and without disabilities, by age, 2007
capd07t03.csv		Table 3. Rate of violent victimization for persons with and without disabilities, by gender, race, and Hispanic origin, 2007
capd07t04.csv		Table 4. Violent victimization rate, by type of disability and type of crime, 2007
capd07t05.csv		Table 5. Victim/offender relationship of violent crime victims with and  without disabilities, by gender, 2007
capd07t06.csv		Table 6. Victim resistance during a violent crime, by victim's disability status and type of resistance, 2007
capd07t07.csv		Table 7. Violent crime, by offender weapon use against persons with and without disabilities, 2007
capd07t08.csv		Table 8. Injury and medical treatment in violent crimes against persons with and without disabilities, 2007
capd07t09.csv		Table 9. Percent of violent crime reported to police, by victim's disability status and type of crime, 2007
capd07t10.csv		Table 10. Household property victimization for persons with and without disabilities, by type of crime, 2007

                        Text tables		
capd07tt01.csv		Text table 1. Violent victimization rate of persons with disabilities, by type of disability and gender, 2007
capd07tt02.csv		Text table 2. Percent of violence, by perceived offender alcohol or drug use and  victim's disability status, 2007
capd07tt03.csv		Text table 3. Percent of reported violent crime, by police response and victim's disability status, 2007
capd07tt04.csv          Text table 4.  Percent of violent crime victims that used a victim assistance agency other than the police, by victim disability status and agency type, 2007

                    Appendix tables
capd07at01.csv      Appendix table 1. U.S. population by disability status, by gender, race, Hisapnic origin, and age, 2007