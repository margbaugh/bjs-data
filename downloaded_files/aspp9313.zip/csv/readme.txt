"Aging of the State Prison Population, 1993-2013    NCJ 248766"			
			
This zip archive contains tables in individual  .csv spreadsheets			
"Aging of the State Prison Population, 1993-2013    NCJ 248766.  The full report including text"			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5602	
						
			
			
Filename			Table title
aspp9313t01.csv			"Table 1. Sentenced state prisoners, by age, December 31, 1993, 2003, and 2013"
aspp9313t02.csv			"Table 2. Imprisonment rate of sentenced state prisoners per 100,000 U.S. adult residents, by age, December 31, 1993, 2003, and 2013"
aspp9313t03.csv			"Table 3. Characteristics of sentenced state prisoners age 65 or older, December 31, 2013"
aspp9313t04.csv			"Table 4. Sentenced state prisoners, by age and sex, December 31, 1993, 2003, and 2013"
aspp9313t05.csv			"Table 5. Sentenced state prisoners, by age, race, and Hispanic origin, December 31, 1993, 2003, and 2013"
aspp9313t06.csv			"Table 6. Imprisonment rate of sentenced state prisoners per 100,000 U.S. adult residents, by age and sex , December 31, 1993, 2003, and 2013 2008"
aspp9313t07.csv			"Table 7. Imprisonment rate of sentenced state prisoners per 100,000 U.S. adult residents, by age, race, and Hispanic origin, December 31, 1993, 2003, and 2013"
aspp9313t08.csv			"Table 8. Admissions of sentenced state prisoners, by age at admission, 1993, 2003, and 2013"
aspp9313t09.csv			"Table 9. Admissions of sentenced state prisoners, by age at admission and type of admission, 1993, 2003, and 2013"
aspp9313t10.csv			"Table 10. Rate of new court commitments to state prison per 100,000 U.S. adult residents, by age at admission, 1993, 2003, and 2013"
aspp9313t11.csv			"Table 11. New court commitment admissions to state prisons, by age at admission and most serious offense, 1993, 2003, 2013"
aspp9313t12.csv			"Table 12. Arrests, by age at arrest and most serious offense, 1993, 2003, and 2012"
aspp9313t13.csv			"Table 13. Arrest rates per 100,000 U.S. residents, by age at arrest and most serious offense, 1993, 2003, and 2013"
aspp9313t14.csv			"Table 14. Rate of new court commitments to state prison per 1,000 arrests, by age at admission and offense, 1993, 2003, and 2013"
aspp9313t15.csv			"Table 15. Distributions of sentence length for new court commitments to state prison, by age at admission and most serious offense, 1993, 2003, and 2013"
aspp9313t16.csv			"Table 16. Mean time expected to be served at time of new court commitment to state prison for persons admitted in 1993, 2003, and 2013, by age at admission and most serious offense"
aspp9313t17.csv			"Table 17.  Time served by released state prisoners, by age and type of admission, 1993, 2003, and 2013"
aspp9313t18.csv			"Table 18. Percent contribution of admissions and sentenced state prisoners aging into the prison population, by age at yearend, December 31, 1993, 2003, and 2013"
aspp9313t19.csv			"Table 19. Number of NCRP records compared to NPS sentenced jurisdiction counts, by record type, 1993, 2003, and 2013"
aspp9313t20.csv			"Table 20. Offense distribution of yearend 1993 state prison population, by method of estimation"
aspp9313t21.csv			"Table 21. Offense distribution of state prison population, by method of data collection, 2003 and 2004"


Figure Tables
aspp9313f01.csv               	"Figure 1. Sentenced state prisoners, by age, December 31, 1993, 2003, and 2013"
aspp9313f02.csv			"Figure 2. Sentenced state prisoners, by age, December 31, 1993, 2003, and 2013"
aspp9313f03.csv			"Figure 3. Percent change in sentenced state prisoners, by age at yearend, 1993�2003 and 2003�2013"
aspp9313f04.csv			"Figure 4. Percent contribution to total change in sentenced state prisoners, by age at yearend, 1993�2003 and 2003�2013"
aspp9313f05.csv			"Figure 5. Percent distribution of U.S. residents and sentenced state prison populations, by age, December 31, 1993, 2003, and 2013"
aspp9313f06.csv			"Figure 6. Percent change in sentenced state prisoners, by age and sex, 1993�2003 and 2003�2013"
aspp9313f07.csv			"Figure 7. Percent contribution to total change in sentenced state prisoners, by age and sex, 1993�2003 and 2003�2013"
aspp9313f08.csv			"Figure 8. Percent change in sentenced state prisoners, by race, 1993�2003 and 2003�2013"
aspp9313f09a.csv		"Figure 9a. Percent of sentenced state prisoners held for violent offenses, by age, December 31, 1993, 2003, and 2013"
aspp9313f09b.csv		"Figure 9b. Percent of sentenced state prisoners held for property offenses, by age, December 31, 1993, 2003, and 2013"
aspp9313f09c.csv		"Figure 9c. Percent of sentenced state prisoners held for drug offenses, by age, December 31, 1993, 2003, and 2013"
aspp9313f10.csv			"Figure 10. Percent of sentenced state prisoners held for murder or nonnegligent manslaughter, by age, December 31, 1993, 2003, and 2013"
aspp9313f11.csv			"Figure 11. Percent of sentenced state prisoners held for rape or sexual assault, by age, December 31, 1993, 2003, and 2013"
aspp9313f12.csv			"Figure 12. Admissions of sentenced state prisoners, by age at admission, 1993, 2003, and 2013"
aspp9313f13.csv			"Figure 13. Percent change in admissions to state prisons, by age at admission, 1993, 2003, and 2013"
aspp9313f14a.csv		"Figure 14a. New court commitment rates for state prisoners ages 18 to 39 per 1,000 arrests, by offense, 1993, 2003, and 2013"
aspp9313f14b.csv		"Figure 14b. New court commitment rates for state prisoners ages 40 to 54 per 1,000 arrests, by offense, 1993, 2003, and 2013"
aspp9313f14c.csv		"Figure 14c. New court commitment rates for state prisoners age 55 or older per 1,000 arrests, by offense, 1993, 2003, and 2013"
aspp9313f15.csv			"Figure 15. Percent of released sentenced state prisoners who served 10 years or more since admission on a new court commitment in 1993, 2003, and 2013, by age of release"
aspp9313f16.csv			"Figure 16. Percent of state prisoners who served 10 years or more since admission on a new court commitment, by age, December 31, 1993, 2003, and 2013"
aspp9313f17.csv			"Figure 17. Percent contribution of sentenced state prisoners aging into the prison population, by age, yearend 1993, 2003, and 2013"


Appendix tables			
aspp9313at01.csv		"Appendix table 1. Standard errors for figure 1: Sentenced state prisoners, by age, December 31, 1993"
aspp9313at02.csv		"Appendix table 2. Standard errors for table 1 and figure 5: Sentenced state prisoners, by age, December 31, 1993"
aspp9313at03.csv		"Appendix table 3. Standard errors for table 4 and table 5: Sentenced state prisoners, by age, race, and Hispanic origin, December 31, 1993"
aspp9313at04.csv		"Appendix table 4. Standard errors for figure 9a, figure 9b, figure 9c, figure 10, and figure 11: Percent of sentenced state prisoners, by most serious offense and age at yearend, December 31, 1993"
aspp9313at05.csv		"Appendix table 5. Standard errors for table 18 and figure 19: Percent contribution of sentenced state prisoners aging into the prison population, December 31, 1993"
aspp9313at06.csv		"Appendix table 6. Proportion of total change in yearend prison population, by age, December 31, 1993, 2003, and 2013"
aspp9313at07.csv		"Appendix table 7. Proportion of total change in yearend prison population, by age and sex, December 31, 1993, 2003, and 2013"
aspp9313at08.csv		"Appendix table 8. Proportion of total change in yearend prison population, by age and race, December 31, 1993, 2003, and 2013"
aspp9313at09.csv		"Appendix table 9. Number of sentenced state prisoners, by age at yearend and most serious offense, December 31, 1993, 2003, and 2013"
aspp9313at10.csv		"Appendix table 10. Standard errors for appendix table 9: Number of sentenced state prisoners, by age at yearend and most serious offense, December 31, 1993"
aspp9313at11.csv		"Appendix table 11. New court commitment admissions to state prisons, by age at admission and most serious offense, 1993, 2003, and 2013"
