Bureau of Justice Statistics
Law Enforcement Management and Administrative Statistics, 1999:
Data for Individual State and Local Agencies with 100 or more Officers
By Brian A. Reaves, Ph.D. and Timothy C. Hart, BJS Statisticians

Contents of Zip archive lema993a.zip.  This file contains the tables from one section of the
report.  Additional tables are available at www.ojp.usdoj.gov/bjs/abstract/lemas99.htm.

LOCAL AGENCIES

III.  OPERATIONS

lem9908a.wk1 Number of district/precinct stations separate from headquarters, and types of
patrol used, 1999                    

lem9909a.wk1 Number and percent of officers assigned to respond to calls for service, type of
9-1-1 system, and number of telephone calls for service received, 1999   
                  
lem9910a.wk1 Criminal investigation and investigative support functions, 1999

lem9911a.wk1  Traffic and vehicle-related functions, 1999

lem9912a.wk1  Special operations, special enforcement, and 
special public safety functions, 1999

lem9913a.wk1  Court-related, detention-related, dispatch, and training academy functions, 1999


