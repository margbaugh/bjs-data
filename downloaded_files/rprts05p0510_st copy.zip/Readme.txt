This zip archive contains tables in individual  .csv spreadsheets	
"from Recidivism of Prisoners Released in 30 States in 2005: Patterns from 2005 to 2010
  - supplemental Tables, "	
NCJ 244205 The full report including text and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4986	

	
Tables	
rprts05p0510t01.csv	Table 1. Most serious commitment offense of prisoners released in 30 states in 2005
rprts05p0510t02.csv	"Table 2. Report title: Recidivism of Prisoners Released in 30 States in 2005: Patterns from 2005 to 2010, �NCJ 244205          
"
	
Appendix Tables	
rprts05p0510at01.csv	Appendix Table 1.  Standard errors for table 1: Most serious commitment offense of prisoners released in 30 states in 2005
rprts05p0510at02.csv	"AppendixTable 2. Standard errors for table 2: Recidivism of prisoners released in 30 states in 2005, by most serious commitment offense and types of post-release arrest charges"
