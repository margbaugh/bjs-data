Jail Inmates in 2022 – Statistical Tables  NCJ 307086	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Jail Inmates in 2022 – Statistical Tables  NCJ 307086.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/jail-inmates-2022-statistical-tables	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to 	
https://bjs.ojp.gov/library/publications/list?series_filter=Prison%20and%20Jail%20Inmates%20at%20Midyear and
https://bjs.ojp.gov/library/publications/list?series_filter=Jail%20Inmates	
	
Filename	Table titles
ji22stt01.csv	Table 1. Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2012–2022
ji22stt02.csv	Table 2. Number of confined inmates in local jails, by demographic characteristics, 2012 and 2017–2022
ji22stt03.csv	Table 3. Percent of confined inmates in local jails, by demographic characteristics, 2012 and 2017–2022
ji22stt04.csv	Table 4. Jail incarceration rates, by demographic characteristics, 2012 and 2017–2022
ji22stt05.csv	Table 5. Number of confined inmates in local jails, by conviction status and offense severity, 2012 and 2017–2022
ji22stt06.csv	Table 6. Percent of confined inmates in local jails, by conviction status and offense severity, 2012 and 2017–2022
ji22stt07.csv	Table 7. Confined inmates in local jails, by probation or parole violation status, midyears 2019–2022
ji22stt08.csv	Table 8. Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, 2012 and 2017–2022
ji22stt09.csv	Table 9. Average daily jail population, by size of jurisdiction, 2022
ji22stt10.csv	Table 10. Midyear population, jail capacity, and percent of capacity occupied in local jails, 2012–2022
ji22stt11.csv	Table 11. Percent of jail capacity occupied at midyear, by size of jurisdiction, 2022
ji22stt12.csv	Table 12. Inmate turnover rate and estimated average time in jail, 2012–2022
ji22stt13.csv	Table 13. Inmate turnover rate and estimated average time in jail, by size of jurisdiction, 2022
ji22stt14.csv	Table 14. Persons under jail supervision, by confinement status, midyears 2012–2022
ji22stt15.csv	Table 15. Number of persons serving weekend-only sentences, 2012–2022
ji22stt16.csv	Table 16. Number of staff employed in local jails, by job function and sex, 2017–2022
ji22stt17.csv	Table 17. Percent of staff employed in local jails, by job function and sex, 2017–2022
	
		Figures
ji22stf01.csv	Figure 1. Estimated average time in jail, by sex, 2015–2022 
	
		Appendix tables
ji22stat01.csv	Appendix Table 1. Standard errors for table 1: Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2012–2022
ji22stat02.csv	Appendix Table 2. Estimates and standard errors for figure 1: Estimated average time in jail, by sex, 2015–2022 
ji22stat03.csv	Appendix Table 3. Standard errors for table 2: Number of confined inmates in local jails, by demographic characteristics, 2012 and 2017–2022
ji22stat04.csv	Appendix Table 4. Standard errors for table 3: Percent of confined inmates in local jails, by demographic characteristics, 2012 and 2017–2022
ji22stat05.csv	Appendix Table 5. Standard errors for table 4: Jail incarceration rates, by demographic characteristics, 2012 and 2017–2022
ji22stat06.csv	Appendix Table 6. Standard errors for table 5: Number of confined inmates in local jails, by conviction status and offense severity, 2012 and 2017–2022
ji22stat07.csv	Appendix Table 7. Standard errors for table 6: Percent of confined inmates in local jails, by conviction status and offense severity, 2012 and 2017–2022
ji22stat08.csv	Appendix Table 8. Standard errors for table 7: Confined inmates in local jails, by probation or parole violation status, midyears 2019–2022
ji22stat09.csv	Appendix Table 9. Standard errors for table 8: Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, 2012 and 2017–2022
ji22stat10.csv	Appendix Table 10. Standard errors for table 9: Average daily jail population, by size of jurisdiction, 2022
ji22stat11.csv	Appendix Table 11. Standard errors for table 10: Midyear population, jail capacity, and percent of capacity occupied in local jails, 2012–2022
ji22stat12.csv	Appendix Table 12. Standard errors for table 11: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2022
ji22stat13.csv	Appendix Table 13. Standard errors for table 12: Inmate turnover rate and estimated average time in jail, 2012–2022
ji22stat14.csv	Appendix Table 14. Standard errors for table 13: Inmate turnover rate and estimated average time in jail, by size of jurisdiction, 2022
ji22stat15.csv	Appendix Table 15. Standard errors for table 14: Persons under jail supervision, by confinement status, midyears 2012–2022
ji22stat16.csv	Appendix Table 16. Standard errors for table 15: Number of persons serving weekend-only sentences, 2012–2022
ji22stat17.csv	Appendix Table 17. Standard errors for table 16: Number of staff employed in local jails, by job function and sex, 2017–2022
ji22stat18.csv	Appendix Table 18. Standard errors for table 17: Percent of staff employed in local jails, by job function and sex, 2017–2022
