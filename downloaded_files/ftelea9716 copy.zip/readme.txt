Full-Time Employees in Law Enforcement Agencies, 1997-2016   NCJ 251762	
This zip archive contains tables in individual  .csv spreadsheets	
from Full-Time Employees in Law Enforcement Agencies, 1997-2016   NCJ 251762.  The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6366	
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://www.bjs.gov/index.cfm?ty=pbse&sid=34	
	
Filename		Table title
ftelea9716t01.csv	Table 1. Officer-to-resident ratio for general-purpose law enforcement agencies, 1997�2016
ftelea9716t02.csv	Table 2. Full-time employees in general-purpose state and local law enforcement agencies, by agency type, 1997�2016
ftelea9716t03.csv	Table 3. LEMAS response rates, by agency type, 2016
	
ftelea9716f01.csv	Figure 1. Full-time sworn officers in general-purpose law enforcement agencies, by agency type, 1997�2016
	
ftelea9716at01.csv	Appendix table 1. Standard errors for table 1: Officer-to-resident ratio for general-purpose law enforcement agencies, 1997�2016
ftelea9716at02.csv	Appendix table 2. Standard errors for table 2: Full-time employees in general-purpose state and local law enforcement agencies, by agency type, 1997�2016
ftelea9716at03.csv	Appendix table 3. Base weights, non-response adjustments, and final weights by strata, by agency type, 2016
