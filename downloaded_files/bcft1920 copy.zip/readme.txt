Background Checks for Firearm Transfers, 2019–2020   NCJ 306971	
	
This zip archive contains tables in individual .csv spreadsheets from 	
Background Checks for Firearm Transfers, 2019–2020   NCJ 306971	
from: https://bjs.ojp.gov/library/publications/background-checks-firearm-transfers-2019-2020	
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Background%20Checks%20for%20Firearm%20Transfers	
	
Filenames		Table titles
bcft1920t01.csv		Table 1. Estimated number of firearm applications and denials since the Brady Act’s effective date, 1994–2020
bcft1920t02.csv		Table 2. Firearm applications and denials, by type of checking agency and type of permit or check, 2019 and 2020
bcft1920t03.csv		Table 3. Firearm applications and denials reported by state agencies, by type of permit or check and jurisdiction, 2019 and 2020
bcft1920t04.csv		Table 4. Firearm applications and denials reported by local agencies, by type of permit or check and size of population served, 2019 and 2020
bcft1920t05.csv		Table 5. Reasons for denial of applications for firearm transfers and permits, by the FBI and state checking agencies, 2019
bcft1920t06.csv		Table 6. Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2020
bcft1920t07.csv		Table 7. Percent change in applications, denials, reasons for denial, and rates of denial, 1999 and 2020
bcft1920t08.csv		Table 8. Bureau of Alcohol, Tobacco, Firearms and Explosives investigation of denials referred by the Federal Bureau of Investigation, 2019 and 2020
bcft1920t09.csv		Table 9. Number of states, by type of check, point of contact status, and reporter of Firearm Inquiry Statistics data, 2019 and 2020
bcft1920t10.csv		Table 10. National Instant Criminal Background Check System Indices records of persons prohibited from receiving or possessing a firearm, yearend 2018–2020
bcft1920t11.csv		Table 11. Number of reporting agencies that participated in the Firearm Inquiry Statistics survey, 2019 and 2020
bcft1920t12.csv		Table 12. Final weights by state and population category for local reporting agencies, 2019 and 2020
	
			Figures
bcft1920f01.csv		Figure 1. Estimated number of applications for firearm transfers and permits since the first full year of the Brady Act’s permanent provisions, 1999–2020
	
			Appendix tables
bcft1920at01.csv	Appendix table 1. Firearm applications and denials by state and local agencies, by jurisdiction and type of permit or check, 2019
bcft1920at02.csv	Appendix table 2. Firearm applications and denials by state and local agencies, by jurisdiction and type of permit or check, 2020
bcft1920at03.csv	Appendix table 3. Standard errors for table 2: Firearm applications and denials, by type of checking agency and type of permit or check, 2019 and 2020
bcft1920at04.csv	Appendix table 4. Standard errors for table 4: Firearm applications and denials reported by local agencies, by type of permit or check and size of population served, 2019 and 2020
bcft1920at05.csv	Appendix table 5. Standard errors for table 6: Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2020
bcft1920at06.csv	Appendix table 6. Agencies that conducted background checks for firearm transfers or permits, by type of application and jurisdiction, December 31, 2020
bcft1920at07.csv	Appendix table 7. Types of background checks and permits for firearm transfers conducted by jurisdictions as of December 31, 2020
bcft1920at08.csv	Appendix table 8. State involvement in the National Instant Criminal Background Check System process, by point of contact status, December 31, 2020
bcft1920at09.csv	Appendix table 9. Reporting of data to the Firearm Inquiry Statistics program, by jurisdiction, 2019 and 2020
