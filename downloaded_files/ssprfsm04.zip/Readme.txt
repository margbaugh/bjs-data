Survey of State Procedures Related to Firearm Sales, Midyear 2004       NCJ 209288 				

This zip archive contains tables in individual  .csv spreadsheets				
from Survey of State Procedures Related to Firearm Sales, Midyear 2004,  NCJ 209288. 
The full report including text and graphics in pdf format are available from:				
http://www.ojp.usdoj.gov/bjs/abstract/ssprfsm04.htm				

This report is one in a series.  More recent editions				
may be available.  To view a list of all in the series go to				
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#ssprfs				


			Tables	
ssprfsm0401.csv			Table 1: Applications for firearm transfers and permits processed by States, 2003 
ssprfsm0401a.csv		Table 1a: Applications for firearm permits processed by local agencies, grouped by population level of community served, 2003 	
ssprfsm0402.csv			Table 2: Prohibited persons: statutory basis for denial of firearm sale or possession, June 30, 2004 	
ssprfsm0403.csv			Table 3: Minors: restrictions based on age or juvenile offender status, June 30, 2004 	
ssprfsm0404.csv			Table 4: Regulation of dealer, private, and gun show sales, June 30, 2004 	
ssprfsm0405.csv			Table 5: Background check and permit procedures, June 30, 2004 	
ssprfsm0406.csv			Table 6: Fees, record retention, and appeals, June 30, 2004 	
ssprfsm0407.csv			Table 7: Prohibited and restricted firearms, June 30, 2004 	
ssprfsm0408.csv			Table 8: National Instant Criminal Background Check System (NICS): Checking agencies, June 30, 2004 	
ssprfsm0409.csv			Table 9: Notification procedures of State agencies regarding denied persons subject to arrest, June 30, 2004 	
ssprfsm0410.csv			Table 10: Data accessed for firearm background checks: domestic violence, June 30, 2004 	
ssprfsm0411.csv			Table 11: Data accessed for firearm background checks: other prohibitions, June 30, 2004 	
ssprfsm0412.csv			Table 12: Revisions of sales regulations and other significant changes in State firearm laws, July 1, 2003 to June 30, 2004 	


			Appendix tables		
ssprfsm04apa1.csv			Appendix tables A1: Federal and State firearm laws, June 30, 2004 
ssprfsm04apa2.csv			Appendix tables A2: Federal and State firearm laws, June 30, 2004 
ssprfsm04apa3.csv			Appendix tables A3: Federal and State firearm laws, June 30, 2004
ssprfsm04apb.csv			Appendix tables  B: Agencies conducting firearm background checks, June 30, 2004 
ssprfsm04apc.csv			Appendix tables  C: State agency Internet sites: firearm information pages and checking agency home pages
