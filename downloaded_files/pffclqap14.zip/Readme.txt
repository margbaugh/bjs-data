Publicly Funded Forensic Crime Laboratories: Quality Assurance Practices, 2014      NCJ 250152	
	
This zip archive contains tables in individual  .csv spreadsheets		
from Publicly Funded Forensic Crime Laboratories: Quality Assurance Practices, 2014  - Statistical Tables, 
NCJ 250152 The full report including text and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5828		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.bjs.gov/index.cfm?ty=pbse&sid=75	

	
Filename	        Table title
pffclqap14t01.csv      Table 1:  Percent of publicly funded forensic crime labs with a professional forensic science accreditation, by type of jurisdiction, staff size, and number of forensic functions performed, 2014
pffclqap14t02.csv      Table 2:  Percent of publicly funded forensic crime labs that conducted proficiency testing, by type of test, jurisdiction, staff size, and number of forensic functions performed, 2014
pffclqap14t03.csv      Table 3:  Percent of publicly funded forensic crime labs with written code of ethics, by type of jurisdiction, 2014
pffclqap14t04.csv      Table 4:  Percent of publicly funded crime labs with one or more externally certified analysts, by staff size, number of forensic functions performed, and accreditation status, 2014
pffclqap14t05.csv      Table 5:  Percent of publicly funded forensic crime labs with resources dedicated to research, by type of jurisdiction and staff size, 2002, 2009, and 2014
pffclqap14t06.csv      Table 6:  Publicly funded forensic crime laboratories, by type of jurisdiction, 2014


Figure Tables
pffclqap14f01.csv	Figure  1:  Percent of publicly funded forensic crime labs accredited by a professional forensic science organization, by type of jurisdiction, 2002, 2005, 2009, and 2014
pffclqap14f02.csv	Figure  2: Percent of publicly funded forensic crime labs that conducted proficiency testing, by type of test, 2002, 2009, and 2014
pffclqap14f03.csv	Figure  3: Percent of publicly funded forensic crime labs with written standards for performance expectations, by type of jurisdiction, 2009 and 2014
pffclqap14f04.csv	Figure  4: Percent of publicly funded forensic crime labs with one or more externally certified analysts, 2009 and 2014

	
Appendix tables	
pffclqap14at01.csv	Appendix table 1: Estimates and standard errors for figure 1: Percent of publicly funded forensic crime labs accredited by a professional forensic science organization, by type of jurisdiction, 2002, 2005, 2009, and 2014
pffclqap14at02.csv	Appendix table 2: Standard errors for table 1: Percent of publicly funded forensic crime labs with a professional forensic science accreditation, by type of jurisdiction, staff size, and number of forensic functions performed, 2014
pffclqap14at03.csv	Appendix table 3: Estimates and standard errors for figure 2: Percent of publicly funded forensic crime labs that conducted proficiency testing, by type of test, 2002, 2009, and 2014
pffclqap14at04.csv	Appendix table 4: Standard errors for table 2: Percent of publicly funded forensic crime labs that conducted proficiency testing, by type of test, jurisdiction, staff size, and number of forensic functions performed, 2014
pffclqap14at05.csv	Appendix table 5: Estimates and standard errors for figure 3: Percent of publicly funded forensic crime labs with written standards for performance expectations, by type of jurisdiction, 2009 and 2014
pffclqap14at06.csv	Appendix table 6: Standard errors for table 3: Percent of publicly funded ff jurisdiction, 2014
pffclqap14at07.csv	Appendix table 7: Estimates and standard errors for figure 4: Percent of publicly funded forensic crime labs with one or more externally certified analysts, 2009 and 2014
pffclqap14at08.csv	Appendix table 8: Standard errors for table 4: Percent of publicly funded crime labs with one or more externally certified analysts, by staff size number of forensic functions performed, and accreditation status, 2014
pffclqap14at09.csv	Appendix table 9: Standard errors for table 5: Percent of publicly funded forensic crime labs with resources dedicated to research, by type of jurisdiction and staff size, 2002, 2009, and 2014

