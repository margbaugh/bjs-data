Jails in Indian Country, 2023   NCJ 309265		
		
This zip archive contains tables in individual .csv spreadsheets		
from Jails in Indian Country, 2023   NCJ 309265.		
The full report including text and graphics in pdf format is available from: 		
https://bjs.ojp.gov/library/publications/jails-indian-country-2023
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=Jails%20in%20Indian%20Country		
		
Filenames		Table titles
jic23t01.csv	Table 1. Persons held, rated capacity, and percent of rated capacity occupied in Indian country jails in June, 2013–2023
jic23t02.csv	Table 2. Indian country jails and persons held, by facility size, midyear 2023
jic23t03.csv	Table 3. Average daily population, admissions, and average length of stay in Indian country jails, by facility size, June 2023
jic23t04.csv	Table 4. Capacity of Indian country jails, by facility size, midyear 2023
jic23t05.csv	Table 5. Percent of rated capacity occupied and number of Indian country jails, by population measures, June 2023
jic23t06.csv	Table 6. Number of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2013–2023
jic23t07.csv	Table 7. Percent of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2013–2023
jic23t08.csv	Table 8. Number of persons employed in Indian country jails, by job function, midyears 2013–2023
jic23t09.csv	Table 9. Percent of persons employed in Indian country jails, by job function, midyears 2013–2023
jic23t10.csv	Table 10. Survey universe and response rates of Indian country jails, 2013–2023
	
			Figures
jic23f01.csv	Figure 1. Number of persons held in Indian country jails, midyear 2013–2023
jic23f02.csv	Figure 2. Number of inmates held in Indian country jails on the last weekday of each month, June 2022–June 2023
jic23f03.csv	Figure 3. Number of admissions and average length of stay in Indian country jails, June 2013–2023
	
			Appendix tables
jic23at01.csv	Appendix table 1. Estimates for figure 2: Number of inmates held in Indian country jails on the last weekday of each month, June 2022–June 2023
jic23at02.csv	Appendix table 2. Estimates for figure 3: Number of admissions and average length of stay in Indian country jails, June 2013–2023
jic23at03.csv	Appendix table 3. Imputation for table 6: Number of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2013–2023
jic23at04.csv	Appendix table 4. Imputation for table 8: Number of persons employed in Indian country jails, by job function, midyears 2013–2023
