Sexual Victimization Reported by Adult Correctional Authorities, 2012-15 NCJ 251146
	
This zip archive contains tables in individual .csv spreadsheets	
from Sexual Victimization Reported by Adult Correctional Authorities, 2012-15 NCJ 251146	
The full report including text and graphics in pdf format is available from 	
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6326

This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=64		
	
	
Filename		Table title
svraca1215t01.csv	Table 1. National estimates of allegations of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215t02.csv	Table 2. Rates per 1,000 inmates of allegations of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215t03.csv	Table 3. National estimates of outcomes of investigations into allegations of sexual victimization, by type of facility, 2012�15
svraca1215t04.csv	Table 4. Outcomes of completed investigations of sexual victimization, by type of facility, 2012�15
svraca1215t05.csv	Table 5. National estimates of substantiated incidents of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215t06.csv	Table 6. Rates per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215t07.csv	Table 7. National estimates of substantiated incidents of sexual victimization, by type of victimization, 2005 and 2010�15
svraca1215t08.csv	Table 8. National estimates of allegations, substantiated incidents, and rates per 1,000 of inmate-on-inmate sexual harassment, by type of facility, 2013�15
svraca1215t09.csv	Table 9. National estimates of outcomes of investigations into allegations of inmate-on-inmate sexual harassment, by type of facility, 2013�15
	
Filename		Figure title
svraca1215f01.csv	Figure 1. National estimates of allegations and substantiated incidents of sexual victimization in adult correctional facilities, 2005�15
svraca1215f02.csv	Figure 2. National estimates of outcomes of alleged sexual victimization in adult correctional facilities, 2010�15
svraca1215f03.csv	Figure 3. National estimates of allegations of sexual victimization in adult correctional facilities, by type of victimization, 2010�15
	
Filename		Appendix table title
svraca1215at01.csv	Appendix table 1. Estimates and standard errors for figure 1: National estimates of allegations and substantiated incidents of sexual victimization in adult correctional facilities, 2005�15
svraca1215at02.csv	Appendix table 2. Estimates and standard errors for figure 2: National estimates of outcomes of alleged sexual victimization in adult correctional facilities, 2010�15
svraca1215at03.csv	Appendix table 3. Standard errors for table 1: National estimates of allegations of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215at04.csv	Appendix table 4. Standard errors for table 2: Rates per 1,000 inmates of allegations of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215at05.csv	Appendix table 5. Estimates and standard errors for figure 3: National estimates of allegations of sexual victimization in adult correctional facilities, by type of victimization, 2010�15
svraca1215at06.csv	Appendix table 6. Standard errors for table 3: National estimates of outcomes of investigations into allegations of sexual victimization, by type of facility, 2012�15
svraca1215at07.csv	Appendix table 7. Standard errors for table 4: Outcomes of completed investigations of sexual victimization, by type of facility, 2012�2015
svraca1215at08.csv	Appendix table 8. Standard errors for table 5: National estimates of substantiated incidents of sexual victimization, by type of facility, 2005 and 2010�15
svraca1215at09.csv	Appendix table 9. Standard errors for table 6: Rates per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2005 and 2010�15
 svraca1215at10.csv	Appendix table 10. Standard errors for table 7: National estimates of substantiated incidents of sexual victimization, by type of victimization, 2005 and 2010�15
svraca1215at11.csv	Appendix table 11. Standard errors for table 8: National estimates of allegations, substantiated incidents, and rates per 1,000 of inmate-on-inmate sexual harassment, by type of facility, 2013�15
svraca1215at12.csv	Appendix table 12. Standard errors for table 9: National estimates of outcomes of investigations into allegations of inmate-on-inmate sexual harassment, by type of facility, 2013�15
