2004 National Corrections Reporting Program

This is one of a series of files from the National Corrections Reporting Program.  
All of the available files back to 1993 may be obtained from
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=36. 

Three groups of tables -- sentence length, time served and most serious offense of state
prisoners-- are archived for each year.
  
In addition to the list of tables in this file, the tables in the related archives are listed below.*

This Zip archive, Time served in State prison, 2004, NCJ 229325
contains the following tables:

   File name      Contents

ncrp0408.csv        State prison releases: time served in prison, by offense and release type
ncrp0409.csv        First releases from State prison: sentence length, time served, and percent of
sentence served, by offense
ncrp0410.csv        First releases from State prison: sentence length and time served in prison, by
offense and sex
ncrp0411.csv        First releases from State prison: sentence length and time served in prison, by
offense and race
ncrp0415.csv        Successful first State parole discharges: sentence length and time served, by
offense
ncrp0416.csv        Unsuccessful first State parole discharges: sentence length and time served, by
offense

*Note:  Beginning in 1999, Table 7 (New court commitments to State prison:  
sentence length and minimum time to be served, by offense) 
was discontinued.  
               
Two related archives are also available.  The tables in these
archives are listed below.

Most serious offense of State prisoners (NCJ 229326)

ncrp0401.csv        State prison admissions: offense, by admission type
ncrp0402.csv        New court commitments to State prisons: offense, by age at admission
ncrp0403.csv        Parole violators returned to State prison: offense, by age at admission
ncrp0404.csv        New court commitments to State prisons: offense, by sex, race, and
Hispanic origin
ncrp0405.csv        Parole violators returned to State prison: offense, by sex, race, and
Hispanic origin
ncrp0412.csv        First entries to parole supervision from State prison: method of prison release,
by offense
ncrp0413.csv        First entries to parole supervision from State prison: offense, by sex, race,
and  Hispanic origin
ncrp0414.csv        State parole discharges: method of parole discharge, by offense 
                               
Sentence length of State prisoners (NCJ 229327)

ncrp0406.csv   State prison admissions: sentence length by offense and admission type 
ncrp0409.csv   First releases from State prison: sentence length, time served, and percent of
sentence served in prison, by
offense
ncrp0410.csv   First releases from State prison: sentence length and time served in prison, by
offense, and sex
ncrp0411.csv   First releases from State prison: sentence length and time served in prison, by
offense, and race 
ncrp0415.csv   Successful first State parole discharges: sentence length and time served, by
offense
ncrp0416.csv   Unsuccessful first State parole discharges: sentence length and time served, by
offense
