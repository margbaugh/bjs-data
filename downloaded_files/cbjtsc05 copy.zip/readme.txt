Civil Bench and Jury Trials in State Courts, 2005

This zip archive contains tables in individual .csv spreadsheets               		
from Civil Bench and Jury Trials in State Courts, 2005, NCJ 223851.		
The full report including text and graphics in pdf format is available 
at: http://www.ojp.usdoj.gov/bjs/abstract/cbjtsc05.htm.          		

This report is an expansion of a series. See also Civil Trial Cases and 
Verdicts in Large Counties, 2001 at:  
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#civil.

Filename		Figure title
cbjtsc05f01.csv		Figure 1. Median compensatory and punitive final awards for plaintiff winners in select trial cases

Filename		Table title
cbjtsc05t01.csv		Table 1. Civil trials in state courts, by case type, 2005
cbjtsc05t02.csv		Table 2. Bench and jury trials in state courts, by selected characteristics, 2005
cbjtsc05t03.csv		Table 3. Primary litigants in civil trials in state courts, by case type, 2005
cbjtsc05t04.csv		Table 4. Civil trials in state courts, by litigant pairings, 2005
cbjtsc05t05.csv		Table 5. Percent of plaintiff winners in civil trials in state courts, by case type, 2005
cbjtsc05t06.csv		Table 6. Plaintiff award winners in civil trials in state courts, by case type, 2005
cbjtsc05t07.csv		Table 7. Plaintiff winners who sought and were awarded punitive damages in civil trials, by selected case types, 2005
cbjtsc05t08.csv		Table 8. Award amounts for plaintiffs who were awarded punitive damages in civil trials in state courts, by case type, 2005
cbjtsc05t09.csv		Table 9. Case processing time and days in trial, by case and trial type, 2005
cbjtsc05t10.csv		Table 10. Civil trials in state courts in the nation's 75 most populous counties, by selected case types, 1992, 1996, 2001, and 2005
cbjtsc05t11.csv		Table 11. Jury trial awards in state courts in the nation's 75 most populous counties, by selected case types, 1992, 1996, 2001 and 2005

Filename		Text table title
cbjtsc05tt01.csv	Text table 1. Civil trials as a percent of total civil cases disposed in state courts in 79 surveyed jurisdictions 2005

Filename		Appendix table title
cbjtsc05at01.csv	Appendix table 1. Standard errors and confidence intervals for civil trials, by selected characteristics, 2005 Civil Justice Survey of State Courts
cbjtsc05at02.csv	Appendix table 2. Standard errors and confidence intervals for civil trials, by case type, 2005 Civil Justice Survey of State Courts
cbjtsc05at03.csv	Appendix table 3. Total number of trials and trials by general civil case type, by sampled counties, 2005 
cbjtsc05at04.csv	Appendix table 4. Median final damage awards for plaintiff winners in jury and bench trials, by sampled counties 2005
