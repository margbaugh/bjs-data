Felony Sentences in State Courts, 2006 - Statistical Tables  NCJ 226846


			
Filename			Table title
fssc06stt11			Table 1.1. Estimated number of felony convictions in state courts, 2006
fssc06stt12			Table 1.2. Types of felony sentences imposed in state courts, by offense, 2006
fssc06stt1.2.1			Table 1.2.1. Estimated number of felony convictions in state courts, by offense and type of sentence, 2006
fssc06stt13			Table 1.3. Mean and median felony sentence lengths in state courts, by offense and type of sentence, 2006
fssc06stt14			Table 1.4. Estimated percent of felons sentenced to life in state prison, by offense, 2006
fssc06stt15			Table 1.5. Felons sentenced to an additional penalty in state courts, by offense, 2006
fssc06stt16			Table 1.6. Comparison of felony convictions in state and federal courts, 2006
fssc06stt21			Table 2.1. Estimated percent of felons sentenced in state courts for a completed or attempted offense, 2006
fssc06stt22			Table 2.2. Number of felony convictions for persons sentenced in state courts, by most serious offense, 2006
fssc06stt23			Table 2.3. Convicted felons sentenced to prison in state courts, by number of convictions, 2006
fssc06stt24			Table 2.4. Mean length of felony sentences imposed in state courts, by number of convictions and offense, 2006
fssc06stt31			Table 3.1. Age of persons convicted of felonies in state courts, by offense, 2006
fssc06stt32			Table 3.2. Gender and race of persons convicted of felonies in state courts, by offense, 2006
fssc06stt33			Table 3.3. Types of felony sentences imposed in state courts, by offense and gender of felons, 2006
fssc06stt34			Table 3.4. Types of felony sentences imposed in state courts, by offense and race of felons, 2006
fssc06stt35			Table 3.5. Mean length of felony sentences imposed in state courts, by offense and gender of felons, 2006
fssc06stt36			Table 3.6. Mean length of felony sentences imposed in state courts, by offense and race of felons, 2006
fssc06stt37			Table 3.7. Mean length of felony sentences imposed in state courts, by offense and combined categories of race and gender, 2006
fssc06stt41			Table 4.1. Types of felony convictions in state courts, by offense, 2006
fssc06stt42			Table 4.2. Types of felony sentences imposed in state courts, by offense and type of conviction, 2006
fssc06stt43			Table 4.3. Mean length of felony sentences imposed in state courts, by offense and type of conviction, 2006
fssc06stt44			Table 4.4. Types of sentences imposed on felons convicted of murder or nonnegligent manslaughter, by type of conviction, 2006
fssc06stt45			Table 4.5. Time between arrest and sentencing for persons convicted of a felony in state courts, by offense, 2006


Text table
fssc06sttt01			Text table 1

Appendix table
fsscst06at			Appendix table.  NJRP sampling design

Standard error tables
fsscstt11a			Table 1.1a Standard errors for Table 1.1, Estimated number of felony convictions in state courts, 2006
fsscstt12a			Table 1.2a. Standard errors for Table 1.2, Types of felony sentences imposed in state courts, 2006
fsscstt13a			Table 1.3a Standard errors for Table 1.3, Mean and median felony sentence lengths in state courts, by offense and type of sentence, 2006
fsscstt23a			Table 2.3a. Case totals and standard errors for Table 2.3, Convicted felons sentenced to prison in state courts, by number of convictions, 2006
fsscstt24a			Table 2.4a. Case totals and standard errors for Table 2.4, Mean length of felony sentences imposed in state courts, by number of convictions and offense, 2006
fsscstt31a			Table 3.1a. Standard errors for Table 3.1, Age of persons convicted of felonies in state courts, by offense, 2006
fsscstt32a			Table 3.2a. Standard errors for Table 3.2, Gender and race of persons convicted of felonies in state courts, 2006
fsscstt33a			Table 3.3a. Case totals and standard errors for Table 3.3, Types of felony sentences imposed in state courts, by offense and gender of felons, 2006
fsscstt34a			Table 3.4a. Case totals and standard errors for Table 3.4, Types of felony sentences imposed in state courts, by offense and race of felons, 2006 
fsscstt42a			Table 4.2a. Case totals and standard errors for Table 4.2, Types of felony sentences imposed in state courts, by offense and type of conviction, 2006 
fsscstt43a			Table 4.3a. Standard errors for Table 4.3, Mean length of felony sentences imposed in state courts, by offense and type of conviction, 2006










