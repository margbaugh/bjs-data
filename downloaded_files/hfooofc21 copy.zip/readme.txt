Heroin, Fentanyl, and Other Opioid Offenses in Federal Courts, 2021   NCJ 307497																						
																						
This zip archive contains tables in individual .csv spreadsheets																						
from Heroin, Fentanyl, and Other Opioid Offenses in Federal Courts, 2021   NCJ 307497.																						
The full report including text and graphics in .pdf format is available at																						
https://bjs.ojp.gov/library/publications/heroin-fentanyl-and-other-opioid-offenses-federal-courts-2021

Filenames		Table titles																					
hfooofc21t01.csv	Table 1. Federal and state arrests by the Drug Enforcement Administration by drug type, FY 2001–2021																					
hfooofc21t02.csv	Table 2. Persons arrested by the Drug Enforcement Administration for heroin, fentanyl, oxycodone, and other opioids, by age and sex, FY 2021																					
hfooofc21t03.csv	Table 3. Demographic characteristics of persons sentenced for a drug offense involving heroin, fentanyl, and other opioids, by opioid type, FY 2021																					
hfooofc21t04.csv	Table 4. Sentencing characteristics of persons sentenced for an opioid offense, by opioid type, FY 2021																					
hfooofc21t05.csv	Table 5. Sentencing outcomes of persons sentenced for an opioid offense, by opioid type, FY 2021																					
hfooofc21t06.csv	Table 6. Persons sentenced in federal district court for heroin, fentanyl, and other opioids, by primary guideline, FY 2021

			Figures																					
hfooofc21f01.csv	Figure 1. Federal and state arrests by the Drug Enforcement Administration involving heroin, fentanyl, and other opioids, FY 2001–2021																					
hfooofc21f02.csv	Figure 2. Federal and state arrests by the Drug Enforcement Administration involving fentanyl and other pharmaceutical opioids, FY 2001–2021																					
hfooofc21f03.csv	Figure 3. Number of drug overdose deaths involving opioids, by type of opioid, 2001–2021																					
hfooofc21f04.csv	Figure 4. Number of persons sentenced for a drug offense involving heroin, fentanyl, or other opioids as primary drug, FY 2001–2021																					
hfooofc21f05.csv	Figure 5. Number of persons sentenced for a drug offense involving fentanyl and other pharmaceutical opioids, by drug type, FY 2001–2021	

			Appendix tables																					
hfooofc21at01.csv	Appendix table 1. Counts for figure 1: Federal and state arrests by the Drug Enforcement Administration involving heroin, fentanyl, and other opioids, FY 2001–2021																					
hfooofc21at02.csv	Appendix table 2. Counts for figure 2: Federal and state arrests by the Drug Enforcement Administration involving fentanyl and other pharmaceutical opioids, FY 2001–2021																					
hfooofc21at03.csv	Appendix table 3. Counts for figure 3: Number of drug overdose deaths involving opioids, by type of opioid, 2001–2021																					
hfooofc21at04.csv	Appendix table 4. Counts for figure 4: Number of persons sentenced for a drug offense involving heroin, fentanyl, or other opioids as primary drug, FY 2001–2021																					
hfooofc21at05.csv	Appendix table 5. Counts for figure 5: Number of persons sentenced for a drug offense involving fentanyl and other pharmaceutical opioids, by drug type, FY 2001–2021																					
hfooofc21at06.csv	Appendix table 6. Counts for map 3: Rates of sentences imposed for heroin, fentanyl, and other opioids per 100 drug sentences by state, FY 2021																					
hfooofc21at07.csv	Appendix table 7. Counts for map 4: Rates of sentences imposed for fentanyl per 100 drug sentences by state, FY 2021