Correctional Populations in the United States, 2021 – Statistical Tables   NCJ 305542	
	
This zip archive contains tables in individual .csv spreadsheets	
from Correctional Populations in the United States, 2021 – Statistical Tables   NCJ 305542.	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/correctional-populations-united-states-2021-statistical-tables	
	
These statistical tables are in a series.  More recent editions	
may be available.  To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Correctional%20Populations%20in%20the%20United%20States	
	
Filenames		Table titles
cpus21stt01.csv		Table 1. Number of persons supervised by adult correctional systems in the United States, by correctional status, December 31, 2011–2021
cpus21stt02.csv		Table 2. Change in the number of persons supervised by adult correctional systems in the United States, December 31, 2011–21
cpus21stt03.csv		Table 3. Composition of the adult correctional system in the United States, by correctional status, December 31, 2011 and 2011
cpus21stt04.csv		Table 4. Rate of persons supervised by adult correctional systems in the United States, by correctional status, December 31, 2011–2021
cpus21stt05.csv		Table 5. Number of persons supervised by adult correctional systems in the United States, by correctional status and sex, December 31, 2011–2021
cpus21stt06.csv		Table 6. Rate of persons supervised by adult correctional systems in the United States, by correctional status and sex, December 31, 2011–2021
cpus21stt07.csv		Table 7. Number of persons supervised by adult correctional systems in the United States, by correctional status and race or Hispanic origin, December 31, 2011–2021
cpus21stt08.csv		Table 8. Rate of persons supervised by adult correctional systems in the United States, by correctional status and race or Hispanic origin, December 31, 2011–2021
cpus21stt09.csv		Table 9. Custody counts of adults in state or federal prison or local jail in the United States, by type of facility, December 31, 2011, 2020, and 2021
cpus21stt10.csv		Table 10. Number of persons incarcerated by other adult correctional systems, 2011, 2020, and 2021
cpus21stt11.csv		Table 11. Number of persons with dual correctional statuses at yearend, by sex and race or Hispanic origin, December 31, 2011–2021
	
			Figures
cpus21stf01.csv		Figure 1. Persons under the supervision of adult correctional systems per 100,000 adult U.S. residents, December 31, 2001–2021
	
			Appendix tables
cpus21stat01.csv	Appendix table 1. Rates for figure 1: Persons under the supervision of adult correctional systems per 100,000 adult U.S. residents, December 31, 2001–2021
cpus21stat02.csv	Appendix table 2. Standard errors for local jail inmates at midyear, total incarcerated population, and total correctional population, by sex and race or Hispanic origin, 2011–2021
cpus21stat03.csv	Appendix table 3. Standard errors for rates of local jail inmates at midyear, total incarceration population, and total correctional population, by sex, race or Hispanic origin, 2011–2021
