Jails in Indian Country, 2015      NCJ 250117	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Jails in Indian Country, 2015, NCJ 250117.  The full report including text	
and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=5824
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
http://bjs.gov/index.cfm?ty=pbse&sid=32
	
Filename	Table title
jic15t01.csv	Table 1. Number of inmates, rated capacity, and percent of capacity occupied in Indian country jails, June 2000, 2004, and 2007-15
jic15t02.csv	Table 2. Indian country jails and percent of inmate population, by facility size, midyear 2015
jic15t03.csv	Table 3. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2015
jic15t04.csv	Table 4. Admissions and expected length of stay in Indian country jails, by facility size, June 2015
jic15t05.csv	Table 5. Admissions and expected length of stay in 66 Indian country jails, by facility size, June 2014 and 2015
jic15t06.csv	Table 6. Persons employed in Indian country jails, by job function, midyear 2010 and 2013-15
jic15t07.csv	Table 7. Indian country jail survey universe and response rates, 2004 and 2007-2015
jic15t08.csv	Table 8. Estimation of inmate characteristics in table 5
jic15t09.csv	Table 9. Estimation of facility staff in table 6

Figure Tables
jic15f01.csv	Figure 1. Inmates confined in Indian country jails, midyear 2000�2004 and 2007�2015
jic15f02.csv	Figure 2. Percent of rated capacity occupied, by facility size, June 2015
	
Appendix tables	
jica1501.csv	Appendix table 1. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, by facility, June 2015
jic15at02.csv	Appendix table 2. Inmates in Indian country jails, by type of offense, midyear 2015
jic15at03.csv	Appendix table 3. Inmates in Indian country jails, by conviction status, midyear 2015
jic15at04.csv	Appendix table 4. Adults and juveniles in the custody of Indian country jails, by sex, midyear 2015
jic15at05.csv	Appendix table 5. Reported inmate characteristics for table 6: Inmates confined in Indian country jails, by demographic characteristics, conviction status, and offense, midyear 2000 and 2010-15
jic15at06.csv	Appendix table 6: Reported number of staff for table 7: Persons employed in Indian country jails, by job function, midyear 2010 and 2013�15
