"Intimate Partner Violence, 1993�2010     NCJ  239203"			
			
This zip archive contains tables in individual  .csv spreadsheets			
from "Intimate Partner Violence, 1993�2010 NCJ  239203". The full report including text			
and graphics in pdf format is available from: http://www.bjs.ojp.usdoj.gov/...			
			
			
			
Filename			Table title
ipv9310t01.csv			"Table 1.  Intimate partner violence, by demographic characteristic, 1993�2010"

			
Figures			
ipv9310f01.csv			"Figure 1. Total violent crime and intimate partner violence, 1993�2010"
ipv9310f02.csv			"Figure 2. Intimate partner violence, by sex, 1993�2010"
ipv9310f03.csv			"Figure 3. Intimate partner violence against females, by age group, 1993-2010"
ipv9310f04.csv			"Figure 4. Intimate partner violence against females, by whether victim was previously victimized by the same offender, 2005�2010"
ipv9310f05.csv			"Figure 5. Intimate partner violence against females, by race and Hispanic origin, 1993�2010"
ipv9310f06.csv			"Figure 6. Intimate partner violence against females, by marital status, 1993-2010"
ipv9310f07.csv			"Figure 7. Intimate partner violence against females, by household composition, 1993�2010"
			
Appendix tables			
ipv9310at01.csv			"Appendix Table 1. Total violent crime and intimate partner violence, by sex, 1993�2010"
ipv9310at02.csv			"Appendix Table 2. Standard errors for appendix table 1: Total violent crime and intimate partner violence, by sex, 1993�2010"
ipv9310at03.csv			"Appendix Table 3. Intimate partner violence against females, by age, 1993�2010"
ipv9310at04.csv			"Appendix Table 4. Standard errors for appendix table 3: Intimate partner violence against females, by age, 1993�2010"
ipv9310at05.csv			"Appendix Table 5. Intimate partner violence against females, by whether victim was previously victimized by the same offender, 2005�2010"
ipv9310at06.csv			"Appendix Table 6. Standard errors for appendix table 5: Intimate partner violence against females, by whether victim was previously victimized by the same offender, 2005�2010"
ipv9310at07.csv			"Appendix Table 7. Intimate partner violence against females, by race and ethnicity, 1993�2010"
ipv9310at08.csv			"Appendix Table 8. Standard errors for appendix table 7: Intimate partner violence against females, by race and ethnicity, 1993�2010"
ipv9310at09.csv			"Appendix Table 9. Intimate partner violence against females, by marital status, 1993�2010"
ipv9310at10.csv			"Appendix Table 10.Standard errors for appendix table 9: Intimate partner violence against females, by marital status, 1993�2010"
ipv9310at11.csv			"Appendix Table 11.Intimate partner violence against females, by household composition, 1993�2010"		
ipv9310at12.csv			"Appendix Table 12.Standard errors for appendix table 11: Intimate partner violence against females, by household composition, 1993�2010 "