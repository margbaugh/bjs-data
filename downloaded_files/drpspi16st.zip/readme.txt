Disabilities Reported by Prisoners: Survey of Prison Inmates, 2016  NCJ 252642		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Disabilities Reported by Prisoners: Survey of Prison Inmates, 2016  NCJ 252642		
The full report including text and graphics in pdf format is available from:		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7306		
		
		
Filenames		Table titles
drpspi16stt01.csv	Table 1. Prevalence of disabilities among all state and federal prisoners, 2016
drpspi16stt02.csv	Table 2. Disabilities among state prisoners, by demographic characteristics, 2016
drpspi16stt03.csv	Table 3. Disabilities among federal prisoners, by demographic characteristics, 2016
drpspi16stt04.csv	Table 4. Disabilities among all state and federal prisoners and the U.S. general population age 18 or older, by age, 2016
drpspi16stt05.csv	Table 5. State and federal prisoners who were ever told they had an attention deficit disorder, ever attended special education classes, or were ever told they had a learning disability, 2016
drpspi16stt06.csv	Table 6. Prevalence of disabilities among all state and federal prisoners, by selected disabilities, 2011-2012 and 2016
		
			Figure titles
drpspi16stf01.csv	Figure 1. Prevalence of disabilities among all state and federal prisoners, 2016
		
			Appendix tables
drpspi16stat01.csv	Appendix table 1. Estimated number of state and federal prisoners, by demographic characteristics, 2016
drpspi16stat02.csv	Appendix Table 2. Standard errors for table 2: Disabilities among state prisoners, by demographic characteristics, 2016
drpspi16stat03.csv	Appendix Table 3. Standard errors for table 3: Disabilities among federal prisoners, by demographic characteristics, 2016
