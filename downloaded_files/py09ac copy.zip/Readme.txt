Prisoners at Yearend2009-Advance Counts, NCJ 230189

This zip archive contains tables in individual .csv spreadsheets
from Prisoners at Yearend 2009-Advance Counts, NCJ 230189.  	
The full report including text and graphics in .pdf format is 
available from:	 http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2272.	  

    Tables
py09act01.csv	Table 1. Changes in the number of prisoners in selected jurisdictions, December 31, 2008 to December 31, 2009

py09act02.csv	Table 2. Change in the U.S. prison population, 2000-2009

Appendix tables
py09acat01.	Appendix table 1. Prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000 and 2008, with advanced counts for 2009


Figures
py09acf01.csv	Figure 1. Prisoners under state and federal jurisdiction at yearend 2000-2008, with advance counts for 2009

py09acf02.csv	Figure 2. Six-month change in the number of prisoners under state and federal jurisdiction, December 1999-2009
