The Nation's Two Crime Measures, 2011-2020   NCJ 303385			
			
This zip archive contains tables in individual  .csv spreadsheets			
from The Nation's Two Crime Measures, 2011-2020   NCJ 303385  The full report including text			
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/nations-two-crime-measures-2011-2020
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
https://bjs.ojp.gov/library/publications/list?series_filter=Nation%E2%80%99s%20Two%20Crime%20Measures
			
Filenames		Figure names		
ntcm1120f01.csv		Figure 1. Rate of violent crime in the NCVS and UCR SRS, 2011–2020		
ntcm1120f02.csv		Figure 2. Rate of property crime in the NCVS and UCR SRS, 2011–2020		
			
			Appendix tables		
ntcm1120at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Rate of violent crime in the NCVS and UCR SRS, 2011–2020		
ntcm1120at02.csv	Appendix table 2. Estimates and standard errors for figure 2: Rate of property crime in the NCVS and UCR SRS, 2011–2020		
ntcm1120at03.csv	Appendix table 3. Rates and standard errors of rape or sexual assault in the NCVS and UCR SRS, 2011–2020		
ntcm1120at04.csv	Appendix table 4. Rates and standard errors of robbery in the NCVS and UCR SRS, 2011–2020		
ntcm1120at05.csv	Appendix table 5. Rates and standard errors of aggravated assault in the NCVS and UCR SRS, 2011–2020		
ntcm1120at06.csv	Appendix table 6. Rates and standard errors of simple assault in the NCVS, 2011–2020		
ntcm1120at07.csv	Appendix table 7. Rates and standard errors of burglary in the NCVS and UCR SRS, 2011–2020		
ntcm1120at08.csv	Appendix table 8. Rates and standard errors of motor vehicle theft in the NCVS and UCR SRS, 2011–2020		
ntcm1120at09.csv	Appendix table 9. Rates and standard errors of other household theft in the NCVS, 2011–2020 		
			
