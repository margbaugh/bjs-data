Indicators of Mental Health Problems Reported by Prisoners and Jail Inmates, 2011-12 Special report NCJ 250612

This zip archive contains tables in individual .csv spreadsheets		
from Indicators of Mental Health Problems Reported by Prisoners and Jail Inmates, 2011-12 Special report NCJ 250612.
The full report including text and graphics in .pdf format is available at		
https://www.bjs.gov//index.cfm?ty=pbdetail&iid=5946
		

Tables

File name		Table number
imhprpji1112t01.csv	Table 01. Prevalence of mental health indicators among prisoners and jail inmates, by type of indicator, 2011�2012
imhprpji1112t02.csv	Table 02. Prevalence of mental health indicators among prisoners and jail inmates, by demographic characteristics, 2011�2012
imhprpji1112t03.csv	Table 03. Indicators of a mental health problem among prisoners and jail inmates, by marital status and education, 2011�2012
imhprpji1112t04.csv	Table 04. Indicators of a mental health problem among prisoners and jail inmates, by current offense, sentence status and length, and time served, 2011�2012
imhprpji1112t05.csv	Table 05. Indicators of a mental health problem among prisoners and jail inmates, by criminal history, 2011�2012
imhprpji1112t06.csv	Table 06. Mental health treatment received by prisoners and jail inmates with an indicator of a mental health problem, by type of indicator, time period, and treatment type, 2011�2012
imhprpji1112t07.csv	Table 07. Prisoners and jail inmates written up or charged with assault, by mental health status, 2011�2012

Figures
imhprpji1112f01.csv     Figure 01. Mental health status of prisoners and jail inmates, by type 
of mental health indicator, 2011�2012
imhprpji1112f02.csv	Figure 02. Prisoners and adult general population who met the criteria for serious psychological distress, 2009�2012
imhprpji1112f03.csv	Figure 03. Jail inmates and adult general population who met the criteria for serious psychological distress, 2009�2012

Appendix Tables

imhprpji1112at01.csv	Appendix Table 01. Characteristics of prisoners and jail inmates, 2011�2012
imhprpji1112at02.csv	Appendix Table 02. Standard errors for appendix table 1: Characteristics of prisoners and jail inmates, 2011�2012
imhprpji1112at03.csv	Appendix Table 03. Percentages and standard errors for figure 1: Mental health status of prisoners and jail inmates, by type of mental health indicator, 2011�2012
imhprpji1112at04.csv	Appendix Table 04. Standard errors for table 1: Prevalence of mental health indicators among prisoners and jail inmates, by type of indicator, 2011�2012
imhprpji1112at05.csv	Appendix Table 05. Percentages and standard errors for figure 2: Prisoners and adult general population who met the criteria for serious psychological distress, 2009�2012
imhprpji1112at06.csv	Appendix Table 06. percentages and standard errors for figure 3: Jail inmates and adult general population who met the criteria for serious psychological distress, 2009�2012
imhprpji1112at07.csv	Appendix Table 07. standard errors for table 2: Prevalence of mental health indicators among prisoners and jail inmates, by demographic characteristics, 2011�2012
imhprpji1112at08.csv	Appendix Table 08. Standard errors for table 3: Indicators of a mental health problem among prisoners and jail inmates, by marital status and education, 2011�2012
imhprpji1112at09.csv	Appendix Table 09. standard errors for table 4: Indicators of a mental health problem among prisoners and jail inmates, by current offense, sentence status and length, and time served, 2011�2012
imhprpji1112at010.csv	Appendix Table 10.Standard errors for table 5: Indicators of a mental health problem among prisoners and jail inmates, by criminal history, 2011�2012
imhprpji1112at011.csv	Appendix Table 11. standard errors for table 6: Mental health treatment received by prisoners and jail inmates with an indicator of a mental health problem, by type of indicator, time period, and treatment type, 2011�2012
imhprpji1112at012.csv	Appendix Table 12. Standard errors for table 7: Prisoners and jail inmates written up or charged with assaults, by mental health status, 2011�2012


