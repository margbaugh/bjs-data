Justice Assistance Grant (JAG) Program 2016 NCJ
	
This zip archive contains tables in individual .csv spreadsheets	

Report title:  Justice Assistance Grant (JAG) Program 2016 NCJ 250157

The full report including text and graphics in .pdf format are available
from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5764

	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=71


Tables	
jagp16t01.csv 	Table 1. State and local allocation amounts, FY 2016
jagp16t02.csv	Table 2. Territories and District of Columbia allocations, FY 2016
jagp16t03.csv	Table 3. Sex Offender Registration and Notification Act bonus fund allocation, FY2016
jagp16t04.csv   Table 4. Prison Rape Elimination Act bonus fund allocations, FY 2016


Figure	
jagp16f01.csv	Figure 1: Distribution of FY 2016 JAG funds
