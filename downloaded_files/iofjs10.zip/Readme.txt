Immigration Offenders in the Federal Justice System, 2010  NCJ 238581

Revised 10/31/2013

This zip archive contains tables in individual .csv spreadsheets		
from Immigration Offenders in the Federal Justice System, 2010  NCJ 238581.		
The full report including text and graphics in .pdf format is available at		
http://www.bjs.gov/


File name		Table number
iofjs10t01.csv   Table 1. Suspects arrested for a federal criminal immigration offense, by federal law enforcement agency making arrest, 2010
iofjs10t02.csv   Table 2. Suspects referred to U.S. attorneys for an immigration offense as the lead charge, 2008-2010
iofjs10t03.csv   Table 3. Immigration suspects in matters referred by U.S. attorneys, by offense type and district, 2010
iofjs10t04.csv   Table 4. Suspects in matters concluded by U.S. attorneys for an immigration offense as the most serious charge, 2010
iofjs10t05.csv   Table 5. Primary reason immigration matters were declined for prosecution, 2010
iofjs10t06.csv   Table 6. Demographic characteristics of federal defendants charged in U.S. district court with criminal immigration offenses, 2010
iofjs10t07.csv   Table 7. Criminal history of defendants charged with immigration offense in federal courts, 2010
iofjs10t08.csv   Table 8. Defendants detained prior to case disposition in U.S.district court, by offense type, citizenship, and judicial district, 2007 and 2010
iofjs10t09.csv   Table 9. Type of disposition, and sentence imposed in immigration cases terminated in U.S. district court, 2002, 2006, and 2010
iofjs10t10.csv   Table 10. Length of term imposed on immigration defendants sentenced to prison, by type of offense and district, 2002, 2006, and 2010
iofjs10t11.csv   Table 11. Characteristics of immigration cases terminated in U.S. district court, by type of counsel, 2010 
iofjs10t12.csv   Table 12. Immigration offenders under correctional supervision, by offense of conviction, fiscal yearend 2010
iofjs10t13.csv   Table 13. Characteristics of immigration offenders in the custody of the Federal Bureau of Prisons, 2002 and 2010
iofjs10t14.csv   Table 14. Immigration offenders returning to federal prison within 3 years of release from a U.S. district court commitment, 2007
iofjs10t15.csv   Table 15. Characteristics of immigration offenders under post-conviction federal supervision, fiscal yearend 2010


			Figure number
iofjs10f01.csv   Figure 1. Federal criminal immmigration arrests, by court of disposition, 1994-2010
iofjs10f02.csv   Figure 2. Number of civil proceedings in immigration court and criminal immigration proceedings in federal district court, 1996�2010
iofjs10f03.csv   Figure 3. Number of civil proceedings in immigration court and criminal immigration proceedings in federal district court, 1996�2010
iofjs10f04.csv   Figure 4. Immigration offenders as a percent of total federal criminal caseload, by stage, 2000 and 2010
iofjs10f05.csv   Figure 5. Figure 5. Aliens apprehended by immigration enforcement authorities, by Border Patrol sector, 1994�2010
iofjs10f06.csv   Figure 6. Region and nationality of aliens apprehended by immigration enforcement agencies, 2002 and 2010
iofjs10f07.csv   Figure 7. Suspects arrested for a federal criminal immigration offense, by Border Patrol sector, 1994�2010
iofjs10f08.csv   Figure 8. Suspects arrested for a federal criminal immigration offense, by Homeland Security agency making arrest, 2003�2010
iofjs10f09.csv   Figure 9. Number of suspects arrested for a federal criminal immigration offense, by age and sex of suspect, 2010
iofjs10f10.csv   Figure 10. Suspects arrested for federal criminal immigration offenses per 100 aliens apprehended, by Southwest border sector, 1994�2010
iofjs10f11.csv   Figure 11. Federal immigration suspects referred to U.S. attorneys, 1992�2010
iofjs10f12.csv   Figure 12. Number of full-time federal prosecutors and Border Patrol officers, 1992�2010
iofjs10f13.csv   Figure 13. Immigration cases in five Southwest border federal judicial districts, by court of disposition, 2010
iofjs10f14.csv   Figure 14. Outcome of matters concluded, by five Southwest border federal judicial districts, 2010
iofjs10f15.csv   Figure 15. Immigration defendants charged with petty misdemeanor and disposed by U.S. magistrate, by five federal Southwest border judicial districts, 1994�2010
iofjs10f16.csv   Figure 16. Defendants in cases filed in U.S. district court, by most serious offense, 1994�2010
iofjs10f17.csv   Figure 17. Nationality of immigration offenders charged in U.S. district court, 2010
iofjs10f18.csv   Figure 18. Felony filings per judge, by Southwest border district, 1995�2010
iofjs10f19.csv   Figure 19. Median felony case processing times from filing to disposition, by Southwest border district, 1995�2010
iofjs10f20.csv   Figure 20. Median case processing time from filing to disposition for total immigration offenses, illegal reentry, and alien smuggling, 2002�2010
iofjs10f21.csv   Figure 21. Average number of prior arrests for defendants charged in U.S. district court with an immigration offense, by type of offense, 2010
iofjs10f22.csv   Figure 22. Average number of prior convictions of defendants charged in U.S. district court with an immigration offense, by type of offense 2010
iofjs10f23.csv   Figure 23. Median prison sentence imposed for all immigration offenses, illegal reentry, and alien smuggling, 1998�2010
iofjs10f24.csv   Figure 24. Percent of immigration defendants in cases terminated, by type of counsel, 2010
iofjs10f25.csv   Figure 25. Immigration defendants in federal criminal cases by representation at case termination in U.S. district court, 1994�2010
iofjs10f26.csv   Figure 26. Nationality of immigration offenders in the custody of the Federal Bureau of Prisons at fiscal yearend, 1994�2010
iofjs10f27.csv   Figure 27. Noncitizens incarcerated in federal prison, by offense type, 1985�2010
iofjs10f28.csv   Figure 28. Felony immigration offenders under federal community supervision, by type of supervision, 1995�2010
iofjs10f29.csv   Figure 29. Percent of immigration offenders returning to federal prison after release, by time to return to prison, 1994�2010
iofjs10f30.csv   Figure 30. Characteristics of offenders under federal supervision-gender, fiscal yearend 2010
iofjs10f31.csv   Figure 31. Characteristics of offenders under federal supervision-citizenship, fiscal yearend 2010
iofjs10f32.csv   Figure 32. Characteristics of offenders under federal supervision-offense type, fiscal yearend 2010
iofjs10f33.csv   Figure 33. Immigration offenders released from federal prison or entering federal supervision, 1998�2010


			Map number

iofjs10m1.csv   Map 1. Immigration offenders released from federal prison or entering federal supervision, 1998�2010
iofjs10m2.csv   Map 2. Apprehensions by Border Patrol sector and criminal immigration suspects arrested in U.S. district courts on the Southwest border, 2010
iofjs10m3.csv   Map 3. Apprehensions by Customs and Border Protection, by Border Patrol sector, 2010
iofjs10m4.csv   Map 4. Federal criminal immigration arrests, by federal judicial district of arrest, 2010
iofjs10m5.csv   Map 5. Number of Border Patrol officers, by Border Patrol sector, 2010
iofjs10m6.csv   Map 6. Immigration suspects investigated in matters referred to U.S. attorneys, 2010
iofjs10m7.csv   Map 7. Felony filings per judge, by federal judicial districts, 2010
iofjs10m8.csv   Map 8. Median case processing time for felonies terminated in U.S. district court, 2010
iofjs10m9.csv   Map 9. Percent of immigration defendants charged in U.S. district court with a prior violent or drug felony conviction, by judicial district, 2010




