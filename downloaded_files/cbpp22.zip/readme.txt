Contacts Between Police and the Public, 2022 NCJ 308847	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Contacts Between Police and the Public, 2022 NCJ 308847.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/contacts-between-police-and-public-2022
	
This report is one in a series.  More recent editions may be available.	
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=Contacts%20Between%20Police%20and%20the%20Public	
	
Filenames		Table titles
cbpp22t01.csv	Table 1. U.S. residents age 16 or older who had police contact, by type of contact and demographic characteristics, 2022
cbpp22t02.csv	Table 2. U.S. residents age 16 or older who had police contact, by type of contact and reason, 2018, 2020, and 2022
cbpp22t03.csv	Table 3. U.S. residents age 16 or older whose police contact involved the threat or nonfatal use of force, by demographic characteristics, 2020 and 2022
cbpp22t04.csv	Table 4. U.S. residents age 16 or older whose most recent police contact was initiated by police, by reason and demographic characteristics, 2022
cbpp22t05.csv	Table 5. Percent of U.S. residents age 16 or older whose most recent police contact was as a driver in a traffic stop, by enforcement action and demographic characteristics, 2020 and 2022
cbpp22t06.csv	Table 6. Percent of U.S. residents age 16 or older whose most recent police contact was a street stop, by enforcement action and demographic characteristics, 2020 and 2022
cbpp22t07.csv	Table 7. Percent of U.S. residents age 16 or older whose most recent police contact involved misconduct, by demographic characteristics, 2020 and 2022
cbpp22t08.csv	Table 8. Percent of U.S. residents age 16 or older whose most recent police contact was initiated by police or related to a traffic accident, by race or Hispanic origin and police action, 2020 and 2022
cbpp22t09.csv	Table 9. U.S. residents age 16 or older whose most recent police-initiated or traffic accident-related contact involved the threat or nonfatal use of force, by perceptions of force and demographic characteristics, 2020 and 2022
cbpp22t10.csv	Table 10. Percent of U.S. residents age 16 or older who engaged in action toward police during their most recent police-initiated or traffic accident-related contact, by demographic characteristics, 2020 and 2022
cbpp22t11.csv	Table 11. U.S. residents age 16 or older whose most recent police contact was initiated by the resident, by reason and demographic characteristics, 2022
cbpp22t12.csv	Table 12. Percent of U.S. residents age 16 or older whose most recent police contact was initiated by the resident for any reason excluding block watch, by perceptions of response and demographic characteristics, 2022
	
			Figures
cbpp22f01.csv	Figure 1. U.S. residents age 16 or older who had police contact, by type of contact and reason, 2022
	
			Appendix tables
cbpp22at01.csv	Appendix table 1. Standard errors for figure 1 and table 2: U.S. residents age 16 or older who had police contact, by type of contact and reason, 2018, 2020, and 2022
cbpp22at02.csv	Appendix table 2. Standard errors for table 1: U.S. residents age 16 or older who had police contact, by type of contact and demographic characteristics, 2022
cbpp22at03.csv	Appendix table 3. Standard errors for table 3: U.S. residents age 16 or older whose police contact involved the threat or nonfatal use of force, by demographic characteristics, 2020 and 2022
cbpp22at04.csv	Appendix table 4. Standard errors for table 4: U.S. residents age 16 or older whose most recent police contact was initiated by police, by reason and demographic characteristics, 2022
cbpp22at05.csv	Appendix table 5. Standard errors for table 5: Percent of U.S. residents age 16 or older whose most recent police contact was as a driver in a traffic stop, by enforcement action and demographic characteristics, 2020 and 2022
cbpp22at06.csv	Appendix table 6. Standard errors for table 6: Percent of U.S. residents age 16 or older whose most recent police contact was a street stop, by enforcement action and demographic characteristics, 2020 and 2022
cbpp22at07.csv	Appendix table 7. Standard errors for table 7: Percent of U.S. residents age 16 or older whose most recent police contact involved misconduct, by demographic characteristics, 2020 and 2022
cbpp22at08.csv	Appendix table 8. Standard errors for table 8: Percent of U.S. residents age 16 or older whose most recent police contact was initiated by police or related to a traffic accident, by race or Hispanic origin and police action, 2020 and 2022
cbpp22at09.csv	Appendix table 9. Standard errors for table 9: U.S. residents age 16 or older whose most recent police-initiated or traffic accident-related contact involved the threat or nonfatal use of force, by perceptions of force and demographic characteristics, 2020 and 2022
cbpp22at10.csv	Appendix table 10. Standard errors for table 10: Percent of U.S. residents age 16 or older who engaged in action toward police during their most recent police-initiated or traffic accident-related contact, by demographic characteristics, 2020 and 2022
cbpp22at11.csv	Appendix table 11. Standard errors for table 11: U.S. residents age 16 or older whose most recent police contact was initiated by the resident, by reason and demographic characteristics, 2022
cbpp22at12.csv	Appendix table 12. Standard errors for table 12: Percent of U.S. residents age 16 or older whose most recent police contact was initiated by the resident for any reason excluding block watch, by perceptions of response and demographic characteristics, 2022
