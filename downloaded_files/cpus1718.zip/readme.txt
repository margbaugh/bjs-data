Correctional Populations in the United States, 2017-2018  NCJ 252157		
		
This zip archive contains tables in individual .csv spreadsheets		
from Correctional Populations in the United States, 2017-2018  NCJ 252157		
The full report including text and graphics in pdf format is available from:		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7026		
		
These statistical tables are in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://www.bjs.gov/index.cfm?ty=pbse&sid=5		
		
Filenames		Table title
cpus1718t01.csv		Table 1. Number of persons supervised by adult correctional systems in the U.S., by correctional status, 2008-2018
cpus1718t02.csv		Table 2. Number of persons supervised by adult correctional systems in the U.S., by correctional status, 2008 and 2018
cpus1718t03.csv		Table 3. Change in the number of persons supervised by adult correctional systems in the U.S., 2008-2018
cpus1718t04.csv		Table 4. Rate of persons supervised by adult correctional systems in the U.S., by correctional status, 2008-2018
cpus1718t05.csv		Table 5. Number of offenders with dual correctional statuses at year-end, 2008-2018
		
			Figure
cpus1718f01.csv		Figure 1. Persons under the supervision of adult correctional systems in the U.S., 2008-2018
		
			Appendix tables
cpus1718at01.csv	Appendix table 1. Number and rate of persons supervised by adult correctional systems in the U.S., by jurisdiction and correctional status, 2018
cpus1718at02.csv	Appendix table 2. Number and rate of persons supervised by adult correctional systems in the U.S., by jurisdiction and correctional status, 2017
cpus1718at03.csv	Appendix table 3. Number of persons incarcerated by other adult correctional systems, 2008, 2017, and 2018
cpus1718at04.csv	Appendix table 4. Custody counts of adults in state or federal prisons or local jails, 2008, 2017, and 2018
cpus1718at05.csv	Appendix table 5. Standard errors for local jail inmates at midyear, 2008-2018
