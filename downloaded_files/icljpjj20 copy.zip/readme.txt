Impact of COVID-19 on the Local Jail Population, January-June 2020		
		
This zip archive contains tables in individual .csv spreadsheets		
from Impact of COVID-19 on the Local Jail Population, January-June 2020   NCJ 255888. The full report including text and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=7268		
		
Filename			Table titles
icljpjj20t01.csv	Table 1. Number of inmates confined in local jails on the last weekday in June 2019 and the last weekday of each month from January to June 2020
icljpjj20t02.csv	Table 2. Local jail population as a percentage of the June 2019 jail population, by region, January-June 2020
icljpjj20t03.csv	Table 3. Admissions and expedited releases, by size of jail jurisdiction, region, and county COVID-19 infection rate, March 1-June 30, 2020
icljpjj20t04.csv	Table 4. COVID-19 testing and positive cases among local jail inmates, by size of jail jurisdiction, region, and county infection rate, March 1-June 30, 2020
icljpjj20t05.csv	Table 5. Inmate population change and inmate and staff COVID-19 testing and cases in the 50 largest local jail jurisdictions, March-June 2020
icljpjj20t06.csv	Table 6. COVID-19 positive tests among local jail staff, by size of jail jurisdiction, region, and county infection rate, March 1-June 30, 2020
icljpjj20t07.csv	Table 7. COVID-19 deaths among local jail inmates and staff, March 1-June 30, 2020
icljpjj20t08.csv	Table 8. Number of inmates confined in local jails, by size of jail jurisdiction, region, and county COVID-19 infection rate, midyear 2019 and midyear 2020
icljpjj20t09.csv	Table 9. Jail capacity, by size of jail jurisdiction, region, and county COVID-19 infection rate, midyear 2019 and midyear 2020
icljpjj20t10.csv	Table 10. Number and percent of confined inmates in local jails, by characteristics, midyear 2019 and midyear 2020
icljpjj20t11.csv	Table 11. Local jail incarceration rates, by sex and race or ethnicity, midyear 2019 and midyear 2020
		
				Figures
icljpjj20f01.csv	Figure 1. Number of inmates confined in local jails on the last weekday in June 2019 and the last weekday of each month from January to June 2020
icljpjj20f02.csv	Figure 2. Local jail population as a percentage of the June 2019 jail population, by region, January-June 2020
		
				Appendix tables
icljpjj20at01.csv	Appendix Table 1. Standard errors for figure 1 and table 1: Number of inmates confined in local jails on the last weekday in June 2019 and the last weekday of each month from January to June 2020
icljpjj20at02.csv	Appendix Table 2. Standard errors for table 2: Local jail population as a percentage of the June 2019 jail population, by region, January-June 2020
icljpjj20at03.csv	Appendix Table 3. Standard errors for table 3: Admissions and expedited releases, by size of jail jurisdiction, region, and county COVID-19 infection rate, March 1-June 30, 2020
icljpjj20at04.csv	Appendix Table 4. Standard errors for table 4: COVID-19 testing and positive cases among local jail inmates, by size of jail jurisdiction, region, and county infection rate, March 1-June 30, 2020
icljpjj20at05.csv	Appendix Table 5. Standard errors for table 6: COVID-19 positive tests among local jail staff, by size of jail jurisdiction, region, and county infection rate, March 1-June 30, 2020
icljpjj20at06.csv	Appendix Table 6. Standard errors for table 8: Number of inmates confined in local jails, by size of jail jurisdiction, region, and county COVID-19 infection rate, midyear 2019 and midyear 2020
icljpjj20at07.csv	Appendix Table 7. Standard errors for table 9: Jail capacity, by size of jail jurisdiction, region, and county COVID-19 infection rate, midyear 2019 and midyear 2020
icljpjj20at08.csv	Appendix Table 8. Standard errors for table 10: Number and percent of confined inmates in local jails, by characteristics, midyear 2019 and midyear 2020
icljpjj20at09.csv	Appendix Table 9. Standard errors for table 11: Local jail incarceration rates, by sex and race or ethnicity, midyear 2019 and midyear 2020
icljpjj20at10.csv	Appendix Table 10. Number of annual admissions to local jails, by size of jail jurisdiction, region, and county COVID-19 infection rate, 2019 and 2020
icljpjj20at11.csv	Appendix Table 11. Standard errors for appendix table 10: Number of annual admissions to local jails, by size of jail jurisdiction, region, and county COVID-19 infection rate, 2019 and 2020
icljpjj20at12.csv	Appendix Table 12. Number of persons under jail supervision outside of jail, by size of jail jurisdiction, region, and county COVID-19 infection rate, midyear 2019 and midyear 2020
icljpjj20at13.csv	Appendix Table 13. Standard errors for appendix table 12: Number of persons under jail supervision outside of jail, by size of jail jurisdiction, region, and county COVID-19 infection rate, midyear 2019 and midyear 2020
