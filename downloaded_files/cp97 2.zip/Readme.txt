Contents of this archive

Filename                                 Title

cp9703.wk1            Table 3:  Method of execution, by State, 1997
cp9704.wk1            Table 4:  Minimum age authorized for capital punishment, 1997
cp9705.wk1            Table 5:  Prisoners under sentence of death, by region, State, and
                                  race, 1996 and 1997
cp9706.wk1            Table 6:  Hispanics and women under sentence of death, by State,
                                  1996 and 1997
cp9707.wk1            Table 7:  Demographic characteristics of prisoners under sentence
                                  of death, 1997
cp9708.wk1            Table 8:  Age at time of arrest for capital offense and age of prisoners
                                  under sentence of death at yearend, 1997
cp9709.wk1            Table 9:  Criminal history profile of prisoners under sentence of death,
                                  by race and Hispanic origin, 1997
cp9710.wk1           Table 10:  Number of persons executed, by jurisdiction, 1930-97
cp9711.wk1           Table 11:  Prisoners under sentence to death who were executed or received
                                  other dispositions, by race and Hispanic origin, 1977-97
cp9712.wk1           Table 12:  Time under sentence of death sentence and execution, 
                                  by race, 1997-97


cp97a01.wk1  Appendix table 1:  Prisoners sentenced to death and the outcome sentence, by year
                                  of sentencing, 1973-97
cp97a02.wk1  Appendix table 2:  Prisoners under sentence of death, on December 31, 1997,
                                  by State and year of sentencing
cp97a03.wk1  Appendix table 3:  Number sentenced to death and number of removals, by 
                                   jurisdiction and reason for removal, 1973-97
cp97a04.wk1  Appendix table 4:  Executions, by State and method, 1977-97



cp97f01.wk1          Figure 1:  Persons under sentence of death, 1957-97
cp97f02.wk1          Figure 2:  Persons under sentence of death, by race, 1968-97
cp97f03.wk1          Figure 3:  Persons executed, 1930-97

