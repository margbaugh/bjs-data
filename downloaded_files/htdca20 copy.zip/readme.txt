Human Trafficking Data-Collection Activities, 2020  NCJ 256001		
		
This .zip archive contains tables in individual  .csv spreadsheets		
Human Trafficking Data-Collection Activities, 2020  NCJ 256001   The full report including text		
and graphics in .pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7286		
		
Filename		Figure titles
htdca20f01.csv		Figure 1. State participation in FBI human-trafficking data collection, by offense type reported, 2015-2019
htdca20f02.csv		Figure 2. Arrests for human-trafficking offenses, by offense type, 2015-2019
		