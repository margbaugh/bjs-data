Crime and Victimization in the Three Largest Metropolitan Areas, 1980-98  NCJ  208075

This zip archive contains tables in individual .csv spreadsheets
from Crime and Victimization in the Three Largest Metropolitan Areas, 
1980-98  NCJ  208075. The full report including text 
and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cv3lma98.htm 


cv3lma98t1     Table 1. Interviews in the metropolitan areas of Chicago, Los Angeles, and New York, as a percentage of all NCVS interviews, 1979-99 

cv3lma98f1     Figure 1. Burglary rates for New York City Metropolitan Area, 1980-98

cv3lma98f2     Figure 2. Burglary rates for Chicago Metropolitan Area, 1980-98

cv3lma98f3     Figure 3. Burglary rates for Los Angeles Metropolitan Area, 1980-98

cv3lma98f4     Figure 4. Robbery rates for New York City Metropolitan Area, 1980-98

cv3lma98f5     Figure 5. Robbery rates for Chicago Metropolitan Area, 1980-98

cv3lma98f6     Figure 2. Robbery rates for Los Angeles Metropolitan Area,  1980-98

cv3lma98f7     Figure 7. Aggravated assault rates for New York City Metropolitan  Area, 1980-98

cv3lma98f8     Figure 8. Aggravated assault rates for Chicago Metropolitan Area, 1980-98

cv3lma98f9     Figure 9. Aggravated assault rates for Los Angeles Metropolitan Area, 1980-98			
