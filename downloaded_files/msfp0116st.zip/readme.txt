Mortality in State and Federal Prisons, 2001-2016 � Statistical Tables   NCJ 251920		
		
This zip archive contains tables in individual  .csv spreadsheets		
Mortality in State and Federal Prisons, 2001-2016 � Statistical Tables   NCJ 251920  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6766		
		
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=76		
		
		
Filename			Tables
msfp0116stt01.csv		Table 1. State and federal prisoner deaths, by cause of death, 2001-2016
msfp0116stt02.csv		Table 2. Number of state and federal prisoner deaths, by cause of death, 2001 and 2006-2016
msfp0116stt03.csv		Table 3. Percent of state prisoner deaths, by cause of death, 2001 and 2006-2016
msfp0116stt04.csv		Table 4. Mortality rate per 100,000 state prisoners, by cause of death, 2001 and 2006-2016
msfp0116stt05.csv		Table 5. Mortality rate per 100,000 federal prisoners, by cause of death, 2001 and 2006-2016
msfp0116stt06.csv		Table 6. Number of state prisoner deaths, by decedent characteristics, 2001 and 2006-2016
msfp0116stt07.csv		Table 7. Percent of state prisoner deaths, by decedent characteristics, 2001 and 2006-2016
msfp0116stt08.csv		Table 8. Mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2001 and 2006-2016
msfp0116stt09.csv		Table 9. Number of deaths in state prisons, by cause of death and decedent characteristics, 2001-2016
msfp0116stt10.csv		Table 10. Average annual mortality rate per 100,000 state prisoners within each demographic group, by cause of death and decedent characteristics, 2001-2016
msfp0116stt11.csv		Table 11. Number of prisoner deaths in state and federal facilities, 2001 and 2006-2016
msfp0116stt12.csv		Table 12. Mortality rate per 100,000 state and federal prisoners, 2001 and 2006-2016
msfp0116stt13.csv		Table 13. Number of prisoner deaths in state and federal facilities, by cause of death, 2001-2016
msfp0116stt14.csv		Table 14. Average annual mortality rate per 100,000 state and federal prisoners, by cause of death, 2001-2016
		
				Figure
msfp0116stf01.csv		Figure 1. Mortality rate per 100,000 state and federal prisoners, 2001-2016
		
				Appendix tables
msfp0116stat01.csv		Appendix table 1. Estimated number of state and federal prisoners in custody, by prisoner characteristics, 2001 and 2006-2016
msfp0116stat02.csv		Appendix table 2. Illness mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat03.csv		Appendix table 3. Cancer mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat04.csv		Appendix table 4. Heart-disease mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat05.csv		Appendix table 5. Liver-disease mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat06.csv		Appendix table 6. Respiratory-disease mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat07.csv		Appendix table 7. Mortality rate due to all other illnesses per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat08.csv		Appendix table 8. Rate of unnatural deaths per 100,000 state prisoners within each demographic group, by decedent characteristics, 2007-2016 (3-year rolling averages)
msfp0116stat09.csv		Appendix table 9. Rates for figure 1: Mortality rate per 100,000 state and federal prisoners, 2001-2016