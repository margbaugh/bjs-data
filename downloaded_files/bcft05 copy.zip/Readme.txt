BACKGROUND CHECKS FOR FIREARM TRANSFERS, 2005 NCJ 214256																

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .csv spreadsheets from the
Firearm Inquiry Statistics (FIST) program Bulletin, "Background Checks for
Firearm Transfers, 2005" NCJ 214256. 
The full report including text and 
graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/bcft05.htm 

This report is one in a series.  Most recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#bcft
----------------------------------------------------------------------------
																	
Filename	Table																
																	
bcft05t01.csv	Table 1. Number of applications and estimates of rejections for firearm transfers or permits, 1994-2005	
bcft05t02.csv	Table 2. Number of applications and rejections, by type of agency and type of check, 1999-2005
bcft05t03.csv	Table 3. Rejection rates for selected FBI states, 1999-2005		
bcft05t04.csv	Table 4. Number of firearm purchase applications received and rejected by State agencies, 1999-2005
bcft05t05.csv	Table 5. Number of applications, rejections, and reasons for rejection among all agencies conducting background checks during the permanent Brady period, 1999-2005	
bcft05t06.csv	Table 6. Reasons for rejection of firearm transfer applications, by State or local agency 1999-2005
bcft05t07.csv	Table 7. Appeal forums in State with a specific appeal procedure, 2005
bcft05t08.csv	Table 8. Appeals by type of checking agency, 1999-2005
bcft05t09.csv	Table 9. Number of arrests reported by type of agency, 2005 and 1999-2005
bcft05t10.csv	Table 10. Notification procedures of State agencies regarding denied persons subject to arrest, 2005

bcft05tt01.csv	Text Table 1. Statewide reporting on exempt carry permit applications, 2005
bcft05tt02.csv	Text Table 2. Local rejection rates by population served and by type of permit
bcft05tt03.csv	Text Table 3. Reasons for rejection of firearm transfer applications, by type of agency, 2005
bcft05tt04.csv	Text Table 4. Statewide agencies reporting appeals, 2005
bcft05tt05.csv	Text table 5. Number of arrests reported by States providing arrest data in 2005
bcft05tt06.csv	Text table 6. Total firearm denials referred to ATF in 2005
bcft05tt07.csv	Text table 7. Number of agencies, sample, and response rate in FIST program survey, 2005

bcft05aa.csv	Appendix Table A. National Instant Criminal Background Check System: Checking agencies - FBI or State point of contact - for firearm transfers, 2005
bcft05ab.csv	Appendix Table B. Agencies conducting firearm background checks, December 31, 2005

