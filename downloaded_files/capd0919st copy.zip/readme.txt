Crime Against Persons with Disabilities, 2009–2019 – Statistical Tables  NCJ 301367	
	
This zip archive contains tables in individual .csv spreadsheets	
from Crime Against Persons with Disabilities, 2009–2019 – Statistical Tables  NCJ 301367	
The full report including text and graphics in .pdf format is available at	
https://bjs.ojp.gov/library/publications/crime-against-persons-disabilities-2009-2019-statistical-tables
	
This report is one in a series.  More recent editions may be available. 	
https://bjs.ojp.gov/library/publications/list?series_filter=Crime%20Against%20People%20with%20Disabilities	
	
Filenames		Table names
capd0919stt01.csv	Table 1. Rate of violent victimization, by type of crime and disability status, 2017–19
capd0919stt02.csv	Table 2. Percent of violent victimizations against persons with disabilities, by type of crime, 2017–19
capd0919stt03.csv	Table 3. Rate of violent victimization against persons with and without disabilities, by victim characteristics, 2017–19
capd0919stt04.csv	Table 4. Rate of violent victimization and average annual number of persons, by victim’s disability status and age, 2017–19
capd0919stt05.csv	Table 5. Rate of violent victimization against persons with disabilities, by disability type and type of crime, 2017–19
capd0919stt06.csv	Table 6. Victim-offender relationship, by victim’s disability status, 2017–19
capd0919stt07.csv	Table 7. Violent crime reported to police, by victim’s disability status and disability type, 2017–19
capd0919stt08.csv	Table 8. Violent crime reported to police, by disability status and type of crime, 2017–19
capd0919stt09.csv	Table 9. Person who notified police of violent crime, by victim’s disability status, 2017–19
capd0919stt10.csv	Table 10. Average annual number of persons age 12 or older, by disability status and disability type for ACS and NCVS, 2017–19
	
			Figure
capd0919stf01.csv	Figure 1. Rate of violent victimization, by disability status, 2009–2019 (2-year rolling averages)
	
			Appendix tables
capd0919stat01.csv	Appendix table 1. U.S. population, by disability status and demographic characteristics, 2017–19
capd0919stat02.csv	Appendix table 2. Estimates and standard errors for figure 1: Rate of violent victimization, by disability status, 2009–2019 (2-year rolling averages)
capd0919stat03.csv	Appendix table 3. Standard errors for table 1: Rate of violent victimization, by type of crime and disability status, 2017–19
capd0919stat04.csv	Appendix table 4. Standard errors for table 2: Percent of violent victimizations against persons with disabilities, by type of crime, 2017–19
capd0919stat05.csv	Appendix table 5. Standard errors for table 3: Rate of violent victimization against persons with and without disabilities, by victim characteristics, 2017–19
capd0919stat06.csv	Appendix table 6. Standard errors for table 4: Rate of violent victimization and average annual number of persons, by victim’s disability status and age, 2017–19
capd0919stat07.csv	Appendix table 7. Standard errors for table 5: Rate of violent victimization against persons with disabilities, by disability type and type of crime, 2017–19
capd0919stat08.csv	Appendix table 8. Standard errors for table 6: Victim-offender relationship, by victim’s disability status, 2017–19
capd0919stat09.csv	Appendix table 9. Standard errors for table 7: Violent crime reported to police, by victim’s disability status and disability type, 2017–19
capd0919stat10.csv	Appendix table 10. Standard errors for table 8: Violent crime reported to police, by disability status and type of crime, 2017–19
capd0919stat11.csv	Appendix table 11. Standard errors for table 9: Person who notified police of violent crime, by victim’s disability status, 2017–19
