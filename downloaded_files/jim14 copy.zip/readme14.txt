Jail Inmates at Midyear 2014 NCJ 248629	
	
This zip archive contains tables in individual .csv spreadsheets	
Jail Inmates at Midyear 2014 NCJ 248629	
The full report including text and graphics in .pdf format are available from:	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5299	
	
This report is one in a series. More recent editions may be available. To 	
"view a list of all in the series go to the 
view a list of all in the series go 
to the http://www.bjs.gov/index.cfm?ty=pbse&sid=38"	
 	
Tables	
jim14t01.csv	Table 1: Inmates confined in local jails at midyear, average daily population, and incarceration rates, 2000�2014
jim14t02.csv	Table 2: Number of inmates in local jails, by characteristics, midyear 2000 and 2005�2014
jim14t03.csv	Table 3: Percent of inmates in local jails, by characteristics, midyear 2000 and 2005�2014
jim14t04.csv	Table 4: Inmates confined in local jails at midyear, by size of jurisdiction, 2013�2014
jim14t05.csv	Table 5: Rated capacity of local jails and percent of capacity occupied, 2000 and 2005�2014
jim14t06.csv	Table 6: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2013�2014
jim14t07.csv	Table 7: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2013 and 2014
jim14t08.csv	Table 8: Inmate population in jail jurisdictions reporting on confined persons being held for U.S. Immigration and Customs Enforcement (ICE), midyear 2002�2014
jim14t09.csv	Table 9: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2014
	
Appendix Tables	
jim14at01.csv	Appendix table 1: Standard errors for table 1: Inmates confined in local jails at midyear, average daily population, and incarceration rates, 2000�2014
jim14at02.csv	Appendix table 2: Reported data for table 2: Number of inmates in local jails, by characteristics, midyear 2000 and 2005�2014
jim14at03.csv	Appendix table 3: Standard errors for table 2: Number of inmates in local jails, by characteristics, midyear 2000 and 2005�2014
jim14at04.csv	Appendix table 4: Standard error ratios for table 3: Percent of inmates in local jails, by characteristics, midyear 2000 and 2005�2014
jim14at05.csv	Appendix table 5: Standard errors for table 4: Inmates confined in local jails at midyear, by size of jurisdiction, 2013�2014
jim14at06.csv	Appendix table 6: Standard errors for table 5: Rated capacity of local jails and percent of capacity occupied, 2000 and 2005�2014
jim14at07.csv	Appendix table 7: Standard errors for table 6: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2013�2014
jim14at08.csv	Appendix table 8: Standard errors for table 7: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2013 and 2014
jim14at09.csv	Appendix table 9: Standard errors for table 8: Inmate population in jail jurisdictions reporting on confined persons being held for U.S. Immigration and Customs Enforcement (ICE), midyear 2002�2014
jim14at10.csv	Appendix table 10: Standard errors for table 9: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2014
	
Figures	
jim14f01.csv	Figure 1: Inmates confined in local jails at midyear and percent change in the jail population, 2000�2014
jim14f02.csv	Figure 2: Midyear custody population, average daily population (ADP), and rated capacity in local jails, 2000�2014
jim14f03.csv	Figure 3: Percent change in the midyear custody population and rated capacity between 2008 and 2014
