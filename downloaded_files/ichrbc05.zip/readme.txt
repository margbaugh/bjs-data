Improving Criminal History Records for Background Checks, 2005		
 		
This zip archive contains tables in individual .csv spreadsheets		
from mproving Criminal History Records for Background Checks, 2005, NCJ 212871		
The full report including  text and graphics in pdf format are available from:		
http://www.ojp.usdoj.gov/bjs/abstract/ichrbc05.htm		

This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#ichrbc		

ichrbc05h1.csv		Highlights: Since 1995 criminal records accessible for background checks increased 83% and the growth rate in automated reocrds was 57%

ichrbc05t1.csv		Table 1.  Pre-sale firearms background check databases used for NICS checks and record holdings, January 2006
		
ichrbc05f1.csv		Figure 1: Among rejections of firearm transfer applications, nonfelony reasons increasded 5 1/2-fold between 1995-2004
ichrbc05f2.csv		Figure 2: Among the almost 48 million firearm transfer applications, 1999-2004, checks approved 98.1% and rejected 1.9%
ichrbc05f3.csv		Figure 3: The National Records Quality Index (NRQI) increased 169% between 1997 and 2003

ichrbc05app.csv		Appendix table:  NCHIP Awards: 1995 - 2005
