
						readme.txt
Criminal Victimization, 2007 NCJ 224390		

This zip archive contains tables in individual .csv spreadsheets		
from Criminal Victimization, 2007 NCJ  224390. The full report including text		
and graphics in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/cv07.htm.		

This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cvus		


Filename		Table title
cv07t01.csv		Table 1. Criminal victimization, numbers, rates, and percent change, by type of crime, 2005 and 2007
cv07t02.csv		Table 2. Rates of criminal victimization and percent change, by type of crime, 1998 and 2007
cv07t03.csv		Table 3. National crime victimization rates and percent change in rates, by type of crime, 2005-2007
cv07t04.csv		Table 4. Rates of violent crime and personal theft, by gender, race, Hispanic origin and age, 2007
cv07t05.csv		Table 5. Property crime rates, by household income and household size, 2007
cv07t06.csv		Table 6. Victim and offender relationship, 2007 
cv07t07.csv		Table 7. Presence of weapons in violent incidents, 2007
cv07t08.csv		Table 8. Crimes reported to the police, by gender, race, and Hispanic origin, 2007 
cv07t09.csv		Table 9. Type of crime,  with bounding adjustment and without first interview, 2007

			Figure title
cv07f01.csv		Figure 1. Overall rate of violent crime fell by 43% from 1998 to 2007
cv07f02.csv		Figure 2. Property crime rates overall fell by 33% from 1998 to 2007
cv07f03.csv		Figure 3. Increases rates of victimization for personal crimes were observed in 2006 during the transition from PAPI to CAPI
cv07f04.csv		Figure 4. Personal crime rates were generally higher for incoming or new sample areas after CAPI was introduced in July, 2006
cv07f05.csv		Figure 5. Transition from PAPI to CAPI in 2006 affected the victimization rate reported for property crime
cv07f06.csv		Figure 6. Property crime rates in 2007 were about the same for incoming, continuing, and outgoing sample areas

			Text table title
cv07tt1.csv		Text table 1. Firearms 1998 and 2007
cv07tt2.csv		Text table 2. Percent of crimes reported to police, 2007
cv07tt3.csv		Text table 3. Comparison of cases reduced in sample and remaining in sample in July 2007
