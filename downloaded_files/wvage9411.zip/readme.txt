Workplace Violence Against Government Employees, 1994-2011, NCJ 241349

 
This zip archive contains tables in individual .csv spreadsheets from
Workplace Violence Against Government Employees, 1994-2011, NCJ 241349

The full electronic report is available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4615

Filename		Table title
wvage9411t01.csv	Percent of workplace violence and employed persons, by type of employee, 2002-2011
wvage9411t02.csv	Rate and percent of workplace violence and percent of employed persons, by occupation and type of employee, 2002-2011
wvage9411t03.csv	Rate, percent, and annual average number of workplace violence, by type of crime and type of employee, 2002-2011
wvage9411t04.csv	Rates of workplace violence, by type of employee and victim characteristics, 2002-2011
wvage9411t05.csv	Victim-offender relationship in workplace violence, by type of employee and sex, 2002-2011
wvage9411t06.csv	Offender weapon possession in workplace violence, by type of weapon and type of employee, 2002-2011
wvage9411t07.csv	Injury in workplace violence, by type of employee, 2002-2011
wvage9411t08.csv	Reasons for not reporting workplace violence to police, by type of employee, 2002-2011

Filename		Figure Title
wvage9411f01.csv	Rate of nonfatal workplace violence against government and private-sector employees, 1994-2011
wvage9411f02.csv	Rate of nonfatal workplace violence against law enforcement and security employees, by type of employee, 1994-2011
wvage9411f03.csv	Rate of nonfatal workplace violence against non-law enforcement and security employees, 1994-2011
wvage9411f04.csv	Rate of nonfatal workplace violence against all government and non-law enforcement and security government employees, by type of employee, 1994-2011
wvage9411f05.csv	Number of workplace homicides, by type of employee, 1993-2011
wvage9411f06.csv	Percent of workplace violence reported to police, by type of employee, 1994-2011

Filename		Appendix table title
wvage9411at01.csv	Rates and standard errors for figure 1: Rate of nonfatal workplace violence against government and private-sector employees, 1994-2011
wvage9411at02.csv	Standard errors for table 1: Percent of workplace violence and employed persons, by type of employee, 2002-2011
wvage9411at03.csv	Rates and standard errors for figure 2: Rate of nonfatal workplace violence against law enforcement and security employees, by type of employee, 1994-2011
wvage9411at04.csv	Rates and standard errors for figure 3: Rate of nonfatal workplace violence against non-law enforcement and security employees, by type of employee, 1994-2011
wvage9411at05.csv	Rates and standard errors for figure 4: Rate of nonfatal workplace violence against all government employees and non-law enforcement and security employees, by type of employee, 1994-2011
wvage9411at06.csv	Standard errors for table 2: Rate and percent of workplace violence and percent of employed persons, by occupation and type of employee, 2002-2011
wvage9411at07.csv	Standard errors for table 3: Rate, percent, and annual average number of workplace violence, by type of crime and type of employee, 2002-2011
wvage9411at08.csv	Numbers for figure 5: Number of workplace homicides, by type of employee, 1993-2011
wvage9411at09.csv	Standard errors for table 4: Rate of workplace violence, by type of employee and victim characteristics, 2002-2011
wvage9411at10.csv	Standard errors for table 5: Victim-offender relationship in workplace violence, by type of employee and sex, 2002-2011
wvage9411at11.csv	Standard errors for table 6: Offender weapon possession in workplace violence, by type of weapon and type of employee, 2002-2011
wvage9411at12.csv	Standard errors for table 7: Injury in workplace violence, by type of employee, 2002-2011
wvage9411at13.csv	Percentages and standard errors for figure 6: Percent of workplace violence reported to police, by type of employee, 1994-2011
wvage9411at14.csv	Standard errors for table 8: Reasons for not reporting workplace violence to police, by type of employee, 2002-2011
wvage9411at15.csv	Percent of workplace violence by occupation with extension of other catgegory, by type of employee, 2002-2011
wvage9411at16.csv	Standard errors for appendix table 15: Percent of workplace violence by occupation with extension of other category, by type of employee, 2002-2011