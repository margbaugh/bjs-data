"Crime Against Persons with Disabilities, 2009-2015 - Statistical Tables"		
		
This zip archive contains tables in individual .csv spreadsheets		
"from Crime Against Persons with Disabilities, 2009-2015 - Statistical Tables. NCJ 250632"		
The full report including text and graphics in .pdf format is available at		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=5986		
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=65		
		
File name               Table number
		

capd0915t01.csv	 	Rate of violent victimization and average annual number of persons, by victim�s disability status and age, 2011�2015
capd0915t02.csv      	Rate of violent victimization against persons with and without disabilities, by type of crime, 2011�2015
capd0915t03.csv      	Rate of violent victimization against persons with and without disabilities, by victim characteristics, 2011�2015
capd0915t04.csv      	Rate of violent victimization against persons with disabilities, by disability type and type of crime, 2011�2015
capd0915t05.csv		Rate of violent victimization against persons with disabilities, by disability type and sex, 2011�2015
capd0915t06.csv		Percent of violent crime against persons with disabilities, by type of crime and number of disability types, 2011�2015
capd0915t07.csv		Rate of violent victimization, by number of disability types and type of crime, 2011�2015
capd0915t08.csv		Victim-offender relationship, by victim's disability status, 2011�2015
capd0915t09.csv		Time violent crime occurred, by victim's disability status, 2011�2015
capd0915t10.csv		Violent crime reported to police, by victim�s disability status and disability type, 2011�2015
capd0915t11.csv		Person who notified police of violent crime, by victim's disability status, 2011�2015
capd0915t12.csv		Reasons for not reporting violent crime to police, by victim's disability status, 2011�2015
capd0915t13.csv		Percent of violent victimizations in which assistance from a nonpolice victim services agency was received, by victim's disability status, 2011�2015


File name               Figures
			
capd0915f1.csv      	Violent victimization, by disability status, 2009�2015


		
File name               Appendix tables
			
capd0915at01.csv	Unadjusted rates and standard errors of violent victimization against persons without disabilities, 2009�2015
capd0915at02.csv        Unadjusted rates and standard errors for violent victimization against persons without disabilities, by type of crime, 2011�2015 
capd0915at03.csv        Unadjusted rates and standard errors for violent victimization against persons without disabilities, by victim characteristics, 2011�2015 
capd0915at04.csv        U.S. population, according to the U.S. Census Bureau's American Community Survey Public Use Microdata Sample data, by disability status and demographic characteristics, 2011�2015
capd0915at05.csv        Rates and standard errors for figure 1: Violent victimization, by disability status, 2009�2015
capd0915at06.csv        Standard errors for table 1: Rate of violent victimization and average annual number of persons, by victim's disability status and age, 2011�2015
capd0915at07.csv        Standard errors for table 2: Rate of violent victimization against persons with and without disabilities, by type of crime, 2011�2015
capd0915at08.csv        Standard errors for table 3: Rate of violent victimization against persons with and without disabilities, by victim characteristics, 2011�2015
capd0915at09.csv        Standard errors for table 4: Rate of violent victimization against persons with disabilities, by disability type and type of crime, 2011�2015
capd0915at10.csv        Standard errors for table 5: Rate of violent victimization against persons with disabilities, by disability type and sex, 2011�2015
capd0915at11.csv 	Standard errors for table 6: Percent of violent crime against persons with disabilities, by type of crime and number of disability types, 2011�2015
capd0915at12.csv	Standard errors for table 7: Rate of violent victimization, by number of disability types and type of crime, 2011�2015
capd0915at13.csv	Standard errors for table 8: Victim-offender relationship, by victim's disability status, 2011�2015
capd0915at14.csv	Standard errors for table 9: Time violent crime occurred, by victim's disability status, 2011�2015
capd0915at15.csv	Standard errors for table 10: Violent crime reported to police, by victim�s disability status and disability type, 2011�2015
capd0915at16.csv	Standard errors for table 11: Person who notified police of violent crime, by victim's disability status, 2011�2015
capd0915at17.csv	Standard errors for table 12: Reasons for not reporting violent crime to police, by victim's disability status, 2011�2015
capd0915at18.csv	Standard errors for table 13: Percent of violent victimizations in which assistance from a nonpolice victim services agency was received, by victim's disability status, 2011�2015













