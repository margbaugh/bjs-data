Correctional Populations in the United States, 2014 NCJ 249513

 
This zip archive contains tables in individual .csv spreadsheets from
Correctional Populations in the United States, 2014 NCJ 249513.
The full electronic report including text and graphics in .pdf format are available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5519


This report is one in a series. Earlier editions 
may be available. To view a list of all in the series 
http://www.bjs.gov/index.cfm?ty=pbse&sid=5


     Tables 
cpus14t01.csv       	Table 1. Estimated number of persons supervised by U.S. adult correctional systems, by correctional status, 2000, 2005�2010, 
cpus14t02.csv		Table 2. Estimated rate of persons supervised by U.S. adult correctional systems, by correctional status, 2000 and 2005�2014
cpus14t03.csv		Table 3. Incarceration rate of inmates under the jurisdiction of state or federal prisons or held in local jails and imprisonment rate of sentenced prisoners under the jurisdiction of state or federal prisons, 2004�2014
cpus14t04.csv		Table 4. Estimated number of persons supervised by U.S. adult correctional systems, by correctional status, 2007 and 2014
cpus14t05.csv		Table 5. Change in the estimated number of persons supervised by U.S. adult correctional systems, 2000�2007 and 2007�2014 
cpus14t06.csv     	Table 6. Estimated number of offenders with multiple correctional statuses at yearend, by correctional status, 2000�2014 

     Figures
cpus14f01.csv	    	Figure 1. Estimated total population under the supervision of U.S. adult correctional systems, by correctional status, 2000�2014
cpus14f02.csv           Figure 2. Estimated number and rate of persons supervised by U.S. adult correctional systems, 2000�2014
cpus14f03.csv           Figure 3. Estimated total population supervised by U.S. adult correctional systems, by jurisdiction, 2014
cpus14f04.csv	        Figure 4. Estimated adult correctional supervision rate, by jurisdiction, 2014
cpus14f05.csv           Figure 5. Distribution of correctional population, by correctional status and jurisdiction, 2014

     Appendix Tables 
cpus14at01.csv    	Appendix table 1. Estimated number and rate of persons supervised by U.S. adult correctional systems, by correctional status and jurisdiction, 2014
cpus14at02.csv    	Appendix table 2. Estimated number and rate of persons supervised by U.S. adult correctional systems, by sex and jurisdiction, 2013 and 2014
cpus14at03.csv    	Appendix table 3. Estimated number of persons supervised by U.S. adult correctional systems, by correctional status and jurisdiction, 1999, 2005, and 2013
cpus14at04.csv		Appendix table 4. Number of inmates incarcerated by other adult correctional systems, 2000, 2005, and 2013�2014
cpus14at05.csv          Appendix table 5. Inmates held in custody in state or federal prisons or local jails, 2000 and 2013�2014
cpus14at06.csv          Appendix table 6. Estimated standard errors for local jail inmates, 2000 and 2005�2014


