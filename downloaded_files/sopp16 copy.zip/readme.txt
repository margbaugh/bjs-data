Sheriffs' Offices: Policies and Procedures, 2016  NCJ 254830			
			
This zip archive contains tables in individual  .csv spreadsheets			
Sheriffs' Offices: Policies and Procedures, 2016  NCJ 254830  The full report including text			
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7007			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
https://www.bjs.gov/index.cfm?ty=pbse&sid=45			
			
Filename	Table title	
sopp16t01.csv	Table 1. Percent of sheriffs� offices that maintained a written community-policing plan, by size of office, 2016		
sopp16t02.csv	Table 2. Annual operating budget of sheriffs� offices, by size of office, 2016		
sopp16t03.csv	Table 3. Percent of sheriffs� offices that required annual in-service training of patrol and field officers, by size of office, 2016		
sopp16t04.csv	Table 4. Percent of sheriffs� offices with written policies or procedural directives, by selected topic and size of office, 2016		
sopp16t05.csv	Table 5. Percent of sheriffs� offices that required written documentation when officers displayed or discharged firearms, by size of office, 2016		
sopp16t06.csv	Table 6. Percent of sheriffs� offices that authorized less-lethal techniques or restraints, by size of office, 2016		
sopp16t07.csv	Table 7. Percent of sheriffs� offices that authorized less-lethal weapons, by size of office, 2016		
sopp16t08.csv	Table 8. Percent of sheriffs� offices requiring external investigation of deaths or uses of force, by size of office, 2016		
sopp16t09.csv	Table 9. Percent of sheriffs� offices with a civilian-complaint review board, by size of office, 2016		
			
		Figure
sopp16f01.csv	Figure 1. Average number of training hours required of each new officer recruit in sheriffs� offices, by size of office, 2016		
			
		Appendix tables
sopp16at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Average number of training hours required of each new officer recruit in sheriffs� offices, by size of office, 2016		
sopp16at02.csv	Appendix table 2. Standard errors for table 1: Percent of sheriffs� offices that maintained a written community-policing plan, by size of office, 2016		
sopp16at03.csv	Appendix table 3. Standard errors for table 2: Annual operating budget of sheriffs� offices, by size of office, 2016		
sopp16at04.csv	Appendix table 4. Standard errors for table 3: Percent of sheriffs� offices that required annual in-service training of patrol and field officers, by size of office, 2016		
sopp16at05.csv	Appendix table 5. Standard errors for table 4: Percent of sheriffs� offices with written policies or procedural directives, by selected topic and size of office, 2016		
sopp16at06.csv	Appendix table 6. Standard errors for table 5: Percent of sheriffs� offices that required written documentation when officers displayed or discharged firearms, by size of office, 2016		
sopp16at07.csv	Appendix table 7. Standard errors for table 6: Percent of sheriffs� offices that authorized less-lethal techniques or restraints, by size of office, 2016		
sopp16at08.csv	Appendix table 8. Standard errors for table 7: Percent of sheriffs� offices that authorized less-lethal weapons, by size of office, 2016		
sopp16at09.csv	Appendix table 9. Standard errors for table 8: Percent of sheriffs� offices requiring external investigation of deaths or uses of force, by size of office, 2016		
sopp16at10.csv	Appendix table 10. Standard errors for table 9: Percent of sheriffs� offices with a civilian-complaint review board, by size of office, 2016		
