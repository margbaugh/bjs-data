Services for Crime Victims, 2019  NCJ 300741	
	
This zip archive contains tables in individual .csv spreadsheets	
from Services for Crime Victims, 2019  NCJ 300741	
The full report including text and graphics in .pdf format is available at	
https://bjs.ojp.gov/library/publications/services-crime-victims-2019	
	
Filename	Table titles
scv19t01.csv	Table 1. Percent of nonprofit or faith-based victim service providers, by most common services provided in the past year, 2019
scv19t02.csv	Table 2. Percent of governmental victim service providers, by most common services provided in the past year, 2019
scv19t03.csv	Table 3. Percent of hospital, medical, or emergency victim service providers, by most common services provided in the past year, 2019
scv19t04.csv	Table 4. Percent of campus victim service providers, by most common services provided in the past year, 2019
scv19t05.csv	Table 5. Percent of tribal victim service providers, by most common services provided in the past year, 2019
scv19t06.csv	Table 6. Percent of victim service providers, by type of provider and services that were difficult for victims to obtain in the local area, 2019
scv19t07.csv	Table 7. Percent of victim service providers, by most common source of victim referral, 2019
	
		Figures
scv19f01.csv	Figure 1. Average number of services provided, by type of victim service provider, 2019
scv19f02.csv	Figure 2. Top-five services provided by victim service providers in the past year, 2019
	
		Appendix tables
scv19at01.csv	Appendix Table 1. Average and median number of services provided, by type of victim service provider, 2019
scv19at02.csv	Appendix Table 2. Percent of victim service providers, by type of services provided in the past year, 2019
scv19at03.csv	Appendix Table 3. Percent of victim service providers, by type of provider and most common services provided in the past year, 2019
scv19at04.csv	Appendix Table 4. Estimates and standard errors for figure 1: Average number of services provided, by type of victim service provider, 2019
scv19at05.csv	Appendix Table 5. Estimates and standard errors for figure 2: Top-five services provided by victim service providers in the past year, 2019
scv19at06.csv	Appendix Table 6. Standard errors for table 6: Percent of victim service providers, by type of provider and services that were difficult for victims to obtain in the local area, 2019
scv19at07.csv	Appendix Table 7. Standard errors for appendix table 1: Average number of services provided, by type of victim service provider, 2019
scv19at08.csv	Appendix Table 8. Standard errors for appendix table 3: Percent of victim service providers, by type of provider and most common services provided in the past year, 2019
