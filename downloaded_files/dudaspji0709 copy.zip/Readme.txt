Drug Use, Dependence, and Abuse Among State Prisoners and Jail Inmates, 2007-2009. NCJ 250546		
		
This zip archive contains tables in individual .csv spreadsheets		
from Drug Use, Dependence, and Abuse Among State Prisoners and Jail Inmates, 2007-2009. NCJ 250546		
The full report including text and graphics in .pdf format is available at		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=5966		
		
File name				Table number
dudaspji0709t01.csv			State prisoners and sentenced jail inmates who met the criteria for drug dependence or abuse, 2007?2009
dudaspji0709t02.csv      		Drug dependence and abuse among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709t03.csv      		Drug dependence and abuse among state prisoners and general population groups, by criminal justice system involvement, 2007?2009
dudaspji0709t04.csv      		Drug dependence and abuse among sentenced jail inmates and general population groups, by criminal justice involvement, 2007?2009
dudaspji0709t05.csv      		State prisoners and sentenced jail inmates who had ever used or regularly used drugs, by drug type, 2002, 2004, and 2007?2009
dudaspji0709t06.csv      		State prisoners and sentenced jail inmates who used drugs at time of offense, by drug type, 2007?2009
dudaspji0709t07.csv      		State prisoners and sentenced jail inmates who committed offense to get money for drugs, by type of offense, 2007? 2009
dudaspji0709t08.csv      		Drug use in month before offense and at the time of offense among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709t09.csv     		Regular cocaine/crack use among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709t10.csv      		Regular use of methamphetamine among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709t11.csv      		Regular use of heroin/opiates among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709t12.csv     		Drug use among state prisoners and general population groups in the month before based on criminal justice system involvement in the past year, by drug type, 2007?2009
dudaspji0709t13.csv      		Drug use among sentenced jail inmates and general population groups in the month before based on criminal justice system involvement in the past year, by drug type, 2007?2009
dudaspji0709t14.csv      		Participation in drug treatment programs since admission among state prisoners and sentenced jail inmates who met drug dependence or abuse criteria, 2007?2009
dudaspji0709t15.csv      		Participation in drug treatment programs since arrival to current facility among state prisoners and sentenced jail inmates who met drug dependence or abuse criteria, by time served, 2007?2009
dudaspji0709t16.csv      		Drug treatment program participation in the past year among the general population who met drug dependence or abuse criteria, by location and involvement in criminal justice system, 2007?2009
dudaspji0709t17.csv      		State prisoners and sentenced jail inmates who answered affirmatively to dependence symptoms, by symptom type and number of symptoms, 2007?2009
dudaspji0709t18.csv     		State prisoners and sentenced jail inmates who answered affirmatively to abuse symptoms, by symptom type and number of symptoms, 2007?2009
		
File name				Figures
dudaspji0709f1.csv      		Inmates and adult general population who met the criteria for drug dependence or abuse, 2007?2009
dudaspji0709f2.csv      		Regular drug use among state prisoners, by race and Hispanic origin, 2007?2009
dudaspji0709f3.csv     			Regular drug use among sentenced jail inmates, by race and Hispanic origin, 2007?2009
dudaspji0709f4.csv      		Drug use in adult general population who had ever used drugs, 2002?2004 and 2007?2009
dudaspji0709f5.csv      		Drug use in adult general population who regularly used drugs, 2002?2004 and 2007?2009
		
File name				Appendix tables
dudaspji0709at01.csv			Standard errors for figure 1: Inmates and adult general population who met the criteria for drug dependence or abuse, 2007?2009
dudaspji0709at02.csv			Standard errors for table 1: State prisoners and sentenced jail inmates who met the criteria for drug dependence or abuse, 2007?2009
dudaspji0709at03.csv			Standard errors for table 2: Drug dependence and abuse among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709at04.csv			Standard errors  for table 3: Drug dependence and abuse among state prisoners and general population groups, by criminal justice system involvement, 2007?2009
dudaspji0709at05.csv			Standard errors for table 4: Drug dependence and abuse among sentenced jail inmates and general population groups, by criminal justice involvement, 2007?2009
dudaspji0709at06.csv			Standard errors for table 5: State prisoners and sentenced jail inmates who had ever used or regularly used drugs, by drug type, 2002, 2004, and 2007?2009
dudaspji0709at07.csv			Standard errors for table 6: State prisoners and sentenced jail inmates who used drugs at time of offense, by drug type, 2007?2009
dudaspji0709at08.csv			Standard errors for table 7: State prisoners and sentenced jail inmates who committed offense to get money for drugs, by type of offense, 2007?2009
dudaspji0709at9.csv			Standard errors for table 8: Drug use in month before offense and at the time of offense among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709at10.csv			Standard errors for figure 2: Regular drug use among state prisoners, by race and Hispanic origin, 2007?2009
dudaspji0709at11.csv			Standard errors for figure 3: Regular drug use among sentenced jail inmates, by race and Hispanic origin, 2007?2009
dudaspji0709at12.csv			Standard errors for table 9: Regular cocaine/crack use among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009 
dudaspji0709at13.csv			Standard errors for table 10: Regular use of methamphetamine among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709at14.csv			Standard errors for table 11: Regular use of heroin/opiates among state prisoners and sentenced jail inmates, by selected characteristics, 2007?2009
dudaspji0709at15.csv			Standard errors for figure 4: Drug use in adult general population who had ever used drugs, 2002?2004 and 2007?2009
dudaspji0709at16.csv			Standard errors for figure 5: Drug use in adult general population who regularly used drugs, 2002?2004 and 2007?2009
dudaspji0709at17.csv			Standard errors for table 12: Drug use among state prisoners and general population groups in the month before based on involvement in the criminal justice system in the past year, by drug type, 2007?2009
dudaspji0709at18.csv			Standard errors for table 13: Drug use among sentenced jail inmates and general population groups in the month before based on involvement in the criminal justice system in the past year, by drug type, 2007?2009
dudaspji0709at19.csv			Standard errors for table 14: Participation in drug treatment programs since admission among state prisoners and sentenced jail inmates who met drug dependence or abuse criteria, 2007?2009
dudaspji0709at20.csv			Standard errors for table 15: Participation in drug treatment programs since admission to current facility among state prisoners and sentenced jail inmates who met drug dependence or abuse criteria, by time served, 2007?2009
dudaspji0709at21.csv			Standard errors for table 16: Drug treatment program participation in the past year among the general population who met drug dependence or abuse criteria, by location and involvement in criminal justice system, 2007?2009
dudaspji0709at22.csv			Standard errors for table 17: State prisoners and sentenced jail inmates who answered affirmatively to dependence symptoms, by symptom type and number of symptoms, 2007?2009
dudaspji0709at23.csv			Standard errors for table 18: State prisoners and sentenced jail inmates who answered affirmatively to abuse symptoms, by symptom type and number of symptoms, 2007?2009
