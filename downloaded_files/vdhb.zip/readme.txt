Victimization During Household Burglary      NCJ 227379			

This zip archive contains tables in individual  .csv spreadsheets			
from Victimization During Household Burglary, NCJ 227379.  The full report including text			
and graphics in pdf format are available from: http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2172


Filename			Table title
vdhbt01.csv			Table  1:   Household burglaries, by type, 2003�2007
vdhbt02.csv			Table  2:   Average annual household burglary, by household composition and head of household characteristics, 2003�2007
vdhbt03.csv			Table  3:   Average annual household burglary, by household income and ownership, 2003�2007
vdhbt04.csv			Table  4:   Average annual household burglary, by type of housing and number of units in the structure, 2003�2007 
vdhbt05.csv			Table  5:   Method of entry and type of damage in completed household burglary involving forcible entry, 2003�2007
vdhbt06.csv			Table  6:   Method of entry and type of damage in attempted household burglary involving forcible entry, 2003�2007 
vdhbt07.csv			Table  7:   Method of entry in household burglary involving unlawful entry, by presence of household member, 2003�2007  
vdhbt08.csv			Table  8:   Victim activity during household burglaries, by presence of household member, 2003�2007  
vdhbt09.csv			Table  9:   Time of occurrence of household burglaries, by presence of household member, 2003�2007
vdhbt10.csv			Table 10:   Type of items taken, 2003�2007 
vdhbt11.csv			Table 11:   Economic loss in household burglaries where property was stolen, 2003-2007 
vdhbt12.csv			Table 12:   Household burglary reported to police, by type of entry, 2003�2007 
vdhbt13.csv			Table 13:   Reasons for not reporting household burglary to police, by presence of household member, 2003�2007
vdhbt14.csv			Table 14:   Household burglary of occupied residences, by victim-offender relationship, 2003�2007
vdhbt15.csv			Table 15:   Type of violence that occurred during household burglaries, by type of burglary, 2003�2007  
vdhbt16.csv			Table 16:   Type of violence that occurred during household burglaries when someone was home, by type of burglary, 2003�2007  
vdhbt17.csv			Table 17:   Victim-offender relationship in violent household burglary, 2003�2007
vdhbt18.csv			Table 18:   Presence of weapon in violent household burglary, by type of burglary, 
vdhbt19.csv			Table 19:   Presence of weapons in violent household burglary committed by a stranger, by type of burglary, 2003�2007
vdhbt20.csv			Table 20:   Injury in violent household burglary, by type of burglary, 2003�2007 

vdhbat01.csv			Appendix table 1:   Standard errors and confidence intervals for key estimates in Victimization during household burglary

Figures
vdhbf01.csv			Figure   1:   Number and percent distribution of household burglaries, 2003�2007
vdhbf02.csv			Figure   2:   Household burglary, 2000-2007

