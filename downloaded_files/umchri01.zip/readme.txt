Use and Management of Criminal History Record Information:  A Comprehensive Report, 2001 Update   NCJ  187670
 
This zip archive contains tables in individual .wk1 spreadsheets
from Use and Management of Criminal History Record Information:
A Comprehensive Report, 2001 Update   NCJ  187670
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/muchri01.htm
 
Filename             Table Title
umchri01.wk1         Appendix 1: Statutes making possession of a firearm by a convicted felon a criminal offense
umchri02.wk1         Appendix 2: Statutes requiring or permitting prior criminal records to be considered in bail decisions
umchri03.wk1         Appendix 3: Statutes authorizing sentencing of persistent recidivists to enhanced terms as career criminals or habitual criminals
umchri04.wk1         Appendix 4: Statutes providing for upgraded charges for offenders with prior convictions
umchri05.wk1         Appendix 5: Statutes providing for enhanced sentences for offenders with prior convictions
umchri06.wk1         Appendix 6: Statutes authorizing consideration of criminal history in correctional classification and supervision
umchri07.wk1         Appendix 7: Statutes providing that parole eligibility shall or may be affected by prior convictions
umchri08.wk1         Appendix 8: Arrest records with fingerprints, 1989 and 1992
umchri09.wk1         Appendix 9: Overview of State criminal history record systems, December 31, 1999
umchri10.wk1         Appendix 10: Automation of master name index and criminal history file, 1989, 1993, 1997 and 1999
umchri11.wk1         Appendix 11: Number of subjects (individual offenders) in State criminal history file, 1995, 1997 and 1999
umchri12.wk1         Appendix 12: Number of final dispositions reported to State criminal history repository, 1993, 1995, 1997 and 1999
umchri13.wk1         Appendix 13: Arrest records with fingerprints, 1989, 1993, 1997 and 1999
umchri14.wk1         Appendix 14: Notice to State criminal history repository of release of arrested persons without charging, 1989, 1993, 1997 and 1999
umchri15.wk1         Appendix 15: Average number of days to process arrest data submitted to State criminal history repository and current status of backlog, 1999
umchri16.wk1         Appendix 16: Average number of days to process disposition data submitted to State criminal history [repository] and current status of backlog,
umchri17.wk1         Appendix 17: Methods to link disposition information to arrest/charge information on criminal history record, 1999
umchri18.wk1         Appendix 18: Data quality audits of State criminal history repository, 1999
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
