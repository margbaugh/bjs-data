JUSTICE EXPENDITURE AND EMPLOYMENT TRENDS SINCE 1980

This zip archive contains tables in individual .wk1
spreadsheets presenting national trends since 1980 
from the Justice Expenditure and Employment Extracts
(CJEE Extracts) series and .txt files providing supporting
documentation.

Text files:

CJEEHIST.TXT - an overview of the BJS Justice
Expenditure and Employment series since 1971.

CJEEMETH.TXT - a description of how the data were
collected, reviewed and adjusted.  It presents data
limitations and how the data may differ from other
sources.

CJEEDEF.TXT  - definitions of terms and concepts used
in the spreadsheets, including definitions of types of
governments, population used, and governmental
expenditure, employment, and functions.

CJEECOMP.TXT - important comparability issues between
the CJEE Extracts data and data from the CJEE Surveys
that the CJEE Extracts program replaced. 


Spreadsheets:

eetrnd01.wk1   Table 1. Total direct and intergovernmental 
		expenditure by level of government, fiscal 
		years 1982-99

eetrnd02.wk1   Table 2.  Total direct expenditure by level 
		of government, fiscal years 1982-99

eetrnd03.wk1   Table 3.  Total employees by level of government, 
		1982-99

eetrnd04.wk1   Table 4.  One-month payroll by level of government, 
		1982-99

eetrnd05.wk1   Table 5.  Total direct and intergovernmental 
		expenditure, by activity and level of government, 
		fiscal years 1980-99

eetrnd06.wk1   Table 6.  Total direct expenditure, by activity and 
		level of government, fiscal years 1980-99

eetrnd07.wk1   Table 7.  Total employees, by activity and level of 
	       government, 1980-99

eetrnd08.wk1   Table 8.  One-month payroll, by activity and level 
		of government, 1980-99

eetrnd09.wk1   Table 9.  Total police full-time equivalent 
		employees, sworn police full-time equivalent 
		employees, and percent sworn of all police 
		employees, by level of government, 1980-99

eetrnd10.wk1   Table 10.  State government direct corrections 
		expenditures for institutions and other corrections, 
		fiscal years 1980-1999

eetrnd11.wk1   Table 11.  Per capita total justice expenditure by
	       	activity for all governments, fiscal years 1980-99

eetrnd12.wk1   Table 12.  Total justice employment per 10,000 
		population by activity, for all governments, 
		1980-1999

