Profile of Prison Inmates, 2016: Survey of Prison Inmates   NCJ 255037	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Profile of Prison Inmates, 2016: Survey of Prison Inmates   NCJ 255037.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/profile-prison-inmates-2016
	
Filenames	Table names
ppi16t01.csv	Table 1. Percent of all prisoners in the United States, federal prisoners, and state prisoners, by demographic characteristics, 2004 and 2016
ppi16t02.csv	Table 2. Percent of all prisoners in the United States, federal prisoners, and state prisoners, by selected characteristics, 2004 and 2016
ppi16t03.csv	Table 3. Percent of all prisoners in the United States, federal prisoners, and state prisoners, by controlling offense, 2004 and 2016
ppi16t04.csv	Table 4. Percent of all prisoners in the United States, federal prisoners, and state prisoners, by controlling offense and sex, 2016
ppi16t05.csv	Table 5. Percent of all prisoners in the United States, by criminal history and sex, 2016
ppi16t06.csv	Table 6. Percent of federal and state prisoners, by criminal history and sex, 2016
ppi16t07.csv	Table 7. Percent of federal and state prisoners, by criminal history and race or ethnicity, 2016
ppi16t08.csv	Table 8. Percent of federal and state prisoners, by selected characteristics and data source, 2016
ppi16t09.csv	Table 9. Percent of all prisoners in the United States, by sentence length, time served, and sex, 2016
ppi16t10.csv	Table 10. Percent of federal and state prisoners, by sentence length, time served, and sex, 2016
ppi16t11.csv	Table 11. Percent of federal and state prisoners, by time left to expected release and sex, 2016
ppi16t12.csv	Table 12. Percent of all prisoners in the United States, federal prisoners, and state prisoners, by housing characteristics prior to arrest, 2016
ppi16t13.csv	Table 13. Percent of all prisoners in the United States, federal prisoners, and state prisoners, by family background while growing up, 2016
ppi16t14.csv	Table 14. Number of facilities and prisoners sampled in the Survey of Prison Inmates, by outcome and jurisdiction, 2016
	
		Figures
ppi16f01.csv	Figure 1. Percent of all prisoners in the United States, by number of prior incarcerations, 2016
ppi16f02.csv	Figure 2. Percent of state prisoners, by type of special condition of sentence, 2016
ppi16f03.csv	Figure 3. Percent of federal prisoners, by type of special condition of sentence, 2016
	
		Appendix tables
ppi16at01.csv	Appendix table 1. Percentages and standard errors for figure 1: Percent of all prisoners in the United States, by number of prior incarcerations, 2016
ppi16at02.csv	Appendix table 2. Standard errors for table 1: Percent of all prisoners in the United States, federal prisoners, and state prisoners, by demographic characteristics, 2004 and 2016
ppi16at03.csv	Appendix table 3. Standard errors for table 2: Percent of all prisoners in the United States, federal prisoners, and state prisoners, by selected characteristics, 2004 and 2016
ppi16at04.csv	Appendix table 4. Standard errors for table 3: Percent of all prisoners in the United States, federal prisoners, and state prisoners, by controlling offense, 2004 and 2016
ppi16at05.csv	Appendix table 5. Standard errors for table 4: Percent of all prisoners in the United States, federal prisoners, and state prisoners, by controlling offense and sex, 2016
ppi16at06.csv	Appendix table 6. Standard errors for table 5: Percent of all prisoners in the United States, by criminal history and sex, 2016
ppi16at07.csv	Appendix table 7. Standard errors for table 6: Percent of federal and state prisoners, by criminal history and sex, 2016
ppi16at08.csv	Appendix table 8. Standard errors for table 7: Percent of federal and state prisoners, by criminal history and race or ethnicity, 2016
ppi16at09.csv	Appendix table 9. Standard errors for table 9: Percent of all prisoners in the United States, by sentence length, time served, and sex, 2016
ppi16at10.csv	Appendix table 10. Standard errors for table 10: Percent of federal and state prisoners, by sentence length, time served, and sex, 2016
ppi16at11.csv	Appendix table 11. Percentages and standard errors for figure 2: Percent of state prisoners, by type of special condition of sentence, 2016
ppi16at12.csv	Appendix table 12. Percentages and standard errors for figure 3: Percent of federal prisoners, by type of special condition of sentence, 2016
ppi16at13.csv	Appendix table 13. Standard errors for table 11: Percent of federal and state prisoners, by time left to expected release and sex, 2016
ppi16at14.csv	Appendix table 14. Standard errors for table 12: Percent of all prisoners in the United States, federal prisoners, and state prisoners, by housing characteristics prior to arrest, 2016
ppi16at15.csv	Appendix table 15. Standard errors for table 13: Percent of all prisoners in the United States, federal prisoners, and state prisoners, by family background while growing up, 2016
