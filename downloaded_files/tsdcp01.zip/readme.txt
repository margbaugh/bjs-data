Traffic Stop Data Collection Policies for State Police, 2001, NCJ 191158


This zip archive contains tables in individual .wk1 spreadsheets
from Traffic Stop Data Collection Policies for State Police, 2001, NCJ 191158.
 The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/tsdcp01.htm  


File Name          Table Titles
tsdcps01.wk1       Table 1. State police agencies, by driver data collection protocols, 2001
tsdcps02.wk1       Table 2. State police agencies that required the collection of information in
                    addition to the driver's race and ethnicity, 2001
tsdcps03.wk1       Table 3. Circumstances during traffic stops in which State police agencies
                    required troopers to collect race data about motorists, by State, 2001
 
 
