Census of Jails: Population Changes, 1999�2013 NCJ 248627	
	
This zip archive contains tables in individual .csv spreadsheets	
from Census of Jails: Population Changes, 1999�2013 NCJ 248627. The full report 	
including text and graphics in .pdf format are available from: 	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5480	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=66	
 	
Tables	
cjpc9913t01.csv	Table 1. Persons under jail supervision, by jail jurisdiction, December 31, 2013
cjpc9913t02.csv	Table 2. Inmates confined in local jails, 1999�2014
cjpc9913t03.csv	Table 3. Inmates confined in local jails, 1999, 2006, and 2013
cjpc9913t04.csv	Table 4. Confined adult local jail inmates per 100,000 adult U.S. residents, 1999 and 2013
cjpc9913t05.csv	Table 5. Confined local jail inmates, by size of jail jurisdiction, December 31, 2013
cjpc9913t06.csv	Table 6. Confined local jail inmates, by age group and sex, December 31, 2013
cjpc9913t07.csv	Table 7. Confined local jail inmates, by race or Hispanic origin, December 31, 2013
cjpc9913t08.csv	Table 8. Admissions to local jails, by size of jurisdiction, January 1�December 31, 2013 
cjpc9913t09.csv	Table 9. Average daily jail population, admissions, and expected average length of stay in local jails, January 1�December 31, 2013
cjpc9913t10.csv	Table 10. Rated capacity and percent of capacity occupied in local jails, by jurisdiction, December 31, 2013
cjpc9913t11.csv	Table 11. Correctional officers in local jails, by sex, December 31, 2013
cjpc9913t12.csv	Table 12. Number and percent change of inmates confined in local jails, 2011 and 2013
cjpc9913t13.csv	Table 13. Inmate characteristics in Federal Bureau of Prisons detention centers, December 31, 2013
cjpc9913t14.csv	Table 14. Facility characteristics of Federal Bureau of Prisons detention centers, 1999 and 2013
cjpc9913t15.csv	Table 15. Correctional officer characteristics in Federal Bureau of Prisons detention centers, December 31, 2013
	
Figure	
cjpc9913f01.csv	Figure 1. Largest jail growth, by selected states, between 2011 and 2013
