Veterans in State and Federal Prison, 2004
 
This zip archive contains tables in individual .csv spreadsheets
from Veterans in State and Federal Prison, 2004, NCJ 217199.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/vsfp04.htm

		
Filename		Appendix tables	
vsfp04at01.csv		Appendix table 1. Military service of veterans in State and Federal prison
vsfp04at02.csv		Appendix table 2. Wartime service of veteran inmates
vsfp04at03.csv		Appendix table 3. Selected characteristics of State and Federal prisoners, by veteran status, 2004
vsfp04at04.csv		Appendix Table 4. Current offense of State and Federal prisoners, by veteran status, 2004
vsfp04at05.csv		Appendix table 5. Offenders in military correctional facilities, 1997 and 2004
vsfp04at06.csv		Appendix table 6. Victim characteristics and use of weapon, by veteran status of violent State prisoners, 2004  
vsfp04at07.csv		Appendix table 7. Criminal history of State and Federal prisoners, by veteran status, 2004
vsfp04at08.csv		Appendix table 8. Maximum sentence length and time to be served until release, by veteran status, State and Federal prisoners, 2004   
vsfp04at09.csv		Appendix table 9. Drug use of State and Federal prisoners, by type of drug and veteran status, 2004  
vsfp04at10.csv		Appendix table 10. Alcohol use histories of State and Federal prisoners, by veteran status, 2004 
vsfp04at11.csv		Appendix table 11. Substance abuse treatment history of State and Federal prisoners, by veteran status, 2004 
vsfp04at12.csv		Appendix table 12. Recent history and symptoms of mental health problems among State and Federal prisoners, by veteran status, 2004   
vsfp04at13.csv		Appendix table 13. Standard errors of the estimated percentages, State prison inmates, 2004   
vsfp04at14.csv		Appendix table 14. Standard erros of the estimated percentages, Federal prison inmates, 2004

			Exhibit figure number
vsfp04exf01.csv		Exhibit figure 1. Percent of prisoners in military custody, by most serious offense, 2004

			Exhibit table number
vsfp04ext01.csv		Exhibit table 1. Incarceration rate of active duty military personnel, by branch of service, 1994-2004
vsfp04ext02.csv		Exhibit table 2. Select characteristics of veterans in State prison, by service era, 2004

			Figures
vsfp04f01.csv		Figure 1. Number of veterans in State and Federal prison, 1985-2004
vsfp04f02.csv		Figure 2. Age distribution of adult male U.S. residents, by veteran status, 2004
vsfp04f03.csv		Figure 3. Reported prior drug use of State prisoners, by veteran status, 2004

			Summary figure
vsfp04sf01.csv		Summary figure 1. Percentage of State and Federal prisoners reporting military service continues to decline, 1986-2004

			Text tables
vsfp04tt01.csv		Text table 1. Prison incarceration rate, per 100,000 adult males in the U.S. resident population, by veteran status, 2004 
vsfp04tt02.csv		Text table 2. Branch of military service of U.S. veterans, 2004
vsfp04tt03.csv		Text table 3. Selected characteristics of Federal prisoners, by veteran status, 2004
vsfp04tt04.csv		Text table 4. Selected characteristics of violent offenses committed by State prisoners, by veteran status, 2004
vsfp04tt05.csv		Text table 5. Mean maximum sentence length of State prisoners, by offense and veteran status, 2004	
vsfp04tt06.csv		Text table 6. Mean maximum sentence length of Federal prisoners by veteran status, 2004
vsfp04tt07.csv		Text table 7. Percent of prisoners meeting criteria for substance dependence or abuse by veteran status, 2004		
vsfp04tt08.csv		Text table 8. Mental health histories of veterans in State prison, by combat status, 2004
 
 
 
 
