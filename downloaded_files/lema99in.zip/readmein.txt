Bureau of Justice Statistics
Law Enforcement Management and Administrative Statistics, 1999:
Data for Individual State and Local Agencies with 100 or more Officers
By Brian A. Reaves, Ph.D. and Timothy C. Hart, BJS Statisticians

Contents of Zip archive lema99in.zip.  This file contains the tables from one section of the
report.  Additional tables are available at www.ojp.usdoj.gov/bjs/abstract/lemas99.htm.

     
lem99a.wk1  Table A.  Number of LEMAS survey respondents with 100 or more full-time sworn personnel 	
including 50 or more officers responding to calls for service*, by State and type of agency, 1999

lem99b.wk1   Table B.  Local law enforcement agencies with 1,000 or more full-time sworn personnel		
including 500 or more officers responding to calls for service, 1999	

lem99c.wk1   Table C.  Summary data for State and local law enforcement agencies	
with 100 or more officers, by type of agency, 1999	
	
	
