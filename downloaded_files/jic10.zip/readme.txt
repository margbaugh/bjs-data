Jails in Indian Country, 2010 NCJ 236073	
	
This zip archive contains tables in individual .csv spreadsheets	
from Jails in Indian Country, 2009, NCJ 236073. The full report 	
including text and graphics in .pdf format are available from: 	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2373	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=32	
 	
Tables	
jic10t01.csv	Table 1. American Indians and Alaska Natives in custody or under community supervision, 2009 and 2010
jic10t02.csv	Table 2. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, 2000, 2004 and 2007�2010
jic10t03.csv	Table 3. Jails in Indian country that held the majority of inmates in 2010 compared to 2009, by facility
jic10t04.csv	Table 4. Indian country jails and percent of inmate population, by facility size, June 2010
jic10t05.csv	Table 5. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2010
jic10t06.csv	Table 6. Jails in Indian country operating above 150% of capacity on their peak day, during June 2010
jic10t07.csv	Table 7. Admissions and expected length of stay in Indian country jails during June, by facility size, June 2010
jic10t08.csv	Table 8. Admissions and expected length of stay in 73 operating Indian country jails in both June 2009 and 2010, by facility size based on the rated capacity at midyear 2009
jic10t09.csv	Table 9. Inmates confined in Indian country jails, by demographic characteristic, conviction status, and offense, midyear 2002, 2004, and 2007�2010
jic10t10.csv	Table 10. Persons employed in Indian country jails, by job function, midyear 2010
	
Appendix tables	
jic10at01.csv	Appendix table 1. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, by facility, June 2010
jic10at02.csv	Appendix table 2. Inmates in Indian country jails, by type of offense, June 2010
jic10at03.csv	Appendix table 3. Inmates in Indian country jails, by conviction status, June 2010
jic10at04.csv	Appendix table 4. Adults and juveniles in the custody of Indian country jails, by sex, June 2010
	
Figures	
jic10f01.csv	Figure 1. Inmates confined in Indian country jails, midyear 2000�2004 and 2007�2010
jic10f02.csv	Figure 2. American Indians and Alaska Natives under correctional supervision in the United States, 2000�2010
jic10f03.csv	Figure 3. Percent of rated capacity occupied, by facility size, June 2010
