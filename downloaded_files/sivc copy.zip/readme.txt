Socio-emotional Impact of Violent Crime, 2013		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from  Socio-emotional Impact of Violent Crime, 2013  NCJ 247076		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5114		
		
		
sivcf01.csv		Figure 1. Violent crime victims who reported the crime to police or received victim services, by level of distress experienced, 2009?2012
sivcf02.csv		Figure 2. Level of distress experienced by violent crime victims, by type of problems experienced as a result of the victimization, 2009?2012
sivcf03.csv		Figure 3. Level of distress experienced by violent crime victims, by type of crime, 2009?2012
sivcf04.csv		Figure 4. Level of distress experienced by serious violent crime victims, by victim?offender relationship, 2009?2012
sivcf05.csv		Figure 5. Recency of interview, by level of distress reported, 2009?2012
		
sivct01.csv		Table 1. Physical and emotional symptoms suffered by violent crime victims who experienced socio-emotional problems as a result of the victimization, by type of crime and victim?offender relationship, 2009?2012
sivct02.csv		Table 2. Victims who experienced socio-emotional problems as a result of the violent victimization, by type of crime and victim?offender relationship, 2009?2012 
sivct03.csv		Table 3. Victims who did and did not experience socio-emotional problems as a result of the violent victimization, by type of violent crime, 2009?2012
sivct04.csv		Table 4. Victims who experienced socio-emotional problems as a result of violent crime victimization, by location of crime and victim?offender relationship, 2009?2012
sivct05.csv		Table 5. Violent crime victims who experienced socio-emotional problems and reported the crime to police or received victim services, by victim?offender relationship, 2009?2012
sivct06.csv		Table 6. Characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by type of crime, 2009?2012
sivct07.csv		Table 7. Characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by victim?offender relationship, 2009?2012
sivct08.csv		Table 8. Household characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by type of crime, 2009?2012
sivct09.csv		Table 9. Household characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by victim?offender relationship, 2009?2012
sivct10.csv		Table 10. Logistic regression analysis of the effect of victim characteristics, type of crime, and victim?offender relationship on the probability of victims experiencing socio-emotional problems, 2009?2012
sivct11.csv		Table 11. Characteristics of incidents and victims who were and were not administered NCVS distress questions, 2009?2012
		
sivcat01.csv		Appendix table 1. Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by type of crime and incident characteristics, 2009?2012
sivcat02.csv		Appendix table 2. Standard errors for appendix table 1: Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by type of crime and incident characteristics, 2009?2012
sivcat03.csv		Appendix table 3. Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by whether victim reported to police or received victim services, 2009?2012
sivcat04.csv		Appendix table 4. Standard errors for appendix table 3: Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by whether victim reported to police or received victim services, 2009?2012
sivcat05.csv		Appendix table 5. Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by victim characteristics, 2009?2012
at06.csv		Appendix table 6. Standard errors for appendix table 5: Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by victim characteristics, 2009?2012
sivcat07.csv		Appendix table 7. Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by household characteristics, 2009?2012
sivcat08.csv		Appendix table 8. Standard errors for appendix 7: Level of distress, relationship problems, and school or work problems experienced by violent crime victims, by household characteristics, 2009?2012
sivcat09.csv		Appendix table 9. Estimates and standard errors for figure 1: Violent crime victims who reported the crime to police or received victim services, by level of distress experienced, 2009?2012
sivcat10.csv		Appendix table 10. Estimates and standard errors for figure 2: Level of distress experienced by violent crime victims, by type of problems experienced as a result of the victimization, 2009?2012
sivcat11.csv		Appendix table 11. Estimates and standard errors for figure 3: Level of distress experienced by violent crime victims, by type of crime, 2009?2012
sivcat12.csv		Appendix table 12. Estimates and standard errors for figure 4: Level of distress experienced by serious violent crime victims, by victim?offender relationship, 2009?2012
sivcat13.csv		Appendix table 13. Standard errors for table 1: Physical and emotional symptoms suffered by violent crime victims who experienced socio-emotional problems as a result of the victimization, by type of crime and victim?offender relationship, 2009?2012
sivcat14.csv		Appendix table 14. Standard errors for table 2: Victims who experienced socio-emotional problems as a result of the violent victimization, by type of crime and victim?offender relationship, 2009?2012
sivcat15.csv		Appendix table 15. Standard errors for table 3: Victims who did and did not experience socio-emotional problems as a result of the violent victimization, by type of crime, 2009?2012
sivcat16.csv		Appendix table 16. Standard errors for table 4: Victims who experienced socio-emotional problems as a result of violent crime victimization, by location of crime and victim?offender relationship, 2009?2012
sivcat17.csv		Appendix table 17. Standard errors for table 5: Violent crime victims who experienced socio-emotional problems and reported the crime to police or received victim services, by victim?offender relationship, 2009?2012
sivcat18.csv		Appendix table 18. Standard errors for table 6: Characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by type of crime, 2009?2012
sivcat19.csv		Appendix table 19. Standard errors for table 7: Characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by victim?offender relationship, 2009?2012
sivcat20.csv		Appendix table 20. Standard errors for table 8: Household characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by type of crime, 2009?2012
sivcat21.csv		Appendix table 21. Standard errors for table 9: Household characteristics of violent crime victims who experienced socio-emotional problems as a result of the victimization, by victim?offender relationship, 2009?2012
sivcat22.csv		Appendix table 22. Coefficients and standard errors for table 10: Logistic regression analysis of the effect of victim characteristics, type of crime, and victim?offender relationship on the probability of victims experiencing socio-emotional problems, 2009?2012
sivcat23.csv		Appendix table 23. Standard errors for table 11: Characteristics of incidents and victims who were and were not administered NCVS distress questions, 2009?2012
sivcat24.csv		Appendix table 24. Estimates and standard errors for figure 5: Recency of interview, by level of distress reported, 2009?2012
