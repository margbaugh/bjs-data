Capital Punishment, 2020 – Statistical Tables   NCJ 302729	
	
This zip archive contains tables in individual .csv spreadsheets	
from Capital Punishment, 2020 – Statistical Tables   NCJ 302729.	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/capital-punishment-2020-statistical-tables
	
These statistical tables are in a series.  More recent editions	
may be available. To view a list of all reports in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Capital%20Punishment	
	
Filenames	Table names
cp20stt01.csv	Table 1. Status of the death penalty, December 31, 2020
cp20stt02.csv	Table 2. Capital offenses, by state, 2020
cp20stt03.csv	Table 3. Federal capital offenses, 2020
cp20stt04.csv	Table 4. Authorized method of execution, by state, 2020
cp20stt05.csv	Table 5. Prisoners under sentence of death, by region, jurisdiction, and race, 2019 and 2020
cp20stt06.csv	Table 6. Demographic characteristics of prisoners under sentence of death, 2020
cp20stt07.csv	Table 7. Female prisoners under sentence of death, by region, jurisdiction, and race, 2019 and 2020
cp20stt08.csv	Table 8. Hispanic prisoners under sentence of death, by region and jurisdiction, 2019 and 2020
cp20stt09.csv	Table 9. Criminal history of prisoners under sentence of death, by race or ethnicity, 2020
cp20stt10.csv	Table 10. Prisoners under sentence of death on December 31, 2020, by year of sentencing and jurisdiction
cp20stt11.csv	Table 11. Prisoners removed from under sentence of death, by region, jurisdiction, and method of removal, 2020
cp20stt12.csv	Table 12. Average elapsed time between sentencing and execution, 1977–2020
cp20stt13.csv	Table 13. Number of prisoners executed, by race or ethnicity, 1977–2020
cp20stt14.csv	Table 14. Number of executions, by method and jurisdiction, 1977–2020
cp20stt15.csv	Table 15. Number of executions, by jurisdiction, 1930–2020 and 1977–2020
	
		Figures
cp20stf01.csv	Figure 1. Number of persons under sentence of death, 1953–2020
cp20stf02.csv	Figure 2. Admissions to and removals from under sentence of death, 1973–2020
cp20stf03.csv	Figure 3. Number of persons executed in the United States, 1930–2020
cp20stf04.csv	Figure 4. Number of prisoners under sentence of death, by race, 1968–2020
cp20stf05.csv	Figure 5. Advance count of executions, January 1, 2021–December 9, 2021
	
		Appendix tables
cp20stat01.csv	Appendix table 1. Demographic characteristics for prisoners under sentence of death, 2020
cp20stat02.csv	Appendix table 2. Counts for figure 1: Number of persons under sentence of death, 1953–2020
cp20stat03.csv	Appendix table 3. Counts for figure 2: Admissions to and removals from under sentence of death, 1973–2020
cp20stat04.csv	Appendix table 4. Counts for figure 3: Number of persons executed in the United States, 1930–2020
cp20stat05.csv	Appendix table 5. Counts for figure 4: Number of prisoners under sentence of death, by race, 1968–2020
