State Court Organization, 2011  NCJ 242850

This zip archive contains tables in individual .csv spreadsheets from State Court Organization, 2011, NCJ 242850.
The full report including text and graphics in pdf format are available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4775

This report is one in a series. More recent editions may be available. To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=47



sco11at01.csv	Appendix Table:	1	Number of appellate court judges in 50 states and the District of Columbia, 2011
sco11at02.csv	Appendix Table:	2	Number of trial court judges in 50 states and the District of Columbia, 2011

sco11f01.csv	Figure:	1	Number of state trial court judges and rate per 100,000 U.S. residents, 1980�2011
sco11f02.csv	Figure: 2	Different structures of trial and appellate state organization in California and Georgia, 2011	


sco11t01.csv	Table: 1	Appellate and trial court structure for 50 states and the District of Columbia, 1980, 1987, 1993, 1998, 2004, and 2011		
sco11t02.csv	Table: 2	Jurisdictional levels of appellate and trial court judges for 50 states and the District of Columbia, 1980, 1987, 1993, 1998, 2004, and 2011
sco11t03.csv	Table: 3	Number of state trial and appellate court judges in 50 states and the District of Columbia, by court type, 1980, 1987, 1993, 1998, 2004, and 2011
sco11t04.csv	Table: 4	Legal qualifications to serve as trial court judge for 50 states and the District of Columbia, by trial courts of general and limited jurisdiction, 2011
sco11t05.csv	Table: 5	Selection of appellate and general jurisdiction trial court judges for initial and subsequent judicial terms for 50 states and the District of Columbia, 2011
sco11t06.csv	Table: 6	Methods of judicial selection in state appellate and trial courts of general jurisdiction for 50 states and the District of Columbia, 1987 and 2011
sco11t07.csv	Table: 7	Length of judicial terms for 47 states and the District of Columbia in state appellate and trial courts of general jurisdiction, by retention methods, 2011
sco11t08.csv	Table: 8	Trial court funding sources for selected expenditure items for 50 states and the District of Columbia, 2011
sco11t09.csv	Table: 9	Responsibilities and functions of administrative offices of the courts (AOCs) for 48 states and the District of Columbia, 2011
sco11t10.csv	Table: 10	Jury size and unanimous verdict requirements for trial courts in 50 states and the District of Columbia, 2011


	

