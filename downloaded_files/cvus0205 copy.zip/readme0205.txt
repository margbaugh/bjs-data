Criminal Victimization in the United States, 2002   NCJ# 200561
 
This zip archive contains tables in individual .wk1 spreadsheets
from the 2002 National Crime Victimization Survey.
It is one of  a series of files from the National Crime Victimization Survey.
All of the files may be obtained from http://www.ojp.usdoj.gov/bjs/abstract/cvus.htm
Six sections are archived -- demography of victims, victims and offenders, geography, crime
event,
victims and the criminal justice system, and series victimizations
 
 
Text files: 
cvusmet.txt --detailed information about the National Crime Victimization Survey and the results
                      from the data collection throughout United States (Methodology). 

Spreadsheets
 
File Name    Table Titles 
        
             VICTIMS AND THE CRIMINAL JUSTICE SYSTEM
cv0291.wk1   Table 91: Percent distribution of victimizations, by type of crime and whether or     
                                        not reported to the police
cv0291b.wk1  Table 91b: Percent of victimizations reported to the police, by type of crime and     
                                          gender and race or ethnicity of victims
cv0292.wk1   Table 92: Percent of victimizations reported to the police, by selected                       
                                       characteristics of victims and type of crime
cv0293.wk1   Table 93: Percent of victimizations reported to the police, by type of crime, victim
                  -offender relationship and gender of victims
cv0293a.wk1  Table 93a: Number and percent distribution of victimizations reported to the           
                                          police, by type of crime, and gender of head of household
cv0294.wk1   Table 94: Percent of victimizations reported to the police, by type of crime, victim
                  -offender relationship and race of victims
cv0295.wk1   Table 95: Percent of victimizations reported to the police, by type of crime, victim
                  -offender relationship and ethnicity of victims
cv0296.wk1   Table 96: Percent of victimizations reported to the police, by type of crime and age 
                                       of victims
cv0297.wk1   Table 97: Percent of victimizations reported to the police, by type of crime, form     
                                       of tenure, and race and ethnicity of head of household
cv0298.wk1   Table 98: Percent of victimizations reported to the police, by type of crime and        
                                       form of tenure
cv0299.wk1   Table 99: Percent of victimizations reported to the police, by type of crime and        
                                       annual family income
cv02100.wk1  Table 100: Percent of victimizations reported to the police, by value of loss and      
                                          type of crime
cv02101.wk1  Table 101: Percent of reasons for reporting victimizations to the police, by type of
                     crime
cv02102.wk1  Table 102: Percent of reasons for not reporting victimizations to the police, by        
                                          type of crime
cv02103.wk1  Table 103: Percent of reasons for not reporting victimizations to the police, by        
                                          race of victims and type of crime
cv02104.wk1  Table 104: Percent of reasons for not reporting victimizations to the police, by        
                                          victim-offender relationship and type of crime
cv02105.wk1  Table 105: Percent of reasons for not reporting victimizations to the police, by        
                                          race of head of household and type of crime
cv02106.wk1  Table 106: Percent distribution of police response to a reported incident, by type    
                                           of crime
cv02107.wk1  Table 107: Percent distribution of incidents where police came to the victim, by     
                                          police response time and type of crime
cv02108.wk1  Table 108: Percent distribution of incidents, by police activity during initial            
                                          contact with victim and type of crime
cv02109.wk1  Table 109: Percent distribution of the kind of agency providing assistance by type  
                                         of crime

Five related archives are also available.  The sections and tables of these archives are listed
below.
 
          DEMOGRAPHY  OF VICTIMS
cv0201.wk1   Table 1: Number, percent distribution, and rate of victimizations, by type of crime
cv0202.wk1   Table 2: Number of victimizations and victimization rates for persons age 12 and    
                                     over, by type of crime and gender of victims
cv0203.wk1   Table 3: Victimization rates for persons age 12 and over, by type of crime and age  
                                      of victims
cv0204.wk1   Table 4: Victimization rates for persons age 12 and over, by gender and age of         
                                      victims and type of crime
cv0205.wk1   Table 5: Number of victimizations and victimization rates for persons age 12 and    
                                     over, by type of crime and race of victims
cv0206.wk1   Table 6: Number of victimizations and victimization rates for persons age 12 and    
                                    over, by type of crime and gender and race of victims
cv0207.wk1   Table 7: Number of victimizations and victimization rates for persons age 12 and    
                                    over, by type of crime and ethnicity of victims
cv0208.wk1   Table 8: Victimization rates for persons age 12 and over, by type of crime and
                ethnicity and gender of victims
cv0209.wk1   Table 9: Victimization rates for persons age 12 and over, by race and age of             
                                     victims and type of crime
cv0210.wk1   Table 10: Number of victimizations and victimization rates for persons age 12 and  
                                       over, by race, gender, and age of victims and type of crime
cv0211.wk1   Table 11: Victimization rates for persons age 12 and over, by type of crime and       
                                        marital status of victims
cv0212.wk1   Table 12: Victimization rates for persons age 12 and over, by gender and marital     
                                        status of victims and type of crime
cv0213.wk1   Table 13: Victimization rates for persons age 12 and over, by gender of head of
                  household, relationship of victims to head and type of crime
cv0214.wk1   Table 14: Victimization rates for persons age 12 and over, by type of crime and       
                                       annual family income of victims
cv0215.wk1   Table 15: Victimization rates for persons age 12 and over, by race and annual          
                                       family income of victims and type of crime
cv0216.wk1   Table 16: Number of victimizations and victimization rates by type of crime and     
                                       race of head of household
cv0217.wk1   Table 17: Number of victimizations and victimization rates by type of crime and
                  ethnicity of head of household
cv0218.wk1   Table 18: Number of victimizations and victimization rates on the basis of thefts
                                       per 1,000 households and of thefts per 1,000 vehicles owned, by selected 
                                       household characteristics
cv0219.wk1   Table 19: Victimization rates by type of crime and age of head of household
cv0220.wk1   Table 20: Victimization rates by type of crime and annual family income
cv0221.wk1   Table 21: Victimization rates by race of head of household, annual family income   
                                       and type of household burglary
cv0222.wk1   Table 22: Victimization rates by race of head of household, annual family income   
                                       and type of theft
cv0223.wk1   Table 23: Victimization rates by race of head of household, annual family income   
                                       and type of motor vehicle theft
cv0224.wk1   Table 24: Victimization rates by type of crime and number of persons in household
cv0225.wk1   Table 25: Victimization rates by type of crime and number of units in structure
                  occupied by household
 
              VICTIMS AND OFFENDERS
cv0226.wk1   Table 26: Number of incidents and victimizations and ratio of victimizations to
                  incidents, by type of crime
cv0227.wk1   Table 27: Number and percent distribution of incidents, by type of crime and           
                                       victim-offender relationship
cv0228.wk1   Table 28: Number of victimizations and victimization rates for persons age 12 and  
                                       over, by type of crime and victim-offender relationship
cv0229.wk1   Table 29: Percent of victimizations involving strangers, by gender and age of           
                                       victims and type of crime
cv0230.wk1   Table 30: Percent of victimizations involving strangers, by gender and race of         
                                        victims and type of crime
cv0231.wk1   Table 31: Percent of victimizations involving strangers, by gender and marital         
                                       status of victims and type of crime
cv0232.wk1   Table 32: Percent distribution of victimizations, by perceived drug or alcohol use    
                                       by offender
cv0233.wk1   Table 33: Number of victimizations, by type of crime and relationship to offender
cv0234.wk1   Table 34: Percent distribution of victimizations, by type of crime and relationship   
                                        to offender
cv0235.wk1   Table 35: Victimization rate by victim-offender relationship, by type of crime and
                  selected victim characteristics
cv0236.wk1   Table 36: Percent distribution of incidents, by type of crime and number of victims
cv0237.wk1   Table 37: Percent distribution of incidents, by victim-offender relationship, type of
                  crime and number of offenders
cv0238.wk1   Table 38: Percent distribution of single-offender victimizations, by type of crime     
                                       and perceived gender of offender
cv0239.wk1   Table 39: Percent distribution of single-offender victimizations, by type of crime     
                                       and perceived age of offender
cv0240.wk1   Table 40: Percent distribution of single-offender victimizations, by type of crime     
                                       and perceived race of offender
cv0241.wk1   Table 41: Percent distribution of single-offender victimizations, by type of crime,    
                                       age of victims and perceived age of offender
cv0242.wk1   Table 42: Percent distribution of single-offender victimizations, based on race of
                  victims, by type of crime and perceived race of offender
cv0243.wk1   Table 43: Percent distribution of single-offender victimizations, by type of crime     
                                       and detailed victim-offender relationship
cv0243a.wk1  Table 43a: Percent distribution of victimizations, by characteristics of victims,
                                          type of crime, and victim/offender relationship
cv0244.wk1   Table 44: Percent distribution of multiple-offender victimizations, by type of crime
                  and perceived gender of offender
cv0245.wk1   Table 45: Percent distribution of multiple-offender victimizations, by type of crime
                  and perceived age of  offenders
cv0246.wk1   Table 46: Percent distribution of multiple-offender victimizations, by type of crime
                  and perceived race of offenders
cv0247.wk1   Table 47: Percent distribution of multiple-offender victimizations, by type of           
                                       crime, age of victims and perceived age of offenders
cv0248.wk1   Table 48: Percent distribution of multiple-offender victimizations, by type of           
                                       crime, race of victims and perceived race of offenders
cv0249.wk1   Table 49: Percent distribution of multiple-offender victimizations, by type of crime
                  and detailed victim-offender relationship
 
             GEOGRAPHY
cv0250.wk1   Table 50: Victimization rates for persons age 12 and over, by type of crime and       
                                       number of years lived at current residence
cv0251.wk1   Table 51: Victimization rates by type of crime and number of years lived at current
                  residence
cv0252.wk1   Table 52: Victimization rates for persons age 12 and over, by type of crime and
                  locality of residence of victims
cv0253.wk1   Table 53: Victimization rates, by type of crime and locality of residence
cv0254.wk1   Table 54: Victimization rates for persons age 12 and over, by locality of residence,
                  race, gender and ethnicity of victims and type of crime
cv0255.wk1   Table 55: Victimization rates by locality of residence, race of head of household      
                                       and type of crime
cv0256.wk1   Table 56: Victimization rates by type of crime, form of tenure, race of head of
                                 household, and locality of residence
cv0257.wk1   Table 57: Victimization rates for persons age 12 and over, by type of crime, region 
                                        and locality of residence
cv0258.wk1   Table 58: Victimization rates by type of crime, region and locality of residence
 
             THE CRIME EVENT
cv0259.wk1   Table 59: Percent distribution of incidents, by type of crime and time of occurrence
cv0260.wk1   Table 60: Percent distribution of incidents, by type of crime, type of offender and
                  time of occurrence
cv0261.wk1   Table 61: Percent distribution of incidents, by type of crime and place of                  
                                       occurrence
cv0262.wk1   Table 62: Percent distribution of incidents, by type of crime, type of offender and
                  place of occurrence
cv0263.wk1   Table 63: Percent distribution of incidents, by victim-offender relationship, type of
                  crime and place of occurrence
cv0264.wk1   Table 64: Percent distribution of incidents, by victim's activity at time of incident
                  and type of crime
cv0265.wk1   Table 65: Percent distribution of incidents, by distance from home and type of         
                                       crime
cv0266.wk1   Table 66: Percent of incidents, by victim-offender relationship, type of crime and
                  weapons use
cv0267.wk1   Table 67: Percent distribution of violent crime victimizations by who was first to    
                                       use or threaten to use physical force
cv0268.wk1   Table 68: Percent of victimizations in which victims took self-protective measures, 
                                       by type of crime and victim-offender relationship
cv0269.wk1   Table 69: Percent of victimizations in which victims took self-protective measures, 
                                       by characteristics of victims and type of crime
cv0270.wk1   Table 70: Percent distribution of self-protective measures employed by victims, by 
                                        type of measure and type of crime
cv0271.wk1   Table 71: Percent distribution of self-protective measures employed by victims, by
                  selected characteristics of victims
cv0272.wk1   Table 72: Percent victimizations in which self-protective measures employed, by     
                                       person taking the measure, outcome of action and type of crime
cv0273.wk1   Table 73: Percent distribution of victimizations in which self-protective measures
                  taken by the victim were helpful
cv0274.wk1   Table 74: Percent distribution of victimizations in which self-protective measures
                  taken by the victim were harmful
cv0275.wk1   Table 75: Percent of victimizations in which victims sustained physical injury, by
                  selected characteristics of victim and type of crime 
cv0276.wk1   Table 76: Percent distribution of victims receiving medical care, by type of crime    
                                       and where care was received
cv0277.wk1   Table 77: Percent of victimizations in which victims incurred medical expenses, by
                  selected characteristics of victims and type of crime
cv0278.wk1   Table 78: Percent of victimizations in which injured victims had health insurance
                  coverage or were eligible for public medical services, by selected             
                                       characteristics of victims
cv0279.wk1   Table 79: Percent of victimizations in which victims received hospital care, by
                  selected characteristics of victims and type of crime
cv0280.wk1   Table 80: Percent distribution of victimizations in which injured victims received
                  hospital care, by selected characteristics of victims, type of crime and      
                                        type of  hospital care
cv0281.wk1   Table 81: Percent of victimizations resulting in economic loss, by type of crime       
                                       and type of loss
cv0282.wk1   Table 82: Total economic loss to victims of crime
cv0283.wk1   Table 83: Percent distribution of victimizations resulting in economic loss, by type 
                                        of crime and value of loss
cv0284.wk1   Table 84: Percent distribution of victimizations resulting in theft loss, by type of
                  crime and type of property stole
cv0285.wk1   Table 85: Percent distribution of victimizations resulting in theft loss, by race of
                  victims, type of crime and value of loss
cv0286.wk1   Table 86: Percent distribution of victimizations resulting in theft loss, by race of
                  victims, type of crime and proportion of loss recovered
cv0287.wk1   Table 87: Percent of victimizations resulting in loss of time from work, by type of
                  crime
cv0288.wk1   Table 88: Percent of victimizations resulting in loss of time from work, by type of
                  crime and race of victims
cv0289.wk1   Table 89: Percent distribution of victimizations resulting in loss of time from           
                                       work, by type of crime and number of days lost
cv0290.wk1   Table 90: Percent distribution of victimizations resulting in loss of time from           
                                       work, by race of victims, type of crime, and number of days lost
 
            SERIES VICTIMIZATIONS
cv02110.wk1  Table 110: Number and percent distribution of series victimizations and of
                     victimizations not in series, by type of crime


