HIV in Prisons, 2020 – Statistical Tables NCJ 302601	
	
This zip archive contains tables in individual .csv spreadsheets	
from HIV in Prisons, 2020 – Statistical Tables NCJ 302601. The full report including text	
and grahics in pdf format is available from: https://bjs.ojp.gov/library/publications/hiv-prisons-2020-statistical-tables
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=HIV%20in%20Prisons%20and%20Jails	
	
Filenames		Table titles
hivp20stt01.csv		Table 1. Persons living with HIV in the custody of state and federal correctional authorities, by sex, 2016–2020
hivp20stt02.csv		Table 2. AIDS-related deaths among prisoners in the custody of state and federal correctional authorities, by demographic characteristics, 2016–2019
hivp20stt03.csv		Table 3. Number of jurisdictions that tested prisoners for HIV during the intake process and percent of all prison admissions, by HIV testing practices, 2016 and 2020
hivp20stt04.csv		Table 4. Number of jurisdictions that tested prisoners for HIV while in custody, by HIV testing practices, 2016 and 2020
hivp20stt05.csv		Table 5. Number of jurisdictions that tested prisoners for HIV during discharge planning and percent of all prison releases, by HIV testing practices, 2016 and 2020
	
			Figures
hivp20stf01.csv		Figure 1. Persons living with HIV and rate of HIV per 100,000 persons in the custody of state and federal correctional authorities, yearend 1991–2020
hivp20stf02.csv		Figure 2. AIDS-related deaths and mortality rate among state prisoners, 1991–2019
hivp20stf03.csv		Figure 3. Number of persons living with HIV in the custody of state and federal correctional authorities, by reporter type, 1991–2020
	
			Appendix tables
hivp20stat01.csv	Appendix Table 1. Estimates for figure 1: Persons living with HIV and rate of HIV per 100,000 persons in the custody of state and federal correctional authorities, yearend 1991–2020
hivp20stat02.csv	Appendix 2. Estimates for figure 2: AIDS-related deaths and mortality rate among state prisoners, 1991–2019
hivp20stat03.csv	Appendix Table 3. AIDS-related deaths among federal prisoners, 1999–2019
hivp20stat04.csv	Appendix Table 4. Persons living with HIV in the custody of state and federal correctional authorities, by jurisdiction, 2016–2020
hivp20stat05.csv	Appendix Table 5. Persons living with HIV in the custody of state and federal correctional authorities, by sex and jurisdiction, 2016–2020
hivp20stat06.csv	Appendix Table 6. HIV testing and consent practices for state and federal prisoners during the intake process, by jurisdiction, 2016
hivp20stat07.csv	Appendix Table 7. HIV testing and consent practices for state and federal prisoners during the intake process, by jurisdiction, 2020
hivp20stat08.csv	Appendix Table 8. HIV testing practices for state and federal prisoners while in custody, by jurisdiction, 2016
hivp20stat09.csv	Appendix Table 9. HIV testing practices for state and federal prisoners while in custody, by jurisdiction, 2020
hivp20stat10.csv	Appendix Table 10. HIV testing practices for state and federal prisoners during discharge planning, by jurisdiction, 2016
hivp20stat11.csv	Appendix Table 11. HIV testing practices for state and federal prisoners during discharge planning, by jurisdiction, 2020
hivp20stat12.csv	Appendix Table 12. Number of prisoners in the custody of state and federal correctional authorities, by sex and jurisdiction, 2016–2020
hivp20stat13.csv	Appendix Table 13. Number of persons in prison living with HIV for figure 3: Number of persons living with HIV in the custody of state and federal correctional authorities, by reporter type, 1991–2020
