Human Trafficking Data Collection Activities, 2023   NCJ 307345	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Human Trafficking Data Collection Activities, 2023   NCJ 307345.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/human-trafficking-data-collection-activities-2023	
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Human%20Trafficking%20Data%20Collection%20Activities	
	
Filenames	Table titles
htdca23t01.csv	Table 1. Characteristics of human trafficking defendants in cases charged in U.S. district court, fiscal year 2021
htdca23t02.csv	Table 2. Admissions to state prison for human trafficking in 36 states, 2017–2021
	
		Figures
htdca23f01.csv	Figure 1. Human trafficking suspects referred to and prosecuted by U.S. attorneys and human trafficking defendants convicted, fiscal years 2011–2021
	
		Appendix tables
htdca23at01.csv	Appendix table 1. Numbers for figure 1: Human trafficking suspects referred to and prosecuted by U.S. attorneys and human trafficking defendants convicted, fiscal years 2011–2021
