Jails in Indian Country, 2012 NCJ 242187	
	
This zip archive contains tables in individual .csv spreadsheets	
from Jails in Indian Country, 2012, NCJ 24187. The full report 	
including text and graphics in .pdf format are available from: 	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4678	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=32	
 	
Tables	
jic12t01.csv	Table 1. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, June 2000, 2004, and 2007�2012
jic12t02.csv	Table 2. Jails in Indian country that held the majority of inmates in 2012 compared to 2011, by facility
jic12t03.csv	Table 3. Indian country jails and percent of inmate population, by facility size, June 2012
jic12t04.csv	Table 4. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2012
jic12t05.csv	Table 5. Jails in Indian country operating above 150% of capacity on their peak day, June 2012
jic12t06.csv	Table 6. Admissions and expected length of stay in Indian country jails, by facility size, June 2012
jic12t07.csv	Table 7. Admissions and expected length of stay in 70 operating Indian country jails, by facility size, June 2011 and 2012
jic12t08.csv	Table 8. Inmates confined in Indian country jails, by demographic characteristic, conviction status, and offense, midyear 2000, 2002, 2004, and 2007�2012
jic12t09.csv	Table 9. Persons employed in Indian country jails, by job function, midyear 2010�2012
jic12t10.csv	Table 10. Indian country jail survey universe and response rates, 2004 and 2007�2012
	
Appendix tables	
jic12at01.csv	Appendix table 1. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, by facility, June 2012
jic12at02.csv	Appendix table 2. Inmates in Indian country jails, by type of offense, midyear 2012
jic12at03.csv	Appendix table 3. Inmates in Indian country jails, by conviction status, midyear 2012
jic12at04.csv	Appendix table 4. Adults and juveniles in the custody of Indian country jails, by sex, midyear 2012
	
Figures	
jic12f01.csv	Figure 1. Inmates confined in Indian country jails, midyear 2000�2004 and 2007�2012
jic12f02.csv	Figure 2. Percent of rated capacity occupied, by facility size, June 2012

