Jails in Indian Country, 2021, and the Impact of COVID-19, July–December 2020   NCJ 304631						
						
This zip archive contains tables in individual .csv spreadsheets						
from Jails in Indian Country, 2021, and the Impact of COVID-19, July–December 2020   NCJ 304631.						
The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/jails-indian-country-2021-and-impact-covid-19-july-december-2020
						
This report is one in a series.  More recent editions may be available. 						
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=Jails%20in%20Indian%20Country						
						
Filenames		Table titles					
jic21icjd20t01.csv	Table 1. Inmates held, rated capacity, and percent of rated capacity occupied in Indian country jails in June, 2010 and 2015–2021
jic21icjd20t02.csv	Table 2. Number of inmates held in Indian country jails, by facility size, midyear 2020 to midyear 2021
jic21icjd20t03.csv	Table 3. Average daily population, admissions, and average length of stay in Indian country jails, by facility size, June 2020–June 2021
jic21icjd20t04.csv	Table 4. Capacity of Indian country jails, by facility size, midyear 2020 to midyear 2021
jic21icjd20t05.csv	Table 5. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2021
jic21icjd20t06.csv	Table 6. Inmates held in Indian country jails, by demographic and criminal justice characteristics, midyears 2010, 2015, and 2019–2021
jic21icjd20t07.csv	Table 7. COVID-19 testing and positive cases among inmates in Indian country jails, by facility size, July 1–December 31, 2020
jic21icjd20t08.csv	Table 8. Admissions to and expedited releases from Indian county jails, by facility size, July 1–December 31, 2020			
jic21icjd20t09.csv	Table 9. Persons employed in Indian country jails, by job function, midyears 2010, 2015, and 2019–2021		
jic21icjd20t10.csv	Table 10. COVID-19 positive cases among staff in Indian country jails, by facility size, July 1–December 31, 2020			
jic21icjd20t11.csv	Table 11. Survey universe and response rates of Indian country jails, 2010 and 2015–2021					
						
			Figures					
jic21icjd20f01.csv	Figure 1. Number of inmates held in Indian country jails, midyears 2010–2021		
jic21icjd20f02.csv	Figure 2. Number of inmates held in Indian country jails on the last weekday of each month from January to December 2020 and the last weekday of June 2021

			Appendix tables					
jic21icjd20at01.csv	Appendix table 1. COVID-19 testing and positive cases among inmates in Indian country jails, by facility size, March 1–June 30, 2020
jic21icjd20at02.csv	Appendix table 2. Admissions to and expedited releases from Indian county jails, by facility size, March 1–June 30, 2020
jic21icjd20at03.csv	Appendix table 3. COVID-19 positive cases among staff in Indian country jails, by facility size, March 1–June 30, 2020
jic21icjd20at04.csv	Appendix table 4. Imputation for inmate characteristics in table 6: Inmates held in Indian country jails, by demographic and criminal justice characteristics, midyears 2010, 2015, and 2019–2021
jic21icjd20at05.csv	Appendix table 5. Imputation for staff in table 9: Persons employed in Indian country jails, by job function, midyears 2010, 2015, and 2019–2021					
