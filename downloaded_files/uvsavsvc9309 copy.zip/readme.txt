Use of Victim Service Agencies by Victims of Serious Violent Crime, 1993-2009.		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Use of Victim Service Agencies by Victims of Serious Violent Crime, 1993-2009 NCJ 234212		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2432	
		
		
uvsavsvc9309f01.csv		Figure 1. Serious violent crime rate per persons age 12 or older and percent of serious violent crime victims who received assistance from victim service agencies, 1993-2009
uvsavsvc9309f02.csv		Figure 2. Serious violent crime victims who received assistance from victim service agencies, by type of agency, 1993-2009
uvsavsvc9309f03.csv		Figure 3. Serious violent crime victims who received follow-up criminal justice system action, by type of action, 2000-2009
uvsavsvc9309f04.csv		Figure 4. Serious violent crime victims who received direct assistance from victim service agencies, by type of injury, 2000-2009
uvsavsvc9309f05.csv		Figure 5. Serious violent crime victims who received direct assistance from victim service agencies, by victim characteristics, 2000-2009
uvsavsvc9309f06.csv		Figure 6. Serious violent crime victims who received direct assistance from victim service agencies, by household characteristics, 2000-2009 
		
uvsavsvc9309t01.csv		Table 1. Serious violent crime victims who received direct assistance from victim service agencies, by whether victimization was reported to the police, 2000-2009
uvsavsvc9309t02.csv		Table 2. Victims who received assistance from victim support agencies, by type of offense, 2000-2009
uvsavsvc9309t03.csv		Table 3. Serious violent crime victims who received assistance from victim service agencies, by victim-offender relationship, 2000-2009Table 2. Victims who received assistance from victim support agencies, by type of offense, 2000-2009
		
uvsavsvc9309a01.csv		Appendix Table 1. Serious violent crime victims who received direct assistance from victim service agencies, by crime and victim characteristics and whether victimiztion was reported to police, 2000-2009
uvsavsvc9309a02.csv		Appendix table 2. Standard errors for appendix table 1: Serious violent crime victims who received direct assistance from victim service agencies, by crime and victim characteristics and whether victimiztion was reported to police, 2000-2009
uvsavsvc9309a03.csv		Appendix Table 3. Number of serious violent crime victimizations and percent of victims who received direct assistance from a victim service agency, by victim characteristics and location of residence, 2000-2009
uvsavsvc9309a04.csv		Appendix Table 4. Standard errors for appendix table 3: Number of serious violent crime victimizations and percent of victims who received direct assistance from a victim service agency, by victim characteristics and location of residence, 2000-2009
uvsavsvc9309a05.csv		Appendix Table 5. Serious violent crime victims who received direct assistance from victim service agencies, by whether the victim experienced criminal justice system action pertaining to the case, 2000-2009
uvsavsvc9309a06.csv		Appendix Table 6. Standard errors for appendix table 5: Serious violent crime victims who received direct assistance from victim service agencies, by whether the victim experienced criminal justice system action pertaining to the case, 2000-2009
uvsavsvc9309a07.csv		Appendix Table 7. Base population numbers and standard errors for serious violent crime rate per 1,000 persons age 12 or older and percentage of serious violent crime victims who received assistance from victim service agencies, 1993-2009
uvsavsvc9309a08.csv		Appendix Table 8. Standard errors for serious violent crime victims who received assistance from victim service agencies, by type of agency, 1993-2009
uvsavsvc9309a09.csv		Appendix Table 9. Standard errors for serious violent crime victims who received direct assistance from victim service agencies, by whether victimization was reported to the police, 2000-2009Appendix Table 8. Standard errors for serious violent crime victims who received assistance from victim service agencies, by type of agency, 1993-2009
uvsavsvc9309a10.csv		Appendix Table 10. Standard errors for serious violent crime victims who received follow-up criminal justice system action, by type of action, 2000-2009
uvsavsvc9309a11.csv		Appendix Table 11. Standard errors for victims who received assistance from victim support agencies, by type of offense, 2000-2009Appendix Table 10. Standard errors for serious violent crime victims who received follow-up criminal justice system action, by type of action, 2000-2009
uvsavsvc9309a12.csv		Appendix Table 12. Standard errors for percentage of serious violent crime victims who received assistance from victim service agencies, by victim-offender relationship, 2000-2009
uvsavsvc9309a13.csv		Appendix Table 13. Percentage of serious violent crime victims who received direct assistance from victim service agencies, by extent of injury experienced, 2000-2009Appendix table 12. Standard errors for percentage of serious violent crime victims who received assistance from victim service agencies, by victim-offender relationship, 2000-2009
uvsavsvc9309a14.csv		Appendix Table 14. Standard errors for percentage of serious violent crime victims who received direct assistance from victim service agencies, by victim characteristics, 2000-2009
uvsavsvc9309a15.csv		Appendix Table 15. Standard errors for percentage of serious violent crime victims who received direct assistance from victim service agencies, by household characteristics, 2000-2009
		
		
