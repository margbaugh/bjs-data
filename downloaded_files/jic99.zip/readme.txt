JAILS IN INDIAN COUNTRY, 1998 AND 1999
NCJ 173410

Contents of this zip archive


jic9901.wk1	Table 1.  Jails in Indian country, by State, June 30, 1999

jic9902.wk1	Table 2.  Number of jails in Indian country, owner of facility, operator, 
				and total rated capacity, June 30, 1999
jic9903.wk1	Table 3.  Inmate characteristics, June 30, 1998 and 1999

jic9904.wk1	Table 4.  Persons under community supervision, June 30, 1998 and 1999

jic9905.wk1	Table 5.  Number of inmates by type of confinement area, June 30, 1998

jic9906.wk1	Table 6.  Facility characteristics of jails in Indian country, June 30, 1998 and 1999

jic9907.wk1	Table 7.  Ten largest jails in Indian country, June 30, 1999

jic9908.wk1	Table 8.  Percent of capacity occupied on June 30 and peak day in June 1998 and 1999

jic9909.wk1	Table 9.  Facilities in Indian country operating above 150% capacity on peak day in June 1999

jic9910.wk1	Table 10.  Court orders, consent decrees, and planned changes for jails in Indian country,
				June 30, 1998 and 1999

jic9911.wk1	Table 11.  Deaths reported by jails in Indian country 1998 and 1999

jic9912.wk1	Table 12.  Counseling and programs offered in jails in Indian country, June 30, 1998

jic9913.wk1	Table 13.  Staff characteristics of jails in Indian country, June 30, 1998

jic9914.wk1	Table 14.  Reported needs of jails in Indian country, June 30, 1998

APPENDIX TABLES:

jic99a01.wk1	 Table 1.    Persons under the supervision of jails in Indian 
				country, June 30, 1998 and 1999
jic99a02.wk1  Table 2.    Inmates in the custody of jails in Indian country, 
				by gender, June 30, 1998 and 1999
jic99a03.wk1  Table 3.    Juveniles in the custody of jails in Indian country, 
				by gender, June 30, 1998 and 1999
jic99a04a.wk1 Table 4a.  Persons supervised in the community by jails in Indian 
				country, by type of alternative supervision, June 30, 1999
jic99a04b.wk1 Table 4b.  Persons supervised in the community by jails in Indian 
				country, by type of alternative supervision, June 30, 1998
jic99a05.wk1	Table 5.    Persons under the supervision of jails in Indian country, 
				by conviction status, June 30, 1998 and 1999
jic99a06.wk1	Table 6.    Inmates under the supervision of jails in Indian country, 
				movements, June 1-30, 1998 and 1999
jic99a07.wk1	Table 7.    Capacity of custody areas and population as a percent 
				of capacity, June 30, 1998 and 1999
jic99a08.wk1	Table 8.    Deaths, suicides, and attempted suicides of inmates 
				in custody of jails in Indian country, 1999 and 1998
jic99a09.wk1	Table 9.    Number of inmates held in drug/alcohol 
				detoxification, June 30, 1999
jic99a10.wk1	Table 10.  Function of jails in Indian country, and type of 
				adult/juvenile separation, June 30, 1998
jic99a11.wk1	Table 11.  Types of confinement areas within jails in Indian 
				country, June 30, 1998
jic99a12.wk1	Table 12.  Jails in Indian country under court order or 
				consent decree for overcrowding or other reasons, June 30, 1999
jic99a13.wk1	Table 13.  Owner and operator of jails in Indian country, 
				facility age, and year of most recent renovation, June 30, 1998
jic99a14.wk1	Table 14.  Planned changes to jails in Indian country 
				and change in capacity, June 30, 1999
jic99a15.wk1	Table 15.  Counseling and special programs available 
				in jails in Indian country, June 30, 1998
jic99a16.wk1	Table 16.  Jail operations staff of jails in Indian country, June 30, 1998

jic99a17.wk1	Table 17.  Reported staffing needs of jails in Indian country, June 30, 1998

jic99a18.wk1	Table 18.  Reported facility needs of jails in Indian country, June 30, 1998
	
jic99a19.wk1	Table 19.  Reported special program needs of jails in Indian 
				country, June 30, 1998
jic99a20.wk1	Table 20.  Tribal affiliation of jails in Indian country, 1998 and 1999
		
jic99a21.wk1	Table 21.  Jails in Indian country, by tribe, 1998 and 1999
		
jic99a22.wk1	Table 22.  Inmates in custody and rated capacity of jails in Indian 
				country, by tribe, 1998 and 1999
