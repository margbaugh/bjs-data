Capital Punishment, 2002   NCJ 201848

This zip archive contains tables in individual .wk1 spreadsheets
from Capital Punishment, 2002, NCJ 201848. The full report including text 
and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cp02.htm 


cp0204.wk1          Table #: 4  Prisoners under sentence of death, by region, State, and race, 2001 and 2002
cp0205.wk1          Table #: 5  Demographic characteristics of prisoners  under sentence of death, 2002
cp0206.wk1          Table #: 6  Hispanics and women under sentence of death, by State, 2001 and 2002
cp0207.wk1          Table #: 7  Age at time of arrest for capital offense and  age of prisoners under sentence of death at yearend 2002
cp0208.wk1          Table #: 8  Criminal history profile of prisoners under sentence of death, by race and Hispanic origin, 2002
cp0209.wk1          Table #: 9  Number of persons  executed, by jurisdiction, 1930-2002
cp0210.wk1          Table #: 10  Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2002
cp0211.wk1          Table #: 11 Time under sentence of death and execution, by race, 1977-2002

                        Highlights tables
cp02ht01.wk1        Highlights table #: 1 Executions during 2002, persons under sentence of death 12/31/02 and jurisdictions without the death penalty
cp02ht02.wk1        Highlights table #: 2 Persons under sentence of death, 1992 and 2002

                         Figures
cp02f01.wk1         Figure #: 1 Persons under sentence of death 1953-2002
cp02f02.wk1         Figure #: 2 Persons under sentence of death, by race, 1968-2002
cp02f03.wk1         Figure #: 3 Admissions to and release from a sentence of death, 1977-2002 
cp02f04.wk1         Figure #: 4 Persons executed, 1930-2002

                         Text tables
cp02t01.wk1         Text table #: 1 Women under sentence of death by race and state, 12/31/02
cp02t02.wk1         Text table #: 2 Persons under sentence  of death, by sex, race, and Hispanic origin, 12/31/02
cp02t03.wk1         Text table #: 3 Number of death sentences imposed on incoming inmates, 1988-2002
cp02t04.wk1         Text table #: 4 Inmates received under sentence of death, 1994-2002
cp02t05.wk1         Text table #: 5 Number of executions, 1977-2002
cp02t06.wk1         Text table #: 6 Number of executions by race/ethnicity and method, 1977-2002

cp02t07.wk1         Text table #: 7 Elapsed time since sentencing for inmates under sentence of death by gender and race/ethnicity

                         Appendix tables
cp02at02.wk1        Appendix table #: 2  Prisoners sentenced to death and the outcome of the sentence, by year of sentencing, 1973-2002
cp02at03.wk1        Appendix table #: 3  Prisoners under sentence of death on December 31, 2002, by State and year of sentencing
cp02at04.wk1        Appendix table #: 4  Number sentenced to death and number of removals, by jurisdiction and reason for removal, 1973-2002
cp02at05.wk1        Appendix table #: 5 Executions, by State and method, 1977-2002

          Box table
cp02bt01.wk1        Box table #: 1 Advance count of executions and method used by jurisdiction, January 1, 2002-September 25, 2003
