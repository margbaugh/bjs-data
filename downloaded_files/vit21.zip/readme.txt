Victims of Identity Theft, 2021   NCJ 306474																						
This zip archive contains tables in individual  .csv spreadsheets
from Victims of Identity Theft, 2021   NCJ 306474. The full report including text
and graphics in pdf format is available from: 			
https://bjs.ojp.gov/library/publications/victims-identity-theft-2021														
This report is one in a series.  More recent editions may be available.	
To view a list of all in the series go to:
https://bjs.ojp.gov/library/publications/list?series_filter=Identity%20Theft
																						
Filenames	Table titles
vit21t01.csv	Table 1. Victims of identity theft, by type of most recent incident of theft, 2021
vit21t02.csv	Table 2. Demographic characteristics of victims of identity theft in the past 12 months and the U.S. residential population age 16 or older, 2021
vit21t03.csv	Table 3. Ways that victims discovered identity theft, by type of theft, 2021
vit21t04.csv	Table 4. Victims of identity theft who knew how the offender obtained their personal information, by method offender used and type of theft, 2021
vit21t05.csv	Table 5. Financial loss for all incidents of identity theft, 2021
vit21t06.csv	Table 6. Financial loss from victims’ most recent incident of identity theft, by type of theft and loss, 2021
vit21t07.csv	Table 7. Number of hours that victims spent resolving financial or credit problems associated with identity theft, 2021
vit21t08.csv	Table 8. Victims who experienced emotional distress from identity theft, by severity of stress and type of theft, 2021
vit21t09.csv	Table 9. Victims of identity theft, by type of organization contacted about the theft, 2021
vit21t10.csv	Table 10. Victims of identity theft in their lifetime, by type of theft, 2021
vit21t11.csv	Table 11. Demographic characteristics of victims who experienced identity theft in their lifetime, 2021
vit21t12.csv	Table 12. Actions that persons age 16 or older took in the past 12 months to reduce the risk of identity theft, 2021
																				
		Figures	
vit21f01.csv	Figure 1. Persons age 16 or older who experienced at least one identity-theft incident in the past 12 months, by type of theft, 2021
vit21f02.csv	Figure 2. Victims of identity theft who knew something of the offender’s identity or how the offender obtained their personal information, by type of theft, 2021
vit21f03.csv	Figure 3. Length of time that victims spent resolving financial or credit problems associated with identity theft, 2021
vit21f04.csv	Figure 4. Victims who experienced severe emotional distress from identity theft, by length of time they spent resolving associated financial or credit problems, 2021
vit21f05.csv	Figure 5. Victims of identity theft who reported the theft to police, by type of theft, 2021
vit21f06.csv	Figure 6. Victims of identity theft who contacted a credit bureau, by action taken, 2021
																						
		Appendix tables
vit21at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Persons age 16 or older who experienced at least one identity-theft incident in the past 12 months, by type of theft, 2021
vit21at02.csv	Appendix table 2. Standard errors for table 1: Victims of identity theft, by type of most recent incident of theft, 2021
vit21at03.csv	Appendix table 3. Standard errors for table 2: Demographic characteristics of victims of identity theft in the past 12 months and the U.S. residential population age 16 or older, 2021
vit21at04.csv	Appendix table 4. Standard errors for table 3: Ways that victims discovered identity theft, by type of theft, 2021
vit21at05.csv	Appendix table 5. Estimates and standard errors for figure 2: Victims of identity theft who knew something of the offender’s identity or how the offender obtained their personal information, by type of theft, 2021
vit21at06.csv	Appendix table 6. Standard errors for table 4: Victims of identity theft who knew how the offender obtained their personal information, by method offender used and type of theft, 2021
vit21at07.csv	Appendix table 7. Standard errors for table 5: Financial loss for all incidents of identity theft, 2021
vit21at08.csv	Appendix table 8. Standard errors for table 6: Financial loss from victims’ most recent incident of identity theft, by type of theft and loss, 2021
vit21at09.csv	Appendix table 9. Estimates and standard errors for figure 3: Length of time that victims spent resolving financial or credit problems associated with identity theft, by type of theft, 2021
vit21at10.csv	Appendix table 10. Standard errors for table 7: Number of hours that victims spent resolving financial or credit problems associated with identity theft, 2021
vit21at11.csv	Appendix table 11. Standard errors for table 8: Victims who experienced emotional distress from identity theft, by severity of stress and type of theft, 2021
vit21at12.csv	Appendix table 12. Estimates and standard errors for figure 4: Victims who experienced severe emotional distress from identity theft, by length of time they spent resolving associated financial or credit problems, 2021
vit21at13.csv	Appendix table 13. Estimates and standard errors for figure 5: Victims of identity theft who report the theft to police, by type of theft, 2021
vit21at14.csv	Appendix table 14. Standard errors for table 9: Victims of identity theft, by type of organization contacted about the theft, 2021
vit21at15.csv	Appendix table 15. Estimates and standard errors for figure 6: Victims of identity theft who contacted a credit bureau, by action taken, 2021
vit21at16.csv	Appendix table 16. Standard errors for table 10: Victims of identity theft in their lifetime, by type of theft, 2021
vit21at17.csv	Appendix table 17. Standard errors for table 11: Demographic characteristics of victims who experienced identity theft in their lifetime, 2021
vit21at18.csv	Appendix table 18. Standard errors for table 12: Actions that persons age 16 or older took in the past 12 months to reduce the risk of identity theft, 2021