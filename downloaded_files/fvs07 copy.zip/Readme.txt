Family Violence Statistics   NCJ  207846


This zip archive contains tables in individual .csv spreadsheets
from Family Violence Statistics, NCJ 207846.  The full report including text 
and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/fvs.htm



fvs0701.csv	Table 7.1: Suspects referred to U.S. attorneys for domestic violence, 2000 to 2002
fvs0702.csv	Table 7.2: Suspects referred to U.S. attorneys for interstate domestic violence or firearm-related domestic violence from 2000 to 2002, by investigating agency
fvs0703.csv	Table 7.3: Characteristics of persons convicted in Federal court for interstate domestic violence from 2000 to 2002

Other sections:

fvs02t1.csv	Text Table 1: Distribution of family violence
fvs02t2.csv	Text Table 2: Percent family violence, by type of offense
fvs02t3.csv	Text Table 3: Drug or alcohol use by offender during family violence incidents
fvs0201.csv	Table 2.1: Offenses against family violence victims compared to nonfamily violence victims between 1998 and 2002, by relationship
fvs0202.csv	Table 2.2: Location of family violence compared to nonfamily violence between 1998 and 2002, by relationship
fvs0203.csv	Table 2.3: Demographic characteristics of family violence victims compared to nonfamily violence victims between 1998 and 2002, by relationship
fvs0204.csv	Table 2.4: Among violent crimes resulting in injury between 1998 and 2002, the type of injury to family violence victims compared to nonfamily violence victims, by relationship
fvs0205.csv	Table 2.5: Medical care for family violence victims compared to nonfamily violence victims between 1998 and 2002, by relationship
fvs0206.csv	Table 2.6: Demographic characteristics of family violence offenders compared to nonfamily violence offenders between 1998 and 2002, by relationship
fvs0207.csv	Table 2.7: Armed offender in family violence compared to nonfamily violence between 1998 and 2002, by relationship
fvs0208.csv	Table 2.8: Offender drug or alcohol use in family violence compared to nonfamily violence between 1998 and 2002, by relationship
fvs0209.csv	Table 2.9: Number of victims and offenders in family violence compared to nonfamily violence between 1998 and 2002, by relationship

fvs03t1.csv	Text Table 1: Percent murdered by a family member in 2002, by gender
fvs03t2.csv	Text Table 2: Percent murdered by a family member in 2002, by age
fvs0301.csv	Table 3.1: Demographic characteristics of family murder victims compared to nonfamily murder victims in 2002, by relationship 
fvs0302.csv	Table 3.2: Demographic characteristics of family murderers compared to nonfamily murderers in 2002, by relationship
fvs0303.csv	Table 3.3: Weapon use in family murder compared to nonfamily murder in 2002, by relationship
fvs0304.csv	Table 3.4: Number of victims and offenders in family murder compared to nonfamily murder in 2002, by relationship

fvs04t1.csv	Text Table 1: Percent of violent victimizations reported to police, by type of offense
fvs04t2.csv	Text Table 2: Percent of violent victimizations involving weapon use
fvs0401.csv	Table 4.1: Percent of family violence reported to police between 1998 and 2002, compared to percent of nonfamily violence, by relationship
fvs0402.csv	Table 4.2: Percent of family violence reported to police between 1998 and 2002, compared to nonfamily violence, by relationship and offense type
fvs0403.csv	Table 4.3: Percent of family violence reported to police between 1998 and 2002, compared to percent of nonfamily violence, by relationship and demographic characteristics of victim
fvs0404.csv	Table 4.4: Percent of family violence reported to police between 1998 and 2002, compared to percent of nonfamily violence, by relationship and whether offender had a weapon
fvs0405.csv	Table 4.5: Reasons family violence was not reported to police between 1998 and 2002, compared to reasons nonfamily violence was not reported, by relationship
fvs0406.csv	Table 4.6: Persons who reported family violence to police between 1998 and 2002, compared to those who reported nonfamily violence, by relationship
fvs0407.csv	Table 4.7: Of crimes reported to police between 1998 and 2002, the percent that resulted in arrest,by offense category and relationship

fvs05t1.csv	Text Table 1: Percent of family violence offenders arrested by police in 18 States and the District of Columbia in 2000, by gender
fvs0501.csv	Table 5.1: Offenses in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0502.csv	Table 5.2: Location of police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0503.csv	Table 5.3: Victim demographic characteristics in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0504.csv	Table 5.4: Victim injury in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0505.csv	Table 5.5: Offender demographic characteristics in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0506.csv	Table 5.6: Weapon use by offender in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0507.csv	Table 5.7: Number of victims and offenders in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0508.csv	Table 5.8: Arrests in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0509.csv	Table 5.9: Arrestee demographic characteristics in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0510.csv	Table 5.10: Victim demographic characteristics in offenses for which an arrest occurred in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0511.csv	Table 5.11: Arrest rates in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship and offense
fvs0512.csv	Table 5.12: Arrest rates in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship and offender demographic characteristics
fvs0513.csv	Table 5.13: Arrest rates in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship and victim demographic characteristics
fvs0514.csv	Table 5.14: Weapon possession at time of arrest in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship
fvs0515.csv	Table 5.15: Disposition of juvenile arrestees in police-recorded family violence compared to nonfamily violence in 18 States and the District of Columbia in 2000, by relationship


fvs06t1.csv	Text Table 1: Pretrial misconduct committed by family assault defendants compared to nonfamily assault defendants
fvs0601.csv	Table 6.1: Family assault cases as a percent of all felony assault cases in State courts of 11 large counties in 2000, by defendant demographic characteristics
fvs0602.csv	Table 6.2: Number of prior arrest charges of family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000
fvs0603.csv	Table 6.3: Number of prior felony arrest charges of family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000 
fvs0604.csv	Table 6.4: Number of prior convictions of family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000
fvs0605.csv	Table 6.5: Number of prior felony convictions of family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000 
fvs0606.csv	Table 6.6: At time of arrest, criminal justice status of family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000 
fvs0607.csv	Table 6.7: Pretrial release or detention of family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000
fvs0608.csv	Table 6.8: Bail amount set for family assault defendants compared to nonfamily assault defendants released or held on bail before case disposition in State courts of 11 large counties in 2000
fvs0609.csv	Table 6.9: Time from arrest to pretrial release for family assault defendants compared to nonfamily assault defendants released before case disposition in State courts of 11 large counties in 2000
fvs0610.csv	Table 6.10: Time from arrest to adjudication for family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000
fvs0611.csv	Table 6.11: Adjudication outcome for family assault defendants compared to nonfamily assault defendants in State courts of 11 large counties in 2000 
fvs0612.csv	Table 6.12: Time from conviction to sentencing for defendants convicted of family assault compared to nonfamily assault in State courts of 11 large counties in 2000 
fvs0613.csv	Table 6.13: Most severe sentence received by defendants convicted of family assault compared to nonfamily assault in State courts of 11 large counties in 2000 
fvs0614.csv	Table 6.14: Length of prison and jail sentences for defendants convicted of family assault compared to nonfamily assault in State courts of 11 large counties in 2000 


fvs08bx1.csv	Box 1: Convicted family violence offenders in State and Federal prisons and in local jails
fvs0801.csv	Table 8.1: Offenses for which family violence offenders were in State prison in 1997, compared to offenses for which nonfamily violence offenders were imprisoned, by relationship
fvs0802.csv	Table 8.2: Location of family violence compared to nonfamily violence for inmates in State prison for a violent crime in 1997, by relationship
fvs0803.csv	Table 8.3: Demographic characteristics of victims of family violence compared to nonfamily violence for inmates in State prison for a violent crime in 1997, by relationship
fvs0804.csv	Table 8.4: Victim injury in family violence compared to nonfamily violence for inmates in State prison for a violent crime in 1997, by relationship
fvs0805.csv	Table 8.5: Demographic characteristics of family violence offenders in State prison in 1997, compared to nonfamily violence offenders, by relationship
fvs0806.csv	Table 8.6: Offender weapon use or possession in family violence compared to nonfamily violence for inmates in State prison for a violent crime in 1997, by relationship
fvs0807.csv	Table 8.7: Offender drug or alcohol use in family violence compared to nonfamily violence for inmates in State prison for a violent crime in 1997, by relationship
fvs0808.csv	Table 8.8: Number of victims and offenders in family violence compared to nonfamily violence for inmates in State prison for a violent crime in 1997, by relationship
fvs0809.csv	Table 8.9: Number of prior sentences of family violence offenders in State prison in 1997 compared to nonfamily violence offenders, by relationship

fvs09t1.csv	Box 1: Restraining orders among jail inmates convicted of family violence
fvs0901.csv	Table 9.1: Offenses for which convicted family violence offenders were in local jail in 2002, compared to offenses for convicted nonfamily violence offenders, by relationship
fvs0902.csv	Table 9.2: Location of family violence compared to nonfamily violence for inmates convicted of a violent crime incarcerated in local jail in 2002, by relationship 
fvs0903.csv	Table 9.3: Demographic characteristics of victims of family violence compared to nonfamily violence for inmates in local jail convicted of a violent crime in 2002, by relationship 
fvs0904.csv	Table 9.4: Victim injury in family violence compared to nonfamily violence for inmates in local jail convicted of a violent crime in 2002, by relationship
fvs0905.csv	Table 9.5: Demographic characteristics of convicted family violence offenders in local jail in 2002, compared to nonfamily violence offenders, by relationship 
fvs0906.csv	Table 9.6: Armed offender in family violence compared to nonfamily violence for inmates in local jail for a violent crime in 2002, by relationship 
fvs0907.csv	Table 9.7: Offender drug or alcohol use in family violence compared to nonfamily violence for inmates in local jail for a violent crime in 2002, by relationship 
fvs0908.csv	Table 9.8: Number of victims and offenders in family violence compared to nonfamily violence for inmates in local jail for a violent crime in 2002, by relationship 

















