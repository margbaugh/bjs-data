Identity Theft Reported by Households, 2005-2010								
								
This zip archive contains tables in individual  .csv spreadsheets               								
from Identity Theft Reported by Households, 2005-2010, NCJ 236245								
The full report including text and graphics in pdf format is available at:              								
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2207								
								
This report is one in a series.  More recent editions            								
may be available.  To view a list of all in the series go to               								
http://www.bjs.gov/index.cfm?ty=pbse&sid=60								
								
itrh0520f01.csv		Figure 1. Percent of households that experienced identity theft, by type of identity theft, 2005, 2007, 2009, and 2010						
itrh0520f02.csv		Figure 2. Household identity theft victimizations involving the misuse of an existing credit card, other existing account, or personal information, 2005, 2006, 2007, 2009, and 2010						
								
itrh0510t01.csv		Table 1. Age, race and Hispanic origin, and marital status of head of households experiencing identity theft, 2005 and 2010						
itrh0510t02.csv		Table 2. Income, location, and size of households that experienced identity theft, 2005 and 2010						
itrh0510t03.csv		Table 3. Households experiencing direct financial loss due to identity theft, by type of identity theft, 2005 and 2010						
itrh0510t04.csv		Table 4. Type of identity theft experienced by victimized households and total financial loss attributed to each type of identity theft, 2010						
								
itrh0510at01.csv	Appendix table 1. Households in which at least one member was a victim of one or more types of identity theft, 2005, 2006, 2007, 2009, and 2010						
itrh0510at02.csv	Appendix table 2. Standard errors for households in which at least one member was a victim of one or more types of identity theft, 2005, 2006, 2007, 2009, and 2010						
itrh0510at03.csv	Appendix table 3. Standard errors for household identity theft victimizations involving the misuse of an existing credit card, other existing account, or personal information, by year 2005-2010						
itrh0510at04.csv	Appendix table 4. Standard errors for age, race and ethnicity, and marital status of head of households experiencing identity theft, 2005 and 2010						
itrh0510at05.csv	Appendix table 5. Standard errors for income, location, and size of households that experienced identity theft, 2005 and 2010						
itrh0510at06.csv	Appendix table 6. Standard errors for households experiencing direct financial loss due to identity theft, by type of identity theft, 2005 and 2010						
itrh0510at07.csv	Appendix table 7. Standard errors for type of identity theft experienced by victimized households and total financial loss attributed to each type of identity theft, 2010						
