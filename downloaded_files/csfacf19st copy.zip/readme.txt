Census of State and Federal Adult Correctional Facilities, 2019 – Statistical Tables NCJ 301366	
	
This zip archive contains tables in individual .csv spreadsheets	
from Census of State and Federal Adult Correctional Facilities, 2019 – Statistical Tables NCJ 301366.	
The full report in .pdf format is available at 	
https://bjs.ojp.gov/library/publications/census-state-and-federal-adult-correctional-facilities-2019-statistical-tables
	
This report is part of a series. A more recent version may be available. Go to 	
https://bjs.ojp.gov/library/publications/list?series_filter=Census%20of%20State%20and%20Federal%20Correctional%20Facilities	
	
Filenames		Table names
csfacf19t01.csv		Table 1. Number of correctional facilities and prisoners in custody, by type and operator, midyear 2019 
csfacf19t02.csv		Table 2. Number of correctional facilities and percent of prisoners, by operator and facility characteristics, midyear 2019 
csfacf19t03.csv		Table 3. Percent of prisoners in confinement and community-based facilities, by operator and demographic characteristics, midyear 2019 
csfacf19t04.csv		Table 4. Percent of prisoners in public and private confinement facilities, by sentence length and custody security level, midyear 2019 
csfacf19t05.csv		Table 5. Number of prisoners in restrictive housing in confinement facilities, by operator and reason, midyear 2019
csfacf19t06.csv		Table 6. State and private facilities that held prisoners for federal, other state, and local authorities, midyear 2019
csfacf19t07.csv		Table 7. Number of prisoners held in state and private facilities for federal, state, and local authorities, midyear 2019
csfacf19t08.csv		Table 8. Number of security incidents in correctional facilities, by type of incident and facility characteristics, July 1, 2018 to June 30, 2019
csfacf19t09.csv		Table 9. Number of security staff, percent of security staff by sex, and prisoner-to-security-staff ratio in confinement facilities, by facility characteristics, midyear 2019
csfacf19t10.csv		Table 10. Number of confinement facilities, security staff, and prisoners and prisoner-to-security-staff ratio, by operator and shift, midyear 2019
csfacf19t11.csv		Table 11. Public and private confinement facilities and prisoners, by work programs available in facility, midyear 2019 
csfacf19t12.csv		Table 12. Confinement and community-based facilities and prisoners, by education programs available in facility, midyear 2019
csfacf19t13.csv		Table 13. Confinement and community-based facilities and prisoners, by special programs available in facility, midyear 2019
csfacf19t14.csv		Table 14. Number of correctional facilities and percent of prisoners, by sex housed and special programs available in facility, midyear 2019
csfacf19t15.csv		Table 15. Number of correctional facilities ineligible for the Census of State and Federal Adult Correctional Facilities, by reason, midyear 2019
	
			Figures
csfacf19f01.csv		Figure 1. Percent of adult correctional facilities and prisoners, by facility type, midyear 2019
csfacf19f02.csv		Figure 2. Percent of confinement and community-based facilities and prisoners, by operator, midyear 2019
	
			Appendix tables
csfacf19at01.csv	Appendix Table 1. Number of confinement and community-based facilities under state or Federal Bureau of Prisons authority, by operator and state, midyear 2019
csfacf19at02.csv	Appendix Table 2. Correctional facilities, by main function of facility, midyear 2019
csfacf19at03.csv	Appendix Table 3. Number of confinement facilities under a court order or consent decree, by specific condition of confinement, midyear 2019
csfacf19at04.csv	Appendix Table 4. Number of prisoners held in correctional facilities for federal, state, and local authorities, by operator and state, midyear 2019
csfacf19at05.csv	Appendix Table 5. Number of prisoners, total security staff, and prisoner-to-security-staff ratio in confinement facilities, by operator and state, midyear 2019
csfacf19at06.csv	Appendix Table 6. Percentages for figure 1: Percent of adult correctional facilities and prisoners, by facility type, midyear 2019
csfacf19at07.csv	Appendix Table 7. Percentages for figure 2: Percent of confinement and community-based facilities and prisoners, by operator, midyear 2019
