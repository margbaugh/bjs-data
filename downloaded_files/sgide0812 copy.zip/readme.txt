State Government Indigent Defense Expenditures, FY 2008-2012 NCJ 246684		
		
 		
This zip archive contains tables in individual .csv spreadsheets from		
State Government Indigent Defense Expenditures, FY 2008-2012 NCJ 246684		
		
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5052		
		
		
Filename		Appendix table title
sgied0812at01.csv		Appendix table 1. State government indigent defense expenditures, by state, FY 2008�2012 (2012 dollars)
		
Filename		Figure title
sgide0812f01.csv		Figure 1. State government indigent defense expenditures, FY 2008�2012 (2012 dollars)
		
Filename		Table title
sgide0812t01.csv		Table 1. State government indigent defense expenditures, FY 2008�2012 (2012 dollars)
sgide0812t02.csv		Table 2. State government judicial-legal expenditures, FY 2008�2012 (2012 dollars)
sgide0812t03.csv		Table 3. Comparison of Indigent Defense Expenditures in BJS�s Census of Public Defender Offices, CY 2007, and Census Bureau�s Indigent Defense Services Study, FY 2008 (2012 dollars)
