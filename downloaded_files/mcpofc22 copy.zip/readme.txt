Methamphetamine, Cocaine, and Other Psychostimulant Offenses in Federal Courts, 2022  NCJ 309288
																
This zip archive contains tables in individual  .csv spreadsheets from
Methamphetamine, Cocaine, and Other Psychostimulant Offenses in Federal Courts, 2022  NCJ 309288.  The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/methamphetamine-cocaine-and-other-psychostimulant-offenses-federal-courts-2022
																
Filenames		Table titles
mcpofc22t01.csv	Table 1. Federal and state arrests by the Drug Enforcement Administration, by drug type, FY 2002–2022
mcpofc22t02.csv	Table 2. Persons arrested by the Drug Enforcement Administration for a psychostimulant offense, by sex and age, FY 2022
mcpofc22t03.csv	Table 3. Demographic characteristics of persons sentenced for a psychostimulant offense, FY 2022
mcpofc22t04.csv	Table 4. Sentencing characteristics of persons sentenced for a psychostimulant offense, FY 2022
mcpofc22t05.csv	Table 5. Sentencing outcomes of persons sentenced for a psychostimulant offense, FY 2022															
mcpofc22t06.csv	Table 6. Persons sentenced for a psychostimulant offense, by whether the offense carried a mandatory minimum sentence, FY 2022
mcpofc22t07.csv	Table 7. Persons sentenced for a psychostimulant offense that carried a mandatory minimum sentence, by whether the penalty was applied, FY 2022
mcpofc22t08.csv	Table 8. Persons sentenced in federal district court for a psychostimulant offense, by primary guideline, FY 2022
																
			Figures															
mcpofc22f01.csv	Figure 1. Federal and state arrests by the Drug Enforcement Administration involving psychostimulants, FY 2002–2022
mcpofc22f02.csv	Figure 2. Federal and state arrests by the Drug Enforcement Administration involving powder methamphetamine and crystal methamphetamine, FY 2002–2022
mcpofc22f03.csv	Figure 3. Federal and state arrests by the Drug Enforcement Administration involving powder cocaine and crack cocaine, FY 2002–2022
mcpofc22f04.csv	Figure 4. Number of drug overdose deaths involving cocaine and other psychostimulants with abuse potential, 2002–2022
mcpofc22f05.csv	Figure 5. Number of drug overdose deaths involving psychostimulants and opioids, 2002–2022															
mcpofc22f06.csv	Figure 6. Number of persons sentenced for a drug offense involving psychostimulants as the primary drug, FY 2002–2022
																
			Maps
mcpofc22m01.csv	Map 1. Rates of sentences imposed for psychostimulants per 100 drug sentences, by state or territory, FY 2022
mcpofc22m02.csv	Map 2. Rates of sentences imposed for methamphetamine per 100 drug sentences, by state or territory, FY 2022
																
			Appendix tables
mcpofc22at01.csv	Appendix table 1. Counts for figure 1: Federal and state arrests by the Drug Enforcement Administration involving psychostimulants, FY 2002–2022
mcpofc22at02.csv	Appendix table 2. Counts for figure 2: Federal and state arrests by the Drug Enforcement Administration involving powder methamphetamine and crystal methamphetamine, FY 2002–2022
mcpofc22at03.csv	Appendix table 3. Counts for figure 3: Federal and state arrests by the Drug Enforcement Administration involving powder cocaine and crack cocaine, FY 2002–2022
mcpofc22at04.csv	Appendix table 4. Counts for figure 4: Number of drug overdose deaths involving cocaine and other psychostimulants with abuse potential, 2002–2022
mcpofc22at05.csv	Appendix table 5. Counts for figure 5: Number of drug overdose deaths involving psychostimulants and opioids, 2002–2022
mcpofc22at06.csv	Appendix table 6. Counts for figure 6: Number of persons sentenced for a drug offense involving psychostimulants as the primary drug, FY 2002–2022
mcpofc22at07.csv	Appendix table 7. Counts and rates for map 1: Rates of sentences imposed for psychostimulants per 100 drug sentences, by state or territory, FY 2022
mcpofc22at08.csv	Appendix table 8. Counts and rates for map 2: Rates of sentences imposed for methamphetamine per 100 drug sentences, by state or territory, FY 2022