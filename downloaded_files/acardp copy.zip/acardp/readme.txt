Assessment of Coverage in the Arrest-Related Deaths Program      NCJ 249099			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Assessment of Coverage in the Arrest-Related Deaths Program, NCJ 249099.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5412	
			
	
			
Filename			Table title
cv14t01.csv			Table 1. Number and percent of law enforcement homicides captured, by source and estimation approach, 2003�2009 and 2011
		

Figure tables			
acardptf01.csv			Figure 1. Estimated number of law enforcement homicides and percent not reported, by data source, 2003�2009 and 2011
acardptf02.csv			Figure 2. Number of law enforcement homicides reported to the ARD program and estimated, lower bound, 2003�2009 and 2011
acardptf03.csv			Figure 3. Number of law enforcement homicides reported to the ARD program and estimated, unadjusted coverage, 2003�2009 and 2011

