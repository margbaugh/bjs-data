
Violent Felons in Large Urban Counties, NCJ 205289

This zip archive contains tables in individual .csv spreadsheets 
from Violent Felons in Large Urban Counties,  NCJ 205289. The full report 
including text and graphics in pdf format are available
from: http://www.ojp.usdoj.gov/bjs/abstract/vfluc.htm

vfluct01.csv	Table: 1	Felony convictions in the 75 largest counties, by most serious conviction charge, selected months, 1990-2002  
vfluct02.csv	Table: 2	Gender of violent felons in the 75 largest counties, by most serious conviction charge, 1990-2002 
vfluct03.csv	Table: 3	Age at arrest of violent felons in the 75 largest counties, by most serious arrest charge, 1990-2002 
vfluct04.csv	Table: 4	Race and Hispanic origin of violent felons in the 75 largest counties, by most serious conviction charge, 1990-2002 
vfluct05.csv	Table: 5	Criminal justice status of violent felons in the 75 largest counties, at the time of arrest, by most serious conviction charge, 1990-2002
vfluct06.csv	Table: 6	Number of prior arrest charges of convicted violent felons in the 75 largest counties, by most serious conviction charge, 1990-2002 
vfluct07.csv	Table: 7	Number of prior felony arrest charges of convicted violent felons in the 75 largest counties, by most serious conviction charge, 1990-2002   
vfluct08.csv	Table: 8	Number of prior convictions of violent felons in the 75 largest counties, by most serious current conviction charge, 1990-2002 
vfluct09.csv	Table: 9	Number of prior felony convictions of violent felons in the 75 largest counties, by most serious current conviction charge, 1990-2002   
vfluct10.csv	Table: 10	Most serious prior conviction of violent felons in the 75 largest counties, by most serious current conviction charge, 1990-2002 
vfluct11.csv	Table: 11	Pretrial release and detention of violent felons in the 75 largest counties, by most serious conviction charge, 1990-2002   
vfluct12.csv	Table: 12	Released violent felons in the 75 largest counties committing misconduct, by most serious conviction charge, 1990-2002 
vfluct13.csv	Table: 13	Adjudication method for violent felons in the 75 largest counties, by most serious conviction charge, 1990-2002 
vfluct14.csv	Table: 14	Legal representation of violent felons in the 75 largest counties, at time of conviction, by most serious conviction charge, 1990-2002 
vfluct15.csv	Table: 15	Most severe type of sentence received by convicted felons in the 75 largest counties, by most serious conviction offense, 1990-2002 
vfluct16.csv	Table: 16	Length of prison sentence received by violent felons in the 75 largest counties, by most serious conviction offense, 1990-2002 
vfluct17.csv	Table: 17	Length of jail sentence received by violent felons in the 75 largest counties, by most serious conviction offense, 1990-2002 
vfluct18.csv	Table: 18	Length of probation sentence received by violent felons in the 75 largest counties, by most serious conviction offense, 1990-2002 

vfluctt01.csv	Text Table: 1	Percent of violent felons released with a set bail amount

vflucata.csv	Appendix Table: A	Participating jurisdictions, State Court Processing Statistics, 1990-2002 

vflucf01.csv	Figure: 1	Race distribution of violent felons in the 75 largest counties, by age at arrest, 1990-2002 
vflucf02.csv	Figure: 2	Violent felons in the 75 largest counties who were denied bail or had bail set at $100,000 or more, 1990-2002 
vflucf03.csv	Figure: 3	Legal representation of violent felons in the 75 largest counties, at time of conviction, by type of adjudication, 1990-2002
vflucf04.csv	Figure: 4	Mean and median number of months sentenced to incarceration for violent felons in the 75 largest counties, 1990-2002

vfluchi.csv	Highlight Table	Criminal history of persons convicted of a violent felony in the 75 largest counties, 1990-2002