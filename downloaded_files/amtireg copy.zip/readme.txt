Assessing Measurement Techniques for Identifying Race, Ethnicity, and Gender: Observation-Based Data Collection in Airports and at Immigration Checkpoints, NCJ 197936																	
																	
This zip archive contains tables and figures in individual .wk1 spreadsheets from the report, "Assessing Measurement Techniques for Identifying Race, Ethnicity, and Gender: Observation-Based Data Collection in Airports and at Immigration Checkpoints."  The full report including tables and graphics in .pdf format is available from:  http://www.ojp.usdoj.gov/bjs/abstract/amtireg.htm   
													
Tables:																	
																	
amtireg1.wk1	Table 1.  Observations at Border Patrol checkpoint, January 2002
amtireg2.wk1	Table 2.  Race and ethnicity observations of drivers and passengers at a Border Patrol checkpoint, 2002 	
amtireg3.wk1	Table 3.  Inter-rater agreement on observations of gender, race, and Hispanic origin, at a Border Patrol checkpoint during 12 periods
amtireg4.wk1	Table 4.  Observations at an airport, 2002
amtireg5.wk1	Table 5.  Inter-rater agreement on observations of gender, race, and Hispanic origin, at an airport during 10 periods

