Federal Hate Crime Prosecutions, 2005-19  NCJ 300952	
	
This zip archive contains tables in individual  .csv spreadsheets	
Federal Hate Crime Prosecutions, 2005-19  NCJ 300952  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/federal-hate-crime-prosecutions-2005-19
	
Filename		Table title
fhcp0519t01.csv		Table 1. Suspects in hate crime matters investigated by U.S. attorneys, by lead charge, fiscal years 2005-19
fhcp0519t02.csv		Table 2. Agencies that referred hate crime matters investigated by U.S. attorneys, fiscal years 2005-19
fhcp0519t03.csv		Table 3. Suspects in hate crime matters investigated by U.S. attorneys, by suspects per matter, fiscal years 2005-19
fhcp0519t04.csv		Table 4. Suspects in hate crime matters concluded by U.S. attorneys, by outcome of investigation and lead charge, fiscal years 2005-19
fhcp0519t05.csv		Table 5. Suspects in hate crime matters that U.S. attorneys declined to prosecute, by reason, fiscal years 2005–19
fhcp0519t06.csv		Table 6. Defendants charged with a hate crime in cases terminated in U.S. district court, by most serious offense, fiscal years 2005-19
fhcp0519t07.csv		Table 7. Defendants charged with a hate crime in cases terminated in U.S. district court, by disposition of case and most serious offense, fiscal years 2005-19
fhcp0519t08.csv		Table 8. Defendants convicted of a hate crime in cases terminated in U.S. district court, by sentence imposed and most serious offense, fiscal years 2005-19
fhcp0519t09.csv		Table 9. Defendants sentenced to prison for a hate crime in cases terminated in U.S. district court, by prison term and most serious offense, fiscal years 2005-19
	
			Figures
fhcp0519f01.csv		Figure 1. Number of suspects in hate crime matters investigated by U.S. attorneys, by lead charge, fiscal years 2005-19
fhcp0519f02.csv		Figure 2. Number of defendants charged with a hate crime in cases terminated in U.S. district court, by most serious offense, fiscal years 2005-19
	
			Appendix tables
fhcp0519at01.csv	Appendix table 1. Number of suspects in hate crime matters investigated by U.S. attorneys, by lead charge, fiscal years 2005–2019
fhcp0519at02.csv	Appendix table 2. Number of defendants charged with a hate crime in cases terminated in U.S. district court, by most serious offense, fiscal years 2005-2019
fhcp0519at03.csv	Appendix table 3. Number of hate crime suspects referred to U.S. attorneys and hate crime defendants convicted in U.S. district court, by state and U.S. territory, fiscal years 2005-19
	
	
	
	
