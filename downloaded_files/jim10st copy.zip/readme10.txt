Jail Inmates at Midyear 2010-Statistical Tables  NCJ 233431	
	
This zip archive contains tables in individual .csv spreadsheets	
Jail Inmates at Midyear 2010-Statistical Tables  NCJ 233431	
The full report including text and graphics in .pdf format are available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2375
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=38
 	
Tables	
jim10stt01.csv	Table 1: Inmates confined in local jails at midyear, average daily population, and incarceration rates, 2000-2010
jim10stt02.csv	Table 2: Rated capacity of local jails and percent of capacity occupied, 2000-2010
jim10stt03.csv	Table 3: Inmates confined in local jails at midyear, by size of jurisdiction, 2009 and 2010
jim10stt04.csv	Table 4: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2009 and 2010
jim10stt05.csv	Table 5: Percent of jail capacity occupied at midyear, by size of jurisdiction 2009 and 2010
jim10stt06.csv	Table 6: Number of inmates in local jails, by characteristic, midyear 2000 and 2005�2010
jim10stt07.csv	Table 7: Percent of inmates in local jails, by characteristic, midyear 2000 and 2005�2010
jim10stt08.csv	Table 8: Inmate population in jail jurisdictions reporting on confined persons being held for U.S. Immigration and Customs Enforcement, midyear 2002-2010
jim10stt09.csv	Table 9: The 50 largest local jail jurisdictions, by number of inmates held, average daily population, and rated capacity, midyear 2008-2010
jim10stt10.csv	Table 10: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2010
jim10stt11.csv	Table 11: Estimated standard errors, by confinement status, Annual Survey of Jails, 2010
jim10stt12.csv	Table 12. Estimated standard errors, by selected characteristic, Annual Survey of Jails, 2010
jim10stt13.csv	Table 13: Estimated percentages of local jail inmates, by selected characteristic and ratio estimates, 2010
	
Figure	
jim10stf01.csv	Figure 1: Inmates confined in local jails at midyear and change in the jail population, 2000-2010
