						readme.txt

Contents of zip archive scs9605.zip
Tables from Section 5 of State Court Sentencing of Convicted Felons, 1996, NCJ 175708

scs9651.wk1		Table 5.1 Transferred juveniles compared to adults by State definition: most serious
                     	offense of felons convicted in State courts, 1996
scs9652.wk1		Table 5.2 Transferred juveniles compared to adults by State definition: most serious
                    	offense, by the type of felony sentence imposed in State courts, 1996
scs9653.wk1		Table 5.3 Transferred juveniles compared to adults by State definition: mean length
                     	of felony sentence imposed in State courts, by the type of sentence and most
                     	serious offense, 1996