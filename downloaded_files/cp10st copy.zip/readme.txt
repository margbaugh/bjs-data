Capital Punishment, 2010 - Statistical Tables  NCJ 236510

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2010 - Statistical Tables  NCJ 236510, electronic only. 
The full electronic report is available at:


These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to:



Tables:
cp10stf01.csv		Figure 1. Number of persons executed in the United States, 1930-2010
cp10stf02.csv		Figure 2. Number of persons under sentence of death, 1953-2010
cp10stf03.csv		Figure 3. Advance count of executions, January 1, 2011 - December 19, 2011
cp10stt02.csv		Table 2.  Method of execution, by state, 2010
cp10stt03.csv		Table 3.  Federal capital offenses, by statute, 2010
cp10stt04.csv		Table 4.  Prisoners under sentence of death, by region, jurisdiction, and race, 2009 and 2010
cp10stt05.csv		Table 5.  Women under sentence of death, by region, jurisdiction, and race, 2009 and 2010
cp10stt06.csv		Table 6.  Hispanics under sentence of death, by region and jurisdiction, 2009 and 2010
cp10stt07.csv		Table 7.  Inmates removed from under sentence of death, by method of removal, 2010
cp10stt08.csv		Table 8.  Average time between sentencing and execution, by year, 1977-2010
cp10stt09.csv		Table 9.  Number of inmates executed, by race, 1977-2010
cp10stt10.csv		Table 10. Executions, by state and method, 1977-2009
cp10stt11.csv		Table 11. Number of persons executed, by jurisdiction, 1930-2010
cp10stt12.csv		Table 12. Prisoners under sentence of death on December 31, 2010, by jurisdiction and year of sentencing
cp10stt13.csv		Table 13. Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2010
cp10stt14.csv		Table 14. Prisoners sentenced to death and outcome of the sentence, by year of sentencing, 1973-2010
cp10stt15.csv		Table 15. Number sentenced to death and number of removals, by jurisdiction and reason for removal, 1973-2010


