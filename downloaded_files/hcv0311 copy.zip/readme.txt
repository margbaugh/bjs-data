Hate Crime Victimization, 2003-2011		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Hate Crime Victimization, 2003-2011 NCJ 241291		
The full report including text and graphics in pdf format is available at:              		
http://bjs.ojp.usdoj.gov/index.cfm-ty=pbse&sid=4164		
		
This report is one in a series. More recent editions may be available. 
To view a list of all in the series go to 
http://bjs.ojp.usdoj.gov/index.cfm-ty=dcdetail&iid=72		
		
hcv0311f01.csv		Figure 1. Victim perceptions of offender bias in hate crime, 2003-2006 and 2007-2011
hcv0311f02.csv		Figure 2. Rate of violent hate crime victimizations, by method used to count high frequency repeat (series) victimizations, 2004-2011
hcv0311f03.csv		Figure 3. Hate and nonhate victimizations, by type of crime, 2003-2011
hcv0311f04.csv		Figure 4. Violent hate and nonhate victimizations, by location, 2003-2011
hcv0311f05.csv		Figure 5. Hate and nonhate victimizations reported to the police, by type of crime, 2003-2006 and 2007-2011
hcv0311f06.csv		Figure 6. Most important reason why violent hate crime victimization was not reported to police, 2003-2006 and 2007-2011
hcv0311f07.csv		Figure 7. Hate crime victimizations recorded in official police records, 2003-2011
hcv0311f08.csv		Figure 8. Offender bias in hate crimes recorded in official police records, 2003-2006 and 2007-2011
		
hcv0311t01.csv		Table 1. Violent hate crimes, excluding and including gender bias, 2010-2011
hcv0311t02.csv		Table 2. Hate crime victimizations, 2004-2011
hcv0311t03.csv		Table 3. Annual average distribution for hate crime victimizations, by offense, 2003-2006 and 2007-2011
hcv0311t04.csv		Table 4. Hate crime victimizations, by type of crime, 2003-2006 and 2007-2011
hcv0311t05.csv		Table 5. Presence of weapons and injuries sustained in violent hate crime victimizations, 2003-2006 and 2007-2011
hcv0311t06.csv		Table 6. Hate crime victimizations, by location, 2003-2006 and 2007-2011
hcv0311t07.csv		Table 7. Hate crime victimizations reported to police, 2003-2006 and 2007-2011
hcv0311t08.csv		Table 8. Characteristics of violent hate crime victims, 2003-2006 and 2007-2011
hcv0311t09.csv		Table 9. Characteristics of violent hate crime offenders as reported by victims, 2003-2006 and 2007-2011
hcv0311t10.csv		Table 10. Hate crime victimizations recorded by the NCVS and UCR, by offense, 2003-2011
		
hcv0311at01.csv		Appendix table 1. Population and total criminal victimization counts, 2003-2011
hcv0311at02.csv		Appendix table 2. Estimates and standard errors for figure 1: Victim perceptions of offender motivation in hate crime, 2003-2006 and 2007-2011 
hcv0311at03.csv		Appendix table 3. Estimates and stardard errors for figure 2: Rate of violent hate crime victimizations, by method used to count high frequency repeat (series) victimizations, 2004-2011
hcv0311at04.csv		Appendix table 4. Standard errors for table 1: Violent hate crimes with crimes motivated by gender bias excluded and included, 2010-2011
hcv0311at05.csv		Appendix table 5. Standard errors for table 2: Hate crime victimizations, 2004-2011
hcv0311at06.csv		Appendix table 6. Standard errors for table 3: Annual average for hate crime victimizations, 2003-2006 and 2007-2011
hcv0311at07.csv		Appendix table 7. Standard errors for table 4: Hate crime victimizations, by type of crime, 2003-2006 and 2007-2011
hcv0311at08.csv		Appendix table 8. Estimates and standard errors for figure 3: Hate and nonhate victimizations, by type of crime, 2003-2011
hcv0311at09.csv		Appendix table 9. Standard errors for table 5: Presence of weapons and injuries sustained in violent hate crime victimizations, 2003-2006 and 2007-2011
hcv0311at10.csv		Appendix table 10. Standard errors for table 6: Hate crime victimizations, by location, 2003-2006 and 2007-2011
hcv0311at11.csv		Appendix table 11. Estimates and standard errors for figure 4: Violent hate and nonhate victimizations, by location, 2003-2011 
hcv0311at12.csv		Appendix table 12. Standard errors for table 7: Hate crime victimizations reported to police, 2003-2006 and 2007-2011
hcv0311at13.csv		Appendix table 13. Estimates and standard errors for figure 5: Hate and nonhate victmizations reported to police, by type of crime, 2003-2006 and 2007-2011
hcv0311at14.csv		Appendix table 14. Standard errors for figure 6: Most important reason why violent hate crime victimization was not reported to police, 2003-2006 and 2007-2011
hcv0311at15.csv		Appendix table 15. Standard errors for table 8: Characteristics of violent hate crime victims, 2003-2006 and 2007-2011
hcv0311at16.csv		Appendix table 16. Standard errors for table 9: Characteristics of violent hate crime offenders as reported by victims, 2003-2006 and 2007-2011
hcv0311at17.csv		Appendix table 17. Standard errors for table 10: Hate crime victimizations recorded by the NCVS and UCR, by offense, 2003-2011
