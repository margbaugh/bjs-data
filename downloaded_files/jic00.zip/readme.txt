Jails in Indian Country, 2000,  NCJ 188156

This zip archive contains tables in individual .wk1 spreadsheets
from Jails in Indian Country,  2000,  NCJ 188156
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jic00.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic

jic0001.wk1    Table #1: Indian country jail inmate characteristics, June 30, 1999 and 2000
                    
jic0002.wk1    Table #2: Persons under community supervision, June 30, 1999 and 2000
                                        
jic0003.wk1    Table #3: Ten largest jails in Indian country, June 30, 2000              
                                                            
jic0004.wk1    Table #4: Jails in Indian country operating above 150% of capacity on peak day
               in June 2000                            

jic0005.wk1    Table #5:  Court orders, consent decrees, and planned changes for jails in Indian
               country, June 30, 2000

jic00a02.wk1   Appendix table #2: Inmates, rated capacity, and percent of capacity occupied jails
               in Indian country, June 2000  
     
jic00a03.wk1   Appendix table #3:  Adults and juveniles in the custody of jails in Indian country,
               by gender, June 30, 2000
          
jic00a04.wk1   Appendix table #4: Inmates in jails in Indian country, by conviction status and
               seriousness of the offense, June 30, 2000

jic00a05.wk1   Appendix table #5: Inmates in jails in Indian country with a DWI/DUI offense or
               a drug violation or in detoxification, June 30, 2000
                                                       
jic00a06.wk1    ppendix table #6: Planned changes to jails in Indian country and change in
               capacity, June 30, 2000

jic00a07.wk1   Appendix table #7: Jails in Indian country under court order or consent decree to   
               limit population or for other reasons, June 30, 2000


                    