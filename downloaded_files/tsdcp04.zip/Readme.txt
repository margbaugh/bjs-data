TRAFFIC STOP DATA COLLECTION POLICIES FOR STATE POLICE, 2004 NCJ 209156																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .wk1 spreadsheets from the
Fact Sheet, "Traffic Stop Data Collection Policies for State Police, 2004"
NCJ 209156. The full report including text and graphics in pdf format are 
available from: http://www.ojp.usdoj.gov/bjs/abstract/tsdcpsp04.htm 

This report is one in a series.  Most recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalph2.htm#tsdcp
----------------------------------------------------------------------------
																	
Filename		Table																
																	
tsdcp04h1.csv	Highlights Table 1. State police agencies collecting race/ethnicity data for traffic stops, 1999, 2001, and 2004

tsdcp0401.csv	Table 1. Agencies that required the collection of information in addition to the driver's race or ethnicity, 2004	
tsdcp0402.csv	Table 2. Circumstances during traffic stops in which State police agencies required troopers to collect race or ethnicity data about motorists, by State, 2004
