Crime and the Nation's Households, 2003   NCJ  206348	

This zip archive contains tables in individual .wk1 spreadsheets
from Crime and the Nation's Households, 2003   NCJ  206348	
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cnh03.htm

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdjo.gov/bjs/pubalp2.htm#cnh

File Name	   Highlights
cnh03ht.cvs	   Highlight 1.  Percent of U. S. households experiencing violent or property crime

	            Table Titles
cnh0301.cvs	   Table 1.  Households experiencing crime, by type of crime, 2003
cnh0302.cvs    Table 2.  Households experiencing crime, by race of the household head, 2003
cnh0303.cvs	   Table 3.  Households experiencing crime, by urban, suburban, and rural location, 2003
cnh0304.cvs	   Table 4.  Households experiencing crime, by number of household members, 2003
cnh0305.cvs	   Table 5.  Households experiencing crime, by type of crime, 1994 and 2003

	           Text Titles
cnh03tt1.cvs   Text Table 1. Violent and Property Crime, 2002-2003
cnh03tt2.cvs   Text Table 2. Hispanic and Non-Hispanic
cnh03tt3.cvs   Text Table 3. Region

	            Figures Titles
cnh03f1.cvs	    Figure 1. Violence by strangers or burglary
cnh03f2.cvs	    Figure 2. Intimate partner violence  
