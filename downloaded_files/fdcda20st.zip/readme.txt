Federal Deaths in Custody and During Arrest, 2020 – Statistical Tables  NCJ 304939	
	
This zip archive contains tables in individual .csv spreadsheets from	
Federal Deaths in Custody and During Arrest, 2020 – Statistical Tables  NCJ 304939	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/federal-deaths-custody-and-during-arrest-2020-statistical-tables
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Deaths%20in%20Custody%20and%20During%20Arrest	
	
Filenames		Table titles
fdcda20stt01.csv	Table 1. Number of deaths reported, by type of death and federal agency, FY 2020
fdcda20stt02.csv	Table 2. Arrest-related deaths, by manner of death and weapon causing death, FY 2020
fdcda20stt03.csv	Table 3. Arrest-related deaths, by decedent characteristics, FY 2020
fdcda20stt04.csv	Table 4. Arrest-related deaths, by reason for law enforcement contact and alleged decedent offense, FY 2020
fdcda20stt05.csv	Table 5. Arrest-related deaths, by decedent condition and actions during the incident, FY 2020
fdcda20stt06.csv	Table 6. Arrest-related deaths, by law enforcement actions, FY 2020
fdcda20stt07.csv	Table 7. Arrest-related deaths, by law enforcement weapon use, FY 2020
fdcda20stt08.csv	Table 8. Deaths in custody, by manner and location of death, FY 2020
fdcda20stt09.csv	Table 9. Deaths in custody, by decedent characteristics, FY 2020
fdcda20stt10.csv	Table 10. Deaths in custody, by decedent offense, legal status, and time served, FY 2020
fdcda20stt11.csv	Table 11. Responses to the Federal Law Enforcement Agency Deaths in Custody Reporting Program, FY 2020
	
			Figures
fdcda20stf01.csv	Figure 1. Number of arrest-related deaths and deaths in custody, FY 2016–2020
	
			Appendix tables
fdcda20stat01.csv	Appendix table 1. Counts for figure 1: Number of arrest-related deaths and deaths in custody, FY 2016–2020
