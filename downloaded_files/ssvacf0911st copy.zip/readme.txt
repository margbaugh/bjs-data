Survey of Sexual Violence in Adult Correctional Facilities, 2009-11 - Statistical Tables NCJ 244227		
		
 		
This zip archive contains tables in individual .csv spreadsheets from		
Survey of Sexual Violence in Adult Correctional Facilities, 2009-11 - Statistical Tables NCJ 244227		
		
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4881		
		
Filename			Table title
ssvacf0911t01.csv		Table 1. Allegations of sexual victimization reported by federal and state prison authorities, by type of victimization, 2011
ssvacf0911t02.csv		Table 2. Allegations of sexual victimization reported by federal and state prison authorities, by type of victimization, 2010
ssvacf0911t03.csv		Table 3. Allegations of sexual victimization reported by federal and state prison authorities, by type of victimization, 2009
ssvacf0911t04.csv		Table 4. Allegations of sexual victimization reported by local jail authorities, by type of victimization, 2011
ssvacf0911t05.csv		Table 5. Allegations of sexual victimization reported by local jail authorities, by type of victimization, 2010
ssvacf0911t06.csv		Table 6. Allegations of sexual victimization reported by local jail authorities, by type of victimization, 2009
ssvacf0911t07.csv		Table 7. Local jail authorities with no allegations of sexual victimization, 2011
ssvacf0911t08.csv		Table 8. Local jail authorities with no allegations of sexual victimization, 2010
ssvacf0911t09.csv		Table 9. Local jail authorities with no allegations of sexual victimization, 2009
ssvacf0911t10.csv		Table 10. Allegations of sexual victimization reported by privately operated jail and prison authorities, by type of victimization, 2011
ssvacf0911t11.csv		Table 11. Allegations of sexual victimization reported by privately operated jail and prison authorities, by type of victimization, 2010
ssvacf0911t12.csv		Table 12. Allegations of sexual victimization reported by privately operated jail and prison authorities, by type of victimization, 2009
ssvacf0911t13.csv		Table 13. Privately operated jail and prison authorities with no allegations of sexual victimization, 2011
ssvacf0911t14.csv		Table 14. Privately operated jail and prison authorities with no allegations of sexual victimization, 2010
ssvacf0911t15.csv		Table 15. Privately operated jail and prison authorities with no allegations of sexual victimization, 2009
ssvacf0911t16.csv		Table 16. Allegations of sexual victimization reported by other correctional facility authorities, by type of victimization, 2011
ssvacf0911t17.csv		Table 17. Allegations of sexual victimization reported by other correctional facility authorities, by type of victimization, 2010
ssvacf0911t18.csv		Table 18. Allegations of sexual victimization reported by other correctional facility authorities, by type of victimization, 2009
