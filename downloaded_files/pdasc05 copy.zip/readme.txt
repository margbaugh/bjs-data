Punitive Damage Awards in State Courts, 2005			
			
This zip archive contains tables in individual .csv  spreadsheets from the Punitive Damage Awards in State Courts, 2005, NCJ 233094.	
The full electronic report is available at: www.bjs.gov/index.cfm?ty=pbdetail&iid=2376

		
			

			
Filename   Table title		
pdasc05t01 Punitive damages sought in civil trials in state courts, by all trials and trials with plaintiff winners, 2005		
pdasc05t02 Percentage of civil cases disposed of by bench or jury trial, 2005		
pdasc05t03 Punitive damages sought in civil trials in state courts, by litigant pairings and by trials with plaintiff winners, 2005		
pdasc05t04 Punitive damages sought in civil trials in state courts, by compensatory damage award amounts, 2005		
pdasc05t05 Plaintiff winners awarded punitive damages in civil trials in state courts, by case types, 2005		
pdasc05t06 Plaintiff winners who requested and were awarded punitive damages in civil trials in state courts, 2005		
pdasc05t07 Plaintiff winners awarded punitive damages in civil trials in state courts, by litigant pairings, 2005		
pdasc05t08 Punitive damage award amounts in civil trials in state courts, 2005		
Pdasc05t09 Ratio of punitive to compensatory damages by median awards in tort trials concluded in state courts, 2005		
pdasc05t10 Comparing punitive damages between bench and jury civil trials concluded in state courts, 2005		
pdasc05t11 Post-trial relief sought in civil trials with punitive damages awarded to plaintiff winners in state courts, 2005		
pdasc05t12 Notices of appeal filed in civil trials with punitive damages awarded to plaintiff winners in state courts, 2005	
			
Filename    Appendix table title		
pdasc05at01 Civil Justice Survey of State Courts, Sampling Framework		
pdasc05at02 Standard errors and confidence intervals for civil trials with punitive awards, by selected characteristics, 2005 Civil Justice Survey of State		
pdasc05at03 Punitive damages sought in civil trials in state courts, by the sampled CJSSC jurisdictions, 2005		
pdasc05at04 Punitive damages awarded in civil trials in state courts, by the sampled CJSSC jurisdictions, 2005		
