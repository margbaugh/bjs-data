Jails in Indian Country, 2001, NCJ 193400

This zip archive contains tables in individual .wk1 spreadsheets
from Jails in Indian Country, 2001, NCJ 193400
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jic01.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic


File name	Table           	Title
jic0101.wk1	Table 1 		Indian country jail inmate characteristics, midyear, 2000 and 2001
				
jic0102.wk1	Table 2 		Indian country jail inmate admissions and reported suicides

jic0103.wk1	Table 3 		Ten largest jails in Indian country, June 29, 2001			
												
jic0104.wk1	Table 4 		Jails in Indian country operating above 150% of capacity on the peak day during June 2001						

jic0105.wk1	Table 5 		Court orders, consent decrees, and planned changes for jails in Indian country

jic01a02.wk1	Appendix table 2 	Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 2001	
	
jic01a03.wk1	Appendix table 3 	Adults and juveniles in the custody of jails in Indian country, by gender, June 29, 2001
		
jic01a04.wk1	Appendix table 4 	Inmates in jails in Indian country, by conviction status and seriousness of the offense, June 29, 2001

jic01a05.wk1	Appendix table 5 	Inmates in jails in Indian country with a DWI/DUI offense or a drug violation or in detoxification, June 29, 2001
											
jic01a06.wk1	Appendix table 6 	Planned changes to jails in Indian country and projected capacity when completed

jic01a07.wk1 	Appendix table 7 	Jails in Indian country under court order or consent decree 
		 			to limit population or for other reasons, June 29, 2001

jic01h01.wk1	Highlights table 1  	Persons under Indian country correctional supervision and inmate admissions, 2000 and 2001 

jic01h02.wk1	Highlights table 2	Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 1998-2001

jic01h03.wk1	Highlights table 3	Planned changes to jails in Indian country

jic01t01.wk1	Text table 1  		American Indians and Alaska Natives under correctional supervision in the United States 

jic01t02.wk1	Text table 2		Persons under community supervision in Indian country, midyear 2000 and 2001

jic01t03.wk1	Text table 3		Number of facilities by size of facility, June 29, 2001

jic01t04.wk1	Text table 4		Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 1998-2001

jic01t05.wk1	Text table 5		Percent of capacity occupied on peak day in June 2001 by rated capacity of facility 
	