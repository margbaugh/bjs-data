"Victims of identity Theft, 2014      NCJ 248991"			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Victims of identity Theft, 2014, NCJ 248991.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5408
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go http://www.bjs.gov/index.cfm?ty=pbse&sid=60

Tables
vit14t01.csv		"Table 1. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012 and 2014"
vit14t02.csv		"Table 2. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by victim characteristics, 2012 and 2014"
vit14t03.csv		"Table 3. Persons age 16 or older who experienced at least one incident of misuse of an existing credit card, existing bank account, new account, or personal information during the pst 12 months, by victim characteristics, 2014"
vit14t04.csv		"Table 4. Most common ways victims discovered identity theft, by type of theft, 2014"
vit14t05.csv		"Table 5. Identity theft victims who knew something about the offender, by type of theft, 2014"
vit14t06.csv		"Table 6. Financial loss among victims who experienced at least one attempted or successful identity theft incident in the past 12 months, 2012 and 2014"
vit14t07.csv		"Table 7. Total financial loss due to identity theft, 2012 and 2014"
vit14t08.csv		"Table 8. Victims who experienced financial or legal problems as a result of identity theft, by type of theft, 2014"
vit14t09.csv		"Table 9. Identity theft and violent crime victims who experienced emotional distress, 2014"
vit14t10.csv		"Table 10. Actions persons age 16 or older took during the past 12 months to reduce the risk of identity theft, by whether the action was taken in response to the theft, 2014"
vit14t11.csv		"Table 11. Persons age 16 or older who experienced identity theft at any point in their lives, type of identity theft they experienced outside of the past year, and ongoing problems from identity theft that occurred outside of the past year, 2014"

Figures 
vit14f01.csv		"Figure 1. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012 and 2014"
vit14f02.csv		"Figure 2. Identity theft victims who knew how their personal information was obtained, 2014"
vit14f03.csv		"Figure 3. Total out-of-pocket loss for identity theft victims experiencing a loss of $1 or more, 2014"
vit14f04.csv		"Figure 4. Victims of identity theft and violent crime who experienced problems as a result of the victimization, 2014"
vit14f05.csv		"Figure 5. Length of time spent resolving financial and credit problems associated with identity theft, by type of identity theft, 2014"
vit14f06.csv		"Figure 6. Identity theft victims who reported work/school or family/friend problems or distress, by length of time spent resolving associated financial and credit problems, 2014"
vit14f07.csv		"Figure 7. Identity theft victims who reported the incident to law enforcement, 2014"
vit14f08.csv		"Figure 8. Identity theft victims who contacted a credit bureau, by action taken, 2014"

Appendix tables		
vit14at01.csv		"Appendix table 1. Financial loss among victims who experienced at least one attempted or successful identity theft incident in the past 12 months, by type of theft and type of loss, 2014"
vit14at02.csv		"Appendix table 2. Standard errors for appendix table 1: Financial loss among victims who experienced at least one attempted or successful identity theft incident in the past 12 months, by type of loss and type of theft, 2014"
vit14at03.csv		"Appendix table 3. Victims who did and did not report identity theft to police, by type of theft and reason for not reporting, 2014"
vit14at04.csv		"Appendix table 4. Standard errors for appendix table 3: Victims who did and did not report identity theft to police, by type of theft and reason for not reporting, 2014"
vit14at05.csv		"Appendix table 5. Identity theft victims who contacted an organization, by type of theft, type of organization, and credit bureau action, 2014"
vit14at06.csv		"Appendix table 6. Standard errors for appendix table 5: Identity theft victims who contacted an organization, by type of theft, type of organization and credit bureau action, 2014"
vit14at07.csv		"Appendix table 7. Standard errors for table 1 and figure 1: Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012 and 2014"
vit14at08.csv		"Appendix table 8. Standard errors for table 2: Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by victim characteristics, 2012 and 2014"
vit14at09.csv		"Appendix table 9. Standard errors for table 3: Persons age 16 or older who experienced at least one incident of misuse of existing credit card, existing bank account, new account, or personal information during the past 12 months, by victim characteristics, 2014"
vit14at10.csv		"Appendix table 10. Standard errors for table 4: Most common ways victims discovered identity theft, by type of theft, 2014"
vit14at11.csv		"Appendix table 11. Estimates and standard errors for figure 2: Identity theft victims who knew how their personal information was obtained, 2014"
vit14at12.csv		"Appendix table 12. Standard errors for table 5: Identity theft victims who knew something about the offender, by type of theft, 2014"
vit14at13.csv		"Appendix table 13. Standard errors for table 6: Financial loss among victims who experienced at least one attempted or successful identity theft incident in the past 12 months, 2012 and 2014"
vit14at14.csv		"Appendix table 14. Standard errors for table 7: Total financial loss due to identity theft, 2012 and 2014"
vit14at15.csv		"Appendix table 15. Estimates and standard errors for figure 3: Total out-of-pocket loss for identity theft victims experiencing a loss of $1 or more, 2014"
vit14at16.csv		"Appendix table 16. Standard errors for table 8: Victims who experienced financial or legal problems as a result of identity theft, by of theft, 2014"
vit14at17.csv		"Appendix table 17. Estimates and standard errors for figure 4: Victims of identity theft and violent crime who experienced problems as a result of the victimization, 2014"
vit14at18.csv		"Appendix table 18. Standard errors for table 9: Identity theft and violent crime victims who experienced emotional distress, 2014"
vit14at19.csv		"Appendix table 19. Estimates for figure 5: Length of time spent resolving financial and credit problems associated with identity theft, by type of identity theft, 2014"
vit14at20.csv		"Appendix table 20. Standard errors for appendix table 19: Length of time spent resolving financial and credit problems associated with identity theft, by type of theft, 2014"
vit14at21.csv		"Appendix table 21. Estimates and standard errors for figure 6: Identity theft victims who reported work/school or family/friend problems or distress, by length of time spent resolving associated financial and credit problems, 2014"
vit14at22.csv		"Appendix table 22. Standard errors for table 10: Actions persons age 16 or older took during the past 12 months to reduce the risk of identity theft, by whether the action was taken in response to the theft, 2014"
vit14at23.csv		"Appendix table 23. Standard errors for table 11: Persons age 16 or older who experienced identity theft at any point in their lives, type of identity theft they experienced outside of the past year, and ongoing problems from identity theft that occurrred outside of the past year, 2014"