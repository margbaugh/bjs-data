Time Served in State Prison, 2018  NCJ 255662		
		
This zip archive contains tables in individual .csv spreadsheets from Time Served in State Prison, 2018  NCJ 255662		
The full report including text and graphics in .pdf format are available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7307		
		
		
		
Filenames		Table names
tssp18t01.csv		Table 1. Time served in state prison before initial release, by most serious offense, 2018
tssp18t02.csv		Table 2. Cumulative percent of prisoners who served a given length of time before initial release, by most serious offense, 2018
tssp18t03.csv		Table 3. Average sentence length and percent of sentence served before initial release, by most serious offense, 2018
tssp18t04.csv		Table 4. Deaths among state prisoners awaiting their initial release, by most serious offense, 2018
		
			Figure name
tssp18f01.csv		Figure 1. Median time served in state prison before initial release, by most serious offense, 2018
