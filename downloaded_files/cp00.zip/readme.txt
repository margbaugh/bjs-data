Capital Punishment 2000  NCJ  190598

This zip archive contains tables in individual .wk1 spreadsheets
from Capital Punishment, NCJ 190598. The full report including 
text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cp00.htm 

cp0005.wk1     Table 5. Prisoners under sentence of death, by region, State, and race, 1999 and 2000

cp0006.wk1     Table 6.  Hispanics and women under sentence of death,  by State, 1999 and 2000 

cp0007.wk1     Table 7.  Demographic characteristics of prisoners  under sentence of death, 2000

cp0008.wk1     Table 8.  Age at time of arrest for capital offense and  age of prisoners under sentence of death at yearend 2000

cp0009.wk1     Table 9.  Criminal history profile of prisoners under sentence of death,  by race and Hispanic origin, 2000

cp0010.wk1     Table 10.  Number of persons  executed, by jurisdiction, 1930-2000

cp0011.wk1     Table 11.  Execution and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2000

cp0012.wk1     Table 12.  Time under sentence of death  and execution, by race, 1977-2000

cp00a1.wk1     Appendix table 1.  Prisoners sentenced to death and the outcome sentence, by year of sentencing, 1973-2000

cp00a2.wk1     Appendix table 2.  Prisoners under sentence of death on December 31, 2000, by State and year of sentencing

cp00a3.wk1     Appendix table 3.  Number sentenced to death and number of removals, by jurisdiction and reason for removal, 1973-2000

cp00a4.wk1     Appendix table 4.  Executions, by State and method, 1977-2000

cp00f1.wk1     Figure 1. Persons under sentence of death, 1953-2000

cp00f2.wk1     Figure 2. Persons under sentence of death at yearend, by race, 1968-2000

cp00f3.wk1     Figure 3. Persons executed, 1930-2000