SHERIFFS' OFFICES 2003 NCJ 211361																	
																	
This zip archive contains tables and figures in individual .csv spreadsheets from the 2003 Law Enforcement and Administrative
Statistics (LEMAS) report, "Sheriffs' Offices 2003."  The full report including tables and graphics in .pdf format 
are available from: http://www.ojp.usdoj.gov/bjs/abstract/so03.htm

This report is one in a series.  More recent editions may be available. To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#so


Tables:
		Exhibit 1. Twenty-five largest sheriffs' offices, by number and function of full-time sworn personnel, 2003	so03e01.csv														
so0301.csv	Table 1. Employment by general purpose State and local law enforcement agencies in the United States, 2003																
so0302.csv 	Table 2. Sheriffs' offices and full-time personnel, by number of sworn personnel, 2003
so0303.csv	Table 3. Sheriffs' offices and full-time personnel, by size of population served, 2003
so0304.csv	Table 4. Average number of employees in sheriffs' offices, by size of population served, 2003
so0305.csv	Table 5. Officers assigned to respond to citizen calls for service in sheriffs' offices, by size of population served, 2003
so0306.csv	Table 6. Authorized full-time strength of sheriffs' offices and percent of authorized strength employed, by size of population served, 2003
so0307.csv	Table 7. Officer separations and new officer hires in sheriffs' offices, by populations served, 2003
so0308.csv	Table 8. Types of officer separations in sheriffs' offices, by size of population served, 2003
so0309.csv	Table 9. Types of new officer hires in sheriffs' offices, by size of population served, 2003
so0310.csv	Table 10. Full-time sworn personnel in sheriffs' offices called-up as full-time military reservists, by size of population served, 2003
so0311.csv	Table 11. Use of sworn reserve or auxiliary officers in sheriffs' offices, by size of population served, 2003
so0312.csv	Table 12. Use of nonsworn reserve or auxiliary officers in sheriffs' offices, by size of population served, 2003
so0313.csv	Table 13. Gender and race of full-time sworn personnel in sheriffs' offices, by size of population served, 2003
so0314.csv	Table 14. Interviews, tests, and examinations used in selection of new officer recruits in sheriffs' offices, by size of population served, 2003
so0315.csv	Table 15. Background checks used in selection of new officer recruits in sheriffs' offices, by size of population served, 2003
so0316.csv	Table 16. Minimum educational requirement for new officers in sheriffs' offices, by size of population served, 2003
so0317.csv	Table 17. Training requirements for new officer recruits in sheriffs' offices, by size of population served, 2003
so0318.csv	Table 18. Annual inservice training requirements for non-probationary officers in sheriffs' offices, by size of population served, 2003
so0319.csv	Table 19. Operating budget of sheriffs' offices, by size of population served, 2003
so0320.csv	Table 20. Average base annual salary for selected positions in sheriffs' offices, by size of population served, 2003
so0321.csv	Table 21. Sheriffs' offices authorizing special pay for full-time sworn personnel, by size of population served, 2003
so0322.csv	Table 22. Collective bargaining authorized by sheriffs' offices, by size of population served, 2003
so0323.csv	Table 23. Average number of district/precinct stations, and neighborhood/community substations operated by sheriffs' offices, by size of population served, 2003
so0324.csv	Table 24. Types of routine patrol other than automobile used by sheriffs' offices, by size of population served, 2003
so0325.csv	Table 25. Dispatch functions of sheriffs' offices, by size of population served, 2003
so0326.csv	Table 26. Full-time sworn personnel in sheriffs' offices serving as communications technicians, by size of population served, 2003
so0327.csv	Table 27. Participation in a 9-1-1 emergency telephone system by sheriffs' offices, by size of population served, 2003
so0328.csv	Table 28. Sheriffs' offices with primary investigative responsibility for selected crimes, by size of population served, 2003
so0329.csv	Table 29. Drug enforcement in sheriffs' offices, by size of population served, 2003
so0330.csv	Table 30. Special units for drug enforcement in sheriffs' offices, by size of population served, 2003
so0331.csv	Table 31. Participation by sheriffs' offices in multi-agency drug enforcement task forces, by size of population served, 2003
so0332.csv	Table 32. Drug asset forfeiture program receipts of sheriffs' offices, by size of population served, 2003
so0333.csv	Table 33. Court-related functions of sheriffs' offices, by size of population served, 2003
so0334.csv	Table 34. Detention functions of sheriffs' offices, by size of population served, 2003
so0335.csv	Table 35. Temporary holding (lockup) facilities operated by sheriffs' offices, by size of population served, 2003
so0336.csv	Table 36. Special public safety functions of sheriffs' offices, by size of population served, 2003
so0337.csv	Table 37. Traffic and vehicle-related functions of sheriffs' offices, by size of population served, 2003
so0338.csv	Table 38. Special operations functions of sheriffs' offices, by size of population served, 2003
so0339.csv	Table 39. Sheriffs' offices with a formal, written community policing plan, by size of population served, 2003
so0340.csv	Table 40. Sheriffs' offices with a mission statement that includes community policing, by size of population served, 2003
so0341.csv	Table 41. Community policing training in sheriffs' offices, by size of population served, 2003
so0342.csv	Table 42. Full-time community policing officers in sheriffs' offices, by size of population served, 2003
so0343.csv	Table 43. Full-time school resource officers in sheriffs' offices, by size of population served, 2003
so0344.csv	Table 44. Ability assessments related to community policing used by sheriffs' offices for selecting new officers, by size of population served, 2003
so0345.csv	Table 45. Community policing policies for sworn personnel in sheriffs' offices, by size of population served, 2003
so0346.csv	Table 46. Community policing activities of sheriffs' offices, by size of population served, 2003
so0347.csv	Table 47. Surveying of citizens by sheriffs' offices, by size of population served, 2003
so0348.csv	Table 48. Policies on handling special populations in sheriffs' offices, by size of population served, 2003
so0349.csv	Table 49. Work-related policies in sheriffs' offices, by size of population served, 2003
so0350.csv	Table 50. Policies on officer use of force in sheriffs' offices, by size of population served, 2003
so0351.csv	Table 51. Written policy directives pertaining to officer conduct and appearance in sheriffs' offices, by size of population served, 2003
so0352.csv	Table 52. Vehicle use policies in sheriffs' offices, by size of population served, 2003
so0353.csv	Table 53. Pursuit driving policies of sheriffs' offices, by size of population served, 2003
so0354.csv	Table 54. Additional written policy directives of sheriffs' offices by size of population served, 2003
so0355.csv	Table 55. Semiautomatic sidearms authorized for use by sworn personnel in sheriffs' offices, by size of population served, 2003
so0356.csv	Table 56. Body armor requirements for field officers in sheriffs' offices, by size of population served, 2003
so0357.csv	Table 57. Types of nonlethal weapons authorized for personal use by sworn personnel in sheriffs' offices, by size of population served, 2003
so0358.csv	Table 58. Number of cars operated by sheriffs' offices, by size of population served, 2003
so0359.csv	Table 59. Number of motorcycles and 4-wheel motorized vehicles other than cars operated by sheriffs' offices, by size of population served, 2003
so0360.csv	Table 60. Number of bicycles operated by sheriffs' offices, by size of population served, 2003
so0361.csv	Table 61. Off-land vehicles operated by sheriffs' offices, by size of population served, 2003
so0362.csv	Table 62. Animals maintained by sheriffs' offices, by size of population served, 2003
so0363.csv	Table 63. Use of video cameras by sheriffs' offices, by size of population served, 2003
so0364.csv	Table 64. Special technologies used by sheriffs' offices, by size of population served, 2003
so0365.csv	Table 65. General functions of computers in sheriffs' offices, by size of population served, 2003
so0366.csv	Table 66. Analytic functions of computers in sheriffs' offices, by size of population served, 2003
so0367.csv	Table 67. Types of computerized information files maintained by more than half of sheriffs' offices, by size of population served, 2003
so0368.csv	Table 68. Types of computerized information files maintained by less than half of sheriffs' offices, by size of population served, 2003
so0369.csv	Table 69. Types of infield computers or terminals used by sheriffs' offices, by size of population served, 2003
so0370.csv	Table 70. Use of infield computers for reports and communications by sheriffs' offices, by size of population served, 2003
so0371.csv	Table 71. Computerized information accessible to infield officers of sheriffs' offices, by size of population served, 2003
so0372.csv	Table 72. Use of Automated Fingerprint Identification Systems (AFIS) in sheriffs' offices, by size of population served, 2003
so0373.csv	Table 73. Methods for transmitting criminal incident reports to the central information system in sheriffs' offices, by size of population served, 2003

Figures:

so03f01.csv	Figure 1. Full-time employment by sheriffs' offices, 1987-2003
so03f02.csv	Figure 2. Net change in number of full-time sheriffs' deputies officers for 12-month period ending June 30, 2003
so03f03.csv	Figure 3. Female and minority sworn personnel in sheriffs' offices, 1987-2003
so03f04.csv	Figure 4. Sworn personnel employed by sheriffs' offices using various recruit screening methods, 2003
so03f05.csv	Figure 5. Training requirements for new officer recruits in sheriffs' offices, 2000 and 2003
so03f06.csv	Figure 6. Annual per officer operating costs of sheriffs' offices, 2000 and 2003
so03f07.csv	Figure 7. Average base starting salary for entry-level officers in sheriffs' offices, 2000 and 2003
so03f08.csv	Figure 8. Starting salaries for entry-level officers in sheriffs' offices authorizing and not authorizing collective bargaining, 2003
so03f09.csv	Figure 9. Percent of sheriffs' offices using foot or bike patrol, by size of population served, 1997-2003
so03f10.csv	Figure 10. Sheriffs' office participation in a 9-1-1 emergency telephone system, 1987-2003
so03f11.csv	Figure 11. Drug asset forfeiture receipts of sheriffs' offices, by size of agency, 2002
so03f12.csv	Figure 12. Percent of sheriffs' offices using full-time community policing officers, 1997, 2000 and 2003
so03f13.csv	Figure 13. Groups with which sheriffs' offices had problem-solving partnerships or written agreements during the year ending June 30, 2003
so03f14.csv	Figure 14. Uses of citizen survey information by sheriffs' offices, 2003
so03f15.csv	Figure 15. Body armor requirements in sheriffs' offices, 1990-2003
so03f16.csv	Figure 16. Sheriffs' offices authorizing officers to use chemical agents, 1990 and 2003
so03f17.csv	Figure 17. Sheriffs' offices using video cameras in patrol cars, 2000 and 2003
so03f18.csv	Figure 18. Sheriffs' offices using infield computers or terminals, 1990 and 2003
so03f19.csv	Figure 19. sheriffs' deputies with infield computer access to information, 1997-2003
so03f20.csv	Figure 20. Sheriffs' offices using electronic methods for transmitting criminal incident reports to a central information system, 1997-2003
