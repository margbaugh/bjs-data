Workplace Violence, 1993-2009    NCJ  233094			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Workplace Violence, 1993-2009     NCJ  233094.  The full report including text			
and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=2377			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=56.			
			
			
Filename			Table title
wv09t01.csv			Table 1. Workplace and nonworkplace violence and violence against persons not employed, by type of crime, 2005-2009
wv09t02.csv			Table 2. Workplace and nonworkplace violence, by occupation, 2005-2009
wv09t03.csv			Table 3. Rate of workplace and nonworkplace violence, by sex, race/Hispanic origin, age, marital status, and annual household income, 2005-2009
wv09t04.csv			Table 4. Percent of workplace and nonworkplace violence and employed persons, by sex, race/Hispanic origin, age, marital status and annual household income, 2005-2009
wv09t05.csv			Table 5. Victim/offender relationship for victims of workplace violence, by sex, 2005-2009
wv09t06.csv			Table 6. Victim resistance during workplace and nonworkplace violence, 2005-2009
wv09t07.csv			Table 7. Perceived offender drug/alcohol use in workplace and nonworkplace violence, 2005-2009
wv09t08.csv			Table 8. Weapons presented by offender in workplace violence and nonworkplace violence, 2005-2009
wv09t09.csv			Table 9. Injury and treatment for victims of workplace and nonworkplace violence, 2005-2009
wv09t10.csv			Table 10. Injury type, workplace and nonworkplace violence, 2005-2009
wv09t11.csv			Table 11. Workplace and nonworkplace violence reported to the police, by sex, race/Hispanic origin, age, and type of crime, 2005-2009
wv09t12.csv			Table 12. Reason for reporting incident to police other than incident was a crime, by workplace and nonworkplace violence, 2005-2009
wv09t13.csv			Table 13. Reason for not reporting crime to police, by workplace and nonworkplace violence, 2005-2009
wv09t14.csv			Table 14. Workplace homicides, by occupation of victim, 2005-2009			
wv09t15.csv			Table 15. Workplace homcide victims, by sex, age, race/Hispanic origin, 2005-2009
wv09t16.csv			Table 16. Workplace homicides, by offender type, 2005-2009
wv09t17.csv			Table 17. Workplace homicides, by incident type, 2005-2009

			
                                Appendix tables			
wv09at01.csv			Appendix Table 1. Standard errors for workplace and nonworkplace violence and violence against persons not employed, by type crime, 2005-2009
wv09at02.csv			Appendix Table 2. Standard errors for workplace and nonworkplace violence, by occupation, 2005-2009
wv09at03.csv			Appendix Table 3. Standard errors for rate of workplace and nonworkplace violence, by sex, race/Hispanic origin, age, marital status, and annual household income, 2005-2009
wv09at04.csv			Appendix Table 4. Standard errors for percentage of workplace and nonworkplace violence and employed persons, by sex, race/Hispanic origin, age, marital status, and annual household income, 2005-2009
wv09at05.csv			Appendix Table 5. Standard errors for victim/offender relationship for victims of workplace violence, by sex,2005-2009
wv09at06.csv			Appendix Table 6. Standard error for victim resistance for workplace and nonworkplace violence,2005-2009
wv09at07.csv			Appendix Table 7. Standard errors for perceived offender drug/alcohol use in workplace and nonworkplace violence, 2005-2009
wv09at08.csv			Appendix Table 8. Standard errors for weapons presented by offender, workplace violence and nonworkplace violence, 2005-2009
wv09at09.csv			Appendix Table 9. Standard errors for injury and treatment for victims of workplace and nonworkplace violence, 2005-2009
wv09at10.csv			Appendix Table 10. Standard errors for injury type, workplace and nonworkplace violence, 2005-2009
wv09at11.csv			Appendix Table 11. Standard errors for workplace and nonworkplace violence reported to police, by sex, race/Hispanic origin, age, and type of crime, 2005-2009
wv09at12.csv			Appendix Table 12. Standard errors for reasons for reporting incident to police other than incident was a crime, by workplace and nonworkplace violence, 2005-2009
wv09at13.csv			Appendix Table 13. Standard errors for reasons for not reporting crime to police, by workplace and nonworkplace violence, 2005-2009


				Figures
wv09f01.csv			Figure 1. Workplace and nonworkplace nonfatal violence against the employed and persons not employed age 16 or older, 1993-2009
wv09f02.csv			Figure 2. Workplace violence, by sex, 1993-2009
wv09f03.csv			Figure 3. Workplace violence rates, by race/ethnicity, 1993-2009
wv09f04.csv			Figure 4. Workplace homicides, 1993-2009

