						readme.txt

Contents of zip archive scs9602.zip
Tables from Section 2 of State Court Sentencing of Convicted Felons, 1996, NCJ 175708


scs9621.wk1		Table 2.1 Demographic characteristics of persons convicted of felonies by State
                   	courts,  by offense, 1996
scs9622.wk1		Table 2.2 Gender, race, and age of felons convicted in State courts, by offense,
                   	1996
scs9623.wk1		Table 2.3 Average age of convicted felons in State courts, by offense, 1996
scs9624.wk1		Table 2.4 Offense and gender of felons, by type of sentence imposed, 1996
scs9625.wk1		Table 2.5 Offense and race of felons, by type of sentence imposed, 1996
scs9626.wk1		Table 2.6 Mean length of felony State court sentences imposed, by offense and gender
                   	of felons, 1996
scs9627.wk1		Table 2.7 Mean length of felony State court sentences imposed, by offense and race
                   	of felons, 1996
scs9628.wk1		Table 2.8 Gender and race of felons sentenced to incarceration or prison by State
                   	courts, by offense, 1996
scs9629.wk1		Table 2.9 Gender and race of felons sentenced to jail or probation by State courts,
                   	by offense, 1996
scs96210.wk1		Table 2.10 Percent of convicted felons sentenced by State courts to incarceration or
                   	prison, by gender, race, and offense, 1996
scs96211.wk1		Table 2.11 Percent of convicted felons sentenced by State courts to jail or
                   	probation, by gender, race, and offense, 1996
scs96212.wk1		Table 2.12 Mean length of State felony sentences to incarceration or prison, by
                   	gender and race of felons, 1996 
scs96213.wk1		Table 2.13 Mean length of State felony sentences to jail or probation, by gender and
                   	race of felons, 1996