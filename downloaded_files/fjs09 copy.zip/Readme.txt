Federal Justice Statistics, 2009  NCJ 234184

This zip archive contains tables in individual .csv spreadsheets		
from Federal Justice Statistics, 2009, NCJ 234184.		
The full report including text and graphics in .pdf format is available at		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2208

This report is one in a series.  More recent editions may be available. 
 To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=62
											

File name		Table number
 fjs09t01.csv    Table 1.  Suspects arrested and booked by the U.S. Marshals Service, by offense and federal district at arrest, 2005 and 2009
 fjs09t02.csv    Table 2.  Characteristics of suspects arrested by the Drug Enforcement Administration, by type of drug, 2009
 fjs09t03.csv    Table 3.  Suspects in matters concluded by U.S. attorneys, by referring authority, 2000, 2005, and 2009
 fjs09t04.csv    Table 4.  Suspects in matters concluded by U.S. attorneys, by offense type, 2005 and 2009
 fjs09t05.csv    Table 5.  Outcome and case processing time of suspects in matters concluded, 2009
 fjs09t06.csv    Table 6. Characteristics of cases terminated in U.S. district court, by type of counsel, 2009
 fjs09t07.csv    Table 7. Outcomes of cases terminated in U.S. district court, by type of counsel, 2009 
 fjs09t08.csv    Table 8.  Defendants detained at any time prior to case termination, 2000, 2005, and 2009
 fjs09t09.csv    Table 9.  Disposition and case processing time of defendants in cases terminated in U.S. district court, 2009
 fjs09t10.csv    Table 10.  Verdict, disposition and sentence received in cases terminated in U.S. district court, 2009 and 2005
 fjs09t11.csv    Table 11.  Defendants convicted and sentenced to a federal prison term, by type of offense, 2005 and 2009
 fjs09t12.csv    Table 12. Characteristics of offenders under post-conviction federal supervision in the community, 2005 and 2009
 fjs09t13.csv    Table 13. Characteristics of offenders in the custody of the Federal Bureau of Prisons, 2009
 fjs09t14.csv    Table 14. Suspects arrested and felony defendants convicted and sentenced by federal and state/local agencies, 2000, 2002, 2004, and 2006
 fjs09t15.csv    Table 15. Criminal appeals terminated in U.S. district court, 2000 and 2009
 fjs09t16.csv    Table 16. Judgeships and prosecutors in federal judicial districts, 2009
fjs09at01.csv    Appendix table 1. Confidence intervals for outcome of suspects in matters concluded, by district population, 2009
fjs09at02.csv    Appendix table 2. Confidence intervals for outcomes of cases terminated in U.S. district court, by type of counsel, 2009
fjs09at03.csv    Appendix table 3. Confidence intervals for defendants detained at any time prior to case termination, by district population, 2009
fjs09at04.csv    Appendix table 4. Confidence intervals for disposition of defendants in cases terminated in U.S. district court, by district population, 2009
fjs09at05.csv    Appendix table 5. Confidence intervals for defendants convicted and sentenced to a federal prison term, by district populations, 2005 and 2009

			Figure number
 fjs09f01.csv	 Figure 1. Number of federal suspects/defendants processed, 1995-2009
 fjs09f02.csv	 Figure 2. Percent of the total federal caseload handled in 5 federal judicial districts along the SW border, 2009
 fjs09f03.csv	 Figure 3. Number of suspects arrested and booked by the U.S. Marshals Service, 1995-2009
 fjs09f04.csv	 Figure 4. Number of immigration suspects processed in federal court in SW border districts, 1995-2009
 fjs09f05.csv	 Figure 5. Time from receipt of matter to disposition for SW border and non-SW border federal judicial districts, 2009
 fjs09f06.csv	 Figure 6. Number of suspects referred to U.S. attorneys by lead charge, 1995-2009
 fjs09f07.csv	 Figure 7. Defendants in federal criminal cases by type of representation at termination, 1995-2009
 fjs09m02.csv	 Map 2. Percent of defendants detained prior to case disposition by federal judicial district, 2009
 fjs09m03.csv	 Map 3. Percent of growth in defendants under post-conviction federal supervision by federal judicial district, 2000-2009
 fjs09f08.csv	 Figure 8. Offenders in the custody of the Federal Bureau of Prisons, by commitment offense, 2000 and 2009
 fjs09f09.csv	 Figure 9. Number of federal offenders in confinement and under supervision in the community at year-end, 2005 and 2009
 fjs09f10.csv	 Figure 10. Federal percent of state and federal felony convictions for selected offenses, 1994-2006.
