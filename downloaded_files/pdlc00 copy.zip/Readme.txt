POLICE DEPARTMENTS IN LARGE CITIES, 1990 and 2000
NCJ 175703																	
																	
This zip archive contains figures and tables in individual .wk1 spreadsheets from the
2000 Law Enforcement and Administrative Statistics (LEMAS) Special Report, "Police 
Departments in Large Cities, 1990 and 2000"
																	
Tables:																	
																	
pdlc0001.wk1	Table 1. Number of full-time employees in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0002.wk1	Table 2. Number of full-time sworn personnel in police departments serving cities with a population of 250,000 or more, 1990 and 2000		
pdlc0003.wk1	Table 3. Female and minority representation among full-time sworn personnel in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0004.wk1	Table 4. Minimum education requirement for new officers	in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0005.wk1	Table 5. Minimum training requirement for new officers in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0006.wk1	Table 6. Annual operating budget of police departments serving cities with a population of 250,000 or more, 1990 and 2000
pdlc0007.wk1	Table 7. Minimum starting salaries in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0008.wk1	Table 8. Types of special pay for sworn personnel in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0009.wk1	Table 9. UCR violent crime index offenses reported to police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0010.wk1	Table 10. UCR property crime index offenses reported to	police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0011.wk1	Table 11. Special units operated by police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0012.wk1	Table 12. Officers assigned to a multi-agency drug task	force by police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0013.wk1	Table 13. Officers assigned to a special drug enforcement unit in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0014.wk1	Table 14. Semiautomatic sidearms authorized by police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0015.wk1	Table 15. Body armor policies for field/patrol officers	in police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0016.wk1	Table 16. Use of off-land vehicles by police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0017.wk1	Table 17. Use of motorcycles by police departments serving cities with a population of 250,000 or more,	1990 and 2000	
pdlc0018.wk1	Table 18. Use of bicycles by police departments	serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0019.wk1	Table 19. Marked vehicle use policies of police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0020.wk1	Table 20. Use of computer-aided dispatch by police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0021.wk1	Table 21. Use of an enhanced 9-1-1 system by police departments	serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0022.wk1	Table 22. Use of in-field computers or terminals by police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc0023.wk1	Table 23. Automated Fingerprint Identification System (AFIS) capabilities of police departments serving cities with a population of 250,000 or more, 1990 and 2000	
pdlc00t1.wk1	In-Text Table 1. Estimated value of drug asset forfeiture receipts, police departments serving cities with a population of 250,000 or more, 1999
pdlc00aa.wk1	Appendix Table A. Full-time employees of police departments serving cities with a population of 250,000 or more, 1990 and 2000
pdlc00ab.wk1	Appendix Table B. Percent of full-time sworn personnel who are women and minorities, and ratio of minority officers to minority residents, in police departments serving cities with a population of 250,000 or more, 1990 and 2000
pdlc00ac.wk1	Appendix Table C. Annual operating budget of police departments serving cities with a population of 250,000 or more, 1990 and 2000
pdlc00ad.wk1	Appendix Table D. UCR violent crime index offenses reported to police departments serving cities with a population of 250,000 or more, 1990 and 2000
pdlc00ae.wk1	Appendix Table E. UCR property crime index offenses reported to police departments serving cities with a population of 250,000 or more, 1990 and 2000

Figures:

pdlc00h1.wk1	Highlights Figure 1. Percent change in number of UCR violent crimes, UCR property crimes, and number of full-time local police officers in cities with 250,000 or more residents, 1990 to 2000
pdlc00f1.wk1	Figure 1. Average ratio of percent minority local police officers to percent minority city residents, cities with a population of 250,000 or more, 1990 and 2000
pdlc00f2.wk1	Figure 2. UCR violent crime index offenses, cities with a population of 250,000 or more, 1990 and 2000
pdlc00f3.wk1	Figure 3. UCR property crime index offenses, cities with a population of 250,000 or more, 1990 and 2000
pdlc00f4.wk1	Figure 4. Number of vehicles per 1,000 sworn personnel operated by police departments in large cities, 1990 and 2000
pdlc00f5.wk1	Figure 5. Technological capabilities of police departments in large cities, 1990 and 2000

In-text Boxes:

pdlc00b1.wk1	In-text Box 1. Fifteen largest local police departments serving cities with a population of 250,000 or more, by	number of full-time sworn personnel and number of full-time sworn personnel per 100,000 residents served, 1990 and 2000
pdlc00b2.wk1	In-text Box 2. Community policing initiatives of police	departments in large cities, 2000