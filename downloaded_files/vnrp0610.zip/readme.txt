Victimizations Not Reported to Police, 2006-2010		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Victimizations Not Reported to Police, 2006-2010 NCJ 238536		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4393	
		
vnrp0610f01.csv		Figure 1. Most important reason violent victimizations were not reported to the police, 2006?2010
vnrp0610f02.csv		Figure 2. Victimizations not reported to the police, by type of crime, 1994?2010
vnrp0610f03.csv		Figure 3. Most important reason violent victimizations were not reported to police, 1994?2010
vnrp0610f04.csv		Figure 4. Trends in the percent of unreported violent victimizations not reported because the police would not or could not do anything to help, 1994?2010
		
vnrp0610t01.csv		Table 1. Victimizations not reported to the police and the most important reason they went unreported, by type of crime, 2006?2010 
vnrp0610t02.csv		Table 2. Violent victimizations not reported to the police and the most important reason they went unreported, by type of injury sustained and whether the offender had a weapon, 2006?2010
vnrp0610t03.csv		Table 3. Violent victimizations not reported to the police and the most important reason they went unreported, by victim-offender relationship, 2006?2010
vnrp0610t04.csv		Table 4. Violent victimizations not reported to the police and the most important reason they went unreported, by location, 2006?2010
vnrp0610t05.csv		Table 5. Violent victimizations not reported to the police and the most important reason they went unreported, by victim characteristics, 2006?2010
vnrp0610t06.csv		Table 6. Violent victimizations not reported to the police and the most important reason they went unreported, by victim household characteristics, 2006?2010
		
vnrp0610at01.csv	Appendix table 1. Detailed response categories for the most important reason violent victimizations were not reported to police, 2006?2010
vnrp0610at02.csv	Appendix table 2. Victimizations not reported to the police, by type of crime, 1994?2010 
vnrp0610at03.csv	Appendix table 3. Standard errors for the most important reason violent victimizations were not reported to the police, 2006?2010
vnrp0610at04.csv	Appendix table 4. Standard errors for victimizations not reported to the police, by type of crime, 1994?2010 
vnrp0610at05.csv	Appendix table 5. Standard errors for the most important reason violent victimizations were not reported to police, 1994?2010
vnrp0610at06.csv	Appendix table 6. Standard errors for percentage of victimizations not reported to police and the most important reason they went unreported, by type of crime, 2006?2010
vnrp0610at07.csv	Appendix table 7. Standard errors for violent victimizations not reported to the police and the most important reason they went unreported, by type of injury sustained and whether the offender had a weapon, 2006?2010
vnrp0610at08.csv	Appendix table 8. Standard errors for violent victimizations not reported to the police and the most important reason they went unreported, by victim-offender relationship, 2006?2010
vnrp0610at09.csv	Appendix table 9. Standard errors for violent victimizations not reported to the police and the most important reason they went unreported, by location of occurrence, 2006?2010
vnrp0610at10.csv	Appendix table 10. Standard errors for violent victimizations not reported to the police and the most important reason they went unreported, by victim characteristics, 2006?2010
vnrp0610at11.csv	Appendix table 11. Standard errors for violent victimizations not reported to the police and the most important reason they went unreported, by victim household characteristics, 2006?2010
vnrp0610at12.csv	Appendix table 12. Standard errors for detailed response categories for the most important reason violent victimizations went unreported to police, 2006?2010
vnrp0610at13.csv	Appendix table 13. Standard errors for trends in the percent of unreported violent victimizations not reported because the police would not or could not do anything to help, 1994?2010
