Background Checks for Firearm Transfers, 2018 NCJ 301318	
	
This zip archive contains tables in individual .csv spreadsheets from 	
Background Checks for Firearm Transfers, 2018 NCJ 301318	
from: https://bjs.ojp.gov/library/publications/background-checks-firearm-transfers-2018

This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Background%20Checks%20for%20Firearm%20Transfers	
	
Filename	Table titles
bcft18t01.csv	Table 1. Estimated number of firearm applications and denials since the Brady Act’s effective date, 1994–2018
bcft18t02.csv	Table 2. Firearm applications and denials, by type of checking agency and permit or check, 1999–2018
bcft18t03.csv	Table 3. Firearm applications and denials reported by state agencies, by type of permit or check and jurisdiction, 2018
bcft18t04.csv	Table 4. Firearm applications and denials reported by local agencies, by type of permit or check and size of population served, 2018
bcft18t05.csv	Table 5. Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2018
bcft18t06.csv	Table 6. Percent change in applications, denials, reasons for denial, and rates of denial, 1999–2018
bcft18t07.csv	Table 7. Bureau of Alcohol, Tobacco, Firearms and Explosives investigation of denials referred by the Federal Bureau of Investigation, 2018
bcft18t08.csv	Table 8. Number of states, by type of check, point of contact status, and reporter of Firearm Inquiry Statistics data, 2018
bcft18t09.csv	Table 9. Prohibited person records submitted to the National Instant Criminal Background Check System Index, 2018
bcft18t10.csv	Table 10. Number of reporting agencies that participated in the Firearm Inquiry Statistics survey, 2018
bcft18t11.csv	Table 11. Final weights by state and population category, 2018
	
		Figure
bcft18f01.csv	Figure 1. Estimated number of applications for firearm transfers and permits since the first full year of the Brady Act’s permanent provisions, 1999–2018
	
		Appendix tables
bcft18ta01.csv	Appendix Table 1. Firearm applications and denials by state and local agencies, by jurisdiction and type of permit or check, 2018
bcft18at02.csv	Appendix Table 2. Standard errors for table 2: Firearm applications and denials reported by local agencies, by type of permit or check, 2018
bcft18at03.csv	Appendix Table 3. Standard errors for table 4: Firearm applications and denials reported by local agencies, by type of permit or check and size of population served, 2018
bcft18at04.csv	Appendix Table 4. Standard errors for table 5: Reasons for denial of applications for firearm transfers and permits, by type of checking agency, 2018
bcft18at05.csv	Appendix Table 5. Agencies that conducted background checks for firearm transfers or permits, by type of application and jurisdiction, December 31, 2018
