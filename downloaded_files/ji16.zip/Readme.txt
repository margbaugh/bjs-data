Jail Inmates in 2016	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Jail Inmates in 2016, NCJ 251210 The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6186

This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to	
https://www.bjs.gov/index.cfm?ty=pbse&sid=38	

	
Filename	Table title
ji16t01.csv	Table 1. Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2000 and 2005�2016
ji16t02.csv	Table 2. Jail incarceration rates, by sex and race/Hispanic origin, 2000, 2005, and 2010�2016
ji16t03.csv	Table 3. Characteristics of confined inmates in local jails, 2000, 2005, and 2010�2016
ji16t04.csv	Table 4. Average daily jail population, by size of jurisdiction, 2016
ji16t05.csv	Table 5. Percent of jail capacity occupied, by size of jurisdiction, 2016
ji16t06.csv	Table 6. Inmate turnover rate and expected length of stay, by size of jurisdiction, 2016
ji16t07.csv	Table 7. Persons under jail supervision, by confinement status, 2000 and 2006�2016
ji16t08.csv	Table 8. Staff employed in local jails, by sex, year-end 2015 and 2016


Figures	
ji16f01.csv	Figure 1. Inmates confined in local jails at midyear, 2000-2016
ji16f02.csv	Figure 2. Jail capacity, average daily population, and percent of capacity occupied in local jails, 2000�2016


Appendix tables	
ji16at01.csv	Appendix table 1. Number of confined inmates in local jails, by characteristic, 2000, 2005 and 2010�2016
ji16at02.csv	Appendix table 2. Standard errors for appendix table 1: Number of confined inmates in local jails, by characteristic, 2000, 2005 and 2010�2016
ji16at03.csv	Appendix table 3. Standard errors for table 1: Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2000 and 2005�2016
ji16at04.csv	Appendix table 4. Standard errors for table 2: Jail incarceration rates, by sex and race/Hispanic origin, 2000, 2005, and 2010�2016
ji16at05.csv	Appendix table 5. Standard errors for table 3: Characteristics of confined inmates in local jails, 2000, 2005, and 2010�2016
ji16at06.csv	Appendix table 6. Standard errors for table 4: Average daily jail population, by size of jurisdiction, 2016
ji16at07.csv	Appendix table 7. Standard errors for table 5: Percent of jail capacity occupied, by size of jurisdiction, 2016
ji16at08.csv	Appendix table 8. Standard errors for table 6: Inmate turnover rate and expected length of stay, by size of jurisdiction, 2016
ji16at09.csv	Appendix table 9. Standard errors for table 7: Persons under jail supervision, by confinement status, 2000 and 2006�2016
ji16at10.csv	Appendix table 10. Standard errors for table 8: Staff employed in local jails, by sex, year-end 2015 and 2016
