Capital Punishment, 2007 - Statistical Tables  NCJ 224528

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2007 - Statistical Tables  NCJ 224528, electronic only. 
The full electronic report is available at:
http://www.ojp.usdoj.gov/bjs/pub/html/cp/2007/cp07st.htm

These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cp


Tables:
cp07st04.csv		Table 4.  Prisoners under sentence of death, by region, jurisdiction, and race, 2006 and 2007
cp07st05.csv		Table 5.  Demographic characteristics of prisoners under sentence of death, 2007
cp07st06.csv		Table 6.  Persons of Hispanic origin and women under sentence of death, by jurisdiction, 2006 and 2007
cp07st07.csv		Table 7.  Age at time of arrest for capital offense and age of prisoners under sentence of death at yearend 2007
cp07st08.csv		Table 8.  Criminal history profile of prisoners under sentence of death, by race and Hispanic origin, 2006
cp07st09.csv		Table 9.  Number of persons executed, by jurisdiction, 1930-2007
cp07st10.csv		Table 10. Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2007
cp07st11.csv		Table 11. Time under sentence of death and execution, by race, 1977-2007
cp07st12.csv		Table 12. Women under sentence of death, by race and jurisdiction, 12/31/07
cp07st13.csv		Table 13. Persons under sentence of death, by gender, race, and Hispanic origin, 12/31/07
cp07st14.csv		Table 14. Number of inmates received under sentence of death, 1995-2007
cp07st15.csv		Table 15. Number of persons executed, 1977-2007
cp07st16.csv		Table 16. Number of persons executed by race, Hispanic origin, and method, 1977-2007
cp07st17.csv		Table 17. Elapsed time since sentencing for inmates under sentence of death on 12/31/07, by gender, race, and Hispanic origin

Advanced count of executions:
cp07sta.csv		Advance count of executions, by jurisdiction, January 1, 2008 - November 30, 2008

