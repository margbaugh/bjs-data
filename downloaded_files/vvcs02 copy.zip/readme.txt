Violent Victimization of College Students, 1995-2002  NCJ 206836	


This zip archive contains tables in individual .csv spreadsheets
from Violent Victimization of College Students, 1995-2002  NCJ 206836.
 The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/vvcs02.htm 

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#vvcs


Spreadsheets	

File Name	Highlight
	
vvcs02h.csv	Highlight 1.  From 1995 to 2002 violence against college students decreased 54%, while violence against nonstudents of similar ages fell 45%.

Table Titles
vvcs0201.csv	Table 1.  Violent victimization rates of college students and nonstudents, by type of crime, 1995-2002
vvcs0202.csv	Table 2.  Violent victimization of persons age 18-24, by type of crime and victims' student status, gender, race and ethnicity, 1995-2002
vvcs0203.csv	Table 3.  Violent victimization of college students, by offender characteristics and type of crime, 1995-2002
vvcs0204.csv	Table 4.  Violent victimization of college students, by location and time of crimes, 1995-2002
vvcs0205.csv	Table 5.  Weapons present in violent crimes against college students, by type of crime and type of weapon, 1995-2002
vvcs0206.csv	Table 6.  Violent crime injuries and their treatment, by student status of victims, 1995-2002
vvcs0207.csv	Table 7.  Reasons for not reporting violent victimization to police, by student status of victims, 1995-2002
vvcs0208.csv	Table 8.  Activity at time of violent victimization, by time of day and student status of victims, 1995-2002

Text Table Title
vvcs02tt1.csv	Text Table 1.  Percent of violent incidents, 1995-2002

Figure Titles
vvcs02f1.csv	Figure 1.  Robbery rates against college students and nonstudents, 1995-2002
vvcs02f2.csv	Figure 2.  Aggravated assault rates against college students and nonstudents, 1995-2002
vvcs02f3.csv	Figure 3.  Simple assault rates against college students and nonstudents, 1995-2002
vvcs02f4.csv	Figure 4.  Violent victimization of female college students and nonstudents age 18-24, 1995-2002
