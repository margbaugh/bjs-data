Capital Punishment, 2001   NCJ 197020

This zip archive contains tables in individual .wk1 spreadsheets
from Indicators of Capital Punishment, 2001   NCJ 197020
The full report including text and graphics in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/cp01.htm 

 
This report is one in a series. More recent editions
may be available. To view a list of all in the series
go to http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cp.
 
 
cp01ht01.wk1 Highlights table #: 1 Executions during 2001, persons under sentence of death 12/31/02 and jurisdictions wit
cp01ht02.wk1 Highlights table #: 2 Persons under sentence of death, 1991 and 2001
 
cp0105.wk1   Table #: 5  Prisoners under sentence of death, by region, State, and race, 2000 and 2001
cp0106.wk1   Table #: 6  Hispanics and women under sentence of death, by State, 2000 and 2001
cp0107.wk1   Table #: 7  Demographic characteristics of prisoners  under sentence of death, 2001
cp0108.wk1   Table #: 8  Age at time of arrest for capital offense and  age of prisoners under sentence of death at yearend 2001 
cp0109.wk1   Table #: 9  Criminal history profile of prisoners under sentence of death,  by race and Hispanic origin, 2001 
cp0110.wk1   Table #: 10  Number of persons  executed, by jurisdiction, 1930-2001
cp0111.wk1   Table #: 11  Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2001
cp0112.wk1   Table #: 12 Time under sentence of death and execution, by race, 1977-2001
 
cp01f01.wk1  Figure #: 1 Persons under sentence of death 1953-2001
cp01f02.wk1  Figure #: 2 Persons under sentence of death at yearend
cp01f03.wk1  Figure #: 3 Persons executed, 1930-2001
 
cp01t01.wk1  Text table #: 1 Women under sentence of death by race and state, 12/31/01
cp01t02.wk1  Text table #: 2 Persons under sentence  of death, by sex, race, and  Hispanic origin, 12/31/01
cp01t03.wk1  Text table #: 3 Inmates received under sentence of death 1994-2000
cp01t04.wk1  Text table #: 4 Number of death sentences imposed on incoming inmates, 1988-2001
cp01t05.wk1  Text table #: 5 Number of executions, 1977-2001
cp01t06.wk1  Text table #: 6 Number of executions by race/ethnicity and method, 1977-2001
cp01t07.wk1  Text table #: 7 Elapsed time since sentencing for inmates under sentence of death by gender and race/ethnicity
 
cp01at01.wk1 Appendix table #: 1  Prisoners sentenced to death and the outcome sentence, by year of sentencing, 1973-2001
cp01at02.wk1 Appendix table #: 2  Prisoners under sentence of death on December 31, 2001, by State and year of sentencing
cp01at03.wk1 Appendix table #: 3  Number sentenced to death and number of removals, by jurisdiction and reason for removals, by jurisdiction and reason for removal, 1973-2001
cp01at04.wk1 Appendix table #: 4 Executions, by State and method, 1977-2001
 
cp01bt01.wk1 Box table #: 1 Advance count of executions and method used by jurisdiction, January 1, 2001-October 31, 2002
 
 
 
 
