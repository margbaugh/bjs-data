Census of Jails, 2005–2019 – Statistical Tables  NCJ 255406		
		
This zip archive contains tables in individual .csv spreadsheets		
from Census of Jails, 2005–2019 – Statistical Tables  NCJ 255406		
The full report including text and graphics in .pdf format is available at		
https://bjs.ojp.gov/library/publications/census-jails-2005-2019-statistical-tables		
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to 		
https://bjs.ojp.gov/library/publications/list?series_filter=Census%20of%20Jails		
		
Filename		Table title
cj0519stt01.csv		Table 1. Persons under the supervision of local jails, by confinement status and state, midyear 2019
cj0519stt02.csv		Table 2. Number of local jail jurisdictions, by size of jurisdiction and state, midyear 2019
cj0519stt03.csv		Table 3. The 50 largest local jail jurisdictions, midyear 2019
cj0519stt04.csv		Table 4. Confined inmates in local jails and incarceration rates, by state, 2005, 2013, and 2019
cj0519stt05.csv		Table 5. Confined inmates in local jails and incarceration rates, by demographic characteristics, 2005, 2013, and 2019
cj0519stt06.csv		Table 6. Confined inmates in local jails, by adult or juvenile status, sex, and state, midyear 2019
cj0519stt07.csv		Table 7. Percent of confined inmates in local jails, by race or ethnicity and state, midyear 2019
cj0519stt08.csv		Table 8. Confined inmates in local jails, by conviction status and state, midyear 2019
cj0519stt09.csv		Table 9. Confined inmates in local jails, by most serious type of offense and state, midyear 2019
cj0519stt10.csv		Table 10. Confined inmates in local jails, by probation or parole violation and state, midyear 2019
cj0519stt11.csv		Table 11. Confined inmates in local jails, by citizenship status and state, midyear 2019
cj0519stt12.csv		Table 12. Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, by state, midyear 2019
cj0519stt13.csv		Table 13. Characteristics of confined inmates in local jails, by urban or rural locality, midyear 2019
cj0519stt14.csv		Table 14. Average daily population, admissions, and average jail time in local jails, by state, 2013 and 2019
cj0519stt15.csv		Table 15. Average daily population, admissions, and average jail time in local jails, by sex and state, July 1, 2018 to June 30, 2019 
cj0519stt16.csv		Table 16. Rated capacity and percent of capacity occupied in local jails, by state, 2013 and 2019
cj0519stt17.csv		Table 17. Local jails under court order or consent decree to limit the size of their inmate populations or for specific conditions, by state, midyear 2019
cj0519stt18.csv		Table 18. Correctional officers in local jails, by sex, inmate-to-correctional-officer ratio, and state, 2013 and 2019
cj0519stt19.csv		Table 19. Characteristics of jail jurisdictions, by urban or rural locality, 2019
cj0519stt20.csv		Table 20. Characteristics of public and private jail facilities, midyear 2019
cj0519stt21.csv		Table 21. Functions of local jails, by state, midyear 2019
cj0519stt22.csv		Table 22. Characteristics of confined inmates in the Federal Bureau of Prisons’ detention facilities and in local jails, midyear 2019
cj0519stt23.csv		Table 23. Characteristics of the Federal Bureau of Prisons’ detention facilities and of local jails, midyear 2019
		
			Figure
cj0519stf01.csv		Figure 1. Jail incarceration rates, by state, 2005 and 2019
		
			Appendix table
cj0519stat01.csv	Appendix Table 1. Characteristics of the Federal Bureau of Prisons’ detention facilities and of local jails, midyear 2019
