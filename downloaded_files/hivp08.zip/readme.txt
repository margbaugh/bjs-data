HIV in Prisons, 2007-08   NCJ 228307		
		
This zip archive contains tables in individual .csv spreadsheets		
HIV in Prisons, 2007-08   NCJ 228307.  The full report including text 		
and graphics in .pdf format are available from:		
http://www.ojp.usdoj.gov/bjs/abstract/hivp08.htm	
		
This report is one in a series. More recent editions may be available. To 		
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#hivpj		
		
hivp08t01.csv		Table 1. State or federal prison inmates reported to be HIV positive or to have confirmed AIDS, 2006-2008
hivp08t02.csv		Table 2. Inmates in custody of state and federal prison authorities reported to be HIV positive or to have confirmed AIDS, by gender, yearend 2007 and 2008
hivp08t03.csv		Table 3. Inmates in custody of state or federal prison authorities and reported to have confirmed AIDS, yearend 2007 and 2008
hivp08t04.csv		Table 4. Percent with confirmed AIDS among state and federal prisoners and the U.S. general population, 1999-2008
hivp08t05.csv		Table 5. Profile of inmates who died from AIDS-related causes in state prisons, 2005-2007
hivp08t06.csv		Table 6. Percent of AIDS-related deaths among all deaths in state prisons and the U.S. general population 
hivp08t07.csv		Table 7. Ratio of AIDS-related deaths in state prisons and the U.S. general population
hivp08t08.csv		Table 8. Inmate deaths in federal prisons by cause, 2007 and 2008
hivp08at01.csv		Appendix table 1. Inmates in custody of state or federal prison authorities and reported to be HIV postitive or to have confirmed AIDS, by jurisdiction 2006-2008
hivp08at02.csv		Appendix table 2. Inmates in custody of state and federal prison authorities reported to be HIV positive or to have confirmed AIDS, by jurisdiction and gender, yearend 2007 and 2008
hivp08at03.csv		Appendix table 3. Inmates in custody of state or federal prison authorities and reported to have confirmed AIDS, by jurisdiction, yearend 2007 and 2008
hivp08at04.csv		Appendix table 4. AIDS-related deaths among state prison inmates reported to the Deaths in Custody Reporting Program, 2007
hivp08at05.csv		Appendix table 5. Circumstances under which inmates were tested for the antibody to HIV, by jurisdiction, 2008
hivp08f01.csv		Figure 1. AIDS-related deaths in state prisons, 1995-2007
