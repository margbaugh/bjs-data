Readme.txt
Federal Criminal Justice Trends, 2003

This zip archive contains tables in individual .csv spreadsheets from Federal Criminal Justice Trends, 2003 NCJ 205331. The full report including text and graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/fcjt03.htm

fcjt03t01.csv	Table: 1	Suspects arrested for Federal offenses and booked by the U.S. Marshals Service, by type offense, 1994-2003
fcjt03t02.csv	Table: 2	Characteristics of suspects arrested and booked by the U.S. Marshals Service, 1994-2003
fcjt03t03.csv	Table: 3	Characteristics of immigration suspects arrested and booked by the U.S. Marshals Service, 1994-2003
fcjt03t04.csv	Table: 4	Suspects arrested by the Drug Enforcement Administration, by type of drug at arrest, 1994-2003
fcjt03t05.csv	Table: 5	Characteristics of suspects arrested by the Drug Enforcement Administration, 1995-2003
fcjt03t06.csv	Table: 6	Suspects in matters referred to U.S. attorneys by type of offense, 1994-2003
fcjt03t07.csv	Table: 7	Suspects in matters concluded by U.S. attorneys by disposition and median case processing time, 1994-2003
fcjt03t08.csv	Table: 8	Number of pretrial defendants detained at any time prior to case termination, by offense
fcjt03t09.csv	Table: 9	Behavior of defendants released prior to trial by offense, 1994-2003
fcjt03t10.csv	Table: 10	Characteristics of defendants at initial hearing in Federal district court, 1994-2003
fcjt03t11.csv	Table: 11	Number of defendants in cases concluded in U.S. district court and percent convicted, 1994-2003
fcjt03t12.csv	Table: 12	Adjudication outcomes of defendants in cases concluded in U.S. district courts and median case processing time, 1994-2003
fcjt03t13.csv	Table: 13	Type of counsel of defendants in cases terminated by offense, adjudication outcome, and median case processing time, 1994-2003
fcjt03t14.csv	Table: 14	Characteristics of defendants convicted in U.S. district courts, 1996 and 2003
fcjt03t15.csv	Table: 15	Number of defendants convicted in U.S. district courts and percent receiving prison sentence, by offense
fcjt03t16.csv	Table: 16	Defendants receiving a prison sentence and mean sentence imposed in months, 1994-2003
fcjt03t17.csv	Table: 17	Defendants receiving a probation-only sentence, 1994-2003
fcjt03t18.csv	Table: 18	Defendants sentenced under the U.S. Sentencing Guidelines, 1994 and 2003
fcjt03t19.csv	Table: 19	Federal drug offenders sentenced under the Federal Sentencing Guidelines and receiving safety valve, 1998-2003
fcjt03t20.csv	Table: 20	Federal offenders resentenced persuant to Rule 35(b) of the Federal Rules of Criminal Procedure after providing substantial assistance to the Government, 1992-2001
fcjt03t21.csv	Table: 21	Number of criminal appeals filed in U.S. district court, 1994-2003
fcjt03t22.csv	Table: 22	Offenders in the custody of the Federal Bureau of Prisons at fiscal yearend by major offense category, 1994-2003
fcjt03t23.csv	Table: 23	Characteristics of offenders in the custody of the Federal Bureau of Prisons, 1994-2003
fcjt03t24.csv	Table: 24	Characteristics of inmates in the custody of the Bureau of Prisons, by age at fiscal yearend, 1994 and 2003
fcjt03t25.csv	Table: 25	Number of first releases from Federal Prison, by offense, and mean time to first release, 1993-2003
fcjt03t26.csv	Table: 26	Offenders under Federal supervision at fiscal yearend, by offense 1994-2003
fcjt03t27.csv	Table: 27	Characteristics of Federal offenders under supervision at fiscal yearend, by type of supervision, 1994-2003
fcjt03t28.csv	Table: 28	Characteristics of offenders under Federal supervision at fiscal yearend, 1994-2003
fcjt03t29.csv	Table: 29	Offenders terminating Federal supervision at fiscal yearend, by type of supervision and outcome, 1994-2003

fcjt03f01.csv	Figure: 1	Number of suspects arrested and booked by U.S. Marshals by selected offenses, 1994-2003
fcjt03f02.csv	Figure: 2	Percent of growth in suspects arrested and booked by the U.S. Marshals, 1994-2003
fcjt03f03.csv	Figure: 3	Number of suspects arrested and booked for an immigration offense, 1994-2003
fcjt03f04.csv	Figure: 4	Number of suspects arrested and booked by the U.S. Marshals by citizenship, 1994-2003
fcjt03f05.csv	Figure: 5	Number of non-U.S. citizen suspects arrested and booked by the U.S. Marshals by country of citizenship, 1994-2003
fcjt03f06.csv	Figure: 6	Number of drug arrests by the Drug Enforcement Administration by drug type, 1994-2003
fcjt03f07.csv	Figure: 7	Percent of total DEA methamphetamine arrests by State, 1994-2003
fcjt03f08.csv	Figure: 8	Number of suspects referred to U.S. attorneys, 1994-2003
fcjt03f09.csv	Figure: 9	Number of suspects referred to U.S. attorneys for immigration violations, 1994-2003
fcjt03f10.csv	Figure: 10	Percent of suspects referred to U.S. attorneys for immigration violations by federal judicial district, 1994-2003
fcjt03f11.csv	Figure: 11	Number of suspects referred to U.S. attorneys for drug violations, 1994-2003

fcjt03hf01.csv	Highlights Figure: 1	Number of suspects/defendants processed by stage
fcjt03hf02.csv	Highlights Figure: 2	Percent of cases filed in U.S. district court by Federal judicial district, 1994-2003
fcjt03hf03.csv	Highlights Figure: 3	Likelihood of prosecution
fcjt03hf04.csv	Highlights Figure: 4	Likelihood of conviction
fcjt03hf05.csv	Highlights Figure: 5	Likelihood of imprisonment
fcjt03hf06.csv	Highlights Figure: 6	Percent of drug offenders receiving mandatory sentence, 1996-2003

fcjt03htt01.csv	Highlights Text Table: 1	Number of suspects/defendants increased steadily across all stages of the Federal criminal justice system

fcjt03ht01.csv	Highlights Table: 1	Percent of defendants receiving sentences within range of the Federal sentencing guidelines