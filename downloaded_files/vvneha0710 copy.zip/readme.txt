Violent Victimization in New and Established Hispanic Areas, 2007-2010, NCJ 246311

 
This zip archive contains tables in individual .csv spreadsheets	
from Violent Victimization in New and Established Hispanic Areas, 2007-2010, NCJ 246311. The full report including text and graphics in .pdf format are available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5090
	

     Tables 
vvneha0710t01.csv   Table 1. Size of Hispanic population, by type of metropolitan area, 1980-2010
vvneha0710t02.csv   Table 2. Size of Hispanic population, by type of county, 1980 and 2010
vvneha0710t03.csv   Table 3. Hispanic and overall population growth, by type of metropolitan area, 1980�2010
vvneha0710t04.csv   Table 4. Hispanic and overall population growth, by type of county, 1980�2010
vvneha0710t05.csv   Table 5. Nonfatal violent victimization, by race and ethnicity and type of metropolitan area, 2007�2010
vvneha0710t06.csv   Table 6. Nonfatal violent victimization, by race and ethnicity and type of county, 2007�2010
vvneha0710t07.csv   Table 7. Age-adjusted nonfatal violent victimization rates, by race and ethnicity and type of metropolitan area, 2007�2010
vvneha0710t08.csv   Table 8. Age-adjusted nonfatal violent victimization rates, by race and ethnicity and type of county, 2007�2010

     Figures
vvneha0710f01.csv   Figure 1. U.S. population growth, 1980�2010
vvneha0710f04a.csv  Figure 4a. Socioeconomic characteristics, by type of metropolitan area, 2006�2010 (a) Per capita income in 2010 inflation-adjusted dollars  
vvneha0710f04b.csv  Figure 4b. Socioeconomic characteristics, by type of metropolitan area, 2006�2010 (b) Poverty rate*
vvneha0710f04c.csv  Figure 4c. Socioeconomic characteristics, by type of metropolitan area, 2006�2010 (c) Unemployment rate** 
vvneha0710f04d.csv Figure 4d. Socioeconomic characteristics, by type of metropolitan area, 2006�2010 (d) Female heads of households with children 
vvneha0710f05a.csv Figure 5a. Socioeconomic characteristics, by type of county, 2006�2010 (a) Per capita income in 2010 inflation-adjusted dollars
vvneha0710f05b.csv Figure 5b. Socioeconomic characteristics, by type of county, 2006�2010 (b) Poverty rate*   
vvneha0710f05c.csv Figure 5c. Socioeconomic characteristics, by type of county, 2006�2010 (c) Unemployment rate**
vvneha0710f05d.csv Figure 5d. Socioeconomic characteristics, by type of county, 2006�2010 (d) Female heads of households with children
vvneha0710f06a.csv Figure 6a. Service and organizational structures, by type of metropolitan area, 2006 (a) Full-time sworn police officers
vvneha0710f06b.csv Figure 6b. Service and organizational structures, by type of metropolitan area, 2006 (b) Social service workers
vvneha0710f06c.csv Figure 6c. Service and organizational structures, by type of metropolitan area, 2006 (c) Civic and social organization employees*
vvneha0710f06d.csv Figure 6d. Service and organizational structures, by type of metropolitan area, 2006 (d) Religious organization employees
vvneha0710f07a.csv Figure 7a. Service and organizational structures, by type of county, 2006 (a) Full-time sworn police officers
vvneha0710f07b.csv Figure 7b. Service and organizational structures, by type of county, 2006 (b) Social service workers
vvneha0710f07c.csv Figure 7c. Service and organizational structures, by type of county, 2006 (c) Civic and social organization employees*
vvneha0710f07d.csv Figure 7d. Service and organizational structures, by type of county, 2006 (d) Religious organization employees
vvneha0710f08a.csv Figure 8a. Age-specific violent victimization rates, by race and ethnicity and type of metropolitan area, 2007�2010 (a) Hispanic
vvneha0710f08b.csv Figure 8b. Age-specific violent victimization rates, by race and ethnicity and type of metropolitan area, 2007�2010 (b) Non-Hispanic white
vvneha0710f08c.csv Figure 8c. Age-specific violent victimization rates, by race and ethnicity and type of metropolitan area, 2007�2010 (c) Non-Hispanic black
vvneha0710f09a.csv Figure 9a. Age-specific violent victimization rates, by race and ethnicity and type of county, 2007�2010 (a) Hispanic
vvneha0710f09b.csv Figure 9b. Age-specific violent victimization rates, by race and ethnicity and type of county, 2007�2010 (b) Non-Hispanic white
vvneha0710f09c.csv Figure 9c. Age-specific violent victimization rates, by race and ethnicity and type of county, 2007�2010 (c) Non-Hispanic black                                      



     Appendix table
vvneha0710at01.csv Appendix table 1. NCVS interviews, by type of metropolitan area, 2007�2010
vvneha0710at02.csv Appendix table 2. NCVS interviews, by type of county, 2007�2010
vvneha0710at03.csv Appendix table 3. Standard errors for table 5: Nonfatal violent victimization, by race and ethnicity and type of metropolitan area, 2007�2010
vvneha0710at04.csv Appendix table 4. Standard errors for table 6: Nonfatal violent victimization, by race and ethnicity and type of county, 2007�2010
vvneha0710at05.csv Appendix table 5. Standard errors for table 7: Age-adjusted nonfatal violent victimization rates, by race and ethnicity and type of metropolitan area, 2007�2010
vvneha0710at06.csv Appendix table 6. Standard errors for table 8:  Age-adjusted nonfatal violent victimization rates, by race and ethnicity and type of county, 2007�2010 



