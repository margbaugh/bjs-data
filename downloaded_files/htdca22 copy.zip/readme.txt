Human Trafficking Data Collection Activities, 2022  NCJ 305205
																				
This zip archive contains tables in individual  .csv spreadsheets
from Human Trafficking Data Collection Activities, 2022  NCJ 305205.  The full report including text
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/human-trafficking-data-collection-activities-2022
																				
This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to:
https://bjs.ojp.gov/library/publications/list?series_filter=Human%20Trafficking%20Data%20Collection%20Activities
																				
Filenames	Table titles
htdca22t01.csv	Table 1. Characteristics of human trafficking defendants in cases charged in U.S. district court, fiscal year 2020
htdca22t02.csv	Table 2. Admissions to state prison for human trafficking in 31 states, 2016–2020	
																				
		Figures																			
htdca22f01.csv	Figure 1. Human trafficking suspects referred to and prosecuted by U.S. attorneys and human trafficking defendants convicted, fiscal years 2011–2020																			
																				
		Appendix tables
htdca22at01.csv	Appendix table 1. Numbers for figure 1: Human trafficking suspects referred to and prosecuted by U.S. attorneys and human trafficking defendants convicted, 2011–2020																			
																				
