Local Police Departments: Policies and Procedures, 2016  NCJ 254826		
		
This zip archive contains tables in individual  .csv spreadsheets		
Local Police Departments: Policies and Procedures, 2016  NCJ 254826.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7006		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=35		
		
		
Filename		Table name
lpdpp16t01.csv		Table 1. Percent of local police departments that maintained a written community-policing plan, by size of population served, 2016
lpdpp16t02.csv		Table 2. Annual operating budget of local police departments, by size of population served, 2016
lpdpp16t03.csv		Table 3. Percent of local police departments that required annual in-service training of patrol and field officers, by size of population served, 2016
lpdpp16t04.csv		Table 4. Percent of local police departments with written policies or procedural directives, by selected topic and size of population served, 2016
lpdpp16t05.csv		Table 5. Percent of local police departments that required written documentation when officers displayed or discharged firearms, by size of population served, 2016
lpdpp16t06.csv		Table 6. Percent of local police departments that authorized less-lethal techniques or restraints, by size of population served, 2016
lpdpp16t07.csv		Table 7. Percent of local police departments that authorized less-lethal weapons, by size of population served, 2016
lpdpp16t08.csv		Table 8. Percent of local police departments requiring external investigation of deaths or uses of force, by size of population served, 2016
lpdpp16t09.csv		Table 9. Percent of local police departments with a civilian-complaint review board, by size of population served, 2016
		
			Figure
lpdpp16f01.csv		Figure 1. Average number of training hours required of each new officer recruit in local police departments, by size of population served, 2016
		
			Appendix tables
lpdpp16at01.csv		Appendix table 1. Estimates and standard errors for figure 1: Average number of training hours required of each new officer recruit in local police departments, by size of population served, 2016
lpdpp16at02.csv		Appendix table 2. Standard errors for table 1: Percent of local police departments that maintained a written community-policing plan, by size of population served, 2016
lpdpp16at03.csv		Appendix table 3. Standard errors for table 2: Annual operating budget of local police departments, by size of population served, 2016
lpdpp16at04.csv		Appendix table 4. Standard errors for table 3: Percent of local police departments that required annual in-service training of patrol and field officers, by size of population served, 2016
lpdpp16at05.csv		Appendix table 5. Standard errors for table 4: Percent of local police departments with written policies or procedural directives, by selected topic and size of population served, 2016
lpdpp16at06.csv		Appendix table 6. Standard errors for table 5: Percent of local police departments that required written documentation when officers displayed or discharged firearms, by size of population served, 2016
lpdpp16at07.csv		Appendix table 7. Standard errors for table 6: Percent of local police departments that authorized less-lethal techniques or restraints, by size of population served, 2016
lpdpp16at08.csv		Appendix table 8. Standard errors for table 7: Percent of local police departments that authorized less-lethal weapons, by size of population served, 2016
lpdpp16at09.csv		Appendix table 9. Standard errors for table 8: Percent of local police departments requiring external investigation of deaths or uses of force, by size of population served, 2016
lpdpp16at10.csv		Appendix table 10. Standard errors for table 9: Percent of local police departments with a civilian-complaint review board, by size of population served, 2016
