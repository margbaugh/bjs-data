Bureau of Justice Statistics
Law Enforcement Management and Administrative Statistics, 1999:
Data for Individual State and Local Agencies with 100 or more Officers
By Brian A. Reaves, Ph.D. and Timothy C. Hart, BJS Statisticians

Contents of Zip archive lema991a.zip.  This file contains the tables from one section of the
report.  Additional tables are available at www.ojp.usdoj.gov/bjs/abstract/lemas99.htm.

LOCAL AGENCIES

SECTION I. PERSONNEL 

lem9901a.wk1  Number of full-time employees, percent of authorized strength, officers per
10,000 residents, and percent change since 1996 in number of full-time employees, 1999

lem9902a.wk1  Number of full-time and part-time sworn employees, and primary job function
of full-time sworn employees, 1999      

lem9903a.wk1  Number of full-time and part-time nonsworn employees, and primary job
function of full-time nonsworn employees, 1999        
 
lem9904a.wk1 Number of reserve/auxiliary sworn officers, community service officers/police
service aides, and nonsworn volunteers, 1999   

