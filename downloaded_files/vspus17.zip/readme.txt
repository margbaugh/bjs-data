Victim Service Providers in the United States, 2017  NCJ 252648		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Victim Service Providers in the United States, 2017  NCJ 252648.  The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6729		
		
		
Filename		Table name
vspus17t01.csv		Table 1. Victim service providers, by type of organization, 2017
vspus17t02.csv		Table 2. Number and percent of organizations on the National Census of Victim Service Providers roster, by final status, 2017
vspus17t03.csv		Table 3. Number and percent of victim service providers, by response and eligibility status, 2017
		
vspus17at01.csv		Appendix table 1. Number, percent, and rate of victim service providers, by state population, 2017
