Tribal Crime Data Collection Activities, 2021 NCJ 301061		
		
This .zip archive contains tables in individual  .csv spreadsheets		
Tribal Crime Data Collection Activities, 2021 NCJ 301061.  The full report including text		
and graphics in .pdf format is available from: https://bjs.ojp.gov/library/publications/tribal-crime-data-collection-activities-2021		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://bjs.ojp.gov/library/publications/list?series_filter=Tribal%20Crime%20Data%20Collection%20Activities		
		
		Table names	
tcdca21t01.csv	Table 1. Inmates held in Indian country jails, by demographic and criminal justice characteristics, midyears 2010 and 2015-2018	
tcdca21t02.csv	Table 2. American Indians and Alaska Natives in the federal justice system, fiscal years 2012-2018	
tcdca21t03.csv	Table 3. Race or ethnicity of offenders under federal supervision after release from prison, fiscal year-end 2018	
tcdca21t04.csv	Table 4. Tribal law enforcement agencies that reported 12 months of complete data to the Uniform Crime Reporting Program, by system used, 2008-2019	
		
		Figures	
tcdca21f01.csv	Figure 1. Cumulative percent of American Indian and Alaska Native state prisoners released in 2012 who had a new arrest, conviction, or return to prison after release, by year following release	
tcdca21f02.csv	Figure 2. Tribal court systems reporting sources of operational funding, 2014	
tcdca21f03.csv	Figure 3. Federal arrests and U.S. district court convictions of American Indians and Alaska Natives, fiscal years 2012-2018	
tcdca21f04.csv	Figure 4. Tribal law enforcement agencies that reported 12 months of complete data to the Uniform Crime Reporting Program, by system used, 2008-2019	
		
		Appendix table	
tcdca21at01.csv	Appendix Table 1. Estimates and standard errors for figure 1: Cumulative percent of American Indian and Alaska Native state prisoners released in 2012 who had a new arrest, conviction, or return to prison after release, by year following release	
		
