Crimes Involving Juveniles, 1993–2022   NCJ 308554																					
																					
This zip archive contains tables in individual  .csv spreadsheets																					
from Crimes Involving Juveniles, 1993–2022   NCJ 308554.  The full report including text																					
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/crimes-involving-juveniles-1993-2022
																					
Filenames	Figures																				
cij9322f01.csv	Figure 1. Rate of nonfatal violent victimization, by age of victim, 1993–2022																				
cij9322f02.csv	Figure 2. Rate of nonfatal violent victimization, by age of victim, 2018–2022																				
cij9322f03.csv	Figure 3. Number of homicides, by age of victim, 1993–2022																				
cij9322f04.csv	Figure 4. Homicide rate per 100,000 persons, by age of victim, 2018–2022																				
cij9322f05.csv	Figure 5. Percent of nonfatal violent incidents, by age of offender, 2021 and 2022																				
cij9322f06.csv	Figure 6. Percent of all arrests that were of persons age 17 or younger, by offense type, 2021 and 2022						
																					
		Appendix tables																				
cij9322at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Rate of nonfatal violent victimization, by age of victim, 1993–2022																				
cij9322at02.csv	Appendix table 2. Estimates and standard errors for figure 2: Rate of nonfatal violent victimization, by age of victim, 2018–2022																				
cij9322at03.csv	Appendix table 3. Estimates and confidence intervals for figure 3: Number of homicides, by age of victim, 1993–2022																				
cij9322at04.csv	Appendix table 4. Estimates and confidence intervals for figure 4: Homicide rate per 100,000 persons, by age of victim, 2018–2022																				
cij9322at05.csv	Appendix table 5. Estimates and standard errors for figure 5: Percent of nonfatal violent incidents, by age of offender, 2021 and 2022																				
cij9322at06.csv	Appendix table 6. Estimates for figure 6: Percent of all arrests that were of persons age 17 or younger, by offense type, 2021 and 2022