Jails in Indian Country, 2009 NCJ 232223	
	
This zip archive contains tables in individual .csv spreadsheets	
from Jails in Indian Country, 2009, NCJ 232223. The full report 	
including text and graphics in .pdf format are available from: 	
http://bjs.gov/index.cfm?ty=pbdetail&iid=2223.	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://bjs.gov/index.cfm?ty=pbse&sid=32.	
 	
Tables	
jic09t01.csv	Table 1. American Indians and Alaska Natives in custody or under community supervision, 2008 and 2009
jic09t02.csv	Table 2. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, 2004 and 2007-2009
jic09t03.csv	Table 3. Indian country jails and percent of inmate population, by facility size, June 2009
jic09t04.csv	Table 4. Jails in Indian country that held the majority of inmates, by facility, June 2009
jic09t05.csv	Table 5. Number of Indian country jails, by percent of rated capacity occupied, June 2009
jic09t06.csv	Table 6. Jails in Indian country operating above 150% of capacity on their peak day, during June 2009
jic09t07.csv	Table 7. Admissions and expected length of stay in Indian country jails during June, by facility size, June 2009
jic09t08.csv	Table 8. Number of inmates confined in Indian country jails, by demographic, characteristics, and offense, June 2000-June 2009
jic09t09.csv	Table 9. Number of persons employed in Indian country jails, by job function, June 2009
jic09t10.csv	Table 10. Inmates rated capacity, and percent of capacity occupied in Indian country, by facility, June 2009
	
Appendix tables	
jic09at01.csv	Appendix table 1. Inmates in jails in Indian country, by type of offense, June 2009
jic09at02.csv	Appendix table 2. Inmates in jails in Indian country, by conviction status, June 2009
jic09at03.csv	Appendix table 3. Number of adults and juveniles in the custody of jails in Indian country, by sex, June 2009
	
Figures	
jic09f01.csv	Figure 1. Inmates confined in Indian country jails, 2000-2004 and 2007-2009
jic09f02.csv	Figure 2. American Indians and Alaska Natives under correctional supervision in the United States, 2000-2009
jic09f03.csv	Figure 3. Percent of rated capacity occupied, by type of inmate count, June 2009
