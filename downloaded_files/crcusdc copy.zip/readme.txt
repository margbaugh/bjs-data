Contents of crcusdc.zip
Tables updated through 2000 in spreadsheet format from Civil Rights Complaints in U.S. District Courts, 1990-98, NCJ 173427
 The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/crcusdc.htm 

crc00hi.wk1           Highlights -  Number of civil rights complaints as a portion of all civil cases  filed in U.S. district courts, 1990-98	

crc00t01.wk1         Table 1. Civil rights related complaints filed in U.S. district courts, 1990-98

crc00t02.wk1         Table 2. Jurisdiction of civil rights-related complaints filed in U.S. district courts, 1990-98	

crc00t03.wk1          Table 3. Types of civil rights complaints filed in U.S. district courts involving a private suit, 1990-98	

crc00t04.wk1         Table 4. Types of civil rights complaints filed in U.S. district courts with the U.S. Government involved as a plaintiff or defendant, 1990-2000	

crc00t05.wk1         Table 5. Disposition of civil rights complaints terminated in U.S. district courts, 1990-2000	

crc00t06.wk1         Table 6. Civil rights complaints disposed of by trial verdict in U.S. district courts, 1990-2000	

crc00t07.wk1         Table 7. Plantiff winners and awards in civil rights complaints terminated by trial in U.S. district courts, 1990-2000	

crc00t08.wk1         Table 8. Plantiff winners and awards in civil rights cases terminated in U.S. district courts by type of trial, 1990-2000	

crc00t09.wk1         Table 9. Winners and awards in civil rights cases terminated by trial verdict in U.S. dsitrict courts by type of case, 1990-2000	

crc00t10.wk1         Table 10. Months from filing of complaint to disposition among civil rights related cases disposed of in U.S. district court, 1990-2000	

crc00p5a.wk1       Box 1 on page 5 - Civil rights related class action suits, 1996-2000

crc00p5b.wk1      Box 2 on page 5 - Civil rights prisoner petitions filed in Federal courts by Federal and State inmates, 1990-2000

crc00p6.wk1        Box on page 6.  Civil rights complaints filed in U.S. courts of appeal, 1990-2000	

crc00p10.wk1      Box on page 10.  Criminal civil rights prosecutions, 1994-2000	

crc00f1.wk1         Figure 1. Number of civil rights complaints filed in U.S. district courts by type of case, 1990-2000	

crc00f2.wk1         Figure 2.  Percent of employment and housing civil rights trials disposed of by a jury,1990-2000

crc00f3.wk1         Figure 3.  Percent of plaintiff winners awarded damages in civil rights complaints disposed of by trial, 1990-2000		

crcf4.wk1              Figure 4. Percentage of civil rights complaints terminated by years from filing to termination.

