Probation and Parole in the United States, 2017-2018  NCJ 252072		
		
This zip archive contains tables in individual .csv spreadsheets from		
Probation and Parole in the United States, 2017-2018  NCJ 252072.  The full report including text		
and graphics in pdf format is available from https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6986		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=42		
		
Filename		Table name
ppus1718t01.csv		Table 1. Adults under community supervision, 2008-2018
ppus1718t02.csv		Table 2. Community-supervision rates of U.S. adult residents, 2008-2018
ppus1718t03.csv		Table 3. Parolees on probation excluded from the January 1 and December 31 community-supervision populations, 2007-2018
ppus1718t04.csv		Table 4. One-day difference based on reporting changes for probation and parole, 2008-2018
ppus1718t05.csv		Table 5. Estimated total probation movements, entries, and exits, 2008-2018
ppus1718t06.csv		Table 6. Estimated total parole movements, entries, and exits, 2008-2018
		
			Figures
ppus1718f01.csv		Figure 1. Adults on probation or parole, 2008-2018
ppus1718f02.csv		Figure 2. Annual percent change of adults on probation, 2008-2018
ppus1718f03.csv		Figure 3. Annual percent change of adults on parole, 2008-2018
ppus1718f04.csv		Figure 4. Estimated total probation movements, entries, and exits, 2008-2018
ppus1718f05.csv		Figure 5. Estimated total parole movements, entries, and exits, 2008-2018
		
			Appendix tables
ppus1718at01.csv	Appendix table 1. Adults under community supervision, 2018
ppus1718at02.csv	Appendix table 2. Adults on probation, 2018
ppus1718at03.csv	Appendix table 3. Adults exiting probation, by type of exit, 2018
ppus1718at04.csv	Appendix table 4. Characteristics of adults on probation, 2008 and 2018
ppus1718at05.csv	Appendix table 5. Adults on parole, 2018
ppus1718at06.csv	Appendix table 6. Adults entering parole, by type of entry, 2018
ppus1718at07.csv	Appendix table 7. Adults exiting parole, by type of exit, 2018
ppus1718at08.csv	Appendix table 8. Characteristics of adults on parole, 2008 and 2018
ppus1718at09.csv	Appendix table 9. Adults under community supervision, 2017
ppus1718at10.csv	Appendix table 10. Adults on probation, 2017
ppus1718at11.csv	Appendix table 11. Adults exiting probation, by type of exit, 2017
ppus1718at12.csv	Appendix table 12. Characteristics of adults on probation, 2007 and 2017
ppus1718at13.csv	Appendix table 13. Adults on parole, 2017
ppus1718at14.csv	Appendix table 14. Adults entering parole, by type of entry, 2017
ppus1718at15.csv	Appendix table 15. Adults exiting parole, by type of exit, 2017
ppus1718at16.csv	Appendix table 16. Characteristics of adults on parole, 2007 and 2017
