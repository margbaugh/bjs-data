CENSUS OF STATE AND LOCAL LAW ENFORCEMENT AGENCIES, 2000 NCJ 194066																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .wk1 spreadsheets from the
Law Enforcement Management and Administrative Statistics (LEMAS) program
Bulletin, "Census of State and Local Law Enforcement Agencies, 2000"
NCJ 194066. The full report including text and graphics in pdf format are
available from: http://www.ojp.usdoj.gov/bjs/abstract/XXXXXXX.htm 

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.XXXXXXX
----------------------------------------------------------------------------
																	
Filename	Table																
																	
cslle00h1.wk1	Highlights Figure 1. As of June 2000, State and local law enforcement agencies had more than 1 million full-time employees, including about 708,000 sworn personnel

cslle0001.wk1	Table 1. Employment by State and local Law enforcement agencies, by type of agency and employee, June 2000	
cslle0002.wk1	Table 2. State and local law enforcement agencies, by size of agency, June 2000		
cslle0003.wk1	Table 3. State and local law enforcement employees, by size of agency, June 2000	
cslle0004.wk1	Table 4. State and local law enforcement agencies and employees, by State, June 2000	
cslle0005.wk1	Table 5. Local police departments, by size of agency, June 2000	
cslle0006.wk1	Table 6. Local police employees, by size of agency, June 2000
cslle0007.wk1	Table 7. Fifty largest local police departments, by number of full-time sworn personnel, June 2000
cslle0008.wk1	Table 8. Local police departments and employees, by State, June 2000
cslle0009.wk1	Table 9. Sheriffs' offices, by size of agency, June 2000
cslle0010.wk1	Table 10. Sheriffs' employees, by size of agency, June 2000
cslle0011.wk1	Table 11. Twenty-five largest sheriffs' offices, by number and function of full-time sworn personnel, June 2000
cslle0012.wk1	Table 12. Sheriffs' offices and employees, by State, June 2000
cslle0013.wk1	Table 13. Primary State law enforcement agency employees, by State, June 2000
cslle0014.wk1	Table 14. State and local law enforcement agencies with special jurisdictions, by type of jurisdiction and number of full-time sworn personnel, June 2000
cslle0015.wk1	Table 15. State and local law enforcement agencies with special jurisdictions employing 200 or more full-time sworn personnel, June 2000
cslle0016.wk1	Table 16. State and local law enforcement agencies with special jurisdictions, by State, June 2000

cslle00t1.wk1	Text Table 1. Number of full-time State and local law enforcement agencies, June 2000
cslle00t2.wk1	Text Table 2. Full-time State and local law enforcement employees per 100,000 residents
cslle00t3.wk1	Text Table 3. Types of general purpose local police, 2000

cslle00f1.wk1	Figure 1. Full-time employees in State and local law enforcement agencies, 1992, 1996, and 2000
cslle00f2.wk1	Figure 2. Selected areas of duty for full-time sworn personnel in State and local law enforcement agencies, 2000
cslle00f3.wk1	Figure 3. Full-time employees in local police departments, 1992, 1996, and 2000
cslle00f4.wk1	Figure 4. Selected areas of duty for full-time sworn personnel in local police departments, 2000
cslle00f5.wk1	Figure 5. Full-time employees in sheriffs' offices, 1992, 1996, and 2000
cslle00f6.wk1	Figure 6. Selected areas of duty for full-time sworn personnel in sheriffs' offices, 2000
cslle00f7.wk1	Figure 7. Full-time employees in the 49 primary State law enforcement agencies, 1992, 1996, and 2000
