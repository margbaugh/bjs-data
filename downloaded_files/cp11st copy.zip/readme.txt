Capital Punishment, 2011 - Statistical Tables  NCJ 242185

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2011 - Statistical Tables  NCJ 242185, electronic only. 
The full electronic report is available at:http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4697


These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to: http://www.bjs.gov/index.cfm?ty=pbse&sid=1

Tables:
cp11stat01.csv		Appendix table 1. Number of inmates under sentence of death, by demographic characteristics, 2011
cp11stf01.csv		Figure 1. Status of the death penalty, December 31, 2011
cp11stf02.csv		Figure 2. Number of persons under sentence of death, 1953-2011
cp11stf03.csv		Figure 3. Admissions to and removals from a sentence of death, 1973-2011
cp11stf04.csv		Figure 4. Number of persons executed in the United States, 1930-2011
cp11stf05.csv		Figure 5. Advance count of executions, January 1, 2012 - December 31, 2012
cp11stt01.csv		Table 1. Capital offenses, by state, 2011
cp11stt02.csv		Table 2.  Method of execution, by state, 2011
cp11stt03.csv		Table 3.  Federal capital offenses, by statute, 2011
cp11stt04.csv		Table 4.  Prisoners under sentence of death, by region, jurisdiction, and race, 2010 and 2011
cp11stt05.csv		Table 5.  Demographic characteristics of prisoners under sentence of death, 2011
cp11stt06.csv		Table 6.  Women under sentence of death, by region, jurisdiction, and race, 2010 and 2011 
cp11stt07.csv		Table 7.  Hispanics under sentence of death, by region and jurisdiction, 2010 and 2011
cp11stt08.csv		Table 8.  Criminal history profile under sentence of death, by race and Hispanic origin, 2011
cp11stt09.csv		Table 9.  Inmates removed from under sentence of death, by method of removal, 2011
cp11stt10.csv		Table 10. Average time between sentencing and execution, by year, 1977-2011
cp11stt11.csv		Table 11. Number of inmates executed, by race, 1977-2011
cp11stt12.csv		Table 12. Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2011
cp11stt13.csv		Table 13. Executions, by jurisdiction and method, 1977-2011
cp11stt14.csv		Table 14. Number of persons executed, by jurisdiction, 1930-2011
cp11stt15.csv		Table 15. Prisoners under sentence of death on December 31, 2011, by jurisdiction and year of sentencing
cp11stt16.csv		Table 16. Prisoners sentenced to death and outcome of sentence, by year of sentencing, 1973-2011
cp11stt17.csv		Table 17. Number sentenced to death and number of removals, by jurisdiction and reason for removal, 1973-2011


