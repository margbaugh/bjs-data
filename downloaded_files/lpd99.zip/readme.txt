LOCAL POLICE DEPARTMENTS 1999
NCJ 186478																	
																	
This zip archive contains tables and figures in individual .wk1
spreadsheets from the 1999 Law Enforcement and Administrative
Statistics (LEMAS) report, "Local Police Departments 1999."
The full report including tables and graphics in .pdf format 
are available from: http://www.ojp.usdoj.gov/bjs/abstract/lpd99.htm

This report is one in a series.  More recent editions
may be available. To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#lpd

																	
Tables:																	
																	
lpd9901.wk1	Table 1. Employment by general purpose State and local
                law enforcement agencies in the United States, 1999																
lpd9902.wk1 	Table 2. Local police departments, by number of sworn 
                personnel, 1999
lpd9903.wk1	Table 3. Local police departments and full-time sworn
		personnel, by size of population served, 1999
lpd9904.wk1	Table 4. Average number of employees in local police
		departments, by size of population served, 1999
lpd9905.wk1	Table 5. Officers assigned to respond to citizen calls
		for service in local police departments, by size
		of population served, 1999
lpd9906.wk1	Table 6. Job function category of full-time employees
		in local police departments, 1999
lpd9907.wk1	Table 7. Authorized full-time strength of local police
		departments, and percent of authorized strength
		employed, by size of population served, 1999
lpd9908.wk1	Table 8. Use of sworn reserve/auxillary officers, and
		nonsworn community service officers/police service aides
		by local police departments, by size of population served, 1999
lpd9909.wk1	Table 9. Stations and substations operated by local police
		departments, by size of population served, 1999
lpd9910.wk1	Table 10. Types of patrol used on a routine basis by local
		police departments, by size of population served, 1999
lpd9911.wk1	Table 11. Dispatch functions of local police 
		departments, by size of population served, 1999
lpd9912.wk1	Table 12. Participation in a 9-1-1 emergency telephone
		system by local police departments, by size of
		population served, 1999
lpd9913.wk1	Table 13. Crime investigation functions of local police
		departments, by size of population served, 1999
lpd9914.wk1	Table 14. Investigative support functions of local police 
		departments, by size of population served, 1999
lpd9915.wk1	Table 15. Court-related functions of local police 
		departments, by size of population served, 1999
lpd9916.wk1	Table 16. Detention facilities of local police
		departments, by size of population served, 1999
lpd9917.wk1	Table 17. Traffic and vehicle-related functions of local
		police departments, by size of population served, 1999
lpd9918.wk1	Table 18. Special operations functions of local police
		departments, by size of population served, 1999
lpd9919.wk1	Table 19. Special public safety functions of local police
		departments, by size of population served, 1999
lpd9920.wk1	Table 20. Local police departments with a community
		policing plan, by size of population served, 1999
lpd9921.wk1	Table 21. Community policing training for new officer
		recruits and in-service officers in local police
		departments, by size of population served, 1999
lpd9922.wk1	Table 22. Community policing officers in local police
		departments, by size of population served, 1999
lpd9923.wk1	Table 23. School resource officers in local police
		departments, by size of population served, 1999
lpd9924.wk1	Table 24. Community-oriented policies for sworn personnel
		in local police departments, by size of population
		served, 1999
lpd9925.wk1	Table 25. Community policing activities of local police
		departments, by size of population served, 1999
lpd9926.wk1	Table 26. Surveying of citizens by local police departments,
		by size of population served, 1999
lpd9927.wk1	Table 27. Local police departments providing citizens with
		routine access to crime statistics or crime maps, by size
		of population served, 1999
lpd9928.wk1	Table 28. Selected types of computers used by local police
		departments for administrative functions, by size of
		population served, 1999
lpd9929.wk1	Table 29. Administrative records stored in a computerized
		format by local police departments, by size of population
		served, 1999
lpd9930.wk1	Table 30. Local police departments using computer-aided
		dispatch, by size of population served, 1999
lpd9931.wk1	Table 31. Offender and suspect records stored in a 
		computerized format by local police departments, by size
		of population served, 1999
lpd9932.wk1	Table 32. Local police departments using computers for
		criminal investigations, by size of population served, 1999
lpd9933.wk1	Table 33. Investigative records stored in a computerized
		format by local police departments, by size of population
		served, 1999
lpd9934.wk1	Table 34. Traffic and vehicle-related records stored in a
		computerized format by local police departments, by size
		of population served, 1999
lpd9935.wk1	Table 35. Crime and calls for service records stored in a
		computerized format by local police departments, by size
		of population served, 1999
lpd9936.wk1	Table 36. Use of computers for crime analysis and crime
		mapping by local police departments, by size of population
		served, 1999
lpd9937.wk1	Table 37. Use of computers for Internet purposes by local
		police departments, by size of population served, 1999
lpd9938.wk1	Table 38. Types of in-field computers or terminals used by
		local police departments, by size of population served, 1999
lpd9939.wk1	Table 39. Use of in-field computers for field reports and
		communications, by local police departments, by size of
		population served, 1999
lpd9940.wk1	Table 40. Computerized information accessible to in-field
		officers of local police departments, by size of population
		served, 1999
lpd9941.wk1	Table 41. Methods for transmitting criminal incident reports
		to a central information system in local police departments,
		by size of population served, 1999
lpd9942.wk1	Table 42. Written policies or procedures on discretionary
		arrest powers and domestic disputes in local police 
		departments, by size of population served, 1999
lpd9943.wk1	Table 43. Written policies or procedures on handling special
		populations in local police departments, by size of
		population served, 1999
lpd9944.wk1	Table 44. Written policies or procedures on officer use of
		force in local police departments, by size of population
		served, 1999
lpd9945.wk1	Table 45. Written policies or procedures on conduct and
		appearance, maximum work hours, and handling of citizen
		complaints in local police departments, by size of population
		served, 1999

Figures:

lpd99f01.wk1	Figure 1. Full-time employment by local police departments,
		1990, 1993, 1997, and 1999

lpd99f02.wk1	Figure 2. Percent of population served by a local police
		department using foot or bicycle patrol units on a routine
		basis, 1997 and 1999

lpd99f03.wk1	Figure 3. Percent of population served by local police
		departments participating in a 9-1-1 emergency telephone
		system, 1990, 1993, 1997, and 1999.	

lpd99f04.wk1	Figure 4. Community policing plans of local police 
		departments, 1999	

lpd99f05.wk1	Figure 5. Percent of local police officers designated as
		community policing officers, by size of population served, 1999

lpd99f06.wk1	Figure 6. Percent of local police officers employed by a
		department that met regularly with citizens to discuss crime-
		related problems, 1999	

lpd99f07.wk1	Figure 7. Purposes for which local police departments used
		information collected in citizen surveys, 1999	

lpd99f08.wk1	Figure 8. Methods for accessing crime statistics provided
		to citizens by local police departments, 1999

lpd99f09.wk1	Figure 9. Percent of local police department dispatch systems
		that were computerized, by size of population served, 1990 and 1999

lpd99f10.wk1	Figure 10. Percent of local police officers employed by a
		department with computerized offender and suspect information,
		1990 and 1999	

lpd99f11.wk1	Figure 11. Number of in-field computers or terminals per 100
		sworn officers in local police departments, by size of
		population served, 1999

lpd99f12.wk1	Figure 12. Percent of local police officers employed by a
		department in which patrol officers have direct access to
		information through in-field computers, 1999	

lpd99f13.wk1	Figure 13. Percent of local police officers employed by a
		department with written policies or procedures, by subject
		area, 1999															
																	
														
