Indicators of Mental Health Problems Reported by Prisoners: Survey of Prison Inmates, 2016 NCJ 252643		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Indicators of Mental Health Problems Reported by Prisoners: Survey of Prison Inmates, 2016 NCJ 252643		
The full report including text and graphics in pdf format is available from:		
https://bjs.ojp.gov/library/publications/indicators-mental-health-problems-reported-prisoners-survey-prison-inmates		
		
Filenames		Table titles	
imhprpspi16stt01.csv	Table 1. Prevalence of mental health indicators among all state and federal prisoners, 2016	
imhprpspi16stt02.csv	Table 2. Prevalence of mental health indicators among state and federal prisoners, by demographic characteristics, 2016	
imhprpspi16stt03.csv	Table 3. Prevalence of state and federal prisoners reporting a history of a mental health problem, by specific mental disorders, 2016	
imhprpspi16stt04.csv	Table 4. Mental health treatment received by state and federal prisoners with an indicator of a mental health problem, by type of indicator, 2016	
imhprpspi16stt05.csv	Table 5. Prevalence of mental health indicators among all state and federal prisoners, 2011-2012 and 2016	
		
			Figure	
imhprpspi16stf01.csv	Figure 1. Prevalence of mental health indicators among all state and federal prisoners, 2016	
		
			Appendix tables	
imhprpspi16stat01.csv	Appendix Table 1. Estimated number of state and federal prisoners, by demographic characteristics, 2016	
imhprpspi16stat02.csv	Appendix Table 2. Standard errors for table 2: Prevalence of mental health indicators among state and federal prisoners, by demographic characteristics, 2016	
imhprpspi16stat03.csv	Appendix Table 3. Standard errors for table 4: Mental health treatment received by state and federal prisoners with an indicator of a mental health problem, by type of indicator, 2016