Federal Justice Statistics, 2016 - Statistical Tables  NCJ 251772		
		
This zip archive contains tables in individual .csv spreadsheets		
from Federal Justice Statistics, 2016 - Statistical Tables  NCJ 251772		
The full report including text and graphics in .pdf format is available at		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7187		
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=62		
		
Filenames		Table names
fjs16stt1.1.csv		Table 1.1. Federal arrests, by most serious offense, FY 2016
fjs16stt1.2.csv		Table 1.2. Federal arrests, by arresting agency, FY 2016
fjs16stt1.3.csv		Table 1.3. Demographic characteristics of federal arrestees, FY 2016
fjs16stt1.4.csv		Table 1.4. Demographic characteristics of suspects arrested by Drug Enforcement Administration agents, by type of drug, FY 2016
fjs16stt1.5.csv		Table 1.5. Warrants cleared and median days from initiation to clearance, by warrant type, FY 2016
fjs16stt1.6.csv		Table 1.6. Warrants cleared and median days from initiation to clearance, by warrant characteristic, FY 2016
fjs16stt2.1.csv		Table 2.1. Suspects in matters opened by U.S. attorneys, by offense, FY 2016
fjs16stt2.2.csv		Table 2.2. Disposition of suspects in criminal matters concluded, by offense, FY 2016
fjs16stt2.3.csv		Table 2.3. Reasons U.S. attorneys declined to prosecute suspects in criminal matters, FY 2016
fjs16stt3.1.csv		Table 3.1. Defendants released at initial hearing or detention hearing, by offense, FY 2016
fjs16stt3.2.csv		Table 3.2. Defendants released prior to case disposition, by defendant characteristics, FY 2016
fjs16stt3.3.csv		Table 3.3. Behavior of federal defendants released to the community pending trial, by offense, FY 2016
fjs16stt4.1.csv		Table 4.1. Defendants in criminal cases filed, by offense, FY 2016
fjs16stt4.2.csv		Table 4.2. Disposition of criminal cases terminated in U.S. district court, by offense, FY 2016
fjs16stt4.3.csv		Table 4.3. Criminal cases disposed of by U.S. magistrates, by offense, FY 2016
fjs16stt4.4.csv		Table 4.4. Characteristics of convicted offenders, FY 2016
fjs16stt5.1.csv		Table 5.1. Offenders sentenced in criminal cases terminated, by offense, FY 2016
fjs16stt5.2.csv		Table 5.2. Type and length of sentence imposed for convicted offenders, by offense, FY 2016
fjs16stt5.3.csv		Table 5.3. Characteristics of convicted offenders sentenced to incarceration, FY 2016
fjs16stt5.4.csv		Table 5.4. Average incarceration sentence length, by offense and offender characteristics, FY 2016
fjs16stt6.1.csv		Table 6.1. Criminal appeals terminated, by type of criminal case and offense, FY 2016
fjs16stt6.2.csv		Table 6.2. Disposition of criminal appeals terminated, by offense, FY 2016
fjs16stt7.1.csv		Table 7.1. Offenders under federal supervision, by offense and type of supervision, FY 2016
fjs16stt7.2.csv		Table 7.2. Demographic characteristics of offenders under federal supervision, FY 2016
fjs16stt7.3.csv		Table 7.3. Outcomes of offenders terminating probation supervision, by offense, FY 2016
fjs16stt7.4.csv		Table 7.4. Outcomes of offenders terminating probation supervision, by offender defender characteristics, FY 2016
fjs16stt7.5.csv		Table 7.5. Outcomes of offenders terminating supervised release, by offense, FY 2016
fjs16stt7.6.csv		Table 7.6. Outcomes of offenders terminating supervised release, by offender demographic characteristics, FY 2016
fjs16stt7.7.csv		Table 7.7. Outcomes of offenders terminating parole, by offense, FY 2016
fjs16stt7.8.csv		Table 7.8. Outcomes of offenders terminating parole, by offender demographic characteristics, FY 2016
fjs16stt8.1.csv		Table 8.1. Admissions and releases of federal prisoners, by offense, FY 2016
fjs16stt8.2.csv		Table 8.2. Demographic characteristics of offenders in the federal prison population, FY 2016
fjs16stt8.3.csv		Table 8.3. Average time to first release and percent of sentence served for federal prisoners released by standard methods, FY 2016
fjs16stt8.4.csv		Table 8.4. Demographic characteristics of offenders first released from prison, by offense, FY 2016
