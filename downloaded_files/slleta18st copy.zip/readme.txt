State and Local Law Enforcement Training Academies, 2018 - Statistical Tables  NCJ 255915 			
			
This zip archive contains tables in individual  .csv spreadsheets			
from State and Local Law Enforcement Training Academies, 2018 - Statistical Tables  NCJ 255915.  The full report including text			
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/state-and-local-law-enforcement-training-academies-2018-statistical-tables
			
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to			
https://bjs.ojp.gov/library/publications/list?series_filter=State%20and%20Local%20Law%20Enforcement%20Training%20Academies			
			
Filenames		Table names		
slleta18stt01.csv	Table 1. Number of academies that provided and recruits who started basic training, by type of academy, 2018		
slleta18stt02.csv	Table 2. Completion status of basic training recruits, by sex, 2018		
slleta18stt03.csv	Table 3. Recruits who started and completed basic training, by race or ethnicity, 2018		
slleta18stt04.csv	Table 4. Mandatory field training that academies required after recruits completed basic training, by type of academy, 2018		
slleta18stt05.csv	Table 5. Characteristics of training academies, recruits, and training provided, by region, 2018		
slleta18stt06.csv	Table 6. Stress training that academies offered and recruits received during basic training, by type of training environment, 2011-13 and 2018		
slleta18stt07.csv	Table 7. Subject areas that academies offered and recruits received during basic training and average length of instruction, 2018		
slleta18stt08.csv	Table 8. Weapons training that academies offered and recruits received during basic training, 2018		
slleta18stt09.csv	Table 9. Special firearms training that academies offered and recruits received during basic training, 2011-13 and 2018		
slleta18stt10.csv	Table 10. Control and defensive tactics training that academies offered and recruits received during basic training, 2018		
slleta18stt11.csv	Table 11. Reality-based or mock scenario training that academies offered and recruits received during basic training, 2011-13 and 2018		
slleta18stt12.csv	Table 12. Training to identify and respond to other officers’ use of excessive force that academies offered and recruits received during basic training, 2018		
slleta18stt13.csv	Table 13. Types of instructors at state and local academies that trained law enforcement, by employment status, 2018		
slleta18stt14.csv	Table 14. Law enforcement experience and education that academies required of full-time instructors, by type of academy, 2018		
slleta18stt15.csv	Table 15. Certifications that academies required of full-time instructors, by type of academy, 2018		
slleta18stt16.csv	Table 16. Academies that provided ongoing or refresher training to full-time instructors, by methods used to develop instructor training content, 2018		
slleta18stt17.csv	Table 17. Response rates for the 2018 Census of Law Enforcement Training Academies, by type of academy, 2018		
			
			Figures		
slleta18stf01.csv	Figure 1. Recruits in basic training programs in state and local law enforcement training academies, by type of training environment, 2011-13 and 2018		
slleta18stf02.csv	Figure 2. Race or ethnicity of recruits who started basic training, 2006, 2011-13, and 2018		
			
			Appendix tables		
slleta18stat01.csv	Appendix table 1. Estimates and standard errors for figure 2: Race or ethnicity of recruits who started basic training, 2006, 2011-13, and 2018		
slleta18stat02.csv	Appendix table 2. Standard errors for table 1: Number of academies that provided and recruits who started basic training, by type of academy, 2018		
slleta18stat03.csv	Appendix table 3. Standard errors for table 2: Completion status of basic training recruits, by sex, 2018		
slleta18stat04.csv	Appendix table 4. Standard errors for table 3: Recruits who started and completed basic training, by race or ethnicity, 2018		
slleta18stat05.csv	Appendix table 5. Standard errors for table 4: Mandatory field training that academies required after recruits completed basic training, by type of academy, 2018		
slleta18stat06.csv	Appendix table 6. Standard errors for table 5: Characteristics of training academies, recruits, and training provided, by region, 2018		
slleta18stat07.csv	Appendix table 7. Standard errors for table 6: Stress training that academies offered and recruits received during basic training, by type of training environment, 2011-13 and 2018		
slleta18stat08.csv	Appendix table 8. Standard errors for table 7: Subject areas that academies offered and recruits received during basic training and average length of instruction, 2018		
slleta18stat09.csv	Appendix table 9. Standard errors for table 8: Weapons training that academies offered and recruits received during basic training, 2018		
slleta18stat10.csv	Appendix table 10. Standard errors for table 9: Special firearms training that academies offered and recruits received during basic training, 2011-13 and 2018		
slleta18stat11.csv	Appendix table 11. Standard errors for table 10: Control and defensive tactics training that academies offered and recruits received during basic training, 2018		
slleta18stat12.csv	Appendix table 12. Standard errors for table 11: Reality-based or mock scenario training that academies offered and recruits received during basic training, 2011-13 and 2018		
slleta18stat13.csv	Appendix table 13. Standard errors for table 12: Training to identify and respond to other officers’ use of excessive force that academies offered and recruits received during basic training, 2018		
slleta18stat14.csv	Appendix table 14. Standard errors for table 13: Types of instructors at state and local academies that trained law enforcement, by employment status, 2018		
slleta18stat15.csv	Appendix table 15. Standard errors for table 14: Law enforcement experience and education that academies required of full-time instructors, by type of academy, 2018		
slleta18stat16.csv	Appendix table 16. Standard errors for table 15: Certifications that academies required of full-time instructors, by type of academy, 2018		
slleta18stat17.csv	Appendix table 17. Standard errors for table 16: Academies that provided ongoing or refresher training to full-time instructors, by methods used to develop instructor training content, 2018		
			
