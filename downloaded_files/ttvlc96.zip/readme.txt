Contents of ZIP archive for 
TORT TRIALS AND VERDICTS IN LARGE COUNTIES, 1996
Civil Justice Survey of State Courts, 1996   NCJ  179769

ttv9601.wk1	Table 1.  Tort cases decided by a trial in the
                Nation's 75 largest counties, 1996

ttv9602.wk1	Table 2.  Number of litigants in tort trial cases, 
		by case type in the Nation's 75 largest counties, 1996

ttv9603.wk1	Table 3.  Pairings of primary litigants in tort trial 
		cases in State courts in the Nation's 75 largest counties, 1996

ttv9604.wk1	Table 4.  Type of business plaintiff and defendant 
		in tort cases in the Nation's 75 largest counties, 1996

ttv9605.wk1	Table 5.  Plaintiff winners in tort trial cases in the
                Nation's 75 largest counties, 1996

ttv9606.wk1	Table 6.  Final award amounts to plaintiff winners in
		tort trial cases in the Nation's 75 largest counties, 1996

ttv9607.wk1	Table 7.  Punitive damages awarded to plaintiff winners
		in tort trial cases in the Nation's 75 largest counties, 1996

ttv9608.wk1	Table 8.  Plaintiff winners with awards reduced due to 
		contributory negligence in the Nation's 75 largest counties, 1996

ttv9609.wk1	Table 9.  Case processing time from filing of complaint to
		verdict or final judgment in State courts in the 
                Nation's 75 largest counties, 1996

ttv96hi.wk1	Highlight.  Median final award amounts (compensatory and
		punitive) to plaintiff winners in tort trial cases in the
                Nation's 75 largest counties, 1996

ttv96b1.wk1	Box 1.  Defective products in product liability cases, 1996

ttv96b2.wk1	Box 2.  Medical and professional malpractice cases decided
		by a trial in the Nation's 75 largest counties, 1996

ttv96b3.wk1	Box 3.	Tort jury trials in 1992

ttv96b4.wk1	Box 4.  Tort reforms enacted by State legislatures since 1986, 
		by issue area

ttv96a1.wk1	Appendix A.  Types of tort cases decided by a trial in State
		courts, by sampled counties, 1996

ttv96a2.wk1	Appendix B.  Final and punitive damage awards for plaintiff
		winners in tort trials, by sampled counties, 1996

ttv96a3.wk1	Appendix C.  Selected estimates, standard errors, and 
		confidence intervals, 1996 survey