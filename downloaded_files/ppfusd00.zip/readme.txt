Prisoner Petitions Filed in U.S. District Courts, with Trends 1980-2000  NCJ  189430
 
This zip archive contains tables in individual .wk1 spreadsheets
from Prisoner Petitions Filed in U.S. District Courts, with Trends 1980-2000  NCJ  189430
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/ppfusd00.htm
 
Filename          Table Title
 
ppf001            Table 1.  Prisoner petitions filed in U.S. district court by Federal and State inmates, 1980-2000
ppf002            Table 2.  Prisoner Petitions filed in U.S. district court by Federal and State inmates, by type of petition and State or jurisdiction, 2000
ppf003            Table 3.  Federal and State Prison Population, 1980-2000
 
         Figures
 
ppf00fh.wk1       Highlights Figure.  Prisoner petitions filed in U.S. district court by Federal and State inmates, 1980-2000
ppf00f1a.wk1      Figure 1a.  Total number of prisoner petitions filed per 1,000 inmates, by jurisdiction, 1980-2000
ppf00f1b.wk1      Figure 1b.  Number of civil rights petitions filed per 1,000 inmates, by jurisdiction, 1980-2000
ppf00f1c.wk1      Figure 1c.  Number of habeas corpus petitions filed per 1,000 inmates, by jurisdiction, 1980-2000
ppf00f2.wk1       Figure 2. Number of prisoner petitions filed in U.S. district court per 1,000 inmates, by State of jurisdiction, 2000
ppf00f3.wk1       Figure 3.  Civil rights petitions filed by State inmates, actual number and estimated number without the Prison Litigation Reform Act, by month
ppf00f3a.wk1      Figure 3a.  Civil rights petitions filed by Federal inmates, actual number and estimated number without the Prison Litigation Reform Act
ppf00f4.wk1       Figure 4.  Habeas corpus petitions filed by State inmates, actual number and estimated number without the Antiterrorism and Effective Death Pena
ppf00f4a.wk1      Figure 4a.  Habeas corpus petitions filed by Federal inmates, actual number and estimated number without the Antiterrorism and Effective Death P
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
