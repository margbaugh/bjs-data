Improving Criminal History Records in Indian COuntry, 2004-2006 NCJRS 218913		


This zip archive contains tables in individual .csv spreadsheets 		
from the Imrpoving Criminal History Records in Indian Country, 2004-2006 		
and .txt files providing supporting documentation. 		


Spreadsheets:		
ichric06t01.csv		"Table 1.  Tribal Criminal History Record Improvement Program by Tribe and State, 2004 - 2006

Text Table:

ichric06t02.csv		"Table 2.  Tribal Criminal History Record Improvement Program Allowable Costs by Grantee, 2004 - 2006


