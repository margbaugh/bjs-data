Census of Publicly Funded Forensic Crime Laboratories, 2009  NCJ 238252

This zip archive contains tables in individual .csv spreadsheets		
from Census of Publicly Funded Forensic Crime Laboratories, 2009  NCJ 238252.		
The full report including text and graphics in .pdf format is available at		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4412


File name		Table number
cpffcl09t01.csv   Table 1. Functions performed by publicly funded forensic crime labs, by type of jurisdiction, 2009
cpffcl09t02.csv   Table 2. Publicly funded forensic crime laboratories, by type of jurisdiction, 2009
cpffcl09t03.csv   Table 3. Examinations and tasks performed by publicly funded forensic crime labs, by type of forensic function and jurisdiction served, 2009
cpffcl09t04.csv   Table 4. Nationally estimated number of requests for services backlogged in publicly funded forensic crime labs, by type of request, yearend 2008�09
cpffcl09t05.csv   Table 5. Nationally estimated number of requests for services received and completed by publicly funded forensic crime labs, by type of request, 2009
cpffcl09t06.csv   Table 6. Percent change in the number of backlogged requests among publicly funded forensic crime labs, by type of request, yearend 2008�09
cpffcl09t07.csv   Table 7. Types of requests for services received by publicly funded forensic crime labs, by type of jurisdiction, 2009
cpffcl09t08.csv   Table 8. Percent of publicly funded forensic crime labs that outsourced requests for services or received requests from other labs, by type of jurisdiction and staff size, 2009
cpffcl09t09.csv   Table 9. Functions performed by laboratory information management systems (LIMS) within publicly funded forensic crime labs, 2009
cpffcl09t10.csv   Table 10. Percent of publicly funded forensic crime labs accredited by a professional forensic science organization, by type of jurisdiction and accreditation, 2009
cpffcl09t11.csv   Table 11. Percent of publicly funded forensic crime labs with resources dedicated to research, by type of jurisdiction and staff size, 2002 and 2009
cpffcl09t12.csv   Table 12. Staff size of publicly funded forensic crime labs, by type of jurisdiction, 2009
cpffcl09t13.csv   Table 13. Positions of employees in publicly funded forensic crime labs, by type of jurisdiction, 2009
cpffcl09t14.csv   Table 14. Nationally estimated annual operating budget (in millions) for the nation�s publicly funded forensic crime laboratories, by type of jurisdiction, 2002, 2005, and 2009
cpffcl09t15.csv   Table 15. Response rates for the Census of Publicly Funded Forensic Crime Laboratories, 2002, 2005, and 2009

			Figure number
cpfcl09f01.csv   Figure 1. Percent of publicly funded forensic crime labs accredited by a professional forensic science organization, by type of jurisdiction, 2002, 2005, and 2009
cpfcl09f02.csv   Figure 2. Percent of publicly funded forensic crime labs outsourcing requests for services, by type of jurisdiction, 2002, 2005, and 2009
cpfcl09f03.csv   Figure 3. Percent of publicly funded forensic crime labs with a laboratory information management system (LIMS), by type of jurisdiction, 2002, 2005, and 2009
cpfcl09f04.csv   Figure 4. Percent of publicly funded forensic crime labs that conducted proficiency testing, by type of test, 2002 and 2009
cpfcl09f05.csv   Figure 5. Nationally estimated number of full-time employees in publicly funded forensic crime labs, by type of jurisdiction, 2002, 2005, and 2009
  
			Appendix table number
cpffcl09at01.csv   Appendix table 1. Number of reported requests for services backlogged in publicly funded forensic crime labs, by type of request, yearend 2008�09
cpffcl09at02.csv   Appendix table 2. Number of reported requests for services received and completed by publicly funded forensic crime labs, by type of request, 2009
cpffcl09at03.csv   Appendix table 3. Number of full-time employees in publicly funded crime forensic labs, by type of jurisdiction, 2002, 2005, and 2009
cpffcl09at04.csv   Appendix table 4. Total annual operating budget (in millions) reported by publicly funded forensic crime labs, by type of jurisdiction, 2002, 2005, and 2009




