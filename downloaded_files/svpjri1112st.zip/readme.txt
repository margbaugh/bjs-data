Sexual Victimization in Prisons and Jails  Reported by Inmates, 2011-12 - Update    NCJ 241399	
		
 		
This zip archive contains tables in individual .csv spreadsheets from		
Sexual Victimization in Prisons and Jails  Reported by Inmates, 2011-12-Update   NCJ 241399
		
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4654		
		
		
		
svpjri1112_transgendert01.csv		Table 1. Prevalence of sexual victimization among transgender adult inmates, by type of facility, National Inmate Survey, 2007, 2008�09, and 2011�12 - Supplemental table
svpjri1112_transgendert02.csv		Table 2. Prevalence of sexual victimization among transgender adult inmates, by type of victimization, National Inmate Survey, 2007, 2008�09, and 2011�12-Supplemental table
svpjri1112_transgendert03.csv		Table 3. Prevalence of sexual victimization among transgender adult prison and jail inmates, by type of incident, level of coercion, and injury, National Inmate Survey, 2007, 2008�09, and 2011-12-Supplemental table
