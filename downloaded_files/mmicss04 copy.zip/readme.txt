Medical Malpractice Insurance Claims in Seven States, 2000-2004 
 
This zip archive contains tables in individual .csv spreadsheets
from Medical Malpractice Insurance Claims in Seven States, 2000 - 2004, NCJ 216339.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/mmicss04.htm

Filename		
			Table number	
mmicss04t01.csv		Table 1. Closed medical malpractice insurance claims, 2000-2004
mmicss04t02.csv		Table 2. Type of health care provider involved in closed medical malpractice insurance claims, by state, 2000-2004
mmicss04t03.csv		Table 3. Facility where injury occurred in closed medical malpractice insurance claims, by state and health care provider, 2000-2004
mmicss04t04.csv		Table 4. Gender of claimant in closed medical malpractice insurance claims, by health care provider and state, 2000-2004
mmicss04t05.csv		Table 5. Percent of insurance payouts in closed medical malpractice insurance claims, by health care provider and state, 2000-2004 
mmicss04t06.csv		Table 6. Number of closed claims with an insurance payout and median payout, by type of disposition, 2000-2004
mmicss04t07.csv		Table 7. Median loss adjustment expenses by type of claim disposition in closed medical malpractice insurance claims with insurance payouts, 2000-2004
	
   			Figures   
mmicss04f01.csv		Figure 1. Trends in payouts in medical malpractice insurance claims in states with any health care provider data
mmicss04f02.csv		Figure 2. Trends in payouts in medical malpractice insurance claims in states with only physician or surgeon data

			Text Tables
mmicss04tt01.csv	Text Table 1: Few medical malpractice insurance claims resulted in payouts of $1 million or more, 2000-2004 
mmicss04tt02.csv	Text Table 2. Median payouts for claims resolved through alternative dispute resolution in Texas
mmicss04tt03.csv	Text Table 3. Average number of months to process a claim from reporting to closing

			Box Text Tables
mmicss04boxtt01.csv	Box Text Table 1. Number of claims and percent of injuries where claimant received payment in Nevada, by type of injury, 2000-2004
mmicss04boxtt02.csv	Box Text Table 2. Number and median payout of medical malpractice insurance claims, by severity of injury, 2000-2004		
	
			Box Figure
mmicss04boxf01.csv	Box figure 1. Trends in severity of injury alleged in medical malpractice claims closed with insurance payouts in Missouri, 1990 - 2004

 
 
 
 
 
 
 
 
