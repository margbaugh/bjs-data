Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2013   NCJ 248756
This zip archive contains tables in individual .csv spreadsheets
Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2013   NCJ 248756
The full report including text and graphics in .pdf format are available from: https://ojprdcweb58.ojp.usdoj.gov:8500/index.cfm?ty=pbdetail&iid=5439

Tables	
mljsp0013stt01.csv	Table 1.  Number of local jail inmate deaths, by cause of death, 2000�2013 
mljsp0013stt02.csv	Table 2.  Percent of local jail inmate deaths, by cause of death, 2000�2013
mljsp0013stt03.csv	Table 3.  Mortality rate per 100,000 local jail inmates, by cause of death, 2000�2013
mljsp0013stt04.csv	Table 4.  Number of local jail inmate deaths, by selected decedent characteristics, 2000�2013
mljsp0013stt05.csv	Table 5.  Percent of local jail inmate deaths, by selected decedent characteristics, 2000�2013
mljsp0013stt06.csv	Table 6.  Mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2013
mljsp0013stt07.csv	Table 7.  Number of local jail inmate deaths, by cause of death and selected decedent characteristics, 2000�2013 
mljsp0013stt08.csv	Table 8.  Average annual mortality rate per 100,000 local jail inmates, by cause of death and selected decedent characteristics, 2000�2013 
mljsp0013stt09.csv	Table 9.  Number and percent of local jail jurisdictions reporting to the Deaths in Custody Program, by number of deaths reported each year, 2000�2013
mljsp0013stt10.csv	Table 10. Number, percent, average daily population, and mortality rate per 100,000 local jail inmate deaths, by hold status, 2013
mljsp0013stt11.csv	Table 11. Number of local jail inmates held on an average day, by state, 2000�2013 
mljsp0013stt12.csv	Table 12. Number of local jail deaths, by state, 2000�2013
mljsp0013stt13.csv	Table 13. Mortality rate per 100,000 local jail inmates, by state, 2000�2013
mljsp0013stt14.csv	Table 14. Number of local jail jurisdictions reporting to the Deaths in Custody Reporting Program, by state, 2000�2013
mljsp0013stt15.csv	Table 15. Number of local jail jurisdictions reporting one or more deaths to the Deaths in Custody Program, by state, 2000�2013
mljsp0013stt16.csv	Table 16. Number of state prisoner deaths, by cause of death, 2001�2013
mljsp0013stt17.csv	Table 17. Percent of state prisoner deaths, by cause of death, 2001�2013 
mljsp0013stt18.csv	Table 18. Mortality rate per 100,000 state prisoners, by cause of death, 2001�2013
mljsp0013stt19.csv	Table 19. Number of state prisoner deaths, by selected decedent characteristics, 2001�2013 
mljsp0013stt20.csv	Table 20. Percent of state prisoner deaths, by selected decedent characteristics, 2001�2013
mljsp0013stt21.csv	Table 21. Mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2013
mljsp0013stt22.csv	Table 22. Estimated number of state and federal prisoners in custody, by selected inmate characteristics, 2001�2013
mljsp0013stt23.csv	Table 23. Number of state prisoner deaths, by cause of death and selected decedent characteristics, 2001�2013
mljsp0013stt24.csv	Table 24. Average annual mortality rate per 100,000 state prisoners, by cause of death and selected decedent characteristics, 2001�2013
mljsp0013stt25.csv	Table 25. Number of state and federal prisoner deaths, by location, 2001�2013
mljsp0013stt26.csv	Table 26. Mortality rate per 100,000 state and federal prisoners, by location, 2001�2013
mljsp0013stt27.csv	Table 27. Number of state and federal prisoner deaths, by cause of death and location, 2001�2013
mljsp0013stt28.csv	Table 28. Average annual mortality rate per 100,000 state and federal prisoners, by cause of death and location, 2001�2013

Figures
mljsp0012stf01.csv	Figure 1. Mortality rate per 100,000 jail inmates, by selected causes of death, 2000�2013
mljsp0012stf02.csv	Figure 2.  Number of prisoner deaths, by cause of death, 2001�2013

Appendix tables
mljsp0013stat01.csv	Appendix table 1. Estimated number of local jail inmates in custody on an average day, by selected inmate characteristics, 2000�2013
mljsp0013stat02.csv	Appendix table 2. Illness mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2001�2013
mljsp0012stat03.csv	Appendix table 3. Heart disease mortality rate per 100,000 local jail inmates, by selected decendent characteristics, 2001�2013
mljsp0012stat04.csv	Appendix table 4. Suicide mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2001�2013
mljsp0012stat05.csv	Appendix table 5. Mortality rate for all other unnatural deaths per 100,000 local jail inmates, by selected decedent characteristics, 2001�2013
mljsp0012stat06.csv	Appendix table 6. Illness mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2002�2013
mljsp0012stat07.csv	Appendix table 7. Cancer mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2002�2013
mljsp0012stat08.csv	Appendix table 8. Heart disease mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2002�2013
mljsp0012stat09.csv	Appendix table 9. Liver disease mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2002�2013
mljsp0012stat10.csv	Appendix table 10.Respiratory disease mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2002�2013
mljsp0012stat11.csv	Appendix table 11. Mortality rate for all other illnesses per 100,000 state prisoners, by selected decedent characteristics, 2002�2013
mljsp0012stat11.csv	Appendix table 12. Mortality rate for unnatural deaths per 100,000 state prisoners, by selected decedent characteristics, 2002�2013


 




