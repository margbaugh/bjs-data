Felony Defendants in Large Urban Counties, 2006	
	
This zip archive contains tables in individual  .csv spreadsheets from Felony Defendants in Large Urban Counties, 2006,  NCJ 228944.  The full report including text and graphics in pdf format are available from: http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2193           	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=27               	
	
fdluc06t01.csv	Table 1: Felony defendants, by most serious arrest charge, 2006
fdluc06t02.csv	Table 2: Age at arrest of felony defendants, by most serious arrest charge, 2006
fdluc06t03.csv	Table 3: Criminal justice status of felony defendants at time of arrest, by most serious arrest charge, 2006
fdluc06t04.csv	Table 4: Prior arrests and convictions of felony defendants at time of arrest, by most serious arrest charge, 2006
fdluc06t05.csv	Table 5: Felony defendants released before or detained until case disposition, by most serious arrest charge, 2006
fdluc06t06.csv	Table 6: Type of pretrial release or detention of felony defendants, by most serious arrest charge, 2006
fdluc06t07.csv	Table 7: Median and mean bail amounts set for felony defendants, by pretrial release/detention outcome and most serious arrest charge, 2006
fdluc06t08.csv	Table 8: Felony defendants released or detained prior to case disposition, by criminal history, 2006
fdluc06t09.csv	Table 9: Released felony defendants committing misconduct, by most serious arrest charge, 2006
fdluc06t10.csv	Table 10: Time from arrest to adjudication for felony defendants, by most serious arrest charge, 2006
fdluc06t11.csv	Table 11: Adjudication outcome for felony defendants, by most serious arrest charge, 2006
fdluc06t12.csv	Table 12: Most severe sentence received by convicted offenders, by most serious conviction offense, 2006
fdluc06t13.csv	Table 13: Length of sentence received by convicted offenders, by most serious conviction offense and sentence type, 2006
fdluc06t14.csv	Table 14: Conditions of probation sentence received most often by offenders, by most serious conviction offense, 2006
fdluc06t15.csv	Table 15: Most severe type of sentence received by offenders convicted of a felony, by prior conviction record, 2006
	
fdluc06f01.csv	Figure 1: Typical outcome of 100 felony defendants arraigned in state courts in the 75 most populous counties, May 2006
fdluc06f02.csv	Figure 2: Most serious arrest charge of felony defendants in the 75 largest counties, 1990 to 2006
fdluc06f03.csv	Figure 3: Age at arrest of felony defendants in the 75 largest counties, 1990 to 2006
fdluc06f04.csv	Figure 4: Type of pretrial release of felony defendants in the nation's 75 largest counties, 1990 to 2006 
fdluc06f05.csv	Figure 5: Pretrial release of felony defendants in the 75 most populous counties, 2006
fdluc06f06.csv	Figure 6: Probability of conviction for felony defendants in the 75 largest counties by most serious arrest charge, 2006
fdluc06f07.csv	Figure 7: Conviction charge probability for felony defendants in the 75 largest counties by most serious arrest charge, 2006
	
fdluc06tt01.csv	Text table 1: SCPS first-stage design
fdluc06tt02.csv	Text table 2: SCPS second-stage design
	
fdluc06at01.csv	Appendix table 1: Level of second most serious charge of felony defendants,  by most serious primary arrest charge, 2006
fdluc06at02.csv	Appendix table 2: Race and Hispanic origin of felony defendants, by most serious arrest charge, 2006 
fdluc06at03.csv	Appendix table 3: Sex of felony defendants, by most serious arrest charge, 2006 
fdluc06at04.csv	Appendix table 4: Number of prior arrest charges of felony defendants,  by most serious current arrest charge, 2006
fdluc06at05.csv	Appendix table 5: Number of prior convictions of felony defendants, by most serious current arrest charge, 2006
fdluc06at06.csv	Appendix table 6:  Number of prior felony convictions of felony defendants, by most serious current arrest charge, 2006
fdluc06at07.csv	Appendix table 7: Most serious prior conviction of felony defendants, by most serious current arrest charge, 2006 
fdluc06at08.csv	Appendix table 8: Types of pretrial release or detention of felony defendants, by most serious arrest charge, 2006 
fdluc06at09.csv	Appendix table 9: Time from conviction to sentencing for convicted offenders, by most serious conviction offense, 2006 
fdluc06at10.csv	Appendix table 10: Length of prison sentence for offenders convicted of a felony, by most serious conviction offense, 2006 
fdluc06at11.csv	Appendix table 11: Length of jail sentence received by convicted offenders, by most serious conviction offense, 2006 
fdluc06at12.csv	Appendix table 12: Length of probation sentence received by convicted offenders, by most serious conviction offense, 2006 
fdluc06at13.csv	Appendix table 13: Standard errors and confidence intervals for felony in defendants in the nations's 75 largest population counties, by most serious arrest charge, 2006 
fdluc06at14.csv	Appendix table 14: Standard errors and confidence intervals for felony defendants in the nation's 75 largest population counties, by selected characteristics, 2006 
fdluc06at15.csv	Appendix table 15: Population, sampling weights, and number of cases, by SCPS jurisdiction, 2006
fdluc06at16.csv	Appendix table 16: Most serious arrest charge of felony defendants, by SCPS jurisdiction, 2006 
fdluc06at17.csv	Appendix table 17: Sex and age of felony defendants, by SCPS jurisdiction, 2006 
fdluc06at18.csv	Appendix table 18: Race and Hispanic/Latino origin, by SCPS jurisdiction, 2006 
fdluc06at19.csv	Appendix table 19: Felony defendants released before or detained until case disposition, by SCPS jurisdiction, 2006 
fdluc06at20.csv	Appendix table 20: Failure-to-appear and re-arrest rates of defendants released prior to case disposition, by SCPS jurisdiction, 2006 
fdluc06at21.csv	Appendix table 21: Adjudication outcome for felony defendants, by SCPS jurisdiction, 2006 
fdluc06at22.csv	Appendix table 22: Most severe type of sentence for offenders convicted of a felony, by SCPS jurisdiction, 2006 
