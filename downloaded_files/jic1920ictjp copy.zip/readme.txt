Jails in Indian Country, 2019–2020 and the Impact of COVID-19 on the Tribal Jail Population  NCJ 300801		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Jails in Indian Country, 2019–2020 and the Impact of COVID-19 on the Tribal Jail Population  NCJ 300801.  		
The full report including text and graphics in pdf format is available from: 		
https://bjs.ojp.gov/library/publications/jails-indian-country-2019-2020-and-impact-covid-19-tribal-jail-population
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://bjs.ojp.gov/library/publications/list?series_filter=Jails%20in%20Indian%20Country		
		
Filenames		Table names	
jic1920ictjpt01.csv	Table 1. Inmates held, rated capacity, and percent of rated capacity occupied in Indian country jails in June, 2000, 2010, and 2015–2020	
jic1920ictjpt02.csv	Table 2. Number of inmates held in Indian country jails, by facility size, midyear 2019 to midyear 2020	
jic1920ictjpt03.csv	Table 3. Average daily population, admissions, and expected average length of stay in Indian country jails, by facility size, June 2019–June 2020	
jic1920ictjpt04.csv	Table 4. COVID-19 testing and positive cases among inmates in Indian country jails, by facility size, March 1–June 30, 2020	
jic1920ictjpt05.csv	Table 5. Admissions to and expedited releases from Indian county jails, by facility size, March 1–June 30, 2020	
jic1920ictjpt06.csv	Table 6. Capacity of Indian country jails, by facility size, midyear 2019 to midyear 2020	
jic1920ictjpt07.csv	Table 7. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2020	
jic1920ictjpt08.csv	Table 8. Inmates held in Indian country jails, by demographic and criminal justice characteristics, midyears 2000, 2010, 2015, and 2019–2020	
jic1920ictjpt09.csv	Table 9. Persons employed in Indian country jails, by job function, midyears 2010, 2015, and 2019–2020	
jic1920ictjpt10.csv	Table 10. COVID-19 positive cases among staff in Indian country jails, by facility size, March 1–June 30, 2020	
jic1920ictjpt11.csv	Table 11. Survey universe and response rates of Indian country jails, 2004 and 2007–2020	
		
			Figures	
jic1920ictjpf01.csv	Figure 1. Number of inmates held in Indian country jails, midyears 2000 and 2010–2020	
jic1920ictjpf02.csv	Figure 2. Number of inmates held in Indian country jails on the last weekday in June 2019 and the last weekday of each month from January to June 2020	
		
			Appendix tables	
jic1920ictjpat01.csv	Appendix table 1. Reported inmate characteristics for table 8: Inmates held in Indian country jails, by demographic and criminal justice characteristics, midyears 2000, 2010, 2015, and 2019–2020	
jic1920ictjpat02.csv	Appendix table 2. Imputation for inmate characteristics in table 8: Inmates held in Indian country jails, by demographic and criminal justice characteristics, midyears 2000, 2010, 2015, and 2019–2020	
jic1920ictjpat03.csv	Appendix table 3. Reported number of staff for table 9: Persons employed in Indian country jails, by job function, midyears 2010, 2015, and 2019–2020	
jic1920ictjpat04.csv	Appendix table 4. Imputation for staff in table 9: Persons employed in Indian country jails, by job function, midyears 2010, 2015, and 2019–2020	
		
		
		
