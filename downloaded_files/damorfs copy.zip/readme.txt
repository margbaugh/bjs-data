Data on Adjudication of Misdemeanor Offenses: Results from a Feasibility Study   NCJ 305157	
	
This zip archive contains tables in individual .csv spreadsheets for	
Data on Adjudication of Misdemeanor Offenses: Results from a Feasibility Study   NCJ 305157.	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/data-adjudication-misdemeanor-offenses-results-feasibility-study
	
	
Filenames	Table titles
damorfst01.csv	Table 1. Case-level misdemeanor data elements
damorfst02.csv	Table 2. Sources of case-level misdemeanor data, by city
damorfst03.csv	Table 3. Data element availability
damorfst04.csv	Table 4. Number of Courts Submitting Case Data Elements and Rates of Missingness for those Elements
damorfst05.csv	Table 5. Range of values for defendant sex and age
damorfst06.csv	Table 6. Comparison of defendant and regional race and Hispanic origin
damorfst07.csv	Table 7. Distribution of Charges in Misdemeanor Courts Across 16 Courts
damorfst08.csv	Table 8. Distribution of Dispositions in Misdemeanor Courts Across 8 Courts
	
	
