Sexual Victimization Reported by Youth in Juvenile Facilities, 2018   NCJ 253042		
		
This zip archive contains tables in individual .csv spreadsheets		
Sexual Victimization Reported by Youth in Juvenile Facilities, 2018   NCJ 253042		
The full electronic report is available at:		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6746	
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://www.bjs.gov/index.cfm?ty=pbse&sid=64	


Filename		Table name
svryjf18t01.csv		Table 1. Youth reporting sexual victimization in juvenile facilities, by type of incident, 2012 and 2018
svryjf18t02.csv		Table 2. Youth reporting sexual victimization in juvenile facilities, by type of incident and sex of youth, 2018
svryjf18t03.csv		Table 3. Juvenile facilities with high rates of sexual victimization, by consent type, 2018
svryjf18t04.csv		Table 4. Juvenile facilities with low rates of sexual victimization, 2018
svryjf18t05.csv		Table 5. Percent of youth in juvenile facilities reporting sexual victimization, by consent type and state, 2018


svryjf18f01.csv		Figure 1. Percent of youth in juvenile facilities reporting sexual victimization, 2012 and 2018
svryjf18f02.csv		Figure 2. Confidence intervals at 95% level for juvenile facilities with high rates of sexual victimization, by consent type, 2018


svryjf18at01.csv	Appendix table 1. National Survey of Youth in Custody sample and response information for adjudicated youth who participated in the survey, by facility, 2018
svryjf18at02.csv	Appendix table 2. Percent of youth reporting sexual victimization, by facility, 2018