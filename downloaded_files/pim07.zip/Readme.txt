Prison Inmates at Midyear 2007, NCJ 221944

This zip archive contains tables in individual .csv spreadsheets from Prison Inmates at Midyear 2007, NCJ 221944.  This full report including text and graphics in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/pim07.htm
    Tables

pim07t01.csv	Table 1. Prisoners under state or federal jurisdiction, by selected characteristics, December 31, 2000 and 2006, and June 30, 2007							
pim07t02.csv	Table 2. Prisoners under the jurisdiction of state or federal correctional authorities, by region and jurisdiction, December 31, 2000 and 2006, and June 30, 2007								
pim07t03.csv	Table 3. Number of prisoners under state or federal jurisdiction, by gender, December 31, 2000, June 30, 2006 and 2007								
pim07t04.csv	Table 4. Number of sentenced prisoners admitted and released from state or federal jurisdiction during the calendar year, 2000-2006											
pim07t05.csv	Table 5. Number of sentenced admissions into state prisons, by type of admission, 2000-2006			
pim07t06.csv	Table 6. Number of prisoners held in private facilities, June 30, 2000-2007								
pim07t07.csv	Table 7. Number of prisoners under jurisdiction in local jails, June 30, 2001-2007								
pim07t08.csv	Table 8. Prisoners and inmates held in custody in state or federal prisons or in local jails, December 31, 2000-2006 and June 30, 2007															
pim07t09.csv	Table 9. Estimated number of persons held in state or federal prisons or local jails, by gender, race, Hispanic origin, and age, June 30, 2007								
pim07t10.csv	Table 10.Estimated number of inmates held in state or federal prison or in local jails per 100,000 residents, by gender, race, Hispanic origin, and age, June 30, 2007								
pim07t11.csv	Table 11.Total change in number of persons held in custody in prison or local jail, June 30, 2000 to 2007					
pim07t12.csv	Table 12. Number of non-U.S. citizens held in state and federal prisons, June 30, 2000-2007					
pim07t13.csv	Table 13. Number of persons under age 18 held in state prisons, June 30, 2000-2007					

    Figures

pim07f01.csv	Figure 1. Percent change in number of prisoners under jurisdiction of state or federal correctional authorities during the first six months of 2006 and 2007.			
pim07f02.csv	Figure 2. Annual and 6-month percent change in number of prisoners under state and federal jurisdiction				
pim07f03.csv	Figure 3. Percent change in 6-month periods in number of prisoners under jurisdiction, by groupings of size of state			
pim07f04.csv	Figure 4. Number admissions and releases, and change in number of sentenced prisoners, 2000-2006			
pim07f05.csv	Figure 5. Percentage of all commitments to state prisons for parole violators														

    Appendix tables

pim07at01.csv	Appendix table 1. Growth in the number of prisoners under state or federal jurisdiction, December 31, 2005 and 2006, June 30, 2006 and 2007, by rank in 2000											
pim07at02.csv	Appendix table 2. Sentenced prisoners under the jurisdiction of state or federal correctional authorities,by region and jurisdiction, December 31, 2000 and 2006, and June 30, 2007 								
pim07at03.csv	Appendix table 3. Male prisoners under the jurisdiction of state or federal correctional authorities, by region and jurisdiction, December 31, 2000 and 2006, and June 30, 2007								
pim07at04.csv	Appendix table 4. Female prisoners under the jurisdiction of state or federal correctional authorities, by region and jurisdiction, December 31, 2000 and 2006, and June 30, 2007								
pim07at05.csv	Appendix table 5. Imprisonment rates of sentenced male and female prisoners under the jurisdiction of state or federal correctional authorities, by gender, region, and jurisdiction, June 30, 2007				
pim07at06.csv	Appendix table 6. Number of sentenced prisoners admitted and released from state or federal jurisdiction, by region and jurisdiction, 2000, 2005, and 2006											
pim07at07.csv	Appendix table 7. Number of sentenced prisoners admitted and released from state or federal jurisdiction, December 31, 2006							
pim07at08.csv	Appendix table 8. Number of state and federal prisoners under jurisdiction in private facilities, June 30, 2006 and 2007					
pim07at09.csv	Appendix table 9. Number of state and federal prisoners under jurisdiction  in local jails by region and jurisdiction on June 30, 2006 and 2007					
pim07at10.csv	Appendix table 10. Estimated percentage of persons held in state or federal prisons or local jails, by gender, race, Hispanic origin, and age, June 30, 2007																
pim07at11.csv	Appendix table 11. Reported number of non-U.S. citizens held in state or federal prisons, by region and jurisdiction, and gender, June 30, 2006 and June 30, 2007							
pim07at12.csv	Appendix table 12. Reported number of inmates under age 18 held in state prisons,by region and jurisdiction, and gender, June 30, 2006, and June 30, 2007							
		
