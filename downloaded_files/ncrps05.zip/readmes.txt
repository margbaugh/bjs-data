2005 National Corrections Reporting Program

This is one of a series of files from the National Corrections Reporting Program.  
All of the available files back to 1993 may be obtained from
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=36. 

Three groups of tables -- sentence length, time served and most serious offense of state
prisoners-- are archived for each year. 

In addition to the list of tables in this file, the tables in the related archives are listed below.*

This Zip archive, Sentence length of state prisoners, NCJ 229330
contains the following tables:

 File name      Contents

ncrp0506.csv   State prison admissions: sentence length by offense and admission type 
ncrp0509.csv   First releases from state prison: sentence length, time served, and percent of
sentence served in prison, by
offense
ncrp0510.csv   First releases from state prison: sentence length and time served in prison, by
offense, and sex
ncrp0511.csv   First releases from state prison: sentence length and time served in prison, by
offense, and race 
ncrp0515.csv   Successful first state parole discharges: sentence length and time served, by
offense
ncrp0516.csv   Unsuccessful first state parole discharges: sentence length and time served, by
offense

*Note:  Beginning in 1999, Table 7 (New court commitments to state prison:  
sentence length and minimum time to be served, by offense) 
was discontinued.  
               
Two related archives are also available.  The tables in these
archives are listed below.

Time served in state prison, 2005 (NCJ 229328)

ncrp0508.csv        State prison releases: time served in prison, by offense and release type
ncrp0509.csv        First releases from state prison: sentence length, time served, and percent of
sentence served, by offense
ncrp0510.csv        First releases from state prison: sentence length and time served in prison, by
offense and sex
ncrp0511.csv        First releases from state prison: sentence length and time served in prison, by
offense and race
ncrp0515.csv        Successful first state parole discharges: sentence length and time served, by
offense
ncrp0516.csv        Unsuccessful first state parole discharges: sentence length and time served, by
offense

Most serious offense of state prisoners (NCJ 229329)

ncrp0501.csv        State prison admissions: offense, by admission type
ncrp0502.csv        New court commitments to state prisons: offense, by age at admission
ncrp0503.csv        Parole violators returned to state prison: offense, by age at admission
ncrp0504.csv        New court commitments to state prisons: offense, by sex, race, and
Hispanic origin
ncrp0505.csv        Parole violators returned to state prison: offense, by sex, race, and
Hispanic origin
ncrp0512.csv        First entries to parole supervision from state prison: method of prison release,
by offense
ncrp0513.csv        First entries to parole supervision from state prison: offense, by sex, race,
and  Hispanic origin
ncrp0514.csv        State parole discharges: method of parole discharge, by offense
