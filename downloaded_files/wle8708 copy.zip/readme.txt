Women in Law Enforcement, 1987�2008 230521		
		
This zip archive contains tables in individual .csv spreadsheets for
Women in Law Enforcement, 1987�2008, NCJ 230521. The full report including 
text and graphics in .pdf format is available from: 
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2274.		
		
Filename		Tables 
wle8708t01.csv		Table 1. Percent and number of full-time sworn officers who are women, by federal law enforcement agencies employing 500 or more full-time officers, 1998 and 2008 
wle8708t02.csv		Table 2. Percent and number of full-time sworn officers who are women among  the largest police departments, 1997 and 2007
		
wle8708f01.csv		Figure 1. Percent of federal law enforcement officers who are women, by type and size of agency, 2008
wle8708f02.csv		Figure 2. Percent of federal law enforcement officers who are women, from 1998-2008*
wle8708f02.csv		Figure 3. Percent of full-time sworn law enforcement officers who are women among local police departments and sheriffs' offices, by size of agency, 2007
wle8708f02.csv		Figure 4. Percent of full-time sworn law enforcement officers who are women among local and state police departments, and sheriffs' offices , 1987-2007
