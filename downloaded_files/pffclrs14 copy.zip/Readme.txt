Publicly Funded Forensic Crime Laboratories: Resources and Services, 2014		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Publicly Funded Forensic Crime Laboratories: Resources and Services, 2014 - Statistical Tables, NCJ 250151 The full report including text		
and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=5827		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://bjs.gov/index.cfm?ty=pbse&sid=75		
		
Filename		Table title	
pffclrs14t01.csv		Table 1: Functions performed by publicly funded forensic crime labs, 2002, 2005, 2009, and 2014
pffclrs14t02.csv		Table 2: Functions performed by publicly funded forensic crime labs, by type of jurisdiction, 2014
pffclrs14t03.csv		Table 3: Percent of publicly funded forensic crime labs that examined  trace evidence, by type of examination, 2009 and 2014
pffclrs14t04.csv		Table 4: Requests for services received and completed by publicly funded forensic crime labs, by type of request, 2009 and 2014
pffclrs14t05.csv		Table 5: Percent of requests for services received by publicly funded forensic crime labs, by type of jurisdiction, 2014
pffclrs14t06.csv		Table 6: Requests for services backlogged in publicly funded forensic crime labs, by type of request, yearend 2009 and 2014
pffclrs14t07.csv		Table 7: Percent of publicly funded forensic crime labs that outsourced requests for services, by type of jurisdiction, 2002, 2005, 2009, and 2014
pffclrs14t08.csv		Table 8: Percent of publicly funded crime labs that outsourced requests for services, by type of service, 2014
pffclrs14t9.csv			able 9: Annual operating budget for publicly funded forensic crime labs, by type of jurisdiction and number of full-time employees, 2014
pffclrs14t10.csv		Table 10: Number of full-time employees in publicly funded forensic crime labs, by type of jurisdiction, 2002, 2005, 2009, and 2014
pffclrs14t11.csv		Table 11: Positions of full-time employees in publicly funded forensic crime labs, by type of jurisdiction, 2014
pffclrs14t12.csv		Table 12: Publicly funded forensic crime labs, by type of jurisdiction, 2014
		
Figures		
pffclrs14f01			Figure 01: Number of requests for services received by publicly funded forensic crime labs, by type of request, 2009 and 2014
		
Appendix tables		
pffclrs14at01.csv		Appendix Table 1: Standard errors for table 1: Functions performed by publicly funded forensic crime labs, 2002, 2005, 2009, and 2014
pffclrs14at02.csv		Appendix Table 2: Standard errors for table 2: Functions performed by publicly funded forensic crime labs, by type of jurisdiction, 2014
pffclrs14at03.csv		Appendix Table 3: Standard errors for table 3: Percent of publicly funded forensic crime labs that examined trace evidence, by type of examination, 2009 and 2014
pffclrs14at04.csv		Appendix Table 4: Standard errors for table 4:  Requests for services received and completed by publicly funded forensic crime labs, by type of request, 2009 and 2014
pffclrs14at05.csv		Appendix Table 5: Standard errors for table 5: Percent of requests for services received by publicly funded forensic crime labs, by type of jurisdiction, 2014
pffclrs14at06.csv		Appendix Table 6: Standard errors for table 6: Requests for services backlogged n publicly funded forensic crime labs, by type of request,  yearend 2009 and 2014
pffclrs14at07.csv		Appendix Table 7: Standard errors for table 7: Percent of publicly funded forensic crime labs outsourcing requests for services, by type of jurisdiction, 2002, 2005, 2009, and 2014
pffclrs14at08.csv		Appendix Table 8: Standard errors for table 8: Percent of publicly funded crime abs outsourcing requests for services, by type of service, 2014
pffclrs14at09.csv		Appendix Table 9: Standard errors for table 9: Annual operating budget for publicly funded forensic crime labs, by type of jurisdiction and number of full-time employees, 2014
pffclrs14at10.csv		Appendix Table 10: Standard errors for table 10: Number of employees in publicly funded forensic crime labs, by type of jurisdiction, 2002, 2005,  2009, and 2014
pffclrs14at11.csv		Appendix Table 11: Standard errors for table 11: Positions of full-time employees in publicly funded forensic crime labs, by type of jurisdiction, 2014
