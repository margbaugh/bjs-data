Suicide in Local Jails and State and Federal Prisons, 2000–2019 – Statistical Tables   NCJ 300731	
	
This zip archive contains tables in individual .csv spreadsheets	
from Suicide in Local Jails and State and Federal Prisons, 2000–2019 – Statistical Tables   NCJ 300731	
The full report including text and graphics in .pdf format is available at	
https://bjs.ojp.gov/library/publications/suicide-local-jails-and-state-and-federal-prisons-2000-2019-statistical-tables

This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to 
https://bjs.ojp.gov/library/publications/list?series_filter=Mortality%20in%20Local%20Jails%20and%20State%20Prisons
	
Filename		Table title
sljsfp0019stt01.csv	Table 1. Total deaths and number and rate of suicides in local jails and state and federal prisons, 2000–2019
sljsfp0019stt02.csv	Table 2. Aggregated number of suicides in local jails, by state and region, 2000–19
sljsfp0019stt03.csv	Table 3. Average rate of suicides per 100,000 inmates in local jails, by state and region, 2000–19
sljsfp0019stt04.csv	Table 4. Percent of suicides in local jails, by demographic characteristics of inmates, 2000–19
sljsfp0019stt05.csv	Table 5. Average rate of suicides per 100,000 inmates in local jails, by demographic characteristics of inmates, 2000–19
sljsfp0019stt06.csv	Table 6. Percent of suicides in local jails, by criminal justice characteristics of inmates, 2000–19
sljsfp0019stt07.csv	Table 7. Percent of suicides in local jails, by circumstances of death, 2000–19
sljsfp0019stt08.csv	Table 8. Percent of local jails, by number of suicides and facility characteristics, 2019
sljsfp0019stt09.csv	Table 9. Percent of local jail jurisdictions, by number of suicides and population characteristics, 2019
sljsfp0019stt10.csv	Table 10. Aggregated number of suicides in state and federal prisons, by state and region, 2001–19
sljsfp0019stt11.csv	Table 11. Average rate of suicides per 100,000 prisoners in state and federal prisons, by state and region, 2001–19
sljsfp0019stt12.csv	Table 12. Percent of suicides in state prisons, by demographic characteristics of prisoners, 2001–19
sljsfp0019stt13.csv	Table 13. Average rate of suicides per 100,000 prisoners in state prisons, by demographic characteristics of prisoners, 2001–19
sljsfp0019stt14.csv	Table 14. Percent of suicides in state prisons, by criminal justice characteristics of prisoners, 2001–19
sljsfp0019stt15.csv	Table 15. Percent of suicides in state prisons, by circumstances of death, 2001–19
sljsfp0019stt16.csv	Table 16. Percent of suicides in federal prisons, by demographic characteristics of prisoners, 2015–19
sljsfp0019stt17.csv	Table 17. Average rate of suicides per 100,000 prisoners in federal prisons, by demographic characteristics of prisoners, 2015–19
sljsfp0019stt18.csv	Table 18. Percent of suicides in federal prisons, by criminal justice characteristics of prisoners, 2015–19
sljsfp0019stt19.csv	Table 19. Percent of suicides in federal prisons, by circumstances of death, 2015–19
sljsfp0019stt20.csv	Table 20. Percent of state and federal prisons, by number of suicides and facility characteristics, 2019
sljsfp0019stt21.csv	Table 21. Percent of state and federal prisons, by number of suicides and population characteristics, 2019
	
			Figures
sljsfp0019stf01.csv	Figure 1. Number of suicides in local jails and state and federal prisons, 2000–2019
sljsfp0019stf02.csv	Figure 2. Rate of suicides per 100,000 inmates in local jails and 100,000 prisoners in state and federal prisons, 2000–2019
sljsfp0019stf03.csv	Figure 3. Percent of suicides in local jails, by time served between admission and death, 2000–04 and 2015–19
sljsfp0019stf04.csv	Figure 4. Percent of suicides in state and federal prisons, by time served between admission and death, 2001–04 and 2015–19

			Appendix table
sljsfp0019stat01.csv	Appendix table 1. Number of correctional facilities, by type and operator, 2019 
