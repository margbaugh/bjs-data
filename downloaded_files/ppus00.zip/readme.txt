Probation and Parole in the United States, 2000   NCJ  188208
 
This zip archive contains tables in individual .wk1 spreadsheets
from Probation and Parole in the United States, 2000   NCJ  188208.
The press release and supporting materials in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/ppus00.htm 
 
 
Filename          Table

pp0001.wk1        Table 1. Persons under adult correctional supervision, 1990-2000
pp0002.wk1        Table 2. Total under adult correctional supervision and number supervised per 100,000 adult residents, by jurisdiction, yearend 2000
pp0003.wk1        Table 3.  Adult on probation, 2000
pp0004.wk1        Table 4.  Adult on parole, 2000
pp0005.wk1        Table 5.  Characteristics of adults on probation, 1990-2000
pp0006.wk1        Table 6.  Characteristics of adults on parole, 1990-2000
