Sexual Victimization Reported by Former State Prisoners, 2008
  NCJ 237363								
								
This zip archive contains tables in individual .csv spreadsheets								
Sexual Victimization Reported by Former State Prisoners, 2008 NCJ 237363								
The full report including text and graphics in .pdf format are available from:								
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4312								
								
								
svrfsp08t01.csv		Table 1. Former state prisoners reporting sexual victimization during most recent period of incarceration, by type of victimization and facility						
svrfsp08t02.csv		Table 2. Former state prisoners reporting sexual victimization in a community-based correctional facility						
svrfsp08t03.csv		Table 3. Criminal history and supervision status of persons under active parole supervision, by sex of former inmate						
svrfsp08t04.csv		Table 4. Type of coercion and physical injury of former state prisoners who reported sexual victimization, by type of incident						
svrfsp08t05.csv		Table 5. Circumstances surrounding sexual victimization of former state prisoners, by type of incident						
svrfsp08t06.csv		Table 6. Former state prisoners reporting sexual victimization, by sex of inmate						
svrfsp08t07.csv		Table 7. Staff sexual misconduct and type of activity, by sex of victim and sex of staff						
svrfsp08t08.csv		Table 8. Prevalence of sexual victimization, by type of incident and former prisoner demographic characteristics						
svrfsp08t09.csv		Table 9. Prevalence of sexual victimization, by type of incident and former prisoner criminal justice status and history						
svrfsp08t10.csv		Table 10. Multivariate logistic regression models of sexual victimization, by type of incident, former prisoner demographic characteristics, and former prisoner criminal justice status and history						
svrfsp08t11.csv		Table 11. Prison facilities entered and prison placements, by former state prisoners						
svrfsp08t12.csv		Table 12. Sequence of reported sexual victimization in prison, by sex of victim and type of incident						
svrfsp08t13.csv		Table 13. Prevalence of sexual victimization during prison placement, by sex of inmate, type of incident, and facility-level characteristics						
svrfsp08t14.csv		Table 14. Prevalence of sexual victimization, comparing results from the National Former Prisoner Survey, 2008, and National Inmate Survey, 2008�09						
svrfsp08t15.csv		Table 15. Prevalence of sexual victimization among male and female placements, by type of incident and former prisoner characteristics						
svrfsp08t16.csv		Table 16. Final multivariate logistic regression models of sexual victimization among male and female placements, by type of incident and former prisoner and facility characteristics						
svrfsp08t17.csv		Table 17. Reporting of sexual victimization, by type of incident and persons to whom the incident was reported						
svrfsp08t18.csv		Table 18. Reasons for not reporting sexual victimization to facility staff, by type of victimization						
svrfsp08t19.csv		Table 19. Facility responses to the reporting of sexual victimization to staff, by type of incident						
svrfsp08t20.csv		Table 20. Post-release responses of victims to sexual victimization, by type of incident						
svrfsp08t21.csv		Table 21. HIV testing and results for former state prisoners, by type of victim						
svrfsp08t22.csv		Table 22. Current employment, housing, and living arrangements of former inmates under active parole supervision, by victimization status						
svrfsp08at01.csv	Appendix table 1. Standard errors for table 4: Type of coercion and physical injury of former state prisoners who reported sexual victimization, by type of incident						
svrfsp08at02.csv	Appendix Table 2. Former state prisoners reporting sexual victimization in a community-based correctional facility						
svrfsp08at03.csv	Appendix Table 3. Criminal history and supervision status of persons under active parole supervision, by sex of former inmate						
svrfsp08at04.csv	Appendix Table 4. Type of coercion and physical injury of former state prisoners who reported sexual victimization, by type of incident						
svrfsp08at05.csv	Appendix Table 5. Circumstances surrounding sexual victimization of former state prisoners, by type of incident						
svrfsp08at06.csv	Appendix Table 6. Former state prisoners reporting sexual victimization, by sex of inmate						
svrfsp08at07.csv	Appendix Table 7. Staff sexual misconduct and type of activity, by sex of victim and sex of staff						
svrfsp08at08.csv	Appendix Table 8. Prevalence of sexual victimization, by type of incident and former prisoner demographic characteristics						
svrfsp08at09.csv	Appendix Table 9. Prevalence of sexual victimization, by type of incident and former prisoner criminal justice status and history						
svrfsp08at10.csv	Appendix Table 10. Multivariate logistic regression models of sexual victimization, by type of incident, former prisoner demographic characteristics, and former prisoner criminal justice status and history						
svrfsp08at11.csv	Appendix Table 11. Prison facilities entered and prison placements, by former state prisoners						
svrfsp08at12.csv	Appendix Table 12. Sequence of reported sexual victimization in prison, by sex of victim and type of incident						
svrfsp08at13.csv	Appendix Table 13. Prevalence of sexual victimization during prison placement, by sex of inmate, type of incident, and facility-level characteristics						
svrfsp08at14.csv	Appendix Table 14. Prevalence of sexual victimization, comparing results from the National Former Prisoner Survey, 2008, and National Inmate Survey, 2008�09						
svrfsp08at15.csv	Appendix Table 15. Prevalence of sexual victimization among male and female placements, by type of incident and former prisoner characteristics						
svrfsp08at16.csv	Appendix Table 16. Final multivariate logistic regression models of sexual victimization among male and female placements, by type of incident and former prisoner and facility characteristics						
svrfsp08at17.csv	Appendix Table 17. Reporting of sexual victimization, by type of incident and persons to whom the incident was reported						
svrfsp08at18.csv	Appendix Table 18. Reasons for not reporting sexual victimization to facility staff, by type of victimization						
svrfsp08at19.csv	Appendix Table 19. Facility responses to the reporting of sexual victimization to staff, by type of incident						
svrfsp08at20.csv	Appendix Table 20. Post-release responses of victims to sexual victimization, by type of incident						
svrfsp08at21.csv	Appendix Table 21. HIV testing and results for former state prisoners, by type of victim						
svrfsp08at22.csv	Appendix Table 22. Current employment, housing, and living arrangements of former inmates under active parole supervision, by victimization status						
