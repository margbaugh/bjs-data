Human Trafficking Incidents Reported by Law Enforcement, 2022 – Statistical Tables   NCJ 309499
																			
This zip archive contains tables in individual .csv spreadsheets for																			
Human Trafficking Incidents Reported by Law Enforcement, 2022 – Statistical Tables   NCJ 309499
The full report including text and graphics in pdf format is available from:
https://bjs.ojp.gov/library/publications/human-trafficking-incidents-reported-law-enforcement-2022-statistical-tables																			
Filenames			Table names																		
htirle22stt01.csv		Table 1. Percent of human trafficking victimizations, by victim sex and age, 2022
htirle22stt02.csv		Table 2. Percent of human trafficking victimizations, by victim race, 2022
																			
				Figures																		
htirle22stf01.csv		Figure 1. Percent of human trafficking incidents and victimizations, by trafficking type, 2022
htirle22stf02.csv		Figure 2. Number of human trafficking incidents and victimizations, 2022
htirle22stf03.csv		Figure 3. Percent of human trafficking victimizations, by victim sex, 2022
htirle22stf04.csv		Figure 4. Percent of human trafficking victimizations, by victim sex and relationship of alleged offender to victim, 2022
htirle22stf05.csv		Figure 5. Percent of human trafficking incidents, by number of victims, 2022
htirle22stf06.csv		Figure 6. Percent of human trafficking incidents, by number of offenders, 2022
htirle22stf07.csv		Figure 7. Percent of human trafficking incidents, by incident location, 2022
htirle22stf08.csv		Figure 8. Percent of human trafficking incidents, by weapon type, 2022
htirle22stf09.csv		Figure 9. Percent of human trafficking incidents, by clearance type, 2022
																			
				Appendix tables																		
htirle22stat01.csv	Appendix table 1. Estimates and confidence intervals for figure 1: Percent of human trafficking incidents and victimizations, by trafficking type, 2022
htirle22stat02.csv	Appendix table 2. Estimates and confidence intervals for figure 2: Number of human trafficking incidents and victimizations, 2022
htirle22stat03.csv	Appendix table 3. Estimates and confidence intervals for figure 3: Percent of human trafficking victimizations, by victim sex, 2022
htirle22stat04.csv	Appendix table 4. Confidence intervals for table 1: Percent of human trafficking victimizations, by victim sex and age, 2022
htirle22stat05.csv	Appendix table 5. Confidence intervals for table 2: Percent of human trafficking victimizations, by victim race, 2022
htirle22stat06.csv	Appendix table 6. Estimates and confidence intervals for figure 4: Percent of human trafficking victimizations, by victim sex and relationship of alleged offender to victim, 2022
htirle22stat07.csv	Appendix table 7. Estimates and confidence intervals for figure 5: Percent of human trafficking incidents, by number of victims, 2022
htirle22stat08.csv	Appendix table 8. Estimates and confidence intervals for figure 6: Percent of human trafficking incidents, by number of offenders, 2022
htirle22stat09.csv	Appendix table 9. Estimates and confidence intervals for figure 7: Percent of human trafficking incidents, by incident location, 2022
htirle22stat10.csv	Appendix table 10. Estimates and confidence intervals for figure 8: Percent of human trafficking incidents, by weapon type, 2022
htirle22stat11.csv	Appendix table 11. Estimates and confidence intervals for figure 9: Percent of human trafficking incidents, by clearance type, 2022
