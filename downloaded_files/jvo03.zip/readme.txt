Juvenile Victimization and Offending, 1993-2003   NCJ 209468			

This zip archive contains tables in individual .csv spreadsheets from Juvenile Victimization and Offending, 1993-2003  NCJ 209468			
The full report including text and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/jvo03.htm			
	
    Highlights		
jvo03h.csv		Highlights	The number of victimizations by violent crime per 1,000 teenagers dropped from about 130 victimizations in 1993 to about 60 in 2003

	Tables title		
jvo0301.csv		Table 1.	Average annual rates of violent victimization, by type of crime and age of victims, 1993-2003
jvo0302.csv		Table 2.	Average annual rates of violent victimization, by victims' characteristics and victims' age, 1993-2003
jvo0303.csv		Table 3.	Violent crime by age of victim, 1993-2003
jvo0304.csv		Table 4.	Robbery, by age of victim, 1993-2003
jvo0305.csv		Table 5.	Aggravated assault, by age of victim, 1993-2003
jvo0306.csv		Table 6.	Simple assault, by age of victim, 1993-2003
jvo0307.csv		Table 7.	Rape/sexual assault, by age of victim, 1993-2003
jvo0308.csv		Table 8.	Violent victimization, by victims' gender and age, 1993-2003
jvo0309.csv		Table 9.	Violent victimization, by victims' race and age, 1993-2003
jvo0310.csv		Table 10.	Violent victimization, by where victims lived, 1993-2003
jvo0311.csv		Table 11.	Violent crimes involving weapons, by age of victim, 1993-2003
jvo0312.csv		Table 12.	Rates of violent victimization involving weapons, by age of victim, 1993-2003
jvo0313.csv		Table 13.	Injuries from violent crime, by age of victim, 1993-2003
jvo0314.csv		Table 14.	Location of violent crime, by age of victim, 1993-2003
jvo0315.csv		Table 15.	Time of violent crime, by age of victim, 1993-2003
jvo0316.csv		Table 16.	Reporting violent crime to the police, by age of victim, 1993-2003
jvo0317.csv		Table 17.	Reasons for not reporting violent crime to the police, by age of victim, 1993-2003
jvo0318.csv		Table 18.	Who reported serious violent crime to police, by age of victim, 1993-2003
jvo0319.csv		Table 19.	Victim-offender relationship for violent crimes committed by juveniles, 1993-2003
jvo0320.csv		Table 20.	Intimate partner violence, by age of victim, 1993-2003 
jvo0321.csv		Table 21.	Age of violent offenders, by age of victim, 1993-2003 
jvo0322.csv		Table 22.	Homicide victimization rates per 100,000, by age, 1993-2003
jvo0323.csv		Table 23.	Homicide offending rates per 100,000, by age, 1993-2003'
jvo0324.csv		Table 24.	Homicide rates per 100,000 for juveniles under 18, victims and offenders by gender, 1993-2003
jvo0325.csv		Table 25.	Homicide rates per 100,000 for juveniles under 18, victims and offenders by race, 1993-2003
jvo0326.csv		Table 26	Relationship of homicide victim to offender, by age of victim, 1993-2003
jvo0327.csv		Table 27.	Weapon use in homicides, by age of victim, 1993-2003

	Figure Titles		
jvo03f1.csv		Figure 1.	Percent of population and victims
jvo03f2.csv		Figure 2.	Rate of robbery victimization per 1,000 persons
jvo03f3.csv		Figure 3.	Rate of aggravated assault victimization per 1,000 persons
jvo03f4.csv		Figure 4.	Rate of simple assault victimization per 1,000 persons
jvo03f5.csv		Figure 5.	Rate of rape/sexual assault victimization per 1,000 persons
jvo03f6.csv		Figure 6.	Rate of violent victimization per 1,000 males
jvo03f7.csv		Figure 7.	Rate of violent victimization per 1,000 females
jvo03f8.csv		Figure 8.	Time of occurrence of serious violent victimizations (adjusted and unadjusted for hours of exposure), by victim age, 1999-2003
jvo03f9.csv		Figure 9.	Percent of nonfatal violent victimizations, annual average, 1993-2003
jvo03f10.csv		Figure 10.	Average annual percent of perceived gang involvement of offender
jvo03f11.csv		Figure 11.	Rate of homicide victimization per 100,000 persons
jvo03f12.csv		Figure 12.	Rate of homicide offending per 100,000 persons

	Text Tables titles		
jvo03tt1.csv		Text table 1.	Age of victim 
jvo03tt2.csv		Text table 2.	Age of offender(s) 
jvo03tt3.csv		Text table 3.	Gender of juvenile offender(s) 
jvo03tt4.csv		Text table 4.	Race of juvenile offender(s)
jvo03tt5.csv		Text table 5.	Was the offender using drugs or alcohol?
