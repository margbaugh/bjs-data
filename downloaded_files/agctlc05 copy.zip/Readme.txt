Appeals from general civil trials in 46 large counties, 2001 - 2005          


This zip archive contains tables in individual  .csv spreadsheets from 
Appeals from general civil trials in 46 large counties, 2001 - 2005,  NCJ 212979.  
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/agctlc05.htm      

Tables
agctlc05t01.csv		Table 1: General civil cases appealed from trial court, by type of case in 46 large counties, 2001 - 2005
agctlc05t02.csv		Table 2. Parties filing notice of appeal from trial court, by type of case in 46 large counties,  2001 - 2005
agctlc05t03.csv		Table 3. Civil cases appealed from trial court, by party filing notice of appeal, and trial court outcome in 46 large counties, 2001 - 2005
agctlc05t04.csv		Table 4. Civil cases appealed from trial court, by types of plaintiffs and defendants in 46 large counties, 2001-2005
agctlc05t05.csv		Table 5. Disposition of civil cases appealed from trial court by appealing party and civil case category in 46 large counties, 2001 - 2005
agctlc05t06.csv		Table 6. Review of trial court outcomes on appeal, by party filing notice of appeal and trial court outcome in 46 large counties, 2001 - 2005
agctlc05t07.csv		Table 7. Reversals in civil cases appealed from trial court, by party filing notice of appeal and trial court outcome in 46 large counties, 2001 - 2005
agctlc05t08.csv		Table 8: Cases reversed on appeal and remanded to trial court in 46 large counties, 2001 - 2005
agctlc05t09.csv		Table 9. Disposition of civil cases appealed from trial court by damages awarded at trial in 46 large counties, 2001 - 2005
agctlc05t10.csv		Table 10. Type of decision in civil appeals decided on the merits in 46 large counties, 2001 - 2005
agctlc05t11.csv		Table 11. Published opinions in civil appeals decided on the merits, by type of decision in 46 large counties, 2001 - 2005
agctlc05t12.csv		Table 12. Number and percent of appeals referred to and resolved by alternative dispute resolution programs, by party filing notice of appeal, 2001 - 2005
agctlc05t13.csv		Table 13. Time from filing to disposition of civil appeals in 46 large counties, 2001 - 2005
agctlc05t14.csv		Table 14. Number of cases appealed from the intermediate appellate courts (IAC) to the courts of last resort (COLR) in 46 large counties, 2001 - 2005

Figures
agctlc05f01.csv		Figure 1. Percent of published opinions with a dissent in civil cases appealed in 46 large counties, 2001-2005

Highlight
agctlc05hi01.csv	Highlights. Flow of civil trials concluded in 2001 that were appealed to an intermediate appellate court or court of last resort in 46 large counties from 2001 - 2005

Appendix Tables
agctlc05ata.csv		Appendix A. Primary basis of appeal for civil cases appealed from trial court, in 46 large counties, 2001 - 2005
agctlc05atb.csv		Appendix B. Selected characteristics of appellate courts participating in the 2001 Supplemental Survey of Civil Appeals
agctlc05atc.csv		Appendix C. Number of issues addressed in civil appeals that produced a written opinion, unsigned per-curiam opinion, or published order in intermediate appellate courts, 2001 - 2005
agctlc05atd.csv		Appendix D. Types of trial court errors alleged in civil appeals that produced a written opinion, unsigned per-curiam opinion, or published order in intermediate appellate courts, 2001 - 2005
agctlc05ate.csv		Appendix E. Standards of review utilized to address legal issues raised in civil appeals that produced a written opinion, unsigned per-curiam opinion, or published order in intermediate appellate courts, 2001 - 2005
agctlc05atf.csv		Appendix F. Resolution of legal issues raised in civil appeals that produced a written opinion, unsigned per-curiam opinion, or published order in intermeidate appellate courts, 2001 - 2005
