Contents of zip archive cv97.zip

Tables from Criminal Victimization 1997:
Changes 1996-97 with Trends 1993-97

cv9701.csv        Table 1.  Criminal victimization, 1996-97
cv9702.csv        Table 2.  Rates of violent crime and personal theft, 
                            by sex, age, race, and Hispanic origin, 1997
cv9703.csv        Table 3.  Rates of violent crime and personal theft, 
                            by household income, marital status, region, and location
cv9704.csv        Table 4.  Household property crime victimization, by race, 
                            Hispanic origin, household income, region, and home ownership 
                            of households victimized, 1997
cv9705.csv        Table 5.  Rates of criminal victimization and percent change, 1993-97
cv97mur.csv       Murder and nonnegligent manslaughter, by characteristics of victims 
                            and location, 1993-97
 
 
 
