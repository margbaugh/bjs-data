Probation and Parole in the United States 2014 NCJ 249047	
	
"This zip archive contains tables in individual .csv spreadsheets from Probation and Parole in the United States, 2014 NCJ 249047" The full report including text"			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5415
	
	
This report is one in a series. More recent editions may be available. 	
"To view a list of all in the series, go to: "	
http://www.bjs.gov/index.cfm?ty=pbse&sid=42	
	
Tables	
ppus14at01.csv	"Appendix table 1. Estimates for figure 2: probation entries and exits, 2000�2014"
ppus14at02.csv	"Appendix table 2. Estimates for figure 4: parole entries and exits, 2000�2014"
ppus14at03.csv	"Appendix table 3. Adults under community supervision, 2014"
ppus14at04.csv	"Appendix table 4. Adults on probation, 2014"
ppus14at05.csv	"Appendix table 5. Adults on parole, 2014"
ppus14at06.csv	"Appendix table 6. Adults entering parole, by type of entry, 2014"
ppus14at07.csv	"Appendix table 7. Adults exiting parole, by type of exit, 2014"
ppus14t01.csv	"Table 1. U.S. adult residents on community supervision, probation, and parole, 2000�2014"
ppus14t02.csv	"Table 2. U.S. adult residents on community supervision, probation, and parole, 2000, 2005�2014"
ppus14t03.csv	"Table 3. Rate of probation exits, by type of exit, 2008�2014"
ppus14t04.csv	"Table 4. Characteristics of adults on probation, 2000, 2013, and 2014"
ppus14t05.csv	"Table 5. Rate of parole exits, by type of exit, 2008�2014"
ppus14t06.csv	"Table 6. Characteristics of adults on parole, 2000, 2013, and 2014"
ppus14t07.csv	"Table 7. Parolees on probation excluded from the January 1 and December 31 community supervision populations, 2008�2014"
ppus14t08.csv	"Table 8. Change in the number of adults on probation based on reporting changes, 2000�2014"
ppus14t09.csv	"Table 9. Change in the number of adults on parole based on reporting changes, 2000�2014"
	
Figures	
ppus14f01.csv	"Figure 1. Adults under community supervision at yearend, 2000�2014"
ppus14f02.csv	"Figure 2. Probation entries and exits, 2000�2014"
ppus14f03.csv	"Figure 3. Percent of the at-risk probation population incarcerated, 2000�2014"
ppus14f04.csv	"Figure 4. Parole entries and exits, 2000�2014"
ppus14f05.csv	"Figure 5. Percent of the at-risk parole population returned to incarceration, 2000�2014"
