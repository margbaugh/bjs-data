Tribal Crime Data Collection Activities, 2024  NCJ 309132																							
																							
This .zip archive contains tables in individual  .csv spreadsheets																							
Tribal Crime Data Collection Activities, 2024  NCJ 309132. The full report including text																							
and graphics in .pdf format is available from: https://bjs.ojp.gov/library/publications/tribal-crime-data-collection-activities-2024																							
																							
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to:																							
https://bjs.ojp.gov/library/publications/list?series_filter=Tribal%20Crime%20Data%20Collection%20Activities																							
																							
Filenames	Table titles																						
tcdca24t01.csv	Table 1. 2024 Census of Tribal Law Enforcement Agencies and Census of Tribal Court Systems project schedule, 2024–2025
tcdca24t02.csv	Table 2. BJS tribal outreach and engagement on the Census of Tribal Law Enforcement Agencies and Census of Tribal Court Systems, by location and date, 2023–2024

		Figures
tcdca24f01.csv	Figure 1. BJS tribal-centered approach for the implementation and development of the tribal crime data collection system, 2023–2024
												
		Appendix tables																						
tcdca24at01.csv	Appendix Table 1. Tribal Leaders Listening Session participating tribes, by state, February 7, 2024							
tcdca24at02.csv	Appendix Table 2. Tribal Law Enforcement Listening Session participating tribal agencies, by participant job title and state, February 12, 2024												
tcdca24at03.csv	Appendix Table 3. Tribal Courts System Listening Session participating tribes, by participant job title and state, February 27, 2024