Campus Law Enforcement, 2011-12 NCJ 248028		
		
This zip archive contains tables in individual .csv spreadsheets		
from Campus Law Enforcement, 2011-12 NCJ 248028, electronic only. 		
The full electronic report is available at: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5216	
		
These statistical tables are in a series.  More recent editions		
may be available.  To view a list of all in the series go to:	http://www.bjs.gov/index.cfm?ty=pbse&sid=79	
		
		
Figures:		
cle1112f01.csv		Figure 1. Use of sworn and armed law enforcement officers on 4-year campuses with 2,500 or more students, 2011�12
cle1112f02.csv		Figure 2. Agencies included in the memorandums of understanding or mutual aid agreements with campus law enforcement agencies serving 2,500 or more students, by type of 4-year campus, 2011�12
cle1112f03.csv		Figure 3. Community policing activities of campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2004�05 and 2011�12
cle1112f04.csv		Figure 4. Functions performed by student patrols in campus law enforcement agencies, on 4-year campuses with 5,000 or more students, 2011�12 
cle1112f05.csv		Figure 5. Nonlethal weapons authorized for use by sworn and nonsworn officers in campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2011�12 
cle1112f06.csv		Figure 6. Selected functions of computers in campus law enforcement agencies on 4-year campuses with 5,000 or more students, 2011�12 
cle1112f07.csv		Figure 7. Serious violent crimes per 100,000 students known to campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2004 and 2011
cle1112f08.csv		Figure 8. Groups that campus law enforcement agencies met with regularly to discuss crime-related problems on 4-year campuses with 2,500 or more students, 2004�05 and 2011�12 
cle1112f09.csv		Figure 9. Campus law enforcement agencies with designated personnel to address special problems or tasks on 4-year schools with 5,000 or more students, 2004�05 and 2011�12 
cle1112f10.csv		Figure 10. Emergency preparedness activities of campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2004�05 and 2011�12
cle1112f11.csv		Figure 11. Percent of students enrolled on campuses using mass notification methods on 4-year campuses with 5,000 or more students, 2011�12
cle1112f12.csv		Figure 12. Methods used by campus law enforcement agencies to screen applicants for entry-level officer positions on 4-year campuses with 2,500 or more students, 2011�12
cle1112f13.csv		Figure 13. Average training requirements for entry-level officers in campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2011�12
cle1112f14.csv		Figure 14. Special pay and benefits for sworn and nonsworn officers in campus law enforcement agencies on 4-year campuses with 5,000 or more students, 2011�12
cle1112f15.csv		Figure 15. Female and minority representation among sworn campus law enforcement personnel on 4-year campuses with 2,500 or more students, 2011�12 and 2004�05
		
Tables:		
cle1112t01.csv		Table 1. Officers providing law enforcement services, by type and size of 4-year campus, 2011�12
cle1112t02.csv		Table 2. Use of sworn and armed law enforcement officers, by type and size of 4-year campus, 2011�12
cle1112t03.csv		Table 3. Average number of full-time campus law enforcement employees per 1,000 students, by type and size of 4-year campus, 2011�12
cle1112t04.csv		Table 4. Extended arrest jurisdiction of sworn officers in campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t05.csv		Table 5. Extended patrol jurisdiction of officers in campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t06.csv		Table 6. Community policing activities of campus law enforcement agencies serving 5,000 or more students, by type of 4-year campus, 2011�12
cle1112t07.csv		Table 7. Use of sworn and nonsworn uniformed officers by campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2011�12
cle1112t08.csv		Table 8. Operation of safety escort services by campus law enforcement agencies serving 5,000 or more students, by type of 4-year campus, 2011�12
cle1112t09.csv		Table 9. Emergency telephone systems of campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t10.csv		Table 10. Enhanced features of emergency phone systems used by campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t11.csv		Table 11. Weapons authorized for use by campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t12.csv		Table 12. Use of electronic devices by patrol officers in campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t13.csv		Table 13. Functions performed by sworn and nonsworn campus law enforcement agencies serving 4-year campuses with 2,500 or more students, 2011�12
cle1112t14.csv		Table 14. Groups that campus law enforcement agencies met with regularly to discuss crime-related problems on 4-year campuses with 2,500 or more students, 2011�12
cle1112t15.csv		Table 15. Average number of serious crimes known to campus law enforcement agencies, by type and size of 4-year campus, 2011
cle1112t16.csv		Table 16. Use of designated personnel by campus law enforcement agencies to address crime and safety issues on 4-year campuses with 5,000 or more students, 2011�12
cle1112t17.csv		Table 17. Emergency preparedness activities of campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2011�12
cle1112t18.csv		Table 18. Interoperability of radio systems used by campus law enforcement agencies, by type and size of 4-year campus, 2011�12
cle1112t19.csv		Table 19. Use of mass notification systems on 4-year campuses with 5,000 or more students, 2011�12
cle1112t20.csv		Table 20. Minimum education levels required for entry-level officers in campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2011�12
cle1112t21.csv		Table 21. Average base starting salary for selected positions in campus law enforcement agencies, 2011�12
		
Appendix tables:		
cle1112at01.csv		Appendix table 1. Enrollment at 4-year campuses in the United States, Fall 2011
cle1112at02.csv		Appendix table 2. Four-year campuses with 2,500 or more students that operated their own campus law enforcement agency, 2011�12
cle1112at03.csv		Appendix table 3. Number of persons employed by campus law enforcement agencies at 4-year campuses with 2,500 or more students, 2011�12 
cle1112at04.csv		Appendix table 4. 25 largest campus law enforcement agencies, by number of full-time employees, 2011�12
cle1112at05.csv		Appendix table 5. 25 largest campus law enforcement agencies, by number of full-time employees, 2011�12
cle1112at06.csv		Appendix table 6. Campus law enforcement agencies serving the 100 largest 4-year campuses in the United States, 2011�12
cle1112at07.csv		Appendix table 7. Additional types of weapons authorized for use by campus law enforcement agencies on 4-year campuses with 2,500 or more students, 2011�12
cle1112at08.csv		Appendix table 8. Vehicles used by campus law enforcement agencies serving 4-year campuses with 5,000 or more students, 2011�12
cle1112at09.csv		Appendix table 9. Response rates for the 2011�12 BJS Survey of Campus Law Enforcement Agencies
cle1112at10.csv		Appendix table 10. Questionnaire items included in the 2011-12 BJS Survey of Campus Law Enforcement Agencies, 4-year campuses with 2,500 or more students
