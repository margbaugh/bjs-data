Capital Punishment, 2021 – Statistical Tables   NCJ 305534	
	
This zip archive contains tables in individual .csv spreadsheets	
from Capital Punishment, 2021 – Statistical Tables   NCJ 305534.	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/capital-punishment-2021-statistical-tables	
	
These statistical tables are in a series.  More recent editions	
may be available. To view a list of all reports in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Capital%20Punishment	
	
Filenames	Table names
cp21stt01.csv	Table 1. Status of the death penalty, December 31, 2021
cp21stt02.csv	Table 2. Capital offenses, by state, 2021
cp21stt03.csv	Table 3. Federal capital offenses, 2021
cp21stt04.csv	Table 4. Authorized method of execution, by state, 2021
cp21stt05.csv	Table 5. Prisoners under sentence of death, by region, jurisdiction, and race, 2020 and 2021
cp21stt06.csv	Table 6. Demographic characteristics of prisoners under sentence of death, 2021
cp21stt07.csv	Table 7. Female prisoners under sentence of death, by region, jurisdiction, and race, 2020 and 2021
cp21stt08.csv	Table 8. Hispanic prisoners under sentence of death, by region and jurisdiction, 2020 and 2021
cp21stt09.csv	Table 9. Criminal history of prisoners under sentence of death, by race or ethnicity, 2021
cp21stt10.csv	Table 10. Prisoners under sentence of death on December 31, 2021, by year of sentencing and jurisdiction
cp21stt11.csv	Table 11. Prisoners removed from under sentence of death, by region, jurisdiction, and method of removal, 2021
cp21stt12.csv	Table 12. Average elapsed time between sentencing and execution, 1977–2021
cp21stt13.csv	Table 13.Number of executions, by jurisdiction, 1930–2021 and 1977–2021
	
		Figures
cp21stf01.csv	Figure 1. Number of prisoners under sentence of death, 1953–2021
cp21stf02.csv	Figure 2. Admissions to and removals from under sentence of death, 1973–2021
cp21stf03.csv	Figure 3. Number of prisoners under sentence of death, by race, 1968–2021
cp21stf04.csv	Figure 4. Number of prisoners executed in the United States, 1930–2021
cp21stf05.csv	Figure 5. Advance count of executions, January 1, 2022–December 31, 2022
	
		Appendix tables
cp21stat01.csv	Appendix table 1. Number of prisoners executed, by race or ethnicity, 1977–2021
cp21stat02.csv	Appendix table 2. Number of executions, by method and jurisdiction, 1977–2021
cp21stat03.csv	Appendix table 3. Counts for figure 1: Number of prisoners under sentence of death, 1953–2021
cp21stat04.csv	Appendix table 4. Counts for figure 2: Admissions to and removals from under sentence of death, 1973–2021
cp21stat05.csv	Appendix table 5. Counts for figure 3: Number of prisoners under sentence of death, by race, 1968–2021
cp21stat06.csv	Appendix table 6. Counts for figure 4: Number of prisoners executed in the United States, 1930–2021