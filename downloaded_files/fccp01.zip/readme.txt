Federal Criminal Case Processing, 2001:  With trends 1982-2001, Reconciled Data  NCJ  197104
																
																	
This zip archive contains tables and figures in individual .wk1 spreadsheets from Federal Criminal Case Processing, 2001:  With trends 1982-2001, Reconciled Data  NCJ  197104.  The full report including tables and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/fccp01.htm
													
Filename:  fcc01fcr.wk1
Cover figure on trends of Federal criminal case processing, 1994-2001

Filename:  fcc01fh1.wk1
Data for Figure H.1.  Number of suspects in criminal matters investigated 
by U.S. attorneys, October 1, 2000 - September 30, 2001

Filename:  fcc01fh2.wk1
Figure H.2.  Number of offenders under Federal correctional supervision, 
September 30, 2001

Filename:  fccp01t1.wk1
Table 1.  Arrests for Federal offenses, by offense, October 1, 2000 - 
September 30, 2001

Filename:  fccp01t2.wk1
Table 2.  Suspects in criminal matters investigated by U.S. attorneys, by 
offense, October 1, 2000 - September 30, 2001

Filename:  fccp00f1.wk1
Data for FCCP figure 1.  Number of suspects in criminal matters investigated 
by U.S. attorneys, 1982-2001

Filename:  fccp01t3.wk1
Table 3.  Disposition of suspects in matters concluded by U.S. attorneys, 
by offense, October 1, 2000 - September 30, 2001

Filename:  fccp01t4.wk1
Table 4.  Defendants in cases proceeded against in U.S. district courts, by 
offense, October 1, 2000 - September 30, 2001

Filename:  fccp01t5.wk1
Table 5.  Disposition of defendants in cases terminating in U.S. district 
court, by offense, October 1, 2000 - September 30, 2001

Filename:  fccp01f2.wk1
Data for FCCP figure 2.  Number of defendants in criminal cases terminated 
in U.S. district court, by category of offense, 1982-2001

Filename:  fccp01t6.wk1
Table 6. Sanctions imposed on offenders convicted and sentenced in U.S. 
district courts, by offense, October 1, 2000 - September 30, 2001

Filename:  fccp01f3.wk1
Data for FCCP Figure 3.  Defendants convicted in U.S. district court:  
Percentage sentenced to prison, by category of offense, 1982-2001

Filename:  fccp01t7.wk1
Table 7.  Criminal appeals filed, by type of criminal case and offense, 
October 1, 2000 - September 30, 2001

Filename:  fccp01t8.wk1
Table 8. Offenders under Federal supervision, by offense, October 1, 2000 - 
September 30, 2001

Filename:  fccp01f4.wk1
Data for FCCP Figure 4.  Number of offenders under Federal supervision, by 
type of supervision, 1987-2001

Filename:  fccp01t9.wk1
Table 9.  Federal prison admissions and releases,  by offense, 
October 1, 2000 - September 30, 2001

Filename:  fccp01f5.wk1
Data for FCCP Figure 5.  U.S. district court commitments and first releases 
from Federal prison, by expected or actual time in prison, 1986-2001

Filename:  fcc01a01.wk1
Table A,1.  Arrests for Federal offenses, by offense, 1994-2001

Filename:  fcc01a02.wk1
Table A.2.  Suspects in criminal matters investigated by U.S. attorneys, 
by offense, 1994-2001

Filename:  fcc01a03.wk1
Table A.3.  Suspects in criminal matters concluded by U.S. attorneys, 
by offense, 1994-2001

Filename:  fcc01a04.wk1
Table A.4.  Suspects in criminal matters concluded by U.S. attorneys:  
Number prosecuted before U.S. district court judge, by offense, 1994-2001

Filename:  fcc01a05.wk1
Table A.5.  Suspects in criminal matters concluded by U.S. magistrates,  
by offense, 1994-2001

Filename:  fcc01a06.wk1
Table A.6.  Suspects in criminal matters concluded by U.S. attorneys:  
Number declined prosecution, by offense, 1994-2001

Filename:  fcc01a07.wk1
Table A.7.  Defendants in cases proceeded against in U.S. district courts, 
by offense, 1994-2001

Filename:  fcc01a08.wk1
Table A.8.  Defendants in cases terminating in U.S. district courts, by 
offense, 1994-2001

Filename:  fcc01a09.wk1
Table A.9.  Defendants in cases terminating in U.S. district courts:  
Percent convicted, by offense, 1994-2001

Filename:  fcc01a10.wk1
Table A.10.  Offenders convicted and sentenced in U.S. district courts, 
by offense, 1994-2001

Filename:  fcc01a11.wk1
Table A.11.  Offenders convicted and sentenced in U.S. district courts:  
Number sentenced to prison, by offense, 1994-2001

Filename:  fcc01a12.wk1
Table A.12.  Criminal appeals filed, by offense, 1994-2001

Filename:  fcc01a13.wk1
Table A.13.  Offenders convicted and sentenced in U.S. district courts:  
Number sentenced to probation only, by offense, 1994-2001

Filename:  fcc01a14.wk1
Table A.14.  Offenders convicted and sentenced in U.S. district courts:  
Mean number of months of imprisonment imposed, by offense, 1994-2001

Filename:  fcc01a15.wk1
Table A.15.  Offenders under Federal supervision, by offense, 1994-2001

Filename:  fcc01a16.wk1
Table A.16.   Population at the end of the year in Federal prisons, by 
offense, 1994-2001
