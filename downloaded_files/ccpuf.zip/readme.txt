CITIZEN COMPLAINTS ABOUT POLICE USE OF FORCE (NCJ 210296)																	

This zip archive contains tables and figures in individual .csv spreadsheets from the 2003 Law Enforcement and Administrative
Statistics (LEMAS) report, "Citizen Complaints about Police Use of Force."  The full report including tables and graphics in .pdf format 
are available from: http://www.ojp.usdoj.gov/bjs/abstract/ccpuf.htm


Tables:
																	
ccpuft01.csv	Table 1. Citizen complaints about police use of force per agency, per 100 full-time aworn officers, and per 100 full-time sworn officers responding to calls for service, by type of agency, 2002
ccpuft02.csv 	Table 2. Complaint dispositions in large law enforcement agencies, by type of agency, 2002
ccpuft03.csv	Table 3. Complaint dispositions in large law enforcement agencies, by number of full-time sworn officers, 2002
ccpuft04.csv	Table 4. Force complaints received by large municipal police departments, by number of full-time sworn officers, 2002
ccpuft05.csv	Table 5. Complaint dispositions in large municipal police departments, by number of full-time sworn officers, 2002
ccpuft06.csv	Table 6. Citizen complaints about police use of force in large municipal police departments, by selected agency administrative characteristics, 2002
ccpuft07.csv	Table 7. Complaint dispositions in large municipal police departments, by selected agency administrative characteristics, 2002

Text tables:

ccpuftt01.csv	Text-table 1. Force complaints received by large law enforcement agencies
ccpuftt02.csv	Text-table 2. Sustained force complaints in large law enforcement agencies

Highlights figure:

ccpufhi01.csv	Highlights figure 1. Citizen complaints about police use of force per 100 full-time sworn officers, by type of agency, 2002