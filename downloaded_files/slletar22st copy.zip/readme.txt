State and Local Law Enforcement Training Academies and Recruits, 2022 - Statistical Tables  NCJ 309348

This zip archive contains tables in individual  .csv spreadsheets
from State and Local Law Enforcement Training Academies and Recruits, 2022 - Statistical Tables  NCJ 309348.  The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/state-and-local-law-enforcement-training-academies-and-recruits-2022
						
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to
https://bjs.ojp.gov/library/publications/list?series_filter=State%20and%20Local%20Law%20Enforcement%20Training%20Academies
																				
Filenames			Table names
slletar22stt01.csv	Table 1. Number and percent of academies that provided, and recruits who started and completed, basic training, by type of academy, 2022
slletar22stt02.csv	Table 2. Positions for which state and local law enforcement training academies trained recruits, 2022
slletar22stt03.csv	Table 3. Community member involvement in recruit evaluation and selection processes or requirements, by general type of academy, 2022
slletar22stt04.csv	Table 4. Number of training academies, recruits trained, and average length of training, by region, 2022
slletar22stt05.csv	Table 5. Completion outcomes of basic training recruits and reasons for noncompletion, by sex, 2022
slletar22stt06.csv	Table 6. Sex of recruits who started and did not complete basic training, by region, 2022
slletar22stt07.csv	Table 7. Recruits who started and completed basic training, by race or ethnicity, 2022
slletar22stt08.csv	Table 8. Military veteran status of recruits who started and completed basic training, by type of academy, 2022
slletar22stt09.csv	Table 9. Recruits who started and completed basic training who held associate’s and bachelor’s degrees, by type of academy, 2022
slletar22stt10.csv	Table 10. Eligibility, response rates, and final analysis weights for the 2022 Census of Law Enforcement Training Academies, by type of academy 

				Figures
slletar22stf01.csv	Figure 1. Race or ethnicity of recruits who started basic training, 2006, 2011–13, 2018, and 2022
slletar22stf02.csv	Figure 2. Training models recruits received during basic training, 2011–13, 2018, and 2022
								
				Appendix tables	
slletar22stat01.csv	Appendix Table 1. Estimates and standard errors for figure 1: Race or ethnicity of recruits who started basic training, 2006, 2011–13, 2018, and 2022
slletar22stat02.csv	Appendix Table 2. Standard errors for table 1: Number and percent of academies that provided, and recruits who started and completed, basic training, by type of academy, 2022
slletar22stat03.csv	Appendix Table 3. Standard errors for table 2: Positions for which state and local law enforcement training academies trained recruits, 2022
slletar22stat04.csv	Appendix Table 4. Standard errors for table 3: Community member involvement in recruit evaluation and selection processes or requirements, by general type of academy, 2022
slletar22stat05.csv	Appendix Table 5. Standard errors for table 4: Number of training academies, recruits trained, and average length of training, by region, 2022
slletar22stat06.csv	Appendix Table 6. Estimates and standard errors for figure 2: Training models recruits received during basic training, 2011–13, 2018, and 2022
slletar22stat07.csv	Appendix Table 7. Standard errors for table 5: Completion outcomes of basic training recruits and reasons for noncompletion, by sex, 2022
slletar22stat08.csv	Appendix Table 8. Standard errors for table 6: Sex of recruits who started and did not complete basic training, by region, 2022
slletar22stat09.csv	Appendix Table 9. Standard errors for table 7: Recruits who started and completed basic training, by race or ethnicity, 2022
slletar22stat10.csv	Appendix Table 10. Standard errors for table 8: Military veteran status of recruits who started and completed basic training, by type of academy, 2022
slletar22stat11.csv	Appendix Table 11. Standard errors for table 9: Recruits who started and completed basic training who held associate’s and bachelor’s degrees, by type of academy, 2022