Jails in Indian Country, 2007, NCJ 223760

This zip archive contains tables in individual .csv spreadsheets
from Jails in Indian Country, 2007, NCJ 223760. The full report 
including text and graphics in .pdf format are available from: 
http://www.ojp.usdoj.gov/bjs/abstract/jic07.htm.

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic.
 
Tables	
jic07t01.csv	Table 1. Number of Inmates, rated capacity, and percent of capacity occupied in Indian country jails, 2004 and 2007
jic07t02.csv	Table 2. American Indians and Alaska Natives in custody or under community supervision, 2004 and 2007
jic07t03.csv	Table 3. Number of Indian country jails and percent of inmate population, by facility size, June 2007 
jic07t04.csv	Table 4. Jails in Indian country that held the majority of inmates, by facility, June 2007
jic07t05.csv	Table 5. Number of Indian country jails, by percent of capacity occupied, June 2007
jic07t06.csv	Table 6. Jails in Indian country operating above 150% of capacity on their peak day during June 2007
jic07t07.csv	Table 7. Admissions, discharges, and average length of stay in Indian Country jails during June, by facility size, 2007 
jic07t08.csv	Table 8. Number of inmates confined in Indian country jails, by characteristic, June 2000-June 2007
jic07t09.csv	Table 9. Employment characteristics in Indian country jails, by job function, June 2007
jic07t10.csv	Table 10. Jails in Indian country with medical and mental health services and policies, by type, June 2007 
jic07t11.csv	Table 11. Jails in Indian country that provided inmate treatment, counseling, and special programs, June 2007
jic07t12.csv	Table 12. Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, by facility, June 2007


Appendix tables	
jic07at01.csv	Appendix table 1. Number of inmates in jails in Indian country, by type of offense, June 2007
jic07at02.csv	Appendix table 2. Number of inmates in jails in Indian country, by conviction status, June 2007
jic07at03.csv	Appendix table 3. Adults and juveniles in the custody of jails in Indian country, by gender, June 2007 
jic07at04.csv	Appendix table 4. Jails in Indian country that provide medical services to inmates, by facility, June 2007
jic07at05.csv	Appendix table 5. Jails in Indian country with policies for screening inmates for the HIV infection, by facility, June 2007
jic07at06.csv	Appendix table 6. Jails in Indian country with policies for testing inmates for hepatitis B, by facility, June 2007
jic07at07.csv	Appendix table 7. Jails in Indian country with policies for testing inmates for hepatitis C, by facility, June 2007
jic07at08.csv	Appendix table 8. Jails in Indian country with policies for testing inmates for tuberculosis, by facility, June 2007
jic07at09.csv	Appendix table 9. Jails in Indian country with policies to provide mental health care for inmates, by facility, June 2007
jic07at10.csv	Appendix table 10. Jails in Indian country with suicide prevention procedures, by facility, June 2007
jic07at11.csv	Appendix table 11. Jails in Indian country that provide treatment, counseling, and special programs on or off facility grounds for inmates, by facility, June 2007
jic07at12.csv	Appendix table 12. Jails in Indian country that provide education programs on or off facility grounds for inmates, by facility, June 2007
jic07at13.csv	Appendix table 13. Jails in Indian country that provide work assignments for inmates, by facility, June 2007

	
Figures	
jic07f01.csv	Figure 1. Inmates confined in Indian country jails, 2000-2004 and 2007
jic07f02.csv	Figure 2. American Indians and Alaska Natives under correctional supervision in the United States, 2000-2007
jic07f03.csv	Figure 3. Percent of capacity occupied, by type of inmate count, June 2007


	



