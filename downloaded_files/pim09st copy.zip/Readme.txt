Readme.TXT

Prison Inmates at Midyear 2009-Statistical Tables, NCJ 230113

This zip archive contains tables in individual .csv spreadsheets from Prison Inmates at Midyear 2009-Statistical 
tables, NCJ 230113.  report including text and graphics in .pdf format is available from:	
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2200.	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=38.

    Tables
pim09st01.csv	Table 1. Prisoners under the jurisdiction of state or federal prisons or in the custody of state or federal prisons or local jails, December 31, 2000 and 2008, and June 30, 2008 and 2009

pim09st02.csv	Table 2. Prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2007 and 2008, and June 30, 2008 and 2009

pim09st03.csv	Table 3. Male prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2007, and 2008, and June 30, 2008 and 2009

pim09st04.csv	Table 4. Females prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2007, and 2008, and June 30, 2008 and 2009

pim09st05.csv	Table 5. Sentenced prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2007, and 2008, and June 30, 2008 and 2009

pim09st06.csv	Table 6. Number of sentenced male prisoners under the jurisdiction of state and federal correctional authorities, December 31, 2000-2008, and June 30, 2008 and 2009

pim09st07.csv	Table 7. Sentenced male prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2007, and 2008, and June 30, 2008 and 2009

pim09st08.csv	Table 8. Number of sentenced female prisoners under the jurisdiction of state or federal correctional authorities, December 31, 2000-2008, and June 30, 2008 and 2009

pim09st09.csv	Table 9. Sentenced female prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2007, and 2008, and June 30, 2008 and 2009

pim09st10.csv	Table 10.  Imprisonment rates of sentenced prisoners under jurisdiction of state and federal correctional authorities, by sex and jurisdiction, June 30, 2009

pim09st11.csv	Table 11. Number of state or federal prisoners in private facilities, December 31, 2000-2008, and June 30, 2008 and 2009

pim09st12.csv	Table 12. Number of state and federal prisoners in private facilities, by jurisdiction, December 31, 2000, 2007 and 2008, and June 30, 2008 and 2009

pim09st13.csv	Table 13. Number of state or federal prisoners in local facilities, December 31, 2000-2008, and June 30, 2008 and 2009

pim09st14.csv	Table 14. Number of state and federal prisoners in local facilities, by jurisdiction, December 31, 2000, 2007, and 2008, and June 30, 2008 and 2009
	
pim09st15.csv	Table 15. Inmates held in custody in state or federal prisons or in local jails, December 31, 2000-2008, and June 30, 2008 and 2009

pim09st16.csv	Table 16. Estimated number of inmates held in custody in state or federal prison, or in local jails, by sex, race, and Hispanic origin, June 30, 2000-2009

pim09st17.csv	Table 17. Estimated number of inmates held in custody in state or federal prisons or in local jails, by sex, race, Hispanic origin, and age, June 30, 2009

pim09st18.csv	Table 18. Estimated number of inmates held in custody in state or federal prisons or in local jails per 100,000 U.S. residents, by sex, race, and Hispanic origin, June 30, 2000-2009

pim09st19.csv	Table 19. Estimated number of inmates held in custody in state or federal prison, or in local jails per 100,000 U.S. residents, by sex, race, Hispanic origin, and age, June 30, 2009

pim09st20.csv	Table 20. Reported number of non-U.S. citizens held in custody in state or federal pris
ons, by sex, region, and jurisdiction, June 30, 2008 and 2009

pim09st21.csv	Table 21. Reported number of inmates under age 18 held in custody in state prisons, by sex, region, and jurisdiction, June 30, 2008 and 2009

Figures
pim09stf01.csv	Figure 1. Six-month count and percent change of prisoners under state and federal jurisdiction, June 30, 2000-2009

pim09stf02.csv	Figure 2. Change in number of prisoners under state and federal jurisdiction, December 31, 2008 to June 30, 2009