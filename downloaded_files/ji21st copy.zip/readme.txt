Jail Inmates in 2021 – Statistical Tables  NCJ 304888	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Jail Inmates in 2021 – Statistical Tables  NCJ 304888.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/jail-inmates-2021-statistical-tables	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to 	
https://bjs.ojp.gov/library/publications/list?series_filter=Prison%20and%20Jail%20Inmates%20at%20Midyear	
	
Filename	Table title
ji21stt01.csv	Table 1. Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2011–2021
ji21stt02.csv	Table 2. Number of confined inmates in local jails, by demographic characteristics, 2011 and 2016–2021
ji21stt03.csv	Table 3. Percent of confined inmates in local jails, by demographic characteristics, 2011 and 2016–2021
ji21stt04.csv	Table 4. Jail incarceration rates, by demographic characteristics, 2011 and 2016–2021
ji21stt05.csv	Table 5. Number of confined inmates in local jails, by conviction status and offense severity, 2011 and 2016–2021
ji21stt06.csv	Table 6. Percent of confined inmates in local jails, by conviction status and offense severity, 2011 and 2016–2021
ji21stt07.csv	Table 7. Confined inmates in local jails, by probation or parole violation status, midyears 2019–2021
ji21stt08.csv	Table 8. Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, 2011 and 2016–2021
ji21stt09.csv	Table 9. Average daily jail population, by size of jurisdiction, 2021
ji21stt10.csv	Table 10. Midyear population, jail capacity, and percent of capacity occupied in local jails, 2011–2021
ji21stt11.csv	Table 11. Percent of jail capacity occupied at midyear, by size of jail jurisdiction, 2021
ji21stt12.csv	Table 12. Inmate turnover rate and estimated average time in jail, 2011–2021
ji21stt13.csv	Table 13. Inmate turnover rate and estimated average time in jail, by size of jurisdiction, 2021
ji21stt14.csv	Table 14. Persons under jail supervision, by confinement status, midyears 2011–2021
ji21stt15.csv	Table 15. Number of persons serving weekend-only sentences, 2011–2021
ji21stt16.csv	Table 16. Number of staff employed in local jails, by job function and sex, 2016–2021
ji21stt17.csv	Table 17. Percent of staff employed in local jails, by job function and sex, 2016–2021
	
		Figures
ji21stf01.csv	Figure 1. Number of inmates confined in local jails at midyear, by conviction status, 2011–2021
	
		Appendix tables
ji21stat01.csv	Appendix table 1. Standard errors for table 1: Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2011–2021
ji21stat02.csv	Appendix table 2. Standard errors for table 2: Number of confined inmates in local jails, by demographic characteristics, 2011 and 2016–2021
ji21stat03.csv	Appendix table 3. Standard errors for table 3: Percent of confined inmates in local jails, by demographic characteristics, 2011 and 2016–2021
ji21stat04.csv	Appendix table 4. Standard errors for table 4: Jail incarceration rates, by demographic characteristics, 2011 and 2016–2021
ji21stat05.csv	Appendix table 5. Standard errors for table 5: Number of confined inmates in local jails, by conviction status and offense severity, 2011 and 2016–2021
ji21stat06.csv	Appendix table 6. Standard errors for table 6: Percent of confined inmates in local jails, by conviction status and offense severity, 2011 and 2016–2021
ji21stat07.csv	Appendix table 7. Standard errors for table 7: Confined inmates in local jails, by probation or parole violation status, midyears 2019–2021
ji21stat08.csv	Appendix table 8. Standard errors for table 8: Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, 2011 and 2016–2021
ji21stat09.csv	Appendix table 9. Standard errors for table 9: Average daily jail population, by size of jurisdiction, 2021
ji21stat10.csv	Appendix table 10. Standard errors for table 10: Midyear population, jail capacity, and percent of capacity occupied in local jails, 2011–2021
ji21stat11.csv	Appendix table 11. Standard errors for table 11: Percent of jail capacity occupied at midyear, by size of jail jurisdiction, 2021
ji21stat12.csv	Appendix table 12. Standard errors for table 12: Inmate turnover rate and estimated average time in jail, 2011–2021
ji21stat13.csv	Appendix table 13. Standard errors for table 13: Inmate turnover rate and estimated average time in jail, by size of jurisdiction, 2021
ji21stat14.csv	Appendix table 14. Standard errors for table 14: Persons under jail supervision, by confinement status, midyears 2011–2021
ji21stat15.csv	Appendix table 15. Standard errors for table 15: Number of persons serving weekend-only sentences, 2011–2021
ji21stat16.csv	Appendix table 16. Standard errors for table 16: Number of staff employed in local jails, by job function and sex, 2016–2021
ji21stat17.csv	Appendix table 17. Standard errors for table 17: Percent of staff employed in local jails, by job function and sex, 2016–2021
