Jails in Indian Country, 2008, NCJ 228271	
	
This zip archive contains tables in individual .csv spreadsheets	
from Jails in Indian Country, 2007, NCJ 228271. The full report 	
including text and graphics in .pdf format are available from: 	
http://www.ojp.usdoj.gov/bjs/abstract/jic07.htm.	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic.	
 	
Tables	
jic08t01.csv	Table 1. American Indians and Alaska Natives in custody or under community supervision, 2007 and 2008
jic08t02.csv	Table 2. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, 2004, 2007, and 2008
jic08t03.csv	Table 3. Indian country jails and percent of inmate population, by facility size, June 2008
jic08t04.csv	Table 4. Jails in Indian country that held the majority of inmates, by facility, June 2008
jic08t05.csv	Table 5. Number of Indian country jails, by percent of rated capacity occupied, June 2008
jic08t06.csv	Table 6. Jails in Indian country operating above 150% of capacity on their peak day during June 2008
jic08t07.csv	Table 7. Admissions and expected length of stay in Indian country jails during June 2008, by facility size
jic08t08.csv	Table 8. Number of inmates confined in Indian country jails, by characteristic, June 2000-June 2008
jic08t09.csv	Table 9. Employment characteristics in Indian country jails, by job function, June 2008
jic08t10.csv	Table 10. Inmates, rated capacity, and percent of capacity occupied in Indian country, by facility, June 2008
	
Appendix tables	
jic08at01.csv	Appendix table 1. Inmates in jails in Indian country, by type of offense, June 2008 
jic08at02.csv	Appendix table 2. Inmates in jails in Indian country, by conviction status, June 2008 
jic08at03.csv	Appendix table 3. Adults and juveniles in the custody of jails in Indian country, by gender, June 2008
	
Figures	
jic08f01.csv	Figure 1. Inmates confined in Indian country jails, 2000-2004 and 2007-2008
jic08f02.csv	Figure 2. American Indians and Alaska Natives under correctional supervision in the United States, 2000-2008
jic08f03.csv	Figure 3. Rated capacity occupied, by type of inmate count, June 2008
