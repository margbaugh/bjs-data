Violent Victimization Committed by Strangers, 1993-2010 NCJ 239424

 
This zip archive contains tables in individual .csv spreadsheets from
Violent Victimization Committed by Strangers, 1993-2010 NCJ 239424
The full electronic report is available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4557

Filename		Table title
vvcs9310t01.csv		Violent victimization committed by strangers, by type of crime, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t02.csv		Violent victimization committed by strangers, by victim characteristics, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t03.csv		Workplace and nonworkplace violent victimization committed by strangers, by victim employement status, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t04.csv		Average annual rate of violent victimization, by victim-offender relationship and location of victim residence, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t05.csv		Average annual rate of violent victimization, by victim-offender relationship and population where victim lived, 1999-2004 and 2005-2010
vvcs9310t06.csv		Average annual percent and number of violent victimizations, by victim-offender relationship and location of crime, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t07.csv		Percent of violent victimization occurring in various locations that were committed by strangers, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t08.csv		Average annual percent and number of violent victimizations, by victim-offender relationship and victim activity when crime occurred, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t09.csv		Average annual percent and number of violent victimizations involving a weapon, by victim-offender relationship and type of weapon, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t10.csv		Average annual percent and number of violent victimizations involving an injury, by victim-offender relationship, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t11.csv		Average annual percent and number of violent victimizations, by victim-offender relationship and number of offenders, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t12.csv		Average annual percent and number of violent victimizations not reported to police, by victim-offender relationship and reason for not reporting, 1993-1998, 1999-2004, and 2005-2010
vvcs9310t13.csv		Circumstances of stranger homicide, 1993-1998, 1999-2004, and 2005-2008

Filename		Figure title		
vvcs9310f01.csv		Rate of violent victimization committed by strangers and offenders known to victims, 1993-2010
vvcs9310f02.csv		Rate of violent victimization committed by strangers, by sex of victim, 1993-2010
vvcs9310f03.csv		Percent of violent victimizations committed by strangers or offenders known to the victim and reported to police, 1993-2010
vvcs9310f04.csv		Victim-offender relationship in homicides, 1993-2008

Filename		Appendix table title
vvcs9310at01.csv	Standard errors for rate of violent victimization committed by strangers and offenders known to victims, 1993-2010
vvcs9310at02.csv	standard errors for violent victimization committed by strangers, by type of crime, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at03.csv	Standard errors for rate of violent victimization committed by strangers, by sex of victim, 1993-2010
vvcs9310at04.csv	Standard errors for violent victimizatino committed by strangers, by victim characteristics, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at05.csv	Standard errors for workplace and nonworkplace violent victimization committed by strangers, by victim employment status, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at06.csv	Standard errors for average annual rate of violent victimization, by victim-offender relationship and location of victim residence, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at07.csv	Standard errors for average annual rate of violent victimization, by victim-offender relationship and population where victim lived, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at08.csv	standard errors for average annual percent and number of violent victimizations, by victim-offender relationship and location of crime, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at09.csv	Standard errors for percent of violent victimizations occurring in various locations that were committed by strangers, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at10.csv	Standard errors for average annual percent and number of violent victimizations, by victim-offender relationship and victim activity when crime occurred, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at11.csv	Standard errors for average annual percent and number of violent victimizations involving a weapon, by victim-offende relationship and type of offender weapon, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at12.csv	Standard errors for average annual percent and number of violent victimizations involving an injury, by victim-offender relationship, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at13.csv	Standard errors for average annual percent and number of violent victimizations, by victim-offender relationship and number of offenders, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at14.csv	Standard errors for average annual percent and number of violent victimizations, by victim-offender relationship and victim perception of offender gang membership, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at15.csv	Percentages and standrad errors for percent of violent victimizations committed by strangers or offender known to the victim and reported to police, 1993-2010
vvcs9310at16.csv	Standard errors for average annual percent and number of violent victimizations not reported to police, by victim-offender relationship and reason for not reporting, 1993-1998, 1999-2004, and 2005-2010
vvcs9310at17.csv	Percents for victim/offender relationship in homicides, 1993-2008 
