ZIP archive contents 

Substance Abuse and Treatment, State and Federal Prisoners, 1997
  
File name     Table location and description

sats97h1.wk1  Highlights box, top table: Self-reported alcohol and drug use, 1991 and 1997
sats97h2.wk1  Highlights box, bottom table: Alcohol and drug treatment/other programs, State prisoners
sats97b2.wk1  Page 2, box table: Drug offenders' criminal history, status at arrest and drug type invol
sats9701.wk1  Table 1: Alcohol or drug use at time of offense, State and Federal prisoners
sats9702.wk1  Table 2: Drug use of State prisoners, 1991 and 1997
sats9703.wk1  Table 3: Drug use of Federal prisoners, 1991 and 1997
sats97b5.wk1  Page 5, box table: Past experiences of alcohol abuse by number of positive CAGE responses
sats9704.wk1  Table 4: Number of positive CAGE responses for State and Federal prisoners, by offense ty
sats9705.wk1  Table 5: Experiences while under the influence of alcohol or drugs reported by State and
sats9706.wk1  Table 6: Levels of prior drug abuse, by selected characteristics of State and Federal pri
sats9707.wk1  Table 7: Levels of prior alcohol abuse, by selected characteristics of State and Federal
sats9708.wk1  Table 8: Substance abuse treatment history of State and Federal prisoners, by prior subst
sats9709.wk1  Table 9: Drug treatment since admission, by levels of prior drug use, 1991and 1997
sats9710.wk1  Table 10: Types of drug treatment received by State prisoners since admission, by prior d
sats9711.wk1  Table 11: Types of drug treatment received by Federal prisoners since admission, by prior
sats9712.wk1  Table 12: Types of alcohol treatment received by State prisoners since admission, by prio
sats9713.wk1  Table 13: Types of alcohol treatment received by Federal prisoners since admission, by pr
sats9714.wk1  Table 14: Alcohol- or drug-involved State prisoners treated for substance abuse,  selecte
sats9715.wk1  Table 15: Alcohol- or drug-involved Federal prisoners treated for substance abuse, select
sats97a1.wk1  Appendix table 1: Current offense of sentenced State and Federal prisoners, 1991 and 1997
sats97a2.wk1  Appendix table 2: Standard errors of estimated percentages, State prison inmates, 1997
sats97a3.wk1  Appendix table 2: Standard errors of estimated percentages, State prison inmates, 1997
 
