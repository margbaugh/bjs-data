BACKGROUND CHECKS FOR FIREARM TRANSFERS, 1999
Firearm Inquiry Statistics Program (FIST)
NCJ 180882

bcft99hi.wk1	Highlights.  Background checks of applications for firearm transfers 
		since implementation of the Brady Act

bcft9901.wk1	Table 1.  Number of applications and estimates of rejections for firearm 
		transfer, 1994-99

bcft9902.wk1	Table 2.  Estimates of applications and rejections, by type of approval
		system among State and local agencies, 1999

bcft9903.wk1	Table 3.  Applications and rejections for ATF-exempt firearm carry permits, 1999

bcft9904.wk1	Table 4.  Reasons for rejection of firearm transfer applications, 1999

bcft9905.wk1	Table 5.  Number of firearm transfer applications received and rejected by 
		State and local agencies, 1999

bcft99f1.wk1	Figure 1.  Applications for firearm transfers peak in December

bcft99f2.wk1	Figure 2.  Applications for firearm transfers per 1,000 residents in 19 States

bcft99a1.wk1	Appendix A.  National Instant Criminal Background Check System: Checking 
		agencies - FBI or State point of contact - for transfers of handguns and 
		long guns, December 1999

bcft99a2.wk1	Appendix B.  State and local agencies conducting background checks for firearm
		transfers, 1999

