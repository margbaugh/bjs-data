This file contains tables in individual spreadsheets from the
1997 National Corrections Reporting
Program.  It is one of a series of files from the National
Corrections Reporting Program since 1993.  
All of the files may be obtained from
http://www.ojp.usdoj.gov/bjs/dtdata.htm#ncrp.
Three groups of tables -- sentence length, time served and most
serious offense of State prisoners-- are archived for each year.  
In addition to the list of tables in this file, the tables in the
related archives are listed below.

This Zip archive, most serious offense of State prisoners, 1997,
NCJ 181756 contains the following tables:

   File name        Contents

NCRP9701.wk1        State prison admissions: offense, by
                    admission type
NCRP9702.wk1        New court commitments to State prisons:
                    offense by age at admission
NCRP9703.wk1        Parole violators returned to State prison:
                    offense by age at admission
NCRP9704.wk1        New court commitments to State prisons:
                    offense by sex, race, and Hispanic origin
NCRP9705.wk1        Parole violators returned to State prison:
                    offense by sex, race, and Hispanic origin
NCRP9712.wk1        First entries to parole supervision from
                    State prison: method of prison release by  
                    offense
NCRP9713.wk1        First entries to parole supervision from
                    State prison: offense by sex, race, and  
                    Hispanic origin
NCRP9714.wk1        State parole discharges: method of parole
                    discharge, by offense 

Two related archives are also available.  The tables in these
archives are listed below.

Time Served in State Prison
                    
          State prison releases: time served in prison, by offense and
     release type

          First releases from State prison: sentence length, time
     served and percent of sentence served in prison by offense
     
          First releases from State prison: sentence length, time
     served in prison by offense and sex
                    
          First releases from State prison: sentence length, time
     served in prison by offense and race 
                    
          Successful first State parole discharges: sentence length
     and time served, by offense

          Unsuccessful first State parole discharges: sentence length
     and time served, by offense

Sentence length of State prisoners 

          State prison admissions: sentence length by offense and
     admission type

          New court commitments to State prisons: sentence length and
     minimum time to be served, by offense
                    
          First releases from State prison: sentence length, time
     served and percent of sentence served in prison by offense
          
          First releases from State prison: sentence length, time
     served in prison by offense and sex
                    
          First releases from State prison: sentence length, time
     served in prison by offense and race 
                    
          Successful first State parole discharges: sentence length
     and time served, by offense
     
          Unsuccessful first State parole discharges: sentence length
     and time served, by offense



