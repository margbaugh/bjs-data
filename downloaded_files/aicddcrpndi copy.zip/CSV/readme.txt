Assessing Inmate Cause of Death: Deaths in Custody Reporting Program and National Death Index
 
This zip archive contains tables in individual .csv spreadsheets
from Assessing Inmate Cause of Death: Deaths in Custody Reporting Program and National Death Index, NCJ 249568.
The full report including text and graphics in .pdf format are available from:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5601

		
Filename		Figure
aicddcrpndif01.csv	Figure 1. DCRP-NDI data linkage flowchart

			Tables
aicddcrpndit01.csv	Table 1. Comparison of DCRP and NDI cause of death data
aicddcrpndit02.csv	Table 2. Matching results between the DCRP and NDI, 2007�2010
aicddcrpndit03.csv	Table 3. Percent missing cause of death data in the DCRP and NDI, by facility type, 2007�2010
aicddcrpndit04.csv	Table 4. Mean number of ICD codes available in the DCRP and NDI, 2007�2010
aicddcrpndit05.csv	Table 5. Distributions of cause of death in the DCRP and NDI, by facility type and sex of decedent, 2007�10 	
aicddcrpndit06.csv	Table 6. Number of NDI causes of death, by DCRP cause of death category, 2007�2010
aicddcrpndit07.csv	Table 7. Percent of NDI causes of death, by DCRP cause of death category, 2007�2010	
aicddcrpndit08.csv	Table 8. Percent of cases in the DCRP and NDI that match on cause of death, 2007�10
aicddcrpndit09.csv	Table 9. DCRP�NDI cause of death (COD) agreement, by status code, COD count, and facility type, 2007�10
aicddcrpndit10.csv	Table 10. Logistic regression of DCRP�NDI cause of death agreement, 2007�2010
aicddcrpndit11.csv	Table 11. Comparison of DCRP and NDI ICD-10 codes, 2007�10
aicddcrpndit12.csv	Table 12. Percent of records with same underlying cause of death, by International Classification of Diseases (ICD-10) codes, 2007�10