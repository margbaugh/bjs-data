Prosecutors in State Courts,  2001, NCJ 193441


This zip archive contains tables in individual .wk1 spreadsheets
from Prosecutors in State Courts,  2001, NCJ 193441
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/psc01.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#prosecutors

 
File Name             Table Name
psc1.wk1              Table 1.  Distribution of personnel for prosecutors' offices, 2001
psc2.wk1              Table 2.  Median staff size in prosecutors' offices, by personnel categories, 2001
psc3.wk1              Table 3.  Length of service and annual salary for chief prosecutor, 2001
psc4.wk1              Table 4.  Budget for prosecutorial functions in prosecutors' offices, 2001
psc5.wk1              Table 5.  Types of cases other than felonies handled in prosecutors' offices, 2001
psc6.wk1              Table 6.  Special categories of felony offenses prosecuted in prosecutors' offices, 2001
psc7.wk1              Table 7.  Criminal cases closed and convicted in prosecutors' offices, 2001
psc8.wk1              Table 8.  Juveniles proceeded against in criminal court by prosecutors' offices, 2001
psc9.wk1              Table 9.  Security measures used for protection by prosecutors' offices, 2001
psc10.wk1             Table 10.  DNA evidence used by prosecutors' offices, 2001
psc11.wk1             Table 11.  Community-related activities engaged in by prosecutors' offices, 2001
pscbox1.wk1           Box 1.  Computer-related crime prosecuted by prosecutors' offices, 2001
pscbox2.wk1           Box 2.  Staffing and budget in prosecutors' offices, 1992 to 2001
pscf1.wk1             Figure 1.  Annual Salary of chief prosecutors, 2001
pscf2.wk1             Figure 2.  Work-related threats and assaults received by members of prosecutors' offices, 2001
pscappend.wk1         Appendix.   Chief prosecutors who handle felony cases in State courts of general jurisdiction, 2001
 
