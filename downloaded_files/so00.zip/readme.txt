SHERIFFS' OFFICES 2000  NCJ 196534																	
																	
This zip archive contains tables and figures in individual .wk1 spreadsheets from the 2000 Law Enforcement and Administrative Statistics (LEMAS) report, "Sheriffs' Offices 2000."  The full report including tables and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/so00.htm

This report is one in a series.  More recent editions may be available. To view a list of all in the series go to http://www.ojp.usdoj.gov/bjs/pubalp2.htm#so

																	
Tables:																	
																	
so0001.wk1	Table 1. Employment by State and local law enforcement agencies in the United States, 2000																
so0002.wk1 	Table 2. Sheriffs' offices and full-time personnel, by number of sworn personnel, 2000
so0003.wk1	Table 3. Sheriffs' offices and full-time personnel, by size of population served, 2000
so0004.wk1	Table 4. Average number of employees in sheriffs' offices, by size of population served, 2000
so0005.wk1	Table 5. Sworn personnel assigned to respond to citizen calls for service in sheriffs' offices, by size of population served, 2000
so0006.wk1	Table 6. Authorized full-time strength of sheriffs' offices and percent of authorized strength employed, by size of population served, 2000
so0007.wk1	Table 7. Gender and race of full-time sworn personnel in sheriffs' offices, by size of population served, 2000
so0008.wk1	Table 8. Interviews, tests and examinations used in selection of new deputy recruits in sheriffs' offices, by size of population served, 2000
so0009.wk1	Table 9. Background checks used in selection of new deputy recruits in sheriffs' offices, by size of population served, 2000
so0010.wk1	Table 10. Minimum educational requirement for new deputies in sheriffs' offices, by size of population served, 2000
so0011.wk1	Table 11. Training requirements for new deputy recruits in sheriffs' offices, by size of population served, 2000
so0012.wk1	Table 12. Annual in-service training requirements for non-probationary deputies in sheriffs' offices, by	size of population served, 2000
so0013.wk1	Table 13. Operating budget of sheriffs' offices, by size of population served, 2000
so0014.wk1	Table 14. Average base annual salary for selected positions in sheriffs' offices, by size of population served, 2000
so0015.wk1	Table 15. Sheriffs' offices authorizing special pay for full-time sworn personnel, by size of population served, 2000
so0016.wk1	Table 16. Work-related policy directives maintained by sheriffs' offices, by size of population served, 2000
so0017.wk1	Table 17. Collective bargaining authorized by sheriffs' offices, by size of population served, 2000
so0018.wk1	Table 18. Types of patrol used on a routine basis by sheriffs' offices, by size of population served, 2000
so0019.wk1	Table 19. Calls for service functions of sheriffs' offices, by size of population served, 2000
so0020.wk1	Table 20. Participation in a 9-1-1 emergency telephone system by sheriffs' offices, by size of population served, 2000
so0021.wk1	Table 21. Homicide and arson investigation in sheriffs' offices, by size of population served, 2000
so0022.wk1	Table 22. Drug enforcement in sheriffs' offices, by size of population served, 2000
so0023.wk1	Table 23. Special units for drug enforcement in sheriffs' offices, by size of population served, 2000
so0024.wk1	Table 24. Participation by sheriffs' offices in multi-agency drug enforcement task forces, by size of population served, 2000
so0025.wk1	Table 25. Drug asset forfeiture program recipts of sheriffs' offices, by size of population served, 2000
so0026.wk1	Table 26. Court-related functions of sheriffs' offices, by size of population served, 2000
so0027.wk1	Table 27. Jail facilities operated by sheriffs' offices, by size of population served, 2000
so0028.wk1	Table 28. Temporary holding (lockup) facilities operated by sheriffs' offices, by size of population served, 2000
so0029.wk1	Table 29. Special operations functions of sheriffs' offices, by size of population served, 2000
so0030.wk1	Table 30. Sheriffs' offices with a community policing plan, by size of population served, 2000
so0031.wk1	Table 31. Community policing training in sheriffs' offices, by size of population served, 2000
so0032.wk1	Table 32. Full-time community policing officers in sheriffs' offices, by size of population served, 2000
so0033.wk1	Table 33. Full-time school resource officers in sheriffs' offices, by size of population served, 2000
so0034.wk1	Table 34. Community-oriented policies for sworn personnel in sheriffs' offices, by size of population served, 2000
so0035.wk1	Table 35. Community policing activities of sheriffs' offices, by size of population served, 2000
so0036.wk1	Table 36. Surveying of citizens by sheriffs' offices, by size of population served, 2000
so0037.wk1	Table 37. Semiautomatic sidearms authorized for use by sworn personnel in sheriffs' offices, by size of population served, 2000
so0038.wk1	Table 38. Body armor requirements for field officers in sheriffs' offices, by size of population served, 2000
so0039.wk1	Table 39. Types of nonlethal weapons authorized for personal use by sworn personnel in sheriffs' offices, by size of population served, 2000
so0040.wk1	Table 40. Written policy directives pertaining to officer use of force in sheriffs' offices, by size of population served, 2000
so0041.wk1	Table 41. Number of cars operated by sheriffs' offices, by size of population served, 2000
so0042.wk1	Table 42. Number of motorcycles and 4-wheel motorized vehicles other than cars operated by sheriffs' offices, by size of population served, 2000
so0043.wk1	Table 43. Number of bicycles operated by sheriffs' offices, by size of population served, 2000
so0044.wk1	Table 44. Vehicle use policies in sheriffs' offices, by size of population served, 2000
so0045.wk1	Table 45. Pursuit driving policies of sheriffs' offices, by size of population served, 2000
so0046.wk1	Table 46. Off-land vehicles operated by sheriffs' offices, by size of population served, 2000
so0047.wk1	Table 47. Animals maintained by sheriffs' offices, by size of population served, 2000
so0048.wk1	Table 48. Use of video cameras by sheriffs' offices, by size of population served, 2000
so0049.wk1	Table 49. Special technologies used by sheriffs' offices, by size of population served, 2000
so0050.wk1	Table 50. Functions of computers in sheriffs' offices, by size of population served, 2000
so0051.wk1	Table 51. Types of computerized information files maintained by more than half of sheriffs' offices, by size of population served, 2000
so0052.wk1	Table 52. Types of computerized information files maintained by less than half of sheriffs' offices, by size of population served, 2000
so0053.wk1	Table 53. Use of Automated Fingerprint Identification Systems (AFIS) in sheriffs' offices, by size of population served, 2000
so0054.wk1	Table 54. Types of in-field computers or terminals used by sheriffs' offices, by size of population served, 2000
so0055.wk1	Table 55. Use of in-field computers for reports and communications by sheriffs' offices, by size of population served, 2000
so0056.wk1	Table 56. Computerized information accessible to in-field officers of sheriffs' offices, by size of population served, 2000
so0057.wk1	Table 57. Methods for transmitting criminal incident reports to the central information system in sheriffs' offices, by size of population served, 2000
so0058.wk1	Table 58. Special policies regarding arrest for domestic assault and protection orders in sheriffs' offices, by size of population served, 2000
so00t01.wk1	In-Text Table 1. Percent of sheriffs' offices operating a training academy, by size of population served, 2000
so00t02.wk1	In-Text Table 2. Agency operating expenditures (in billions), by type of agency, 1990 and 2000

Figures:

so00h01.wk1	Highlights Figure 1. Female and minority officers in sheriffs' offices, 1990 and 2000
so00h02.wk1	Highlights Figure 2. Sheriffs' offices using in-field computers or terminals, 1990 and 2000
so00h03.wk1	Highlights Figure 3. Percent of 9-1-1 systems in sheriffs' offices with enhanced capability, 1990 and 2000
so00f01.wk1	Figure 1. Employment by State and local law enforcement agencies, 1990 and 2000
so00f02.wk1	Figure 2. Female and minority sheriffs' officers, 1990 and 2000
so00f03.wk1	Figure 3. Sheriffs' deputies employed by departments using various recruit screening methods, 2000
so00f04.wk1	Figure 4. Sworn personnel in sheriffs' offices with a college education requirement for new recruits, 1990 and 2000
so00f05.wk1	Figure 5. Annual per officer operating costs of sheriffs' offices, 1990 and 2000
so00f06.wk1	Figure 6. Average base starting salary for deputies in sheriffs' offices, 1990 and 2000
so00f07.wk1	Figure 7. Base starting salaries for entry-level deputies in sheriffs' offices authorizing and not authorizing collective bargaining for sworn personnel, 2000
so00f08.wk1	Figure 8. Sheriffs' offices using foot and bicycle patrols, 1997 and 2000
so00f09.wk1	Figure 9. Sheriffs' offices participating in a 9-1-1 emergency telephone system, 1990 and 2000
so00f10.wk1	Figure 10. Drug asset forfeiture receipts of sheriffs' offices, by size of agency, 1999
so00f11.wk1	Figure 11. Community policing plans of sheriffs' offices, 2000
so00f12.wk1	Figure 12. Percent of sheriffs' offices using full-time community policing officers, 1997 and 2000
so00f13.wk1	Figure 13. Groups that sheriffs' offices regularly met with to adress crime-related problems, 2000
so00f14.wk1 	Figure 14. Uses of citizen survey information by sheriffs' offices, 2000
so00f15.wk1	Figure 15. Sheriffs' offices requiring all regular field officer to wear protective armor, 1990 and 2000
so00f16.wk1	Figure 16. Sheriffs' offices authorizing officers to use chemical agents, 1990 and 2000
so00f17.wk1	Figure 17. Sheriffs' offices using computers for Internet access, 1997 and 2000
so00f18.wk1	Figure 18. Sheriffs' offices using in-field computers or terminals, 1990 and 2000
so00f19.wk1	Figure 19. Percent of sheriffs' deputies employed by a department providing officers with in-field computer access to information, 1997 and 2000
so00f20.wk1	Figure 20. Percent of sheriffs' offices transmitting criminal incident reports to their central information system primarily on paper, 1997 and 2000														
																	
In-text Boxes:

so00b01.wk1	In-text Box 1. Twenty-five largest sheriffs' offices, by number and function of full-time sworn personnel, 2000
											
