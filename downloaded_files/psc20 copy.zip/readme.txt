Prosecutors in State Courts, 2020   NCJ 309440
																
This zip archive contains tables in individual  .csv spreadsheets from
Prosecutors in State Courts, 2020   NCJ 309440. The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/prosecutors-state-courts-2020

This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=Prosecutors%20in%20State%20Courts
																
Filenames			Table titles
psc20t01.csv		Table 1. Attorneys employed in state prosecutor offices, by population served, 2020
psc20t02.csv		Table 2. Race and ethnicity of full-time attorneys in state prosecutor offices, by population served, 2020
psc20t03.csv		Table 3. Full-time non-attorney staff employed in state prosecutor offices, by population served, 2020
psc20t04.csv		Table 4. State prosecutor office operating expenditures, total, per office, and per prosecutor, by population served, 2020
psc20t05.csv		Table 5. Total number of felony matters reviewed by state prosecutor offices, by population served, 2020
psc20t06.csv		Table 6. Percent of state prosecutor offices that handled selected types of offenses, by population served, 2020
psc20t07.csv		Table 7. Percent of state prosecutor offices with written and unwritten policies for case processing practices and duties, by type of policy, 2020
psc20t08.csv		Table 8. Percent of state prosecutor offices directly providing and referring victims to victim services, by type of service, 2020
psc20t09.csv		Table 9. National Survey of Prosecutors sampling strata, 2020
psc20t10.csv		Table 10. National Survey of Prosecutors response rates, 2020
		
				Figures
psc20f01.csv		Figure 1. Number of attorneys employed in state prosecutor offices, by population served, 2020
psc20f02.csv		Figure 2. Sex of full-time attorneys in state prosecutor offices, by population served, 2020
psc20f03.csv		Figure 3. Number of staff in state prosecutor offices, 1992–2020
psc20f04.csv		Figure 4. Felony case outcomes reported by state prosecutor offices, by population served, 2020
		
				Appendix tables
psc20at01.csv		Appendix table 1. Estimates and standard errors for figure 1: Number of attorneys employed in state prosecutor offices, by population served, 2020; and table 1: Attorneys employed in state prosecutor offices, by population served, 2020
psc20at02.csv		Appendix table 2. Standard errors for table 2: Race and ethnicity of full-time attorneys in state prosecutor offices, by population served, 2020
psc20at03.csv		Appendix table 3. Estimates and standard errors for figure 2: Sex of full-time attorneys in state prosecutor offices, by population served, 2020
psc20at04.csv		Appendix table 4. Standard errors for table 3: Full-time non-attorney staff employed in state prosecutor offices, by population served, 2020
psc20at05.csv		Appendix table 5. Totals for figure 3: Number of staff in state prosecutor offices, 1992–2020
psc20at06.csv		Appendix table 6. Standard errors for table 4. State prosecutor office operating expenditures, total, per office, and per prosecutor, by population served, 2020
psc20at07.csv		Appendix table 7. Standard errors for table 5: Total number of felony matters reviewed by state prosecutor offices, by population served, 2020
psc20at08.csv		Appendix table 8. Standard errors for table 6:  Percent of state prosecutor offices that handled selected types of offenses, by population served, 2020
psc20at09.csv		Appendix table 9. Estimates and standard errors for figure 4: Felony case outcomes reported by state prosecutor offices, by population served, 2020
psc20at10.csv		Appendix table 10. Standard errors for table 7: Percent of state prosecutor offices with written and unwritten policies for case processing practices and duties, by type of policy, 2020
psc20at11.csv		Appendix table 11. Standard errors for table 8: Percent of state prosecutor offices directly providing and referring victims to victim services, by type of service, 2020
