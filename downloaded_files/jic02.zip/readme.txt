Jails in Indian Country, 2002, NCJ 198997

This zip archive contains tables in individual .wk1 spreadsheets
from Jails in Indian Country, 2002, NCJ 198997
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jic02.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic


File name		Table           	Title
jic0201.wk1		Table 1 Indian country jail inmate characteristics, midyear 2001-2002				
jic0202.wk1		Table 2 Ten largest jails in Indian country, June 28, 2002
jic0203.wk1		Table 3 Jails in Indian country operating above 150% capacity on the peak day during June 2002															
jic0204.wk1		Table 4 	Staff characteristics of jails in Indian country, June 28, 2002				
jic02a01.wk1	Appendix table 1 	Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 2002	
jic02a02.wk1	Appendix table 2 	Adults and juveniles in the custody of jails in Indian country, by gender and conviction status, June 28, 2002		
jic02a03.wk1	Appendix table 3 	Inmates in jails in Indian country, by seriousness of offense and type of offense, June 28, 2002
jic02h01.wk1	Highlights table 1  Persons under Indian country correctional supervision and inmate admissions, midyear 2001-2002 
jic02h02.wk1	Highlights table 2	Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 1998 and 2000-2002
jic02h03.wk1	Highlights table 3	Inmates in jails in Indian country, by type of offense, type of offense, June 28, 2002
jic02t01.wk1	Text table 1  	American Indians and Alaska Natives under correctional supervision in the United States 
jic02t02.wk1	Text table 2	Persons under community supervision in Indian country, midyear 2001-2002 
jic02t03.wk1	Text table 3	Indian country jail inmate admissions and reported suicides
jic02t04.wk1	Text table 4	Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 1998 and 2000-2002
jic02t05.wk1	Text table 5	Percent of capacity occupied on peak day in June 2002 by rated capacity of facility  
jic02f01.wk1	Figure 1  Inmate population on the last weekday of each month between June 29, 2001 and June 28, 2002