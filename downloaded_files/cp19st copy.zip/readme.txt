Capital Punishment, 2019 - Statistical Tables  NCJ 300381	
	
This zip archive contains tables in individual .csv spreadsheets	
from Capital Punishment, 2019 - Statistical Tables  NCJ 300381	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/capital-punishment-2019-statistical-tables	
	
These statistical tables are in a series.  More recent editions	
may be available. To view a list of all reports in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Capital%20Punishment	
	
Filenames	Table titles
cp19stt01.csv	Table 1. Status of the death penalty, December 31, 2019
cp19stt02.csv	Table 2. Capital offenses, by state, 2019
cp19stt03.csv	Table 3. Federal capital offenses, 2019
cp19stt04.csv	Table 4. Authorized method of execution, by state, 2019
cp19stt05.csv	Table 5. Prisoners under sentence of death, by region, jurisdiction, and race, 2018 and 2019
cp19stt06.csv	Table 6. Demographic characteristics of prisoners under sentence of death, 2019
cp19stt07.csv	Table 7. Female prisoners under sentence of death, by region, jurisdiction, and race, 2018 and 2019
cp19stt08.csv	Table 8. Hispanic prisoners under sentence of death, by region and jurisdiction, 2018 and 2019
cp19stt09.csv	Table 9. Criminal history of prisoners under sentence of death, by race or ethnicity, 2019
cp19stt10.csv	Table 10. Prisoners under sentence of death on December 31, 2019, by year of sentencing
cp19stt11.csv	Table 11. Prisoners removed from under sentence of death, by region, jurisdiction, and method of removal, 2019
cp19stt12.csv	Table 12. Average elapsed time between sentencing and execution, 1977–2019
cp19stt13.csv	Table 13. Number of prisoners executed, by race or ethnicity, 1977–2019
cp19stt14.csv	Table 14. Number of executions, by method and jurisdiction, 1977–2019
cp19stt15.csv	Table 15. Number of executions, by jurisdiction, 1930–2019 and 1977–2019
	
		Figures
cp19stf01.csv	Figure 1. Number of prisoners under sentence of death, 1953–2019
cp19stf02.csv	Figure 2. Admissions to and removals from under sentence of death, 1973–2019
cp19stf03.csv	Figure 3. Number of prisoners executed under civil authority in the United States, 1930–2019
cp19stf04.csv	Figure 4. Number of prisoners under sentence of death, by race, 1968–2019
cp19stf05.csv	Figure 5. Advance count of executions, January 1, 2020–December 31, 2020
	
		Appendix tables
cp19stat01.csv	Appendix table 1. Demographic characteristics for prisoners under sentence of death, 2019
cp19stat02.csv	Appendix table 2. Counts for figure 1: Number of prisoners under sentence of death, 1953–2019
cp19stat03.csv	Appendix table 3. Counts for figure 2: Admissions to and removals from under sentence of death, 1973–2019
cp19stat04.csv	Appendix table 4. Counts for figure 3: Number of prisoners executed under civil authority in the United States, 1930–2019
cp19stat05.csv	Appendix table 5. Counts for figure 4: Number of prisoners under sentence of death, by race, 1968–2019
