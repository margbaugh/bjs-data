Federal Justice Statistics, 2013-14 NCJ 249149

This zip archive contains tables in individual .csv spreadsheets		
from Federal Justice Statistics, 2013-14 NCJ 249149.
The full report including text and graphics in .pdf format is available at		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5885

This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=62			

File name		Table number
fjs1314t01.csv	    Table 1. Offenders in federal confinement or under federal supervision in the community, 2010, 2013, and 2014
fjs1314t02.csv      Table 2. Federal arrests by most serious offense and federal district, 2010, 2013, and 2014
fjs1314t03.csv      Table 3. Federal arrests and individual suspects arrested, by most serious offense and federal district, 2014
fjs1314t04.csv      Table 4. Demographic characteristics of Drug Enforcement Administration arrestees, by type of drug, 2014
fjs1314t05.csv      Table 5. Suspects in matters opened by U.S. attorneys, by referring authority, 2001, 2012, 2013, and 2014
fjs1314t06.csv      Table 6. Suspects in matters referred to U.S. attorneys, by offense type and federal district of referral, 2010, 2013, and 2014
fjs1314t07.csv      Table 7. Suspects in matters referred to U.S. attorneys, by offense type, 2014
fjs1314t08.csv      Table 8. Outcome and case processing time of suspects in matters concluded, 2014
fjs1314t09.csv      Table 9. Outcomes of suspects in matters concluded by Department of Homeland Security and Department of Justice, 2014
fjs1314t10.csv      Table 10. Defendants detained at any time prior to case termination, 2014
fjs1314t11.csv      Table 11. Defendants in cases filed in U.S. district court, by offense type and district, 2012, 2013, and 2014
fjs1314t12.csv      Table 12. Defendants in cases filed in U.S. district court, by offense type, 2014
fjs1314t13.csv      Table 13. Demographic characteristics of federal defendants in cases charged in U.S. district court, by sex of defendant, 2014
fjs1314t14.csv      Table 14. Disposition and case processing time of defendants in cases terminated in U.S. district court, 2014
fjs1314t15.csv      Table 15. Disposition and sentence received for defendants in cases terminated in U.S. district court, 2010, 2013, and 2014
fjs1314t16.csv      Table 16. Defendants in cases terminated in U.S. district court, by type of counsel and district, 2014
fjs1314t17.csv      Table 17. Defendants in cases ending in conviction and sentence to a federal prison term, by type of offense, 2010 and 2014
fjs1314t18.csv      Table 18. Demographic characteristics of federally sentenced offenders in the custody of the Federal Bureau of Prisons, 2004, 2013, and 2014
fjs1314t19.csv      Table 19. Demographic characteristics of offenders under post-conviction federal supervision, 2014
fjs1314t20.csv      Table 20. Demographic characteristics of offenders returning to federal prison within 3 years of release from a U.S. district court commitment, 2012
fjs1314t21.csv      Table 21. Offenders returning to federal prison within 3 years of release from a U.S. district court commitment, by offense characteristics, 2012


File name		Figure number
fjs1314f01.csv	    Figure 1. Suspects and defendants processed in the federal justice system, 1994�2014
fjs1314f02.csv	    Figure 2. Arrests and individual suspects arrested, 1994�2014
fjs1314f03.csv	    Figure 3. Federal immigration arrests and individual immigration suspects arrested, 1994-2014
fjs1314f04.csv	    Figure 4. Federal sex offense arrests and individual sex offense suspects arrested, 1994-2014
fjs1314f05.csv	    Figure 5. Federal drug offense arrests and individual drug offense suspects arrested, 1994-2014
fjs1314f06.csv	    Figure 6. Federal and state arrests by the DEA, suspects referred by the DEA to U.S. attorneys, and DEA suspects prosecuted in U.S. district court, 1995�2014
fjs1314f07.csv	    Figure 7. Federal and state arrests by the Drug Enforcement Administration, by drug type,1995�2014
fjs1314f08.csv	    Figure 8. Females arrested by the Drug Enforcement Administration, by race and Hispanic origin, 1995�2014
fjs1314f09.csv	    Figure 9. Males arrested by the Drug Enforcement Administration, by race and Hispanic origin, 1995�2014
fjs1314f10.csv	    Figure 10. Federal weapons offense arrests and individual weapons offense suspects arrested, 1994�2014
fjs1314f11.csv	    Figure 11. Federal arrests for a supervision violation and individual supervision violation suspects arrested, 1994�2014
fjs1314f12.csv	    Figure 12. Matters referred and suspects in matters referred to U.S. attorneys, 1994�2014
fjs1314f13.csv	    Figure 13. Drug offense matters referred and suspects in drug matters referred to U.S. attorneys, 1994�2014
fjs1314f14.csv	    Figure 14. Fraud offense matters referred and suspects in fraud matters referred to U.S. attorneys, 1994�2014
fjs1314f15.csv	    Figure 15. Median days from matter referral to prosecutor decision for case handling, 1994�2014             
fjs1314f16.csv	    Figure 16. Criminal cases filed and individual defendants in cases filed in U.S. district court, 1994�2014
fjs1314f17.csv	    Figure 17. Defendants in cases filed in U.S. district court, by most serious offense, 1994�2014
fjs1314f18.csv	    Figure 18. Nationality of non-U.S. citizens charged in U.S.district court, 2012�2014
fjs1314f19.csv	    Figure 19. Median days from felony case filing to case termination, by mode of disposition, 1994�2014
fjs1314f20.csv	    Figure 20. Defendants in criminal cases terminated in U.S. district court, by type of representation, 1994�2014
fjs1314f21.csv	    Figure 21. Median prison sentence imposed, by most serious felony offense at sentencing, 1994�2014
fjs1314f22.csv	    Figure 22. Prisoners in the custody of the Federal Bureau of Prisons, by most serious commitment offense, 2004 and 2014
fjs1314f23.csv	    Figure 23. Offenders under federal supervision, by type of offense,2004 and 2014
fjs1314f24.csv	    Figure 24. Offenders returning to federal prison after release from a U.S. district court commitment, by year of release and time to return, 1998�2014
fjs1314f25.csv	    Figure 25. Offenders returned to federal prison within 3 years of release in 2012 from U.S. district court commitment, by age at release






