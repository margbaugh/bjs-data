Aviation units in Large Law Enforcement Agencies, 2007.		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Aviation Units in Large Law Enforcement Agencies, 2007 NCJ 226672		
The full report including text and graphics in pdf format are available at:              		
http://www.ojp.usdoj.gov/bjs/abstract/aullea07.htm          		
		
		
aullea07f01.csv		Figure 1. Select operations performed by aviation units, 2007
aullea07f02.csv		Figure 2. Functions performed by aviation units operating planes
aullea07f03.csv		Figure 3. Functions performed by aviation units operating helicopters
aullea07f04.csv		Figure 4. Median number of personnel employed by or assigned to aviation units, by type of unit, 2007
aullea07f05.csv		Figure 5. Median number of personnel employed by or assigned to aviation units, by type of agency, 2007
aullea07f06.csv		Figure 6. Median number of aviation unit personnel per aircraft operated, by type of agency, 2007
		
aullea07t01.csv		Table 1. Law enforcement agencies with 100 or more sworn personnel and aviation units, by agency type and size, 2007
aullea07t02.csv		Table 2. Characteristics of law enforcement aviation units in law enforcement agencies with 100 or more sworn officers, 2007
aullea07t03.csv		Table 3. Aircraft operated by aviation units, by type of agency, 2007
aullea07t04.csv		Table 4. Median expenditures for aircraft by expense, by type of agency, and type and number of aircraft, 2007
aullea07t05.csv		Table 5. Method of aircraft acquisition, by type of agency and aircraft, 2007
aullea07t06.csv		Table 6. Average age of aircraft operated by aviation law enforcement units, by type of agency, 2007
aullea07t07.csv		Table 7. Aviation units with specialized aircraft equipment, by type of agency, 2007
aullea07t08.csv		Table 8. Median number of flight hours and missions flown, by type of law enforcement agency, 2007
aullea07t09.csv		'Table 9. General law enforcement operations, by type of aviation activity, 2007
aullea07t10.csv		Table 10. Special law enforcement operations, by type of aviation activity, 2007
aullea07t11.csv		Table 11. Law enforcement aviation unit personnel, by position title, 2007
aullea07t12.csv		Table12. Pilot and pilot candidate qualifications, by type of law enforcement agency, 2007
aullea07t13.csv		Table 13. License and rating requirements for pilot in command (PIC), by type of law enforcement aircraft, 2007
aullea07t14.csv		Table14.  Pilot training provided by law enforcement agencies, by type and frequency, 2007
aullea07t15.csv		Table 15. Aviation unit safety measures, by type of law enforcement agency, 2007
		
aullea07tt01.csv		Text table 1. Type of aviation unit, by type of law enforcement agency, 2007
aullea07tt02.csv		Text table 2. Fuel and maintenance expenditures adjusted by number of flight hours
aullea07tt03.csv		Text table 3. Aviation units that obtained aircraft during 2007 and number of aircraft obtained, by type of agency
aullea07tt04.csv		Text table 4: Median number of flight hours logged per aviation unit mission, by type of agency, 2007
aullea07tt05.csv		Text table 5. Percent of units employing a certified flight instrutor (CFI), by type of agency, 2007
aullea07tt06.csv		Text table 6. Percent of aviation units or agencies paying for pilot training, by type of training, 2007
aullea07tt07.csv		Text table 7. Accidents involving aircraft used by law enforcement aviation units
		
aullea07btt01.csv		Box text table 1. Functions performed by multi-craft units, by type of aircraft used, 2007
		
aullea07at01.csv		Appendix table 1. Law enforcement agencies with 100 or more sworn personnel and aviation units, by state and unit characteristics, 2007
aullea07at02.csv		Appendix table 2. Types and numbers of aircraft operated, by type of law enforcement agency, 2007
aullea07at03.csv		Appendix table 3. Number of aircraft operated by aviation units, by type of agency, 2007
aullea07at04.csv		Appendix table 4. Activities engaged in by law enforcement aviation units, 2007
aullea07at05.csv		Appendix table 5. Agencies that reported operating a plane or helicopter in the 2007 LEMAS survey but were not included in the CLEAU
