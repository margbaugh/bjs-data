Census of State and Local Law Enforcement Agencies, 2004					

This zip archive contains tables in individual .csv spreadsheets from Census of State and Local Law Enforcement Agencies, 2004, NCJ 212749. The full report including text and graphics in .pdf format are available from 
http://www.ojp.usdoj.gov/bjs/abstract/csllea04.htm					

File name					
			Table Number		
csllea04t01.csv		Table 1. Employment by State and local law enforcement agencies, by type of agency and employee, September 2004			
csllea04t02.csv		Table 2. State and local law enforcement employees, by size of agency, September 2004			
csllea04t03.csv		Table 3. Change in full-time employment by State and local law enforcement agencies, 1992-2004			
csllea04t04.csv		Table 4. Full-time local police employees, by size of agency, September 2004			
csllea04t05.csv		Table 5. Sheriffs' employees, by size of agency, September 2004			
csllea04t06.csv		Table 6. Primary State law enforcement agency employees, by State, September 2004			
csllea04t07.csv		Table 7. Special jurisdiction law enforcement agencies, by type of jurisdiction and number of full-time sworn personnel, September 2004			
csllea04t08.csv		Table 8. Thirty largest State and local law enforcement agencies with special jurisdictions, by number of full-time sworn personnel, September 2004			

			Figures
csllea04f01.csv		Figure 1. State and local law enforcement employees and number of UCR violent crimes, 2000-2004	
csllea04f02.csv		Figure 2. Number of full-time State and local law enforcement employees and UCR violent crimes, per 100,000 residents, 1992-2004	
csllea04f03.csv		Figure 3. Full-time employees in local police departments, 1992-2004	
csllea04f05.csv		Figure 4. Full-time employees in sheriffs' offices, 1992-2004	
csllea04f05.csv		Figure 5. Full-time employees in primary State law enforcement agencies, 1992-2004	

			Text Tables
csllea04tt01.csv	Text Table 1. Type of local police departments, 2004		
csllea04tt02.csv	Text Table 2. Five largest sheriffs' offices, 2004		
csllea04tt03.csv	Text Table 3. Primary State law enforcement agencies, by number of full-time sworn personnel, 2004		
csllea04tt04.csv	Text Table 4. Ten largest transit system law enforcement agencies, 2004		
csllea04tt05.csv	Text Table 5. Ten largest airport law enforcement agencies, 2004		

			Box Text Tables
csllea04boxtt01.csv	Box Text Table 1. Comparison of CSLLEA  and UCR, 1992-2004		

			Highlights
csllea04h1.csv		Highlight 1. State and Local law enforcement agencies added fewer officers from 2000 to 2004 than in prior 4-year periods	

			Appendix Tables
csllea04ap01.csv	Appendix Table 1. State and local law enforcement agencies and employees, by State, September 2004		
csllea04ap02.csv	Appendix Table 2. Fifty largest State and local law enforcement agencies, by number of full-time sworn personnel, September 2004		
csllea04ap03.csv	Appendix Table 3. Local police departments and employees, by State, September 2004		
csllea04ap04.csv	Appendix Table 4. Fifty largest local police departments, by number of full-time sworn personnel, September 2004		
csllea04ap05.csv	Appendix Table 5. Sheriffs' offices and employees, by State, September 2004		
csllea04ap06.csv	Appendix Table 6. Fifty largest sheriffs' offices, by number of full-time sworn personnel, September 2004		
