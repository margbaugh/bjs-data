BACKGROUND CHECKS FOR FIREARM TRANSFERS, 2001 NCJ 195235																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .wk1 spreadsheets from the
Firearm Inquiry Statistics (FIST) program Bulletin, "Background Checks for
Firearm Transfers, 2001" NCJ 195235. The full report including text and 
graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/bcft01.htm 

This report is one in a series.  Most recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#bcft
----------------------------------------------------------------------------
																	
Filename		Table																
																	
bcft01h1.wk1	Highlights Table 1. Background checks of applications for firearm transfers since implementation of the Brady Act

bcft0101.wk1	Table 1. Number of applications and estimates of rejections for firearm transfer, 1994-2001	
bcft0102.wk1	Table 2. FIST estimates, by type of agency and approval system and total FBI checks, 2001		
bcft0103.wk1	Table 3. Number of firearm purchase applications received and rejected by State agencies, 2000-2001	
bcft0104.wk1	Table 4. Reasons for rejection of firearm transfer applications, 1996-2001	
bcft0105.wk1	Table 5. Trends in applications, rejections, and reasons for rejection since the beginning of the Brady Act, among all agencies conducting such checks, 1994-2001	
bcft0106.wk1	Table 6. Appeals of denied applications, 2001

bcft01t1.wk1	Text Table 1. Applications and rejections by State agencies issuing exemptions and reporting to FIST
bcft01t2.wk1	Text Table 2. Local rejection rates by population served and by type of permit, 2001
bcft01t3.wk1	Text Table 3. Notification procedures of State points of contact (POC's) regarding denied persons subject to arrest, 2001
bcft01t4.wk1	Text Table 4. Number of arrests reported by States providing arrest data in 2001

bcft01aa.wk1	Appendix Table A. National Instant Criminal Background Check System: Checking agencies - FBI or State point of contact - for firearm transfers, 2001
bcft01ab.wk1	Appendix Table B. State and local agencies conducting background checks for firearm applications, 2001


