Sexual Victimization Reported by Adult Correctional Authorities, 2019–2020 – Statistical Tables   NCJ 308553	
	
This zip archive contains tables in individual .csv spreadsheets	
from Sexual Victimization Reported by Adult Correctional Authorities, 2019–2020 – Statistical Tables   NCJ 308553	
The full report including text and graphics in pdf format is available from 	
https://bjs.ojp.gov/library/publications/sexual-victimization-reported-adult-correctional-authorities-2019-2020	
	
This report is one in a series.  More recent editions	
may be available. To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Publications	
	
Filenames		Table titles
svraca1920stt01.csv	Table 1. Number and rate per 1,000 inmates of allegations of sexual victimization, by type of facility, 2013–2020 
svraca1920stt02.csv	Table 2. Number and rate per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2013–2020 
svraca1920stt03.csv	Table 3. Outcomes of investigations into allegations of sexual victimization, by year and type of facility, 2019 and 2020 
svraca1920stt04.csv	Table 4. Substantiated incidents of sexual victimization, by type of victimization, 2013–2020
svraca1920stt05.csv	Table 5. Substantiated incidents involving single or multiple victims or perpetrators, by type of victimization, 2019–20
svraca1920stt06.csv	Table 6. Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt07.csv	Table 7. Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stt08.csv	Table 8. Demographic characteristics of victims in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt09.csv	Table 9. Demographic characteristics of perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt10.csv	Table 10. Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt11.csv	Table 11. Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stt12.csv	Table 12. Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt13.csv	Table 13. Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stt14.csv	Table 14. Demographic characteristics of victims in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt15.csv	Table 15. Demographic characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt16.csv	Table 16. Employment characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt17.csv	Table 17. Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stt18.csv	Table 18. Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stt19.csv	Table 19. Sexual victimization incidents reported by federal and state prison authorities, by type of inmate-on-inmate victimization, 2019
svraca1920stt20.csv	Table 20. Sexual victimization incidents reported by federal and state prison authorities, by type of staff-on-inmate victimization, 2019
svraca1920stt21.csv	Table 21. Sexual victimization incidents reported by federal and state prison authorities, by type of inmate-on-inmate victimization, 2020
svraca1920stt22.csv	Table 22. Sexual victimization incidents reported by federal and state prison authorities, by type of staff-on-inmate victimization, 2020
	
			Figures
svraca1920stf01.csv	Figure 1. Allegations and substantiated incidents of sexual victimization in adult correctional facilities, 2005–2020
svraca1920stf02.csv	Figure 2. Allegations of sexual victimization in adult correctional facilities, by outcome of investigation, 2013–2020
svraca1920stf03.csv	Figure 3. Allegations of sexual victimization in adult correctional facilities, by type of victimization, 2013–2020
	
			Appendix tables
svraca1920stat01.csv	Appendix table 1. Summary of sampled facilities, by type and status, 2019 and 2020
svraca1920stat02.csv	Appendix table 2. Nonresponding adult correctional facilities, by state, 2019 and 2020
svraca1920stat03.csv	Appendix table 3. Numbers, rates, and standard errors for figure 1: Allegations and substantiated incidents of sexual victimization in adult correctional facilities, 2005–2020
svraca1920stat04.csv	Appendix table 4. Estimates and standard errors for figure 2: Allegations of sexual victimization in adult correctional facilities, by outcome of investigation, 2013–2020
svraca1920stat05.csv	Appendix table 5. Estimates and standard errors for figure 3: Allegations of sexual victimization in adult correctional facilities, by type of victimization, 2013–2020
svraca1920stat06.csv	Appendix table 6. Standard errors for table 1: Number and rate per 1,000 inmates of allegations of sexual victimization, by type of facility, 2013–2020 
svraca1920stat07.csv	Appendix table 7. Standard errors for table 2: Number and rate per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2013–2020
svraca1920stat08.csv	Appendix table 8. Standard errors for table 3: Outcomes of investigations into allegations of sexual victimization, by year and type of facility, 2019 and 2020 
svraca1920stat09.csv	Appendix table 9. Standard errors for table 4: Substantiated incidents of sexual victimization, by type of victimization, 2013–2020
svraca1920stat10.csv	Appendix table 10. Standard errors for table 5: Substantiated incidents involving single or multiple victims or perpetrators, by type of victimization, 2019–20
svraca1920stat11.csv	Appendix table 11. Standard errors for table 6: Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat12.csv	Appendix table 12. Standard errors for table 7: Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stat13.csv	Appendix table 13. Standard errors for table 8: Demographic characteristics of victims in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat14.csv	Appendix table 14. Standard errors for table 9: Demographic characteristics of perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat15.csv	Appendix table 15. Standard errors for table 10: Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat16.csv	Appendix table 16. Standard errors for table 11: Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stat17.csv	Appendix table 17. Standard errors for table 12: Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat18.csv	Appendix table 18. Standard errors for table 13: Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2019–20
svraca1920stat19.csv	Appendix table 19. Standard errors for table 14: Demographic characteristics of victims in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat20.csv	Appendix table 20. Standard errors for table 15: Demographic characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat21.csv	Appendix table 21. Standard errors for table 16: Employment characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat22.csv	Appendix table 22. Standard errors for table 17: Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2019–20
svraca1920stat23.csv	Appendix table 23. Standard errors for table 18: Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2019–20