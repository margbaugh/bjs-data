Victimas Hispanas de Crimenes Violentos, 1993-2000 NCJ 191208

El nombre      Titulo del Cuadro 
del archivo    

vhcv0001.wk1      Cuadro 1.  Numero e indice de victimizaciones violentas, por tipo de crimen, raza, y origen hispano, 2000. 
vhcv0002.wk1      Cuadro 2.  Indice de crimenes violentos, por origen hispano, raza, sexo, edad, estado civil, ingreso familiar anual, y lugar de residencia, 1993-2000.
vhcv0003.wk1      Cuadro 3.  Relacion de la victima con el delincuente violento, por raza y origen hispano de la victima, 1993-2000.
vhcv0004.wk1      Cuadro 4.  Presencia y tipo de armas, por raza y origen hispano de la victima, 1993-2000.
vhcv0005.wk1      Cuadro 5.  Herida resultante del crimen y tratamiento de dicha herida, por raza y origen hispano de la victima, 1993-2000. 
vhcv0006.wk1      Cuadro 6. Percepcion por parte de la victima del uso de drogas or alcohol por parte del delincuente, por raza y origen hispano de la victima, 1993-2000.
vhcv0007.wk1      Cuadro 7.  Denuncia policial del crimen violento, por raza y origen hispano de la victima, 1993-2000.
vhcv0008.wk1.     Cuadro 8. Porcentaje de crimenes violentos contra victimas hispanas denunciados a la policia, por caracteristicas de las victimas, 1993-2000.
vhcv0009.wk1.     Cuadro 9.  Razones para no notificar los crimenes violentos a la policia, por raza y origen hispano de la victima, 1993-2000.
vhcv00app.wk1     Cuardro apendice.  Indices de victimizaciones violentas cada 1,000 hispanos, por sexo, edad, estado civil, ingreso familiar anual, y lugar de residencia, 1993-2000. 
vhcv00hlfig.wk1   El indice de crimenes violentos contra los hispanos cayo un 56% desde el ano 1993 hasta el 2000.  El indice de crimenes contra blancos disminuyo un 50% , y contra negros, un 51%.
vhcv00fig1.wk1   Indice de victimizaciones violentas cada 1.000 hispanos en areas urbanas, suburbanas y rurales.
vhcv00fig2.wk1   Indice de victimizaciones violentas cada 1.000 hispanos y estado civil.
vhcv00fig3.wk1   Indice de victimizaciones violentas cada 1.000 hispanos y edades.
