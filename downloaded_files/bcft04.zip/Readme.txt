Background Checks for Firearm Transfers, 2004 (NCJ 210117)																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .csv spreadsheets from the
Firearm Inquiry Statistics (FIST) program Bulletin, "Background Checks for
Firearm Transfers, 2004" NCJ 210117.  The full report including text and 
graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/bcft04.htm 

This report is one in a series.  Most recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#bcft
----------------------------------------------------------------------------
																	
Filename		Table																
																	
bcft04h1.csv	Highlights Table 1. Background checks of applications for firearm transfers since implementation of the Brady Act

bcft0401.csv	Table 1. Number of applications and estimates of rejections for firearm transfer, 1994-2004	
bcft0402.csv	Table 2. FIST estimates, by type of agency and approval system and total FBI checks, 1999-2004
bcft0403.csv	Table 3. Rejection rates for selected FBI states, 1999-2004		
bcft0404.csv	Table 4. Number of firearm purchase applications received and rejected by State agencies, 1999-2004
bcft0405.csv	Table 5. Reasons for rejection of firearm transfer applications, 1999-2004
bcft0406.csv	Table 6. Trends in applications, rejections, and reasons for rejection under permanent provisions of the Brady Act, among all agencies conducting such checks, 1999-2004		
bcft0407.csv	Table 7. Appeals of denied applications, 2004	
bcft0408.csv	Table 8. Number of appeals reported, by type of agency, 1999-2004
bcft0409.csv	Table 9. Notification procedures of State points of contact (POC's) regarding denied persons subject to arrest, 2004
bcft0410.csv	Table 10. Number of arrests reported, by type of agency, 1999-2004

bcft04t1.csv	Text Table 1. Applications and rejections for exemptions reported by State agencies to FIST
bcft04t2.csv	Text Table 2. Local rejection rates by population served and by type of permit, 1999-2004
bcft04t3.csv	Text Table 3. Local and State reasons for rejection, 1999-2004
bcft04t4.csv	Text Table 4. Number of arrests reported by States providing arrest data in 2004

