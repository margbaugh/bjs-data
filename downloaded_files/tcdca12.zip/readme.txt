Tribal Crime Data Collection Activities, 2012  NCJ 239077		
 		
This zip archive contains tables in individual .csv spreadsheets from 		
Tribal Crime Data Collection Activities, 2012  NCJ 239077		
The full report including text and graphics in pdf format		
are available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4493		
		
		
tcdca12t01.csv		Table 1 . American Indian and Alaska Native population, by Hispanic/Latino origin, 2010
tcdca12t02.csv		Table 2. American Indians and Alaska Natives reporting tribal affiliation, by race, 2010 
tcdca12t03.csv		Table 3. U.S. population living on and off American Indian reservations and Alaska Native villages, 2010
tcdca12t04.csv		Table 4. Resident population of the 20 largest American Indian reservations and Alaska Native villages, by race, 2010
tcdca12t05.csv		Table 5. Full-time equivalent sworn tribal law enforcement officers in the 20 largest tribal police departments, 2008 
tcdca12t06.csv		Table 6. Federally recognized tribes that completed BJS-sponsored training on the FBI's Uniform Crime Reporting (UCR) Program, 2009?2010
tcdca12t07.csv		Table 7. Violent and property crime reported by tribal law enforcement agencies to the FBI?s UCR Program, 2008?2010
tcdca12t08.csv		Table 8. American Indian tribes that received Edward Byrne Memorial Justice Assistance Grant (JAG) awards, 2008?2011
tcdca12t09.csv		Table 9. Suspects in matters investigated by U.S. Attorneys, by offense, 2010
tcdca12t10.csv		Table 10. Defendants in criminal cases filed in U.S. district courts, by type of offense, 2010
		
tcdca12f01.csv		Figure 1. Total Edward Byrne Memorial Justice Assistance Grant Allocations to American Indian tribes, 2008?2011
tcdca12f02.csv		Figure 2. American Indians and Alaska Natives affiliated with the 10 largest tribes, by race, 2010
tcdca12f04.csv		Figure 4. American Indians and Alaska Natives affiliated with the 10 largest tribes, by race, 2010
