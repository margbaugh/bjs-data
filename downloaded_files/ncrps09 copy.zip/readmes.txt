2009 National Corrections Reporting Program

This is one of a series of files from the National Corrections Reporting Program.  
All of the available files back to 1993 may be obtained from http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2174.

Three groups of tables -- sentence length, time served and most serious offense of state prisoners-- are archived for each year.

Data for 2009 for some states were estimated to provide continuity.

In addition to the list of tables in this file, the tables in the related archives are listed below.*

This Zip archive, Sentence length of state prisoners, NCJ 234204 contains the following tables:

File name           Contents

ncrp0906.csv        State prison admissions: sentence length by offense and admission type 
ncrp0909.csv        First releases from state prison: sentence length, time served, and percent of sentence served in prison, by offense
ncrp0910.csv        First releases from state prison: sentence length and time served in prison, by offense, and sex
ncrp0911.csv        First releases from state prison: sentence length and time served in prison, by offense, and race 
ncrp0915.csv        Successful first state parole discharges: sentence length and time served, by offense
ncrp0916.csv        Unsuccessful first state parole discharges: sentence length and time served, by offense

*Note:  Beginning in 1999, Table 7 (New court commitments to state prison: sentence length and minimum time to be served, by offense) was discontinued.  
               
Two related archives are also available.  The tables in these archives are listed below.

Time served in state prison, 2009 (NCJ 234202)

ncrp0908.csv        State prison releases: time served in prison, by offense and release type
ncrp0909.csv        First releases from state prison: sentence length, time served, and percent of sentence served, by offense
ncrp0910.csv        First releases from state prison: sentence length and time served in prison, by offense and sex
ncrp0911.csv        First releases from state prison: sentence length and time served in prison, by offense and race
ncrp0915.csv        Successful first state parole discharges: sentence length and time served, by offense
ncrp0916.csv        Unsuccessful first state parole discharges: sentence length and time served, by offense

Most serious offense of state prisoners (NCJ 234203)

ncrp0901.csv        State prison admissions: offense, by admission type
ncrp0902.csv        New court commitments to state prisons: offense, by age at admission
ncrp0903.csv        Parole violators returned to state prison: offense, by age at admission
ncrp0904.csv        New court commitments to state prisons: offense, by sex, race, and Hispanic origin
ncrp0905.csv        Parole violators returned to state prison: offense, by sex, race, and Hispanic origin
ncrp0912.csv        First entries to parole supervision from state prison: method of prison release, by offense
ncrp0913.csv        First entries to parole supervision from state prison: offense, by sex, race, and  Hispanic origin
ncrp0914.csv        State parole discharges: method of parole discharge, by offense
