Local Police Departments, 2007		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Local Police Departments, 2007 NCJ 231174		
The full report including text and graphics in pdf format is available at:              		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=1750		
		
This report is one in a series.  More recent editions may be available. To view a list of all in the series go to		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=35		
		
		
		
lpd07f01.csv		Figure 1. Per resident operating costs for local police departments, by size of population served, 2007
lpd07f02.csv		Figure 2. Local police officers employed by a department that used in-field computers, 1990-2007
lpd07f03.csv		Figure 3. Full-time employees of local police departments, 1987-2007
lpd07f04.csv		Figure 4. Per officer operating costs of local police departments, 2003 and 2007
lpd07f05.csv		Figure 5. Local police officers employed by a department using selected screening methods in the hiring process, 2003 and 2007
lpd07f06.csv		Figure 6. Training requirements for local police officer recruits, by size of population served, 2000, 2003, and 2007
lpd07f07.csv		Figure 7. Starting salaries for entry-level officers in local police departments, by size of population served and collective bargaining status, 2007
lpd07f08.csv		Figure 8. Local police officers employed by a department with selected workplace policies, 2007
lpd07f09.csv		Figure 9. Minority representation among local police officers, 1987-2007
lpd07f10.csv		Figure 10. Local police officers employed by a department with selected special population/situation policies, 2007
lpd07f11.csv		Figure 11. Local police departments using regularly scheduled foot or bicycle patrol, by size of population served, 1997-2007
lpd07f12.csv		Figure 12. Local police officers employed by a department with use-of-force policies and procedures, 2007
lpd07f13.csv		Figure 13. Use of conducted energy devices by local police departments, by size of population served, 2000, 2003, and 2007
lpd07f14.csv		Figure 14. Body armor requirements for field officers in local police departments, 1990-2007
lpd07f15.csv		Figure 15. Use of in-car video cameras by local police departments, by size of population served, 2000, 2003, and 2007
lpd07f16.csv		Figure 16. Local police departments using in-field computers or terminals, by size of population served, 1997-2007
lpd07f17.csv		Figure 17. Local police officers employed by a department providing in-field computer access to information, 1997-2007
lpd07f18.csv		Figure 18. Local police departments using electronic methods for transmitting criminal incident reports to a central information system, by size of population served, 1997-2007
lpd07f19.csv		Figure 19. Local police departments using full-time community policing officers, by size of population served,1997-2007
lpd07f20.csv		Figure 20. Local police officers employed by a department engaging in selected preparedness activities, 2007
		
lpd07t01.csv		Table 1. General purpose state and local law enforcement agencies, 2007
lpd07t02.csv		Table 2. Local police departments and full-time employees, by number of sworn personnel, 2007
lpd07t03.csv		Table 3. Local police departments and full-time employees, by size of population served, 2007
lpd07t04.csv		Table 4. Annual operating budget of local police departments, by size of population served, 2007
lpd07t05.csv		Table 5. Education requirements for new officers in local police departments, by size of population served, 2007
lpd07t06.csv		Table 6. Training requirements for new officer recruits in local police departments, by size of population served, 2007
lpd07t07.csv		Table 7. Average base annual salary for selected full-time positions in local police departments, by size of population served, 2007
lpd07t08.csv		Table 8. Workplace policies of local police departments, by size of population served, 2007
lpd07t09.csv		Table 9. Race and ethnicity of full-time sworn personnel in local police departments, by size of population served, 2007
lpd07t10.csv		Table 10. Gender of full-time sworn personnel in local police departments, by size of population served, 2007
lpd07t11.csv		Table 11. Emergency 9-1-1 system participation of local police departments, by size of population served, 2007
lpd07t12.csv		Table 12. Types of regularly scheduled patrols other than automobile used by local police departments, by size of population served, 2007
lpd07t13.csv		Table 13. Special population/situation policies of local police departments, by size of population served, 2007
lpd07t14.csv		Table 14. Less-than-lethal weapons authorized for use by a majority of local police departments, by size of population served, 2007
lpd07t15.csv		Table 15. Use-of-force policies and procedures in local police departments, by size of population served, 2007
lpd07t16.csv		Table 16. Body armor requirements for field officers in local police departments, by size of population served, 2007
lpd07t17.csv		Table 17. Motorized vehicles operated by local police departments, by size of population served, 2007
lpd07t18.csv		Table 18. Off-land vehicles operated by local police departments, by size of population served, 2007
lpd07t19.csv		Table 19. Use of animals by local police departments for law enforcement purposes, by size of population served, 2007
lpd07t20.csv		Table 20. Use of video cameras by local police departments, by size of population served, 2007
lpd07t21.csv		Table 21. General functions of computers in local police departments, by size of population served, 2007
lpd07t22.csv		Table 22. Analytic functions of computers in local police departments, by size of population served, 2007
lpd07t23.csv		Table 23. Use of in-field computers and terminals by local police departments, by size of population served, 2007
lpd07t24.csv		Table 24. Use of in-field computers for reports and communications by local police departments, by size of population served, 2007
lpd07t25.csv		Table 25. Types of computerized information accessible to in-field officers in local police departments, by size of population served, 2007
lpd07t26.csv		Table 26. Methods used by local police departments for transmitting criminal incident reports to a central information system, by size of population served, 2007
lpd07t27.csv		Table 27. Community policing policies of local police departments, by size of population served, 2007
lpd07t28.csv		Table 28. Community policing training for new officer recruits in local police departments, by size of population served, 2007
lpd07t29.csv		Table 29. Community-oriented policies for patrol officers in local police departments, by size of population served, 2007
lpd07t30.csv		Table 30. Community policing activities of local police departments, by size of population served, 2007
lpd07t31.csv		Table 31. Full-time community policing officers and units in local police departments, by size of population served, 2007
lpd07t32.csv		Table 32. Full-time school resource officers in local police departments, by size of population served, 2007
lpd07t33.csv		Table 33. Drug task force participation of local police departments, by size of population served, 2007
lpd07t34.csv		Table 34. Gang task force participation of local police departments, by size of population served, 2007
lpd07t35.csv		Table 35. Human trafficking task force participation of local police departments, by size of population served, 2007
lpd07t36.csv		Table 36. Anti-terrorism task force participation of local police departments, by size of population served, 2007
lpd07t37.csv		Table 37. Preparedness activities of local police departments, by size of population served, 2007
		
lpd07tt01.csv		Text Table 1. Average officer-to-resident ratio for municipal and township police departments, 2007
lpd07tt02.csv		Text Table 2. Use of community policing officers by local police departments, 1997-2007
lpd07tt03.csv		Text Table 3. Local police departments with a written terrorism response plan, by size of population served, 2007
lpd07tt04.csv		Text Table 4. Local police departments that use a shared radio network that achieves interoperability, by size of population served, 2007
		
lpd07at01.csv		Appendix Table 1. Fifty largest local police departments in the United States, by number of full-time sworn personnel, 2007
lpd07at02.csv		Appendix Table 2. Drug asset forfeiture receipts of local police departments, by size of population served, 2006
lpd07at03.csv		Appendix Table 3. Background and record check methods used in selection of new officer recruits in local police departments, by size of population served, 2007
lpd07at04.csv		Appendix Table 4. Personal attribute screening methods used in selection of new officer recruits in local police departments, by size of population served, 2007
lpd07at05.csv		Appendix Table 5. Physical attribute screening methods used in selection of new officer recruits in local police departments, by size of population served, 2007
lpd07at06.csv		Appendix Table 6. In-service training requirements for sworn personnel in local police departments, by size of population served, 2007
lpd07at07.csv		Appendix Table 7. Special pay and benefits for full-time sworn personnel in local police departments, by size of population served, 2007
lpd07at08.csv		Appendix Table 8. Local police officers assigned to respond to calls for service, by size of population served, 2007
lpd07at09.csv		Appendix Table 9. Wireless capabilities of emergency 9-1-1 systems in local police departments, by size of population served, 2007
lpd07at10.csv		Appendix Table 10. Types of sidearms authorized for use by sworn personnel in local police departments, by size of population served, 200
lpd07at11.csv		Appendix Table 11. Types of batons authorized for use by sworn personnel in local police departments, by size of population served, 2007
lpd07at12.csv		Appendix Table 12. Less-than-lethal weapons or actions authorized for use by fewer than half of local police departments, by size of population served, 2007
lpd07at13.csv		Appendix Table 13. Number of motorized land vehicles operated by local police departments and percent unmarked, by size of population served, 2007
lpd07at14.csv		Appendix Table 14. Vehicle use policies for sworn personnel in local police departments, by size of population served, 2007
lpd07at15.csv		Appendix Table 15. Automated fingerprint identification systems (AFIS) in local police departments, by size of population served, 2007
lpd07at16.csv		Appendix Table 16. Types of in-field computers or terminals used by local police departments, by size of population served, 2007
lpd07at17.csv		Appendix Table 17. Screening methods related to community policing used in selection of new officer recruits for local police departments, by size of population served, 2007
lpd07at18.csv		Appendix Table 18. Full-time intelligence personnel in local police departments with primary duties related to terrorist activities, by size of population served, 2007
lpd07at19.csv		Appendix Table 19. Item non-response for local police department data in the 2007 LEMAS survey
lpd07at20.csv		Appendix Table 20. Standard errors of the estimated percentages for local police departments, by size of population served , 2007
lpd07at21.csv		Appendix Table 21. Standard errors of the estimated personnel counts for local police departments, 2007
lpd07at22.csv		Appendix table 22. Standard errors for estimated operating budgets and starting salaries for entry-level officers in local police departments, 2007
