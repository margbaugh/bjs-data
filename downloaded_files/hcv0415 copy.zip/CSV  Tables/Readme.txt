"Hate Crime Victimization, 2004-2015"		
		
This zip archive contains tables in individual .csv spreadsheets		
"from Hate Crime Victimization, 2004-2015. NCJ 250653"		
The full report including text and graphics in .pdf format is available at		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=5967		
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=72		
		
File name		Table number
hcv0415t01.csv		"Hate crime victimization, 2004�2015"
hcv0415t02.csv      	"Victims' evidence that a hate crime occurred, 2011�2015"
hcv0415t03.csv      	"Hate and nonhate crime victimization, by type of crime, 2011�2015"
hcv0415t04.csv      	"Presence of weapons and injuries sustained in violent hate and nonhate crime victimization, 2006�2015"
hcv0415t05.csv      	"Hate and nonhate crime victimization, by location, 2011�2015"
hcv041506.csv      	"Police-related actions taken in hate and nonhate crime victimization, 2011�2015"
hcv0415t07.csv      	"Most important reason why victimization was not reported to police, 2011�2015"
hcv0415t08.csv      	"Characteristics of violent crime victims, 2011�2015"
hcv0415t09.csv     	"Region and location of residence of violent hate crime victims, 2011�2015"
hcv0415t10.csv      	"Characteristics of violent offenders as reported by victims of hate and nonhate crime victimization, 2011�2015"
hcv0415t11.csv      	"Hate crime victimization recorded by the NCVS and UCR, by offense, 2003�2015"
		
File name		Figures
hcv0415f1.csv      	"Violent hate crime victimization reported and not reported to police, 2004�2015"
hcv0415f2.csv      	"Victim�s perception of bias in hate crime victimization, 2011�2015"
hcv0415f3.csv     	"Victims� perception of bias in hate crime victimization, 2007�2015"
hcv0415f4.csv      	"Type of crime experienced in hate and nonhate violent victimization, 2011�2015"
hcv0415f5.csv      	"NCVS and UCR hate crime victimizations, 2003�2015"
		
File name		Appendix tables
hcv0415at01.csv		"Estimates and standard errors for figure 1: Violent hate crime victimization reported and not reported to police, 2004�2015"
hcv0415at02.csv		"Standard errors for table 1: Hate crime victimization, 2004�2015"
hcv0415at03.csv		"Standard errors for figure 2: Victim�s perception of bias in hate crime victimization, 2011�2015"
hcv0415at04.csv		"Estimates and standard errors for figure 3: Victims' perception of bias in hate crime victimization, 2007�2015"
hcv0415at05.csv		"Standard errors for table 2: Victims' evidence that a hate crime occurred, 2011�2015"
hcv0415at06.csv		"Standard errors for Table 3: Hate and nonhate crime victimization, by type of crime, 2011�2015"
hcv0415at07.csv		"Estimates and standard errors for figure 4: Type of crime experienced in hate and nonhate violent victimization, 2011�2015"
hcv0415at08.csv		"Standard errors for table 4: Presence of weapons and injuries sustained in violent hate and nonhate crime victimization, 2006�2015"
hcv0415at9.csv		"Standard errors for table 5: Hate and nonhate crime victimization, by location, 2011�2015"
hcv0415at10.csv		"Standard errors for table 6: Police-related actions taken in hate and nonhate crime victimization, 2011�2015"
hcv0415at11.csv		"Standard errors for table 7:  Most important reason why victimization was not reported to police, 2011�2015"
hcv0415at12.csv		"Standard errors for table 8: Characteristics of violent hate crime victims, 2011�2015"
hcv0415at13.csv		"Standard errors for table 9: Region and location of residence of violent hate crime victims, 2011�2015"
hcv0415at14.csv		"Standard errors for table 10: Characteristics of violent offenders as reported by victims of hate and nonhate crime, 2011�2015"
hcv0415at15.csv		"Standard errors for table 11: Hate crime victimization recorded by the NCVS and UCR, by offense, 2003�2015"
