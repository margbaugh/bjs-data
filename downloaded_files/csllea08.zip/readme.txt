Census of State and Local Law Enforcement Agencies, 2008															
															
This zip archive contains tables in individual  .csv spreadsheets               															
Census of State and Local Law Enforcement Agencies, 2008 NCJ 233982															
The full report including text and graphics in pdf format is available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2216             															
															
															
This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=73														
															
															
csllea08f01.csv		Figure 1. Net increase in full-time sworn personnel employed by state and local law enforcement agencies, per 4-year period, 1992-2008													
csllea08f02.csv		Figure 2. Number of full-time state and local and law enforcement employees, 1992-2008													
csllea08f03.csv		Figure 3. Number of full-time state and local and law enforcement employees per 100,000 residents, 1992-2008													
csllea08f04.csv		Figure 4. Number of full-time sworn personnel per 100,000 residents employed by state and local law enforcement agencies, by state, 2008													
csllea08f05.csv		Figure 5. Full-time employees in local police departments, 1992-2008													
csllea08f06.csv		Figure 6. Full-time employees in sheriffs' offices, 1992-2008													
csllea08f07.csv		Figure 7. Full-time employees in primary State law enforcement agencies, 1992-2008													
															
csllea08t01.csv		Table 1. State and local law enforcement employees, by type of agency, 2008													
csllea08t02.csv		Table 2. Full-time state and local law enforcement employees, by size of agency, 2008													
csllea08t03.csv		Table 3. Full-time local police employees, by size of agency, 2008													
csllea08t04.csv		Table 4. Full-time sheriffs' employees, by size of agency, 2008													
csllea08t05.csv		Table 5. Full-time primary state law enforcement agency employees, by size of agency, 2008													
csllea08t06.csv		Table 6. Primary state law enforcement agency full-time sworn personnel, 2008													
csllea08t07.csv		Table 7. Special jurisdiction law enforcement agencies, by type of jurisdiction and number of full-time sworn personnel, 2008													
csllea08t08.csv		Table 8. Thirty largest law enforcement agencies serving public colleges and universities, by number of full-time sworn personnel, 2008													
csllea08t09.csv		Table 9. Fifteen largest law enforcement agencies serving public school districts, by number of full-time sworn personnel, 2008													
csllea08t10.csv		Table 10. Thirty largest state and local natural resource law enforcement agencies , by number of full-time sworn personnel, 2008													
csllea08t11.csv		Table 11. Fifty largest State and local law enforcement agencies with transportation-related jurisdictions, by number of full-time sworn personnel, 2008													
csllea08t12.csv		Table 12. Comparison of CSLLEA and Uniform Crime Reports data, 1992-2008													
															
csllea08at01.csv	Appendix table 1. Percent of state and local law enforcement employees, by type of agency,  2008													
csllea08at02.csv	Appendix table 2. Percent distribution of full-time state and local law enforcement employees, by size of agency, 2008													
csllea08at03.csv	Appendix table 3. Percent distribution of local police employees, by size of agency, 2008													
csllea08at04.csv	Appendix table 4. Percent distribution of full-time sheriffs' employees, by size of agency, 2008													
csllea08at05.csv	Appendix table 5. Fifty largest state and local law enforcement agencies, by number of full-time sworn personnel, 2008													
csllea08at06.csv	Appendix table 6. State and local law enforcement agencies and employees, by state, 2008													
csllea08at07.csv	Appendix table 7. Local police departments and employees, by state, 2008													
csllea08at08.csv	Appendix table 8. Fifty largest local police departments, by number of full-time sworn personnel, 2008													
csllea08at09.csv	Appendix table 9. Sheriffs' offices and employees, by state, 2008													
csllea08at10.csv	Appendix table 10. Fifty largest sheriffs� offices, by number of full-time sworn personnel, 2008													
