Indicators of Workplace Violence, 2019   NCJ 250748	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Indicators of Workplace Violence, 2019   NCJ 250748.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/indicators-workplace-violence-2019	
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Violence%20in%20the%20Workplace	
	
Filenames	Table titles
iwv19t1.1.csv	Table 1.1. Nationally representative data sources used in this report
iwv19t2.1.csv	Table 2.1 Occupations of workplace homicide victims, 2015–2019
iwv19t2.2.csv	Table 2.2 Characteristics of workplace homicide victims, 2015–2019
iwv19t3.1.csv	Table 3.1 Cause of death in workplace homicides, 2015–2019
iwv19t3.2.csv	Table 3.2 Time of day of workplace homicides, 2015–2019
iwv19t3.3.csv	Table 3.3 Location of workplace homicides, 2015–2019
iwv19t5.1.csv	Table 5.1 Average annual victimization rate of nonfatal workplace violence, by occupation, 2015–19
iwv19t5.2.csv	Table 5.2 Average annual rate and percent of nonfatal workplace violence and percent of workers, by occupation group and employee type, 2015–19
iwv19t5.3.csv	Table 5.3 Average annual rate of nonfatal workplace violence, by victim characteristics, 2015–19
iwv19t5.4.csv	Table 5.4 Victim-offender relationship in nonfatal workplace violence, by sex of victim, 2015–19
iwv19t6.1.csv	Table 6.1 Rate and percent of nonfatal workplace violence, by type of crime, 2015–19
iwv19t6.2.csv	Table 6.2 Season and time of day of nonfatal workplace violence, 2015–19
iwv19t6.3.csv	Table 6.3 Percent of nonfatal workplace violence occurring in restricted areas, by occupation group, 2015–19
iwv19t7.1.csv	Table 7.1 Nonfatal workplace violence reported to police, by victim characteristics and type of crime, 2015-19
iwv19t7.2.csv	Table 7.2 Nonfatal workplace violence reported to police, by occupation group, 2015–19
iwv19t7.3.csv	Table 7.3 How police were notified of nonfatal workplace violence, 2015–19
iwv19t7.4.csv	Table 7.4 Most important reasons for reporting nonfatal workplace violence to police, 2015–19
iwv19t7.5.csv	Table 7.5 Most important reasons for not reporting nonfatal workplace violence to police, 2015–19
iwv19t8.1.csv	Table 8.1 Nonfatal workplace violence, by offender characteristics and number of offenders, 2015–19
iwv19t9.1.csv	Table 9.1 Offender weapon possession during nonfatal workplace violence, by weapon type, 2015–19
iwv19t9.2.csv	Table 9.2 Offender weapon possession in nonfatal workplace violence, by type of crime, 2015–19
iwv19t9.3.csv	Table 9.3 Percent of nonfatal workplace violence involving an offender with a weapon, by occupation group, 2015–19
iwv19t10.1.csv	Table 10.1 Injury type in nonfatal workplace violence, 2015–19
iwv19t10.2.csv	Table 10.2 Injury and medical treatment for victims of nonfatal workplace violence, 2015–19
iwv19t10.3.csv	Table 10.3 Percent of nonfatal workplace violence resulting in victim injury, by occupation group, 2015–19
iwv19t11.1.csv	Table 11.1 Nonfatal emergency department-treated injuries due to workplace violence, by victim characteristics and disposition after treatment, 2015–19
iwv19t11.2.csv	Table 11.2 Nonfatal emergency department-treated injuries due to workplace violence, by selected diagnosis, 2015–19
iwv19t11.3.csv	Table 11.3 Nonfatal emergency department-treated injuries due to workplace violence, by selected diagnosis and injured part of body, 2015–19
iwv19t11.4.csv	Table 11.4 Nonfatal emergency department-treated injuries due to workplace violence, by selected diagnosis and victim’s sex, 2015–19
iwv19t11.5.csv	Table 11.5 Nonfatal emergency department-treated workplace violence injuries due to workplace violence, by selected injury event, 2015–19
iwv19t12.1.csv	Table 12.1 Incidence rate and number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by occupation, 2015–2019
iwv19t12.2.csv	Table 12.2 Incidence rate and number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by victim characteristics and length of service of victim, 2015–2019
iwv19t12.3.csv	Table 12.3 Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by victim-offender relationship and sex of victim, 2019
iwv19t12.4.csv	Table 12.4 Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by event or exposure and sex of victim, 2019
iwv19t12.5.csv	Table 12.5 Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by part of body, 2015–2019
iwv19t12.6.csv	Table 12.6 Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by nature of injury or illness, 2015–2019
iwv19t13.1.csv	Table 13.1 Socio-emotional problems due to nonfatal workplace violence, 2015–19
	
Filenames	Figures
iwv19f1.1a.csv	Figure 1.1a. Number of workplace homicides, 1992–2019
iwv19f1.1b.csv	Figure 1.1b. Number of total homicides, 1992–2019
iwv19f1.2.csv	Figure 1.2. Percent of fatal occupational injuries that are workplace homicides, 1992–2019
iwv19f4.1.csv	Figure 4.1. Rate of nonfatal workplace violence and total nonfatal violent crime, based on 2-year rolling averages, 1994–2019
iwv19f4.2.csv	Figure 4.2. Rate of nonfatal workplace violence, by type of crime, based on 2-year rolling averages, 1994–2019
iwv19f7.1.csv	Figure 7.1. Nonfatal workplace violence reported to police, based on 2-year rolling averages, 1994–2019
iwv19f9.1.csv	Figure 9.1. Offender weapon possession in nonfatal workplace violence, based on 2-year rolling averages, 1994–2019
iwv19f10.1.csv	Figure 10.1. Nonfatal workplace violence resulting in victim injury, based on 2-year rolling averages, 1994–2019
iwv19f12.1.csv	Figure 12.1. Incidence rate for occupational injuries and illnesses with days away from work resulting from workplace violence in private industry (1992–2010) and intentional injury by other persons in private industry (2011–2019), per 10,000 FTEs, 1992–2019
iwv19f12.2.csv	Figure 12.2. Number of occupational injuries and illnesses with days away from work resulting from workplace violence in private industry (1992–2010) and intentional injury by other persons in private industry (2011–2019), 1992–2019
	
Filenames	Appendix tables
iwv19at1.csv	Appendix table 1. Numbers for cover map: Number of workplace homicides, by state, 2019
iwv19at2.csv	Appendix table 2. Numbers for figure 1.1: Number of workplace homicides and total homicides, 1992–2019
iwv19at3.csv	Appendix table 3. Percentages for figure 1.2: Percent of fatal occupational injuries that are workplace homicides, 1992–2019
iwv19at4.csv	Appendix table 4. Rates and standard errors for figure 4.1: Rate of nonfatal workplace violence and total nonfatal violent crime, based on 2-year rolling averages, 1994–2019
iwv19at5.csv	Appendix table 5. Rates and standard errors for figure 4.2: Rate of nonfatal workplace violence, by type of crime, based on 2-year rolling averages, 1994–2019
iwv19at6.csv	Appendix table 6. Standard errors for table 5.1: Average annual victimization rate of nonfatal workplace violence, by occupation, 2015–19
iwv19at7.csv	Appendix table 7. Standard errors for table 5.2: Average annual rate and percent of nonfatal workplace violence and percent of workers, by occupation group and employee type, 2015–19
iwv19at8.csv	Appendix table 8. Standard errors for table 5.3: Average annual rate of nonfatal workplace violence, by victim characteristics, 2015–19
iwv19at9.csv	Appendix table 9. Standard errors for table 5.4: Victim-offender relationship in nonfatal workplace violence, by sex of victim, 2015–19
iwv19at10.csv	Appendix table 10. Standard errors for table 6.1: Rate and percent of nonfatal workplace violence, by type of crime, 2015–19
iwv19at11.csv	Appendix table 11. Standard errors for table 6.2: Season and time of day of nonfatal workplace violence, 2015–19
iwv19at12.csv	Appendix table 12. Standard errors for table 6.3: Percent of nonfatal workplace violence occurring in restricted areas, by occupation group, 2015–19
iwv19at13.csv	Appendix table 13. Percentages and standard errors for figure 7.1: Nonfatal workplace violence reported to police, based on 2-year rolling averages, 1994–2019
iwv19at14.csv	Appendix table 14. Standard errors for table 7.1: Nonfatal workplace violence reported to police, by victim characteristics and type of crime, 2015–19
iwv19at15.csv	Appendix table 15. Standard errors for table 7.2: Nonfatal workplace violence reported to police, by occupation group, 2015–19
iwv19at16.csv	Appendix table 16. Standard errors for table 7.3: How police were notified of nonfatal workplace violence, 2015–19
iwv19at17.csv	Appendix table 17. Standard errors for table 7.4: Most important reasons for reporting nonfatal workplace violence to police, 2015–19
iwv19at18.csv	Appendix table 18. Standard errors for table 7.5: Most important reasons for not reporting nonfatal workplace violence to police, 2015–19
iwv19at19.csv	Appendix table 19. Standard errors for table 8.1: Nonfatal workplace violence, by offender characteristics and number of offenders, 2015–19
iwv19at20.csv	Appendix table 20. Percentages and standard errors for figure 9.1: Offender weapon possession in nonfatal workplace violence, based on 2-year rolling averages, 1994–2019
iwv19at21.csv	Appendix table 21. Standard errors for table 9.1: Offender weapon possession during nonfatal workplace violence, by weapon type, 2015–19
iwv19at22.csv	Appendix table 22. Standard errors for table 9.2: Offender weapon possession in nonfatal workplace violence, by type of crime, 2015–19
iwv19at23.csv	Appendix table 23. Standard errors for table 9.3: Percent of nonfatal workplace violence involving an offender with a weapon, by occupation group, 2015–19
iwv19at24.csv	Appendix table 24. Percentages and standard errors for figure 10.1: Nonfatal workplace violence resulting in victim injury, based on 2-year rolling averages, 1994–2019
iwv19at25.csv	Appendix table 25. Standard errors for table 10.1: Injury type in nonfatal workplace violence, 2015–19
iwv19at26.csv	Appendix table 26. Standard errors for table 10.2: Injury and medical treatment for victims of nonfatal workplace violence, 2015–19
iwv19at27.csv	Appendix table 27. Standard errors for table 10.3: Percent of nonfatal workplace violence resulting in victim injury, by occupation group, 2015–19
iwv19at28.csv	Appendix table 28. Rates and standard errors for figure 12.1: Incidence rate for occupational injuries and illnesses with days away from work resulting from workplace violence in private industry (1992–2010) and intentional injury by other persons in private industry (2011–2019), per 10,000 FTEs, 1992–2019
iwv19at29.csv	Appendix table 29. Numbers and standard errors for figure 12.2: Number of occupational injuries and illnesses with days away from work resulting from workplace violence in private industry (1992–2010) and intentional injury by other persons in private industry (2011–2019), 1992–2019
iwv19at30.csv	Appendix table 30. Standard errors for table 12.1: Incidence rate and number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by occupation, 2015–2019
iwv19at31.csv	Appendix table 31. Standard errors for table 12.2: Incidence rate and number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by victim characteristics and length of service of victim, 2015–2019
iwv19at32.csv	Appendix table 32. Standard errors for table 12.3: Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by victim-offender relationship and sex of victim, 2019
iwv19at33.csv	Appendix table 33. Standard errors for table 12.4: Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by event or exposure and sex of victim, 2019
iwv19at34.csv	Appendix table 34. Standard errors for table 12.5: Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by part of body, 2015–2019
iwv19at35.csv	Appendix table 35. Standard errors for table 12.6: Number of nonfatal occupational injuries and illnesses with days away from work resulting from workplace violence, by nature of injury or illness, 2015–2019
iwv19at36.csv	Appendix table 36. Standard errors for table 13.1: Socio-emotional problems due to nonfatal workplace violence, 2015–19
