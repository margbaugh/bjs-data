Federal Prosecution of Human Trafficking, 2001-2005  NCJ 215248

This zip archive contains tables in individual .csv spreadsheets from Federal Prosecution of Human Trafficking, 2001-2005  NCJ 215248. The full report including text and graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/fpht05.htm

fpht05t01.csv	Table: 1	Table 1.  Suspects in matters referred to U.S. attorneys with human trafficking offenses as lead charge, 2001-2005
fpht05t02.csv	Table: 2	Table 2.  Defendants adjudicated in Federal courts for a human trafficking offense as any charge filed, 2001-2005

