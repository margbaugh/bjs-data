Indicators of School Crime and Safety:  2004  NCJ 205290			

This Zip archive contains tables in individual .csv spreadsheets			
From Indicators of School Crime and Safety:  2004  NCJ 205290			
the full report including text and graphics in .pdf format are available from:			
http://www.ojp.usdoj.gov/bjs/abstract/iscs04.htm			

This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#iscs			


Tables			
iscs04s2-1.csv			Table S2.1.�Standard errors for table 2.1: Number of nonfatal crimes against students ages 12�18 at school, by type of crime and selected student characteristics: 1992-2002
iscs04s2-2.csv			Table S2.2.�Standard errors for table 2.2: Rate of nonfatal crimes against students ages 12�18 at school per 1,000 students, by type of crime and selected student characteristics: 1992-2002
iscs04s2-3.csv			Table S2.3.�Standard errors for table 2.3: Number of nonfatal crimes against students ages 12�18 away from school, by type of crime and selected student characteristics: 1992-2002
iscs04s2-4.csv			Table S2.4.�Standard errors for table 2.4: Rate of nonfatal crimes against students ages 12�18 away from school per 1,000 students, by type of crime and selected student characteristics: 1992-2002
iscs04s3-1.csv			Table S3.1.�Standard errors for table 3.1: Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student characteristics: Selected years 1995-2003
iscs04s4-1.csv			Table S4.1.�Standard errors for table 4.1: Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by selected student characteristics: Selected years 1993-2002
iscs04s5-1.csv			Table S5.1.�Standard errors for table 5.1: Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and selected student characteristics: Selected years 1993-2003
iscs04s6-1.csv			Table S6.1.�Standard errors for table 6.1: Percentage of students ages 12�18 who reported being bullied at school during the previous 6 months, by selected student characteristics: 1999, 2001, and 2003
iscs04s7-1.csv			Table S7.1.�Standard errors for table 7.1: Number and percentage of public schools that reported various types of crime and number of incidents, by type of crime and selected school characteristics: 1999-2000
iscs04s7-2.csv			Table S7.2.�Standard errors for table 7.2: Number and percentage of public schools that reported various types of crime to the police and number of incidents, by type of crime and selected school characteristics: 1999-2000
iscs04s8-1.csv			Table S8.1.�Standard errors for table 8.1: Percentage and number of public schools that took a serious disciplinary action, number of actions taken, and percentage distribution of actions according to type, by type of offense: 1999-2000
iscs04s9-1.csv			Table S9.1.�Standard errors for table 9.1: Average annual number of nonfatal crimes against teachers and average annual rate of crimes per 1,000 teachers at school, by type of crime and selected teacher and school characteristics: 1998-2002
iscs04s10-1.csv			Table S10.1.�Standard errors for table 10.1: Percentage and number of public and private school teachers who reported that they were threatened with injury by a student during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993-94 and 1999-2000
iscs04s10-2.csv			Table S10.2.�Standard errors for table 10.2: Percentage and number of public and private school teachers who reported that they were physically attacked by a student during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993-94 and 1999-2000
iscs04s11-1.csv			Table S11.1.�Standard errors for table 11.1: Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student characteristics: Selected years 1993-2003
iscs04s12-1.csv			Table S12.1.�Standard errors for table 12.1: Percentage of students ages 12�18 who reported being afraid during the previous 6 months, by selected location and student characteristics: Selected years 1995-2003
iscs04s13-1.csv			Table S13.1.�Standard errors for table 13.1: Percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months, by selected student characteristics: Selected years 1995-2003
iscs04s14.1.csv			Table S14.1.�Standard errors for table 14.1: Percentage of students ages 12�18 who reported being targets of hate-related words or seeing hate-related graffiti at school during the previous 6 months, by selected student characteristics: 1999, 2001 and 2003
iscs04s14-2.csv			Table S14.2.�Standard errors for table 14.2: Percentage of students ages 12�18 who reported being targets of hate-related words at school during the previous 6 months, by selected student characteristics: 2003
iscs04s15-1.csv			Table S15.1.�Standard errors for table 15.1: Percentage of students ages 12�18 who reported that street gangs were present at school during the previous 6 months, by urbanicity and selected student characteristics: 2001 and 2003
iscs04s16-1.csv			Table S16.1.�Standard errors for table 16.1: Percentage of public schools that reported selected discipline problems by frequency, by school characteristics: 1999-2000
iscs04s17-1.csv			Table S17.1.�Standard errors for table 17.1: Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and selected student characteristics: Selected years 1993-2003
iscs04s18-1.csv			Table S18.1.�Standard errors for table 18.1: Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and selected student characteristics: Selected years 1993-2003
iscs04s19-1.csv			Table S19.1.�Standard errors for table 19.1: Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by selected student characteristics: Selected years 1993-2003


iscs041-1.csv			Table 1.1.�Number of school-associated violent deaths and number of homicides and suicides of youth ages 5�19, by location: 1992�2002
iscs042-1.csv			Table 2.1.�Number of nonfatal crimes against students ages 12�18 at school, by type of crime and selected student characteristics: 1992�2002
iscs042-2.csv			Table 2.2.�Rate of nonfatal crimes against students ages 12�18 at school per 1,000 students, by type of crime and selected student characteristics: 1992-2002
iscs042-3.csv			Table 2.3.�Number of nonfatal crimes against students ages 12�18 away from school, by type of crime and selected student characteristics: 1992-2002
iscs042-4.csv			Table 2.4.�Rate of nonfatal crimes against students ages 12�18 away from school per 1,000 students, by type of crime and selected student characteristics: 1992-2002
iscs043-1.csv			Table 3.1.�Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student characteristics: Selected years 1995-2003
iscs044-1.csv			Table 4.1.�Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by selected student characteristics: Selected years 1993-2003
iscs045-1.csv			Table 5.1.�Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and selected student characteristics: Selected years 1993-2003
iscs046-1.csv			Table 6.1.�Percentage of students ages 12�18 who reported being bullied at school during the previous 6 months, by selected student characteristics: 1999, 2001, and 2003
iscs047-1.csv			Table 7.1.�Number and percentage of public schools that reported various types of crime and number of incidents, by type of crime and selected school characteristics: 1999-2000
iscs047-2.csv			Table 7.2.�Number and percentage of public schools that reported various types of crime to the police and number of incidents, by type of crime and selected school characteristics: 1999-2000
iscs048-1.csv			Table 8.1.�Percentage and number of public schools that took a serious disciplinary action, number of actions taken, and percentage distribution of actions according to type, by type of offense: 1999-2000
iscs049-1.csv			Table 9.1.�Average annual number of nonfatal crimes against teachers and average annual rate of crimes per 1,000 teachers at school, by type of crime and selected teacher and school characteristics: 1998-2002
iscs0410-1.csv			Table 10.1.�Percentage and number of public and private school teachers who reported that they were threatened with injury by a student during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993-94 and 1999-2000
iscs0410-2.csv			Table 10.2.�Percentage and number of public and private school teachers who reported that they were physically attacked by a student during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993-94 and 1999-2000
iscs0411-1.csv			Table 11.1.�Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student characteristics: Selected years 1993-2003
iscs0412-1.csv			Table 12.1.�Percentage of students ages 12�18 who reported being afraid during the previous 6 months, by location and selected student characteristics: Selected years 1995-2003
iscs0413-1.csv			Table 13.1.�Percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months, by selected student characteristics: Selected years 1995-2003
iscs0414-1.csv			Table 14.1.�Percentage of students ages 12�18 who reported being targets of hate-related words or seeing hate-related graffiti at school during the previous 6 months, by selected student characteristics: 1999, 2001, and 2003
iscs0414-2.csv			Table 14.2.�Percentage of students ages 12�18 who reported being targets of hate-related words at school during the previous 6 months, by selected student characteristics: 2003
iscs0415-1.csv			Table 15.1.�Percentage of students ages 12�18 who reported that street gangs were present at school during the previous 6 months, by urbanicity and selected student characteristics: 2001 and 2003
iscs0416-1.csv			Table 16.1.�Percentage of public schools that reported selected discipline problems by frequency, by school characteristics: 1999�2000
iscs0417-1.csv			Table 17.1.�Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and selected student characteristics: Selected years 1993-2003
iscs0418-1.csv			Table 18.1.�Percentage of students in grades 9�12 who reported using marijuana during  the previous 30 days, by location and selected student characteristics: Selected years 1993-2003
iscs0419-1.csv			Table 19.1.�Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by selected student characteristics: Selected years 1993-2003


Figures			
iscs04fig1.1.csv			Figure 1.1.�Number of homicides and suicides of youth ages 5�19, by location: 1999�2000
iscs04fig1.2.csv			Figure 1.2.�Number of homicides and suicides of youth ages 5�19 at school: 1992�2002
iscs04fig2.1.csv			Figure 2.1.�Rate of nonfatal crimes against students ages 12�18 per 1,000 students, by type of crime and location:  1992-2002
iscs04fig2.2.csv			Figure 2.2.�Rate of nonfatal crimes against students ages 12�18 at school per 1,000 students, by type of crime and selected student charactieristics:  2002
iscs04fig2.3.csv			Figure 2.3.�Rate of nonfatal crimes against students ages 12�18 away from school per 1,000 students, by type of crime and selected student characteristics:  2002
iscs04fig3.1.csv			Figure 3.1.�Percentage of students ages 12�18 who reported nonfatal criminal victimization at school during the previous 6 months, by type of victimization:  Selected years 1995-2003
iscs04fig3.2.csv			Figure 3.2.�Percentage of students ages 12�18 who reported nonfatal criminal victimization at school during the previous 6 months, by grade level and type of victimization:  2003
iscs04fig4.1.csv			Figure 4.1.�Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by sex:  Selected years 1993-2003
iscs04fig4.2.csv			Figure 4.2.�Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by grade:  Selected years 1993-2003  
iscs04fig5.1.csv			Figure 5.1.�Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and sex:  Selected years 1993-2003
iscs04fig5.2.csv			Figure 5.2.�Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and grade:  Selected years 1993-2003
iscs04fig6.1.scv			Figure 6.1.�Percentage of students ages 12�18 who reported being bullied at school during the previous 6 months, by sex:  1999, 2001, and 2003
iscs04fig6.2.csv			Figure 6.2.�Percentage of students ages 12�18 who reported being bullied at school during the previous 6 months, by grade and school sector:  2003
iscs04fig7.1.csv			Figure 7.1.�Percentage of public schools that reported various types of crime and percentage of public schools that reported various types of crime to the police, by type of crime and school level:  1999-2000
iscs04fig7.2.csv			Figure 7.2.�Percentage of public schools that reported various types of crime and percentage of public schools that reported various types of crime to the police, by type of crime and enrollment:  1999-2000
iscs04fig7.3.csv			Figure 7.3.�Percentage of public schools that reported various types of crime and percentage of public schools that reported various types of crime to the police, by type of crime and urbanicity:  1999-2000
iscs04fig8.1.csv			Figure 8.1.�Percentage distribution of serious disciplinary actions taken by public schools, by type of action:  1999-2000
iscs04fig8.2.csv			Figure 8.2.�Percentage of public schools that took a serious disciplinary action for selected offenses, by type of offense:  1999-2000
iscs04fig9.1.csv			Figure 9.1.�Average annual rate of nonfatal crimes against teachers at school per 1,000 teachers, by type of crime and selected teacher and school characteristics:  1998-2002
iscs04fig10.1.csv			Figure 10.1.�Percentage of public and private school teachers who reported that they were threatened with injury or that they were physically attacked by a student from school during the previous 12 months, by urbanicity:  1993-94 and 1999-2000
iscs04fig10.2.csv			Figure 10.2.�Percentage of public and private school teachers who reported that they were threatened with injury or that they were physically attacked by a student from school during the previous 12 months, by urbanicity and school sector:  1999-2000
iscs04fig11.1.csv			Figure 11.1.�Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and sex:  Selected years 1993-2003
iscs04fig11.2.csv			Figure 11.2.�Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and grade:  Selected years 1003-2003
iscs04fig12.1.csv			Figure 12.1.�Percentage of students ages 12�18 who reported being afraid during the previous 6 months, by location:  Selected years 1995-2003
iscs04fig12.2.csv			Figure 12.2.�Percentage of students ages 12�18 who reported being afraid of attack or threat of attack during the previous 6 months, by location and race/ethnicity:  2003
iscs04fig13.1.csv			Figure 13.1.�Percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months, by selected student characteristics:  2003
iscs04fig14.1.csv			Figure 14.1.�Percentage of students ages 12�18 who reported being targets of hate-related words or seeing hate-related graffiti at school during the previous 6 months, by student characteristics:  2003
iscs04fig15.1.csv			Figure 15.1.�Percentage of students ages 12�18 who reported that street gangs were present at school during the previous 6 months, by urbanicity and race/ethnicity:  2003
iscs04fig15.2.csv			Figure 15.2.�Percentage of students ages 12�18 who reported that street gangs were present at school during the previous 6 months, by school sector and urbanicity:  2003
iscs04fig16.1.csv			Figure 16.1.�Percentage of public schools that reported selected discipline problems, by school level:  1999-2000
iscs04fig17.1.csv			Figure 17.1.�Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and sex:  Selected years 19993-2003
iscs0efig17.2.csv			Figure 17.2.�Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and grade:  Selected years 1993-2003
iscs04fig18.1.csv			Figure 18.1.�Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and sex:  Selected years 1993-2003
iscs04fig18.2.csv			Figure 18.2.�Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and grade:  Selected years 1993-2003
iscs04fig19.1.csv			Figure 19.1.�Percentage of students in grades 9�12 who reported drugs were made available to them on school property during the previous 12 months, by sex:  Selected years 1993-2003
iscs04fig19.2.csv			Figure 19.2.�Percentage of students in grades 9�12 who reported drugs were made available to them on school property during the previous 12 months, by grade:  Selected years 1993-2003
