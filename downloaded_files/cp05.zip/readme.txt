Capital Punishment, 2005   NCJ 215083

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2005   NCJ 215083. The full report including 
text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cp05.htm

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cp

cp05ht01.csv		"Highlights table #: 1 Executions during 2005, persons under sentence of death 12/31/05 and jurisdictions without the death penalty"
cp05ht02.csv		"Highlights table #: 2 Persons under sentence of death, 1995 and 2005"

cp05t04.csv		"Table #: 4  Prisoners under sentence of death, by region, State, and race, 2004 and 2005"
cp05t05.csv		"Table #: 5  Demographic characteristics of prisoners under sentence of death, 2005"
cp05t06.csv		"Table #: 6  Hispanics and women under sentence of death, by State, 2004 and 2005"
cp05t07.csv		"Table #: 7  Age at time of arrest for capital offense and  age of prisoners under sentence of death at yearend 2005"
cp05t08.csv		"Table #: 8  Criminal history profile of prisoners under sentence of death, by race and Hispanic origin, 2005"
cp05t09.csv		"Table #: 9  Number of persons  executed, by jurisdiction, 1930-2005"
cp05t10.csv		"Table #: 10  Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2005"
cp05t11.csv		"Table #: 11 Time under sentence of death and execution, by race, 1977-2005"

cp05f1.csv		"Figure #: 1 Persons under sentence of death 1953-2005"
cp05f2.csv		"Figure #: 2 Persons under sentence of death, by race, 1968-2005"
cp05f3.csv		"Figure #: 3 Admissions to and release from a sentence of death, 1977-2005"
cp05f4.csv		"Figure #: 4 Persons executed, 1930-2005"

cp05tt01.csv		"Text table #: 1 Women under sentence of death by race and state, 12/31/05"
cp05tt02.csv		"Text table #: 2 Persons under sentence  of death, by sex, race, and Hispanic origin, 12/31/05"
cp05tt03.csv		"Text table #: 3 Inmates received under sentence of death, 1995-2005"
cp05tt04.csv		"Text table #: 4 Number of executions, 1977-2005"
cp05tt05.csv		"Text table #: 5 Number of executions by race/ethnicity and method, 1977-2005"
cp05tt06.csv		"Text table #: 6 Elapsed time since sentencing for inmates under sentence of death by gender and race/ethnicity"

