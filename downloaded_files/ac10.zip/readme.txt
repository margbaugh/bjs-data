Alcohol and Crime: Data from 2002 to 2008																		
																		
This zip archive contains tables in individual .csv spreadsheets																		
from Alcohol and Crime: Data from 2002 to 2008, electronic only. 																		
The full electronic report is available at:																		
http://bjs.ojp.usdoj.gov//index.cfm?ty=pbdetail&iid=2313																		
																		
Filename		Table																
ac10t01.csv	Table 1. Sex of offenders in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t02.csv	Table 2. Age of offenders in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t03.csv	Table 3. Sex of victims in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t04.csv	Table 4. Age of victims in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t05.csv	Table 5. Age of victims in alcohol-involved and other violent incidents known to law enforcement, by age of offender, 2007																
ac10t06.csv	Table 6. Relationship of victims and offenders in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t07.csv	Table 7. Number of victims involved in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t08.csv	Table 8. Number of offenders in alcohol-related and other violent incidents known to law enforcement, 2007																
ac10t09.csv	Table 9. Most serious offense in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t10.csv	Table 10. Arrests made in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t11.csv	Table 11. Percent of alcohol-involved and other violent incidents known to law enforcement suspected of involving other drugs, 2007																
ac10t12.csv	Table 12. Presence of weapons in alcohol-invovled and other violent incidents known to law enforcement, 2007																
ac10t13.csv	Table 13. Type of injury sustained by victims in alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t14.csv	Table 14. Type of injury sustained by victims in alcohol-involved and other violent incidents known to law enforcement, by offender age group, 2007 																
ac10t15a.csv	Table 15a. Month alcohol-involved and other violence occurred in incident known to law enforcement, 2007																
ac10t15b.csv	Table 15b. Proportion of violent incidents known to law enforcement that were alcohol-involved by months, 2007																
ac10t16.csv	Table 16. Day of the week alcohol-involved and other violence occurred in incidents known to law enforcement, 2007																
ac10t17.csv	Table 17. Most serious offense in alcohol-involved or other violent incidents known to law enforcement occurring on weekdays and weekends, 2007�																
ac10t18.csv	Table 18. Time-of-day of alcohol-involved and other violent incidents known to law enforcement, 2007																
ac10t19.csv	Table 19. Time-of-day alcohol-involved and other violent incidents known to law enforcement, by offender age group, 2007																
ac10t20.csv	Table 20. Location of alcohol-involved incidents known to law enforcement, 2007 																
ac10t21.csv	Table 21. Location of alcohol-involved and other violent incidents known to law enforcement occurred, by day-of-week, 2007 
																
ac10t22.csv	Table 22. Age of victims involved in alcohol-related violent incidents, by age of offenders, 2004-2008																
ac10t22se.csv	Table 22se. Standard errors for age of victims involved in alcohol-related violent incidents, by age of offenders, 2004-2008																
ac10t23.csv	Table 23. Sex of victims involved in alcohol-related violent incidents, by sex of offenders, 2004-2008																
ac10t23se.csv	Table 23se. Standard errors for sex of victims involved in alcohol-related violent incidents, by sex of offender, 2004-2008																
ac10t24.csv	Table 24. Injuries sustained by victims who perceived the offender had used alcohol, 2004-2008																
ac10t25.csv	Table 25. Number of victimizations for which victims perceived offenders had used alcohol, by type of crime, 1997-2008																
ac10t25se.csv	Table 25se. Standard errors for number of victimizations when victims said they knew offenders had used alcohol, by type of crime, 1997-2008																
ac10t26.csv	Table 26. Victims involved in alcohol-related violent incidents, by location and time-of-day, 2004-2008																
ac10t27.csv	Table 27. Victim-offender relationship in violent victimizations where vicitms perceived alcohol use by offenders, 2004-2008																
ac10t28.csv	Table 28. Presence of weapons in violent victimizations where victims perceived alcohol use by offenders, 2004-2008																
ac10t29.csv	Table 29. State and federal prisoners who reported alcohol use at the time of offense, by type of offense, 2004																
ac10t30.csv	Table 30 . Convicted local jail inmates who reported alcohol use at the time of offense, by type of offense, 2002																
ac10apt1.csv	Appendix table 1. Victims who percieved offenders had been using alcohol, by type of crime, 1997-2008																
ac10apt1se.csv	Appendix table 1se . Standard errors for the number of victims who perceived offenders had been using alcohol, by type of crime, 1997-2008																
ac10apt2.csv	Appendix table 2.  Number and percent of violent incidents known to law enforcement involving alcohol by state in the 2007 NIBRS sample																
