HIV in Prisons and Jails, 1999  NCJ  187456

This zip archive contains tables in individual .wk1 spreadsheets
from HIV in Prisons and Jails, 1999  NCJ  187456
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/hivpj99.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#hivpj



hivp9901.wk1    Table 1.  Inmates in custody of State or Federal prison authorities and known to be positive for the human immunodeficiency virus, 1997-1999
hivp9902.wk1    Table 2.  Inmates in custody of State or Federal prison authorities, by type of HIV infection or confirmed AIDS, yearend 1999
hivp9903.wk1    Table 3.  State and Federal  prison inmates known to be positive for the human immunodeficiency virus, by gender, yearend 1999
hivp9904.wk1    Table 4.  Number of inmate deaths in State prisons, by cause, 1995 and 1999
hivp9905.wk1    Table 5.  AIDS-related deaths of State and Federal prisoners, 1999
hivp9906.wk1    Table 6.  Circumstances under which inmates are tested for the antibody to the human immunodeficiency virus, by jurisdiction, 1999
hivp9907.wk1    Table 7.  Jail inmates known to be positive for the human immunodeficiency virus, Census of Jails 1999 and 1993
hivp9908.wk1    Table 8.  The 50 largest local jail jurisdictions: Number and percent of inmates who were HIV positive, June 30, 1999
hivp9909.wk1    Table 9.  AIDS-related deaths of local jail inmates, July 1, 1998, to June 30, 1999
