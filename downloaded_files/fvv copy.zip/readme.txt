Female Victims of Violence     NCJ  228356			

This zip archive contains tables in individual.csv spreadsheets	
from Female Victims of Violence, NCJ  228356.  
The full report including text and graphics in pdf format are available
from: http://www.ojp.usdoj.gov/bjs/abstract/fvv.htm			


Filename			Table title
fvvt01.csv			Table  1:   Violence by intimate partners, by type of crime and gender of the victims, 2008
fvvt02.csv			Table  2:   Demographic characteristics of intimate partner violence victims and defendants in 16 large counties, May 2002

Figures
fvvf01.csv			Figure   1: Nonfatal violent victimization rate by victim/offender relationship and victim gender, 1993-2008
fvvf02.csv			Figure   2:  Intimate homicide victims by gender
