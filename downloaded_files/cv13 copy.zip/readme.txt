Criminal Victimization, 2013      NCJ 247648			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization, 2013, NCJ 247648.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov//index.cfm?ty=pbdetail&iid=5111			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=6			
			
			
Filename			Table title
cv13t01.csv			Table 1. Violent victimization, by type of violent crime, 2004, 2012, and 2013
cv13t02.csv			Table 2. Firearm violence, 2004�2013
cv13t03.csv			Table 3. Property victimization, by type of property crime, 2004, 2012, and 2013
cv13t04.csv			Table 4. Number of victims and prevalence rate, by type of crime, 2004, 2012, and 2013
cv13t05.csv			Table 5. Prevalence of violent crime, by victim demographic characteristics, 2004, 2012, and 2013
cv13t06.csv			Table 6. Percent of victimizations reported to police, by type of crime, 2004, 2012, and 2013
cv13t07.csv			Table 7. Rates of victimizations reported and not reported to police, by type of crime, 2004, 2012, and 2013
cv13t08.csv			Table 8. Violent crime victims who received assistance from a victim service agency, by type of crime, 2004, 2012, and 2013
cv13t09.csv			Table 9. Violent victimization, by victim demographic characteristics, 2004, 2012, and 2013
cv13t10.csv			Table 10. Violent and property victimization, by household location, 2004, 2012, and 2013
cv13t11.csv			Table 11. Percent change in the number of crimes reported in the UCR and the NCVS, 2012�2013
			
Figures			
cv13f01.csv			Figure 1. Violent and property victimization, 1993�2013

			
Appendix tables			
cv13at01.csv			Appendix table 1. Estimates and standard errors for figure 1: Violent and property victimization, 1993�2013
cv13at02.csv			Appendix table 2. Standard errors for table 1: Violent victimization, by type of violent crime, 2004, 2012, and 2013
cv13at03.csv			Appendix table 3. Standard errors for table 2: Firearm violence, 2004�2013
cv13at04.csv			Appendix table 4. Standard errors for table 3: Property victimization, 2004, 2012, and 2013
cv13at05.csv			Appendix table 5. Standard errors for table 4: Number of victims and prevalence rate, by type of crime, 2004, 2012, and 2013
cv13at06.csv			Appendix table 6. Standard errors for table 5: Prevalence of violent crime, by victim demographic characteristics, 2004, 2012, and 2013
cv13at07.csv			Appendix table 7. Standard errors for table 6: Percent of victimizations reported to police, by type of crime, 2004, 2012, and 2013
cv13at08.csv			Appendix table 8. Standard errors for table 7: Rates of victimizations reported and not reported to police, by type of crime, 2004, 2012 and 2013
cv13at09.csv			Appendix table 9. Standard errors for table 8: Violent crime victims who received assistance from a victim service agency, by type of crime, 2004, 2012, and 2013
cv13at10.csv			Appendix table 10. Standard errors for table 9: Violent victimization, by victim demographic characteristics, 2004, 2012, and 2013
cv13at11.csv			Appendix table 11. Standard errors for table 10: Violent and property victimization, by household location, 2004, 2012, and 2013

