TRIBAL LAW ENFORCEMENT, 2000  NCJ 197936																	
																	
This zip archive contains tables and figures in individual .wk1 spreadsheets from the 2000 Census of State and Local Law Enforcement Agencies (CSLLEA) report, "Tribal Law Enforcement, 2000."  The full report including tables and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/tle00.htm
													
Tables:																	
																	
tle0001.wk1	Table 1. Tribally operated law enforcement agencies and employees, by size of agency, June 2000
tle0002.wk1 	Table 2. Full-time community policing officers in tribally operated law enforcement agencies, by size of agency, 2000
tle0003.wk1	Table 3. Full-time school resource officers in tribally operated law enforcement agencies, by size of agency, 2000
tle0004.wk1	Table 4. The 20 largest tribally operated law enforcement agencies, by the number of full-time sworn personnel, the service population, reservation land area, and the number of full-time sworn officers per 1,000 residents and per 100 square miles, 2000
tle00t01.wk1	In-Text Table 1. Violent and property offenses reported by law enforcement agencies in Indian country, 1998-2000
tle00t02.wk1	In-Text Table 2. Selected offenses (other than Part I offenses) reported by tribal law enforcement agencies, 2000

Figures:

tle00f01.wk1	Figure 1. Selected services and functions of tribally operated law enforcement agencies, 2000
