Employment of Persons Released from Federal Prison in 2010 NCJ 303147	
	
This zip archive contains tables in individual .csv spreadsheets from	
Employment of Persons Released from Federal Prison in 2010 NCJ 303147. The full report including text	
and graphics in pdf format is available from https://bjs.ojp.gov/library/publications/employment-persons-released-federal-prison-2010
	
Filenames	Table titles
eprfp10t01.csv	Table 1. Persons released from federal prison in 2010, by Protected Identification Key assignment and demographic and criminal justice characteristics
eprfp10t02.csv	Table 2. Percent of persons in the study population who were employed during the quarters prior to or the quarter of admission to federal prison, by demographic and criminal justice characteristics
eprfp10t03.csv	Table 3. Median quarterly earnings of persons in the study population who were employed during the quarters prior to or the quarter of admission to federal prison, by demographic and criminal justice characteristics
eprfp10t04.csv	Table 4. Measures of employment of persons in the study population during the 16 quarters after release from federal prison in 2010, by demographic and criminal justice characteristics
eprfp10t05.csv	Table 5. Percent of persons in the study population who were employed during the quarter of release or the 16 quarters after release from federal prison in 2010, by demographic and criminal justice characteristics
eprfp10t06.csv	Table 6. Median quarterly earnings of persons in the study population who were employed during the quarter of release or the 16 quarters after release from federal prison in 2010, by demographic and criminal justice characteristics
eprfp10t07.csv	Table 7. Percent of persons in the study population who were employed during the 4 quarters prior to admission, the quarters of admission and release, or the 16 quarters after release from federal prison, by employment industry sector
eprfp10t08.csv	Table 8. Persons in the study population who were employed during quarter 4 after release from federal prison in 2010, by employment industry sector and demographic and criminal justice characteristics
eprfp10t09.csv	Table 9. U.S. citizenship status of persons released from federal prison in 2010, by Protected Identification Key assignment and demographic and criminal justice characteristics
eprfp10t10.csv	Table 10. Percent of persons released from federal prison in 2010, by U.S. citizenship status, Protected Identification Key assignment, and demographic and criminal justice characteristics
	
		Figures
eprfp10f01.csv	Figure 1. Percent of persons in the study population who were employed during any of the 16 quarters after release from federal prison in 2010, by race or ethnicity
eprfp10f02.csv	Figure 2. Percent of persons in the study population who were employed during the quarters prior to or the quarter of admission to federal prison, by race or ethnicity
eprfp10f03.csv	Figure 3. Percent of persons in the study population who were employed during the quarters prior to or the quarter of admission to federal prison, by most serious offense
eprfp10f04.csv	Figure 4. Mean number of quarters between release from federal prison and first employment, by time served on BOP commitment resulting in 2010 release
eprfp10f05.csv	Figure 5. Percent of persons in the study population who were employed before admission to or after release from federal prison, by age at 2010 release from BOP
eprfp10f06.csv	Figure 6. Percent of persons in the study population who were employed before admission to or after release from federal prison, by time served before 2010 release
eprfp10f07.csv	Figure 7. Percent of persons in the study population who were employed before admission to or after release from federal prison, by most serious offense
eprfp10f08.csv	Figure 8. Median quarterly earnings of persons in the study population who were employed during either quarter 1 or quarter 16 post-prison, by demographic and criminal justice characteristics
	
		Appendix tables
eprfp10at01.csv	Appendix Table 1. Number of persons in the study population who were employed during the quarter of release or the 16 quarters after release from federal prison in 2010, by demographic and criminal justice characteristics 
