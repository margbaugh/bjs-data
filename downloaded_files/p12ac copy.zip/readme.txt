Prisoners in 2012 � Advance Counts, NCJ 242467

This zip archive contains tables in individual .csv spreadsheets from Prisoners in 2012 � Advance Counts, NCJ 242467. 
The full report, including text and graphics, in pdf format is available from: 
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4737
	
This report is one in a series. More recent editions may be available. 
To view a list of all in the series, go to: 
http://www.bjs.gov/index.cfm?ty=pbse&sid=40	
	
Tables	
p12act01.csv	Table 1: Prisoners under the jurisdiction of state or federal correctional authorities, December 31, 2002�2012
p12act02.csv	Table 2: Prisoners under jurisdiction of state or federal correctional authorities, by jurisdiction and sex, December 31, 2011 and 2012
p12act03.csv	Table 3: Sentenced prisoners under the jurisdiction of California state correctional authorities, by sex, December 31, 2002�2012
p12act04.csv	Table 4: Most serious offense committed by sentenced inmates in California state prisons, by sex and offense type , December 31, 2010 and 2012
p12act05.csv	Table 5: Sentenced prisoners under the jurisdiction of state or federal correctional authorities, December 31, 2002�2012
p12act06.csv	Table 6: Sentenced prisoners under jurisdiction of state or federal correctional authorities, by jurisdiction and sex, December 31, 2011 and 2012
p12act07.csv	Table 7: Imprisonment rate of sentenced prisoners under the jurisdiction of state or federal correctional authorities, December 31, 2002�2012
p12act08.csv	Table 8: Imprisonment rate of sentenced prisoners under jurisdiction of state or federal correctional authorities, by jurisdiction and sex, December 31, 2011 and 2012
p12act09.csv	Table 9: Estimated percent of sentenced prisoners under state jurisdiction, by offense, sex, race, and Hispanic origin, December 31, 2011
p12act10.csv	Table 10: Estimated number of sentenced prisoners under state jurisdiction, by offense, sex, race, and Hispanic origin, December 31, 2011
	
Figures	
p12acf01.csv	Figure 1: Prisoners under state and federal jurisdiction at yearend, 2002�2012


