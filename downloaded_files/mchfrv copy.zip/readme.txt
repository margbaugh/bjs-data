Methods for Counting High-Frequency Repeat Victimizations in the National Crime Victimization Survey  NCJ  237308		
		
This Zip archive contains tables and figures in individual .csv spreadsheets 		
from Methods for Counting High-Frequency Repeat Victimizations in the National Crime Victimization Survey  NCJ  237308.		
The full report, including text and graphics in .pdf format are available from: 		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2240		
		
		
File name		Table or figure title
mchfrvt01.csv		Table 1. Percent of victimizations reported as series victimizations, 1993�2009
mchfrvt02.csv		Table 2. Percent of victimizations reported as series victimizations, by type of crime, 1993�1999 and 2000�2009
mchfrvt03.csv		Table 3. Activity at time of most recent violent series victimization, 1992�1995 and 2000�2009
mchfrvt04.csv		Table 4. Distribution of violent series victimizations, by age and sex, 2000�2009
mchfrvt05.csv		Table 5. Violent series victimizations at work or on duty, by sex and occupation, age 18 or older, 2001�2009*
mchfrvt06.csv		Table 6. Characteristics of most recent series victimization compared to other victimizations in the series, by age and sex, 2000�2009
mchfrvt07.csv		Table 7. Responses to �How many times did this type of incident happen?� for all violent victimizations, 1993�2009
mchfrvt08.csv		Table 8. Consistency of first and second responses to How many times did this type of incident happen?, 1993�2009
mchfrvt09.csv		Table 9. Characteristics of violent incidents for nonseries and series victimizations, 1993�2009
mchfrvt10.csv		Table 10. Percent change in victimization rates with series victimizations included and excluded, by type of crime
mchfrvt11.csv		Table 11. Percent change in victimization rates with series victimizations included and excluded, by type of victimization
		
mchfrvf01.csv		Figure 1. Activity during most recent incident in series victimization for male and female youth ages 12 to 17, 2000-2009
mchfrvf02.csv		Figure 2. Activity during most recent incident in series victimization for male and female adults ages 18 or older, 2000-2009
mchfrvf03.csv		Figure 3. Victim-offender relationship in most recent incident in series victimization for male and female youth ages 12 to 17, 2000-2009
mchfrvf04.csv		Figure 4. Victim-offender relationship in most recent incident in series victimization for male and female adults age 18 or older, 2000-2009
mchfrvf05.csv		Figure 5. Responses to How many times did this type of incident happen? for all violent series victimizations, 1993-2009
mchfrvf06.csv		Figure 6. Series victims' first and second responses to How many times did this type of thing happen?, 1993-2009
mchfrvf07.csv		Figure 7.  Mean difference between the first and second responses to How many times did this type of incident happen? for all violent series victimizations, 1993-2009
mchfrvf08.csv		Figure 8. Responses to How many times did this type of incident happen? for all violent victimizations, 1993-2009
mchfrvf09.csv		Figure 9. Violent victimization rates with series victimizations included and excluded, 1993-2009 
mchfrvf10.csv		Figure 10. Rape and sexual assault victimization rates with series victimizations included and excluded, 1993-2009 
mchfrvf11.csv		Figure 11. Robbery victimization rates with series victimizations included and excluded, 1993-2009 
mchfrvf12.csv		Figure 12. Aggravated assault victimization rates with series victimizations included and excluded, 1993-2009 
mchfrvf13.csv		Figure 13. Simple assault victimizations rates with series victimizations included and excluded, 1993-2009 
mchfrvf14.csv		Figure 14. Rates of female intimate partner violence including series victimizations counted as 1, and counted using victim reports for females age 12 and older, 1993-2009 
mchfrvf15.csv		Figure 15. Rates of violent victimization at school with series victimizations excluded and included for youth ages 12 to 17, 1993-2009 
mchfrvf16.csv		Figure 16. Rates of violent victimization at work or on duty with series victimizations included and excluded for adults age 18 or older, 1993-2009 
mchfrvf17.csv		Figure 17. Percent of violent victimization reported to police with series victimizations counted as 1 and counted using victim report, 1993-2009 
mchfrvf18.csv		Figure 18. Percent of violent victimizations resulting in injury with series victimizations counted as 1 and counted using victim report, 1993-2009 
mchfrvf19.csv		Figure 19. Percent of violent victimizations involving weapon use with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvf20.csv		Figure 20. Percent of violent victimizations involving strangers with series victimizations counted as 1 and counted using victim report, 1993-2009 
mchfrvf21.csv		Figure 21. Percent of violent victimizations involving intimate partners with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvf22.csv		Figure 22. Percent of violent victimizations involving intimate partners with series victimizations counted as 1 and counted using victim reports for females age 12 and older, 1993-2009 
		
mchfrvat01.csv		Appendix table 1. Standard errors for table 1: Percent of victimizations reported as series victimizations 1993-2009
mchfrvat02.csv		Appendix table 2. Standard errors for table 2: Percent of victimizations reported as series victimizations, by type of crime, 1993-1999 and 2000-2009
mchfrvat03.csv		Appendix table 3. Standard errors for table 4: Distribution of violent series victimizations by age and sex, 2000-2009
mchfrvat04.csv		Appendix table 4. Standard errors for figure 1: Activity during most recent incident in series victimization for male and female youth ages 12-17, 2000-2009
mchfrvat05.csv		Appendix table 5. Standard errors for figure 2: Activity during most recent incident in series victimization for male and female adults age 18 or older, 2000-2009 
mchfrvat06.csv		Appendix table 6.  Standard errors for table 5: Violent series victimizations at work or on duty, by sex and occupation, age 18 or older, 2001-2009
mchfrvat07.csv		Appendix table 7. Standard errors for figure 3: Victim-offender relationship in most recent incident in series victimization for male and female youth ages 12-17, 2000-2009
mchfrvat08.csv		Appendix table 8. Standard errors for figure 4: Victim-offender relationship in most recent incident in series victimization for male and female adults ages 18 or older, 2000-2009
mchfrvat09.csv		Appendix table 9. Standard errors for table 6: Characteristics of most recent series victimization compared to other victimizations in the series, by age and sex, 2000-2009
mchfrvat10.csv		Appendix table 10. Standard errors for figure 17: Percent of violent victimization reported to police with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvat11.csv		Appendix table 11. Standard errors for figure 18: Percent of violent victimizations resulting in injury with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvat12.csv		Appendix table 12. Standard errors for figure 19: Percent of violent victimizations involving weapon use with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvat13.csv		Appendix table 13. Standard errors for figure 20: Percent of violent victimizations involving strangers with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvat14.csv		Appendix table 14. Standard errors for figure 21: Percent of violent victimizations involving intimate partners with series victimizations counted as 1 and counted using victim reports, 1993-2009 
mchfrvat15.csv		Appendix table 15. Standard errors for figure 22: Percent of violent victimizations involving intimate partners with series incidents counted as 1 and counted using victim reports for females 12 and older, 1993-2009 
