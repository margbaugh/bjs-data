Federal Deaths in Custody and During Arrest, 2016-2017 – Statistical Tables  NCJ 252838		
		
This zip archive contains tables in individual .csv spreadsheets from		
Federal Deaths in Custody and During Arrest, 2016-2017 – Statistical Tables  NCJ 252838		
The full electronic report is available at: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7190		
		
Filenames			Table name
fdcda1617stt01.csv		Table 1. Number of deaths, by type of death and federal agency, FY 2016 and FY 2017
fdcda1617stt02.csv		Table 2. Arrest-related deaths, by manner of death and weapon causing death, FY 2016 and FY 2017
fdcda1617stt03.csv		Table 3. Arrest-related deaths, by decedent characteristics, FY 2016 and FY 2017
fdcda1617stt04.csv		Table 4. Arrest-related deaths, by reason for law enforcement contact and alleged decedent offense, FY 2016 and FY 2017
fdcda1617stt05.csv		Table 5. Arrest-related deaths, by decedent actions during the incident, FY 2016 and FY 2017
fdcda1617stt06.csv		Table 6. Law enforcement actions during arrest-related deaths, FY 2016 and FY 2017
fdcda1617stt07.csv		Table 7. Law enforcement use of weapons and response during arrest-related deaths, FY 2016 and 2017
fdcda1617stt08.csv		Table 8. Deaths in custody, by manner and location of death, FY 2016 and FY 2017
fdcda1617stt09.csv		Table 9. Deaths in custody, by decedent characteristics, FY 2016 and FY 2017
fdcda1617stt10.csv		Table 10. Deaths in custody, by decedent offense and status, FY 2016 and FY 2017
fdcda1617stt11.csv		Table 11. Responses to the Federal Law Enforcement Agency Deaths in Custody Reporting Program, FY 2016 and FY 2017
		
				Figure
fdcda1617stf01.csv		Figure 1. Percent of deaths, by type and manner of death, FY 2016 and FY 2017
		
				Appendix table
fdcda1617stat01.csv		Appendix table 1. Counts and percentages for figure 1: Percent of deaths, by type and manner of death, FY 2016 and FY 2017
