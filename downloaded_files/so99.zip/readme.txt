SHERIFFS' OFFICES 1999
NCJ 186479																	
																	
This zip archive contains tables and figures in individual .wk1
spreadsheets from the 1999 Law Enforcement and Administrative
Statistics (LEMAS) report, "Sheriffs' Offices 1999". 
The full report including tables and graphics in .pdf format 
are available from: http://www.ojp.usdoj.gov/bjs/abstract/so99.htm

This report is one in a series.  More recent editions
may be available. To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#sd



																	
Tables:																	
																	
so9901.wk1	Table 1. Employment by general purpose State and local
                law enforcement agencies in the United States, 1999																
so9902.wk1 	Table 2. Sheriffs' offices, by number of sworn and civilian
                personnel, 1999
so9903.wk1	Table 3. Sheriffs' offices and full-time personnel, by
		size of population served, 1999
so9904.wk1	Table 4. Average number of employees in sheriffs' offices,
		by size of population served, 1999
so9905.wk1	Table 5. Officers assigned to respond to citizen calls
		for service in sheriffs' offices, by size of population
		served, 1999
so9906.wk1	Table 6. Job function category of full-time employees
		in sheriffs' offices, 1999
so9907.wk1	Table 7. Authorized full-time strength of sheriffs' offices,
		and percent of authorized strength employed, by size of
		population served, 1999
so9908.wk1	Table 8. Use of sworn reserve/auxillary officers, and
		nonsworn community service officers/police service aides
		by sheriffs' offices, by size of population served, 1999
so9909.wk1	Table 9. Stations and substations operated by sheriffs'
		offices, by size of population served, 1999
so9910.wk1	Table 10. Types of patrol used on a routine basis by sheriffs'
		offices, by size of population served, 1999
so9911.wk1	Table 11. Dispatch functions of sheriffs' offices, by
		size of population served, 1999
so9912.wk1	Table 12. Participation in a 9-1-1 emergency telephone
		system by sheriffs' offices, by size of	population 
		served, 1999
so9913.wk1	Table 13. Crime investigation functions of sheriffs'
		offices, by size of population served, 1999
so9914.wk1	Table 14. Investigative support functions of sheriffs' 
		offices, by size of population served, 1999
so9915.wk1	Table 15. Court-related functions of sheriffs' 
		offices, by size of population served, 1999
so9916.wk1	Table 16. Detention facilities of sheriffs'
		offices, by size of population served, 1999
so9917.wk1	Table 17. Traffic and vehicle-related functions of local
		police offices, by size of population served, 1999
so9918.wk1	Table 18. Special operations functions of sheriffs'
		offices, by size of population served, 1999
so9919.wk1	Table 19. Special public safety functions of sheriffs'
		offices, by size of population served, 1999
so9920.wk1	Table 20. Sheriffs' offices with a community
		policing plan, by size of population served, 1999
so9921.wk1	Table 21. Community policing training for new officer
		recruits and in-service officers in sheriffs'
		offices, by size of population served, 1999
so9922.wk1	Table 22. Community policing officers in sheriffs'
		offices, by size of population served, 1999
so9923.wk1	Table 23. School resource officers in sheriffs'
		offices, by size of population served, 1999
so9924.wk1	Table 24. Community-oriented policies for sworn personnel
		in sheriffs' offices, by size of population
		served, 1999
so9925.wk1	Table 25. Community policing activities of sheriffs'
		offices, by size of population served, 1999
so9926.wk1	Table 26. Surveying of citizens by sheriffs' offices,
		by size of population served, 1999
so9927.wk1	Table 27. sheriffs' offices providing citizens with
		routine access to crime statistics or crime maps, by size
		of population served, 1999
so9928.wk1	Table 28. Selected types of computers used by sheriffs'
		offices for administrative functions, by size of
		population served, 1999
so9929.wk1	Table 29. Administrative records stored in a computerized
		format by sheriffs' offices, by size of population
		served, 1999
so9930.wk1	Table 30. sheriffs' offices using computer-aided
		dispatch, by size of population served, 1999
so9931.wk1	Table 31. Offender and suspect records stored in a 
		computerized format by sheriffs' offices, by size
		of population served, 1999
so9932.wk1	Table 32. Sheriffs' offices using computers for
		criminal investigations, by size of population served, 1999
so9933.wk1	Table 33. Investigative records stored in a computerized
		format by sheriffs' offices, by size of population
		served, 1999
so9934.wk1	Table 34. Traffic and vehicle-related records stored in a
		computerized format by sheriffs' offices, by size
		of population served, 1999
so9935.wk1	Table 35. Records of crime and calls for service stored in a
		computerized format by sheriffs' offices, by size
		of population served, 1999
so9936.wk1	Table 36. Use of computers for crime analysis and crime
		mapping by sheriffs' offices, by size of population
		served, 1999
so9937.wk1	Table 37. Use of computers for Internet purposes by
		sheriffs' offices, by size of population served, 1999
so9938.wk1	Table 38. Types of in-field computers or terminals used by
		sheriffs' offices, by size of population served, 1999
so9939.wk1	Table 39. Use of in-field computers for field reports and
		communications, by sheriffs' offices, by size of
		population served, 1999
so9940.wk1	Table 40. Computerized information accessible to in-field
		officers of sheriffs' offices, by size of population
		served, 1999
so9941.wk1	Table 41. Methods for transmitting criminal incident reports
		to a central information system in sheriffs' offices,
		by size of population served, 1999
so9942.wk1	Table 42. Written policies or procedures on discretionary
		arrest powers and domestic disputes in sheriffs' 
		offices, by size of population served, 1999
so9943.wk1	Table 43. Written policies or procedures on handling special
		populations in sheriffs' offices, by size of
		population served, 1999
so9944.wk1	Table 44. Written policies or procedures on officer use of
		force in sheriffs' offices, by size of population
		served, 1999
so9945.wk1	Table 45. Written policies or procedures on conduct and
		appearance, maximum work hours, and handling of citizen
		complaints in sheriffs' offices, by size of population
		served, 1999

Figures:

so99f01.wk1	Figure 1. Full-time employment by sheriffs' offices,
		1990, 1993, 1997, and 1999

so99f02.wk1	Figure 2. Percent of sheriffs' offices using foot or bicycle
		patrol units on a routine basis, by size of population
		served, 1997 and 1999

so99f03.wk1	Figure 3. Sheriffs' offices participating in a 9-1-1 emergency
		telephone system, 1990, 1993, 1997, and 1999.	

so99f04.wk1	Figure 4. Community policing plans of sheriffs' offices, 1999	

so99f05.wk1	Figure 5. Percent of sworn personnel in sheriffs' offices
		designated as community policing officers, by size of 
		population served, 1999

so99f06.wk1	Figure 6. Percent of sworn personnel of a sheriff's office who
		regularly met with citizens to discuss crime-related problems, 1999	

so99f07.wk1	Figure 7. Purposes for which sheriffs' offices used
		information collected in citizen surveys, 1999	

so99f08.wk1	Figure 8. Methods for accessing crime statistics provided
		to citizens by sheriffs' offices, 1999

so99f09.wk1	Figure 9. Percent of sheriffs' office dispatch systems
		that were computerized, by size of population served, 1990 and 1999

so99f10.wk1	Figure 10. Percent of sheriffs' officers employed by an
		office with computerized offender and suspect information,
		1990 and 1999	

so99f11.wk1	Figure 11. Number of in-field computers or terminals per 100
		sworn officers in sheriffs' offices, by size of	population
		served, 1999

so99f12.wk1	Figure 12. Percent of sworn personnel employed by a sheriffs'
		office in which patrol officers have direct access to
		information through in-field computers, 1999	

so99f13.wk1	Figure 13. Percent of sworn personnel employed by a sheriffs'
		office with written policies or procedures, by subject
		area, 1999															
																	
														
