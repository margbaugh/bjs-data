This file contains tables in individual spreadsheets from the 2000 National Corrections Reporting Program.  
It is one of a series of files from the National Corrections Reporting Program since 1993.
All of the files may be obtained from http://www.ojp.usdoj.gov/bjs/dtdata.htm#ncrp.
Three groups of tables -- sentence length, time served and most serious offense -- 
are archived for each year In addition to the list of tables in this file, the tables in the
related archives are listed below.*

This Zip archive, Most serious offense of State prisoners, 2000, NCJ 199937 contains the following tables:

   File name        Contents

ncrp0001.wk1        State prison admissions: offense, by admission type
ncrp0002.wk1        New court commitments to State prisons: offense, by age at admission
ncrp0003.wk1        Parole violators returned to State prison: offense, by age at admission
ncrp0004.wk1        New court commitments to State prisons: offense, by gender, race, and Hispanic origin
ncrp0005.wk1        Parole violators returned to State prison: offense, by gender, race, and Hispanic origin
ncrp0012.wk1        First entries to parole supervision from State prison: method of prison release, by offense
ncrp0013.wk1        First entries to parole supervision from State prison: offense, by gender, race, and  Hispanic origin
ncrp0014.wk1        State parole discharges: method of parole discharge, by offense 

*Note:  Beginning in 1999, Table 7 (New court commitments to State prison:  sentence length and minimum time to be served, by offense) was discontinued.  

Two related archives are also available.  The tables in these
archives are listed below.

Time Served in State Prison (NCJ 199935)
                    
          State prison releases: time served in prison, by offense and
     release type

          First releases from State prison: sentence length, time
     served, and percent of sentence served in prison, by offense
     
          First releases from State prison: sentence length and time
     served in prison, by offense and gender
                    
          First releases from State prison: sentence length and time
     served in prison, by offense and race 
                    
          Successful first State parole discharges: sentence length
     and time served, by offense

          Unsuccessful first State parole discharges: sentence length
     and time served, by offense

Sentence length of State prisoners (NCJ 199936)

          State prison admissions: sentence length, by offense and
     admission type
          
          First releases from State prison: sentence length, time
     served, and percent of sentence served in prison, by offense
          
          First releases from State prison: sentence length and time
     served in prison, by offense and gender
                    
          First releases from State prison: sentence length and time
     served in prison, by offense and race 
                    
          Successful first State parole discharges: sentence length
     and time served, by offense
     
          Unsuccessful first State parole discharges: sentence length
     and time served, by offense