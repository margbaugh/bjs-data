This file contains tables in individual spreadsheets on U.S.
military corrections from Correctional Populations
in the United States, 1998 NCJ - 192929
 
It is one of a series of files from the National Corrections
Reporting Program since 1993. All of the files may be obtained from
http://www.ojp.usdoj.gov/bjs/pubalph.htm#Correctional Population in United States
Six section of tables -- Jail inmates, Probation, Prisoners, Parole, 
Capital punishment, and U.S. military corrections.

In addition to the list of tables in this file, the tables in the
related archives are listed below.

 
U.S. military corrections in 1998

File name       Table           Title
cpu98801.wk1  	Table 8.1  	Number of military correctional facilities, capacity, and number of prisoners, by branch
				of service holding prisoners, type of facility, and location, December 31, 1998
cpu98802.wk1  	Table 8.2  	Number of prisoners under military jurisdiction, 
				by branch of service, December 31, 1997, and 1998
cpu98803.wk1  	Table 8.3  	Number of prisoners under military jurisdiction, by branch
				of service to which prisoners belonged and branch of service
				holding them, December 31, 1998
cpu98804.wk1  	Table 8.4 	Percent of prisoners under military jurisdiction, by branch of service
				to which prisoners belonged and branch of service holding them,
				December 31, 1998
cpu98805.wk1  	Table 8.5  	Number of prisoners under military jurisdiction, by officer/enlisted status, gender, race,
				and Hispanic origin, December 31, 1998
cpu98806.wk1  	Table 8.6  	Number of prisoners under military jurisdiction, by most serious offense, officer/enlisted status, 
				and branch of service,  December 31, 1998
cpu98807.wk1  	Table 8.7 	Percent of prisoners under military jurisdiction, by most serious offense, officer/enlisted status,
				and branch of service, December 31, 1998
cpu98608.wk1  	Table 8.8 	Number of prisoners under military jurisdiction, by sentence length,
				office/enlisted status, and branch of service, December 31, 1998
cpu98809.wk1  	Table 8.9  	Number of admissions to U.S. military confinement facilities, by type of admission,
				officer/enlisted status, and branch of service holding prisoners, 1998
cpu98810.wk1  	Table 8.10  	Percent of admissions to U.S. military confinement facilities, by type of admission,
				officer/enlisted status, and branch of service holding prisoners, 1998
cpu98811.wk1  	Table 8.11 	Admissions to U.S. military confinement facilities, by type of admission,
				and branch of service to which prisoners belonged, 1998
cpu98812.wk1  	Table 8.12  	Number of pre-trial confinements in U.S. military confinement facilities, by officer/enlisted
				status and branch of service, 1997 and 1998
cpu98813.wk1  	Table 8.13  	Number of releases from U.S. military confinement facilities, by method of release, officer/enlisted
				status, and branch of service, 1998



Tables in the related archives are listed below.

Jail inmates in 1998
 
File name	Table           Title
cpu98201.wk1  	Table 2.1	Persons under jail supervision, by confinement 
				status and type of program, midyear 1995-98
cpu98202.wk1  	Table 2.2  	One-day count and average daily population 
				of jail inmates, midyear 1990 and 1995-98
cpu98203.wk1  	Table 2.3  	Gender, race, and Hispaic origin of local jail
				inmates, midyear 1990 and 1995-98
cpu98204.wk1  	Table 2.4  	Number of jail inmates and rates per
				100,000 U.S. residents, midyear 1990-1998
cpu98205.wk1  	Table 2.5  	Number of jail inmates and rates per 
				100,000 U.S. residents, by race, midyear 1990-1998
cpu98206.wk1  	Table 2.6  	Conviction status of adult jail inmates, by gender, 
				midyear 1990 and 1995-98
cpu98207.wk1  	Table 2.7  	Jail capacity and occupancy, midyear 1990 and 1995-98
cpu98208.wk1  	Table 2.8  	The 25 largest local jail jurisdictions:  Number of inmates held,
				average, daily population, rated capacity, midyear 1996-98
cpu98209.wk1  	Table 2.9  	Standard error estimates for the Annual Survey of Jails, 1998
cpu98210.wk1  	Table 2.10  	Standard error estimates for the number of inmates and
				rated capacity for the Annual Survey of Jails, midyear 1990-1998



Probation in 1998
 
File name	Table           Title
cpu98301.wk1  	Table 3.1  	Characteristics of adults on probation, 1998
cpu98302.wk1  	Table 3.2  	Adults on probation, 1998
cpu98303.wk1  	Table 3.3  	Adults on probation, by status of probation, 1998
cpu98304.wk1  	Table 3.4  	Adults on probation, by status of supervision, 1998
cpu98305.wk1  	Table 3.5 	Adults entering probation, by type of sentence, 1998
cpu98306.wk1  	Table 3.6  	Adults leaving probation, by type of discharge, 1998
cpu98307.wk1  	Table 3.7  	Adults on probation, by gender and Hispanic origin, 1998
cpu98308.wk1  	Table 3.8  	Adults on probation, by race, 1998
cpu98309.wk1  	Table 3.9  	Adults on probation, by severity of offense, 1998
cpu98310.wk1  	Table 3.10 	Adults on probation under intensive supervision,
				under electronic monitoring, in a bootcamp, or incarcerated, 1998
cpu98311.wk1  	Table 3.11  	Adults on probation, by selected offenses, 1998



Prisoners in 1998
 
File name       Table           Title
cpu98501.wk1	Table 5.1  	Prisoners under State or Federal jurisdiction, by sentence length, 1997 and 1998
cpu98502.wk1  	Table 5.2  	Male prisoners under State and Federal jurisdiction, by sentence length, 1997 and 1998
cpu98503.wk1  	Table 5.3  	Female prisoners under State or Federal jurisdiction, by sentence length, 1997 and 1998
cpu98504.wk1  	Table 5.4  	Incarceration rates for prisoners under State or Federal jurisdiction
				or in State or Federal custody, by sentence length, 1998
cpu98505.wk1  	Table 5.5  	Prisoners housed in jails because of crowded State facilities, by gender, 1997 and 1998
cpu98506.wk1  	Table 5.6  	Prisoners under State or Federal jurisdiction, by race, 1998
cpu98507.wk1  	Table 5.7  	Male prisoners under State or Federal jurisdiction, by race, 1998
cpu98508.wk1  	Table 5.8  	Female prisoners under State or Federal jurisdiction, by race, 1998
cpu98509.wk1  	Table 5.9  	Prisoners under State and Federal jurisdiction, by gender and Hispanic origin, 1998
cpu98510a.wk1 	Table 5.10a  	Sentenced prisoners admitted to State or Federal jurisdiction, by type of admission, 1998
cpu98510b.wk1  	Table 5.10b  	Sentenced prisoners released from State or Federal jurisdiction, by type of release, 1998
cpu98511a.wk1  	Table 5.11a  	Sentenced male prisoners admitted to State or Federal jurisdiction, by type of admission, 1998
cpu98511b.wk1  	Table 5.11b  	Sentenced male prisoners released from State or Federal jurisdiction, by type of release, 1998
cpu98512a.wk1  	Table 5.12a  	Sentenced female prisoners admitted to State or Federal jurisdiction, by type of admission, 1998
cpu98512b.wk1  	Table 5.12b  	Sentenced female prisoners released from State or Federal jurisdiction, by type of release, 1998
cpu98513.wk1  	Table 5.13  	Sentenced prisoners released conditionally or unconditionally from State or Federal jurisdiction, 
				by type of release, 1998
cpu98514.wk1  	Table 5.14  	Sentenced male prisoners released conditionally or unconditionally from State or Federal jurisdiction,
				by type of release, 1998
cpu98515.wk1  	Table 5.15  	Sentenced female prisoners released conditionally or unconditionally from State or Federal jurisdiciton, 
				by type of release, 1998
cpu98516.wk1  	Table 5.16  	Sentenced prisoners admitted to State or Federal jurisdiction for violation of parole
				or other conditional release, by gender and status of sentence, 1998
cpu98517.wk1  	Table 5.17  	Deaths among sentenced prisoners under State or Federal jurisdiction, by gender and cause of death, 1998
cpu98518.wk1  	Table 5.18  	Prisoners in custody of State or Federal correctional authorities, by sentence length, 1997 and 1998
cpu98519.wk1  	Table 5.19  	Male prisoners in custody of State or Federal correctional authorities, by sentence length, 1997 and 1998
cpu98520.wk1  	Table 5.20  	Female prisoners in custody of State or Federal correctional authorities, by sentence length, 1997 and 1998



Parole in 1998

File name       Table           Title
cpu98601.wk1  	Table 6.1  	Characteristics of adults on parole, 1998
cpu98602.wk1  	Table 6.2  	Adults on parole, 1998
cpu98603.wk1  	Table 6.3  	Adults on parole, by status of supervision, 1998
cpu98604.wk1  	Table 6.4  	Adults entering parole, by type of sentence, 1998
cpu98605.wk1  	Table 6.5  	Adults leaving parole, by type of discharge, 1998
cpu98606.wk1  	Table 6.6  	Adults on parole, by gender and Hispanic origin, 1998
cpu98607.wk1  	Table 6.7  	Adults on parole, by race, 1998
cpu98608.wk1  	Table 6.8  	Adults on parole, by sentence length, 1998
cpu98609.wk1  	Table 6.9  	Adults on parole under intensive supervision, under
				electronic monitoring, or in a bootcamp, 1998
cpu98610.wk1  	Table 6.10  	Adults on parole, by type of release, 1998
cpu98611.wk1  	Table 6.11  	Deaths of adults on parole, by cause of death, 1998



Capital punishment in 1998

File name       Table           Title
cpu98701.wk1 	Table 7.1  	Summary characteristics of all prisoners present at yearend, received
				from court, and removed from under a sentence of death, 1998
cpu98702.wk1  	Table 7.2  	Movement of all prisoners under sentence of death, by race, 1998
cpu98703.wk1  	Table 7.3  	Movement of female prisoners under sentence of death, by race, 1998
cpu98704.wk1  	Table 7.4  	Movement of Hispanic prisoners under sentence of death, 1998
cpu98705.wk1  	Table 7.5  	Time between sentencing and the yearend for prisoners
				under sentence of death, 1998
cpu98706.wk1  	Table 7.6  	Age of prisoners under sentence of death, 1998
cpu98707.wk1  	Table 7.7 	Legal status at time of capital offense for prisoners under sentence of death, 1998
cpu98708.wk1  	Table 7.8  	Felony history of prisoners under sentence of death, 1998
cpu98709.wk1  	Table 7.9.  	Age of prisoners received from court under sentence of death, by race, 1998
cpu98710.wk1  	Table 7.10  	Level of education completed by prisoners received from court
				under sentence of death, 1998
cpu98711.wk1  	Table 7.11  	Legal status at time of capital offense for prisoners 
				received from court under sentence of death, by race, 1998
cpu98712.wk1  	Table 7.12  	Felony history of prisoners received from court
				under sentence of death, by race, 1998
cpu98713.wk1  	Table 7.13 	Means of removal for all prisoners who left death row, by race, 1998
cpu98714.wk1  	Table 7.14  	Status of prisoners removed from death row, by race, 1998
cpu98715.wk1  	Table 7.15  	Time between sentencing and removal for prisoners
				removed from death row, 1998
cpu98716.wk1  	Table 7.16  	Age of prisoners removed from death row, 1998
cpu98717.wk1  	Table 7.17  	Legal status at time of capital offense for prisoners removed from death row, 1998
cpu98718.wk1  	Table 7.18  	Felony history of prisoners removed from death row, 1998
cpu98719.wk1  	Table 7.19  	Prisoners executed under civil authority in the United States, by year, region, and jurisdiction, 1930-98
cpu98720.wk1  	Table 7.20  	Prisoners executed under civil authority in the United States, by race and offense, 1930-98



