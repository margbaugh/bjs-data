Census of Tribal Justice Agencies in 2002, NCJ 205332			

This zip archive contains tables in individual .csv spreadsheets
from Census of Tribal Justice Agencies in 2002, NCJ 205332.
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/ctjaic02.htm

Filename			Tables

ctjaic02t01.csv			Table 1.  American Indian and Alaska Native (AIAN) population, by place of residence, 2000 
ctjaic02t02.csv			Table 2.  Number of tribes, Public Law 280 status, and court systems by State
ctjaic02t03.csv			Table 3.  Tribal law enforcement, 2002 
ctjaic02t04.csv			Table 4.  Tribal cross deputization and authority recognition on and off reservation  
ctjaic02t05.csv			Table 5.  Tribal court systems, 2002  
ctjaic02t06.csv			Table 6.  Type of separate courts in tribal justice system, 2002 
ctjaic02t07.csv			Table 7.  Number of full time judges, prosecutors, public defenders, and attorneys working in the tribal justice system, 2002   
ctjaic02t08.csv			Table 8.  Tribal law enforcement detention functions, 2002  
ctjaic02t09.csv			Table 9.  Types of intermediate sanctions in tribal adult criminal sentencing, 2002   
ctjaic02t10.csv			Table 10.  Tribal law enforcement criminal justice data access, 2002  
ctjaic02t11.csv			Table 11.  Tribal offender, incident data caseload, 2002  
ctjaic02t12.csv			Table 12.  Tribal justice agencies by whether electronically networked, 2002 
ctjaic02t13.csv			Table 13.  Tribal justice criminal statistics electronic sharing, 2002
