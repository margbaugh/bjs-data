CENSUS OF PUBLICLY FUNDED FORENSIC CRIME LABORATORIES, 2002 NCJ 207205																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .csv spreadsheets from the
BJS report, "Census of Publicly Funded Forensic Crime Laboratories, 2002". 
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cpffcl02.htm 
----------------------------------------------------------------------------
																	
Filename		Table																
																	
cpffcl0201.csv	Table 1. Publicly funded forensic crime laboratories and employees in the United States, by size of laboratory, 2002	
cpffcl0202.csv	Table 2. Publicly funded forensic crime laboratories and employees in the United States, by type of jurisdiction served, 2002
cpffcl0203.csv	Table 3. Employment by publicly funded forensic crime laboratories in the United States, by size of laboratory, 2002
cpffcl0204.csv	Table 4. Employment by publicly funded forensic crime laboratories in the United States, by type of jurisdiction served, 2002
cpffcl0205.csv	Table 5. Median number of FTE's in different employment categories, by size of laboratory, 2002
cpffcl0206.csv	Table 6. Median number of FTE's in different employment categories, by type of jurisdiction served, 2002
cpffcl0207.csv	Table 7. Forensic crime laboratory functions, by size of laboratory, 2002
cpffcl0208.csv	Table 8. Forensic crime laboratory functions, by type of jurisdiction served, 2002
cpffcl0209.csv	Table 9. Cases received and yearend case backlog, by size of laboratory, 2002
cpffcl0210.csv	Table 10. Cases received and yearend case backlog, by type of jurisdiction served, 2002
cpffcl0211.csv	Table 11. Requests for forensic services and estimated yearend backlog in the Nation's publicly funded forensic crime laboratories, by type of function, 2002
cpffcl0212.csv	Table 12. Median number of requests for forensic services and estimated yearend backlog in the Nation's publicly funded forensic crime laboratories, by size of laboratory, 2002
cpffcl0213.csv	Table 13. Median number of requests for forensic services and estimated yearend backlog in the Nation's publicly funded forensic crime laboratories, by type of jurisdiction served, 2002
cpffcl0214.csv	Table 14. Expected and actual requests completed per examiner FTE, by type of function, 2002
cpffcl0215.csv	Table 15. Estimated additional personnel needs in order to achieve a 30-day turnaround on all requests for forensic services received, by type of function, 2002
cpffcl0216.csv	Table 16. Outsourcing of requests for forensic services, by size of laboratory, 2002
cpffcl0217.csv	Table 17. Outsourcing of requests for forensic services, by type of jurisdiction served, 2002
cpffcl0218.csv	Table 18. Publicly funded labs accredited by professional organizations, by size of laboratory, 2002
cpffcl0219.csv	Table 19. Publicly funded labs accredited by professional organizations, by jurisdiction served, 2002
cpffcl0220.csv	Table 20. Operating budget of publicly funded laboratories, by size of laboratory, 2002
cpffcl0221.csv	Table 21. Operating budget of publicly funded laboratories, by type of jurisdiction served, 2002
cpffcl0222.csv	Table 22. Laboratories receiving at least some funding from various sources, by size of laboratory, 2002
cpffcl0223.csv	Table 23. Laboratories receiving at least some funding from various sources, by type of jurisdiction served, 2002
cpffcl0224.csv	Table 24. Median base annual salary for selected positions in publicly funded laboratories, by size of laboratory, 2002 
cpffcl0225.csv	Table 25. Median base annual salary for selected positions in publicly funded laboratories, by type of jurisdiction served, 2002

cpffcl02f1.csv	Figure 1. Forensic crime laboratory functions, 2002
cpffcl02f2.csv	Figure 2. Procedures included in standard protocols for latent prints, 2002
cpffcl02f3.csv	Figure 3. Procedures included in standard protocols for controlled substances, 2002
cpffcl02f4.csv	Figure 4. Procedures included in standard protocols for DNA analysis, 2002
cpffcl02f5.csv	Figure 5. Types of proficiency tests used for analysts/examiners, 2002
cpffcl02f6.csv	Figure 6. Average proportion of laboratory budgets from Federal, State, and local sources, by type of jurisdiction served, 2002