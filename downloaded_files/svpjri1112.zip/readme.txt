Sexual Victimization in Prisons and Jails  Reported by Inmates, 2011-12 NCJ 241399		
		
 		
This zip archive contains tables in individual .csv spreadsheets from		
Sexual Victimization in Prisons and Jails  Reported by Inmates, 2011-12 NCJ 241399		
		
The full electronic report is available at: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4654		
		
		
Filename		Table title
svpjri1112t01.csv		Table 1.  Adult inmates reporting sexual victimization, by type of facility and incident, National Inmate Survey, 2011�12
svpjri1112t02.csv		Table 2.  Prevalence of sexual victimization across inmate surveys, by type of incident, National Inmate Survey, 2007, 2008�09, and 2011�12
svpjri1112t03.csv		Table 3.  Facilities with high rates of  inmate-on-inmate sexual victimization, by type of facility, National Inmate Survey, 2011-12
svpjri1112t04.csv		Table 4.  Facilities with high rates of  staff sexual misconduct, by type of facility, National Inmate Survey, 2011-12
svpjri1112t05.csv		Table 5:  Facilities with low rates of sexual victimization, by type of facility, National Inmate Survey, 2011-12
svpjri1112t06.csv		Table 6.  Rates of sexual victimization in special correctional facilities, by type of incident and facility, National Inmate Survey, 2011-12
svpjri1112t07.csv		Table 7.  Prevalence of sexual victimization, by type of incident and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112t08.csv		Table 8.  Prevalence of sexual victimization, by type of incident and inmate sexual characteristics, National Inmate Survey, 2011�12
svpjri1112t09.csv		Table 9.  Prevalence of sexual victimization, by type of incident and inmate criminal justice status and history, National Inmate Survey, 2011�12
svpjri1112t10.csv		Table 10. Juvenile inmates reporting sexual victimization, by type of incident, National Inmate Survey, 2011�12
svpjri1112t11.csv		Table 11. Prevalence of sexual victimization, by type of incident and age of inmate, National Inmate Survey, 2011�12
svpjri1112t12.csv		Table 12. Prevalence of sexual victimization among juveniles ages 16�17 and inmates ages 18�19 and 20�24, by type of incident and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112t13.csv		Table 13. Circumstances surrounding incidents among juveniles ages 16�17 and inmates ages 18�19 and 20�24, by type of victimization, National Inmate Survey, 2011�12
svpjri1112t14.csv		Table 14. Prevalence of victimization by current mental health status and history of mental health problems among inmates, by type of facility, National Inmate Survey, 2011�12
svpjri1112t15.csv		Table 15. Prevalence of serious psychological distress among adults in prisons, jails, and the U.S. civilian noninstitutional population, 2011�12
svpjri1112t16.csv		Table 16. Prevalence of inmate-on-inmate sexual victimization, by current mental health status and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112t17.csv		Table 17. Prevalence of staff sexual misconduct, by current mental health status and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112t18.csv		Table 18. Circumstances surrounding incidents among adult inmates, by current mental health status and type of victimization, National Inmate Survey, 2011�12
svpjri1112t19.csv		Table 19. Prevalence of sexual victimization, by type of incident and inmate sexual orientation, National Inmate Survey, 2011�12
svpjri1112t20.csv		Table 20. Circumstances surrounding incidents of sexual victimization among heterosexual and non-heterosexual inmates, National Inmate Survey, 2011�12
		
Filename		Figure Title
svpjri1112af01.csv		Figure 1. Confidence intervals at the 95% level for prisons with high rates of inmate-on-inmate sexual victimization, National Inmate Survey, 2011�12
svpjri1112af02.csv		Figure 2. Confidence intervals at the 95% level for jails with high rates of inmate-on-inmate sexual victimization, National Inmate Survey, 2011�12
svpjri1112af03.csv		Figure 3. Confidence intervals at the 95% level for prisons with high rates of staff sexual misconduct, National Inmate Survey, 2011�12
svpjri1112af04.csv		Figure 4. Confidence intervals at the 95% level for jails with high rates of staff sexual misconduct, National Inmate Survey, 2011�12
		
Filename		Appendix table title
svpjri1112at01.csv		Appendix table 1: Characteristics of state and federal prisons and prevalence of sexual victimization, by facility, National Inmate Survey, 2011-12
svpjri1112at02.csv		Appendix table 2:  Percent of prison inmates reporting sexual victimization, by type of incident and facility, National Inmate Survey, 2011-12
svpjri1112at03.csv		Appendix table 3:  Percent of prison inmates reporting sexual victimization by level of coercion, by facility, National Inmate Survey, 2011-12
svpjri1112at04.csv		Appendix table 4:  Percent of prison inmates reporting nonconsensual sexual acts and abusive sexual contacts, by facility, National Inmate Survey, 2011-12
svpjri1112at05.csv		Appendix table 5:  Characteristics of jails and prevalence of sexual victimization, by facility, National Inmate Survey, 2011-12
svpjri1112at06.csv		Appendix table 6:  Percent of jail inmates reporting victimization, by type of incident and facility, National Inmate Survey, 2011-12
svpjri1112at07.csv		Appendix table 7:  Percent of jail inmates reporting sexual victimization, by level of coercion, and facility, National Inmate Survey, 2011-12
svpjri1112at08.csv		Appendix table 8:  Percent of jail inmates reporting nonconsensual sexual acts and abusive sexual contacts, by facility, National Inmate Survey, 2011-12
svpjri1112at09.csv		Appendix table 9:  Characteristics of special correctional facilities and prevalence of sexual victimization, by facility, National Inmate Survey, 2011-12
svpjri1112at10.csv		Appendix table 10. Standard errors for table 2: Prevalence of sexual victimization across inmate surveys, by type of incident, National Inmate Survey, 2007, 2008�09, and 2011�12
svpjri1112at11.csv		Appendix table 11. Standard errors for table 7: Prevalence of sexual victimization, by type of incident and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112at12.csv		Appendix table 12. Standard errors for table 8: Prevalence of sexual victimization, by type of incident and inmate sexual characteristics, National Inmate Survey, 2011�12
svpjri1112at13.csv		Appendix table 13. Standard errors for table 9: Prevalence of sexual victimization, by type of incident and inmate criminal justice status and history, National Inmate Survey, 2011�12
svpjri1112at14.csv		Appendix table 14. Standard errors for table 10: Juvenile inmates reporting sexual victimization, by type of incident, National Inmate Survey, 2011�12
svpjri1112at15.csv		Appendix table 15. Standard errors for table 11: Prevalence of sexual victimization, by type of incident and age of inmate, National Inmate Survey, 2011�12
svpjri1112at16.csv		Appendix table 16. Standard errors for table 12: Prevalence of sexual victimization among juveniles ages 16�17 and inmates ages 18�19 and 20�24, by type of incident and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112at17.csv		Appendix table 17. Standard errors for table 13: Circumstances surrounding incidents among juveniles ages 16�17 and inmates ages 18�19 and 20�24, by type of victimization, National Inmate Survey, 2011�12
svpjri1112at18.csv		Appendix table 18.  Standard errors for table 14: Prevalence of victimization by current mental health status and history of mental health problems among inmates, by type of facility, National Inmate Survey, 2011�12
svpjri1112at19.csv		Appendix table 19. Standard errors for table 15: Prevalence of serious psychological distress among adults in prisons, jails, and the U.S. civilian noninstitutional population, 2011�12
svpjri1112at20.csv		Appendix table 20. Standard errors for table 16: Prevalence of inmate-on-inmate victimization, by current mental health status and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112at21.csv		Appendix table 21. Standard errors for table 17: Prevalence of staff sexual misconduct, by current mental health status  and inmate characteristics, National Inmate Survey, 2011�12
svpjri1112at22.csv		Appendix table 22. Standard errors for table 18: Circumstances surrounding incidents among adult inmates, by current mental health status and type of victimization, National Inmate Survey, 2011�12
svpjri1112at23.csv		Appendix table 23. Standard errors for table 19: Prevalence of sexual victimization, by type of incident and inmate sexual orientation, National Inmate Survey, 2011�12
svpjri1112at24.csv		Appendix table 24. Standard errors for table 20: Circumstances surrounding incidents of sexual victimization among heterosexual and non-heterosexual inmates, National Inmate Survey, 2011�12
