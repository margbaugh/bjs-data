Hate Crime Reported in NIBRS, 1997-99   NCJ 186765


Filename		Table

hcrnt1.wk1		Table 1.  Hate-bias incidents, by type of bias motivation, 1997-99
hcrnt2.wk1		Table 2.  Most serious offense committed during hate-bias incidents, 1997-99
hcrnt3.wk1 		Table 3.  Most serious offense, by type of bias motivation, 1997-99
hcrnt4.wk1		Table 4.  Type of hate crime victims, 1997-99
hcrnt5.wk1		Table 5.  Victim characteristics by offense type, 1997-99
hcrnt6.wk1		Table 6.  Relationship of victim to offender, by most serious offense committed during incident, 1997-99
hcrnt7.wk1		Table 7.  Group victimization patterns among violent incidents, by most serious offense, 1997-99
hcrnt8.wk1		Table 8.  Offender characteristics, by most serious offense, 1997-99
hcrnt9.wk1		Table 9.  Group offending patterns among violent offenses, by most serious offense, 1997-99
hcrnt10.wk1		Table 10.  Location of hate crime incidents, by type of bias motivation, 1997-99
hcrnt11.wk1		Table 11.  Violent hate crime incidents, by type of weapon, 1997-99
hcrnt12.wk1		Table 12.  Hate crimes cleared by arrest or exceptional means, by most serious offense, 1997-99
hcrnt13.wk1		Table 13.  Arrestee characteristics, by arrest offense type, 1997-99

hcrntf1.wk1		Figure 1.  Ages of victims of violent hate crimes 
hcrntf2.wk1		Figure 2.  Suspected age of violent hate crime offenders
hcrntf3.wk1		Figure 3.  Suspected age of property hate crime offenders 

Appendix table

hcrntat1.wk1		Appendix table.  Population covered by agencies reporting NIBRS hate crime incidents, 1997-99	

