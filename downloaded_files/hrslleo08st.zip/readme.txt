Hiring and Retention of State and Local Law Enforcement Officers, 2008  NCJ 238251		
		
This zip archive contains tables in individual .csv spreadsheets		
Hiring and Retention of State and Local Law Enforcement Officers, 2008  NCJ 238251		
The full report including text and graphics in .pdf format are available from:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4514		
		
		
hrslleo08t01.csv		Table 1. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08t02.csv		Table 2. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08t03.csv		Table 3. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08t04.csv		Table 4. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08t05.csv		Table 5. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08t06.csv		Table 6. Assaults on federal officers with arrest and firearm authority, 2008
hrslleo08t07.csv		Table 7. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08t08.csv		Table 8. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 20088
hrslleo08t09.csv		Table 9. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08t10.csv		Table 10. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08t11.csv		Table 11. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08t12.csv		Table 12. Assaults on federal officers with arrest and firearm authority, 2008
hrslleo08t13.csv		Table 13. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08t14.csv		Table 14. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08t15.csv		Table 15. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08t16.csv		Table 16. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08t17.csv		Table 17. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08t18.csv		Table 18. Assaults on federal officers with arrest and firearm authority, 2008
hrslleo08t19.csv		Table 19. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08t20.csv		Table 20. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08t21.csv		Table 21. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08t22.csv		Table 22. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08t23.csv		Table 23. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08at01.csv		Appendix Table 1. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08at02.csv		Appendix Table 2. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08at03.csv		Appendix Table 3. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08at04.csv		Appendix Table 4. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08at05.csv		Appendix Table 5. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08at06.csv		Appendix Table 6. Assaults on federal officers with arrest and firearm authority, 2008
hrslleo08at07.csv		Appendix Table 7. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08at08.csv		Appendix Table 8. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08at09.csv		Appendix Table 9. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08at10.csv		Appendix Table 10. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08at11.csv		Appendix Table 11. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08at12.csv		Appendix Table 12. Assaults on federal officers with arrest and firearm authority, 2008
hrslleo08at13.csv		Appendix Table 13. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08at14.csv		Appendix Table 14. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08at15.csv		Appendix Table 15. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08at16.csv		Appendix Table 16. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08at17.csv		Appendix Table 17. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08at18.csv		Appendix Table 18. Assaults on federal officers with arrest and firearm authority, 2008
hrslleo08at19.csv		Appendix Table 19. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008
hrslleo08at20.csv		Appendix Table 20. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008
hrslleo08at21.csv		Appendix Table 21. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008
hrslleo08at22.csv		Appendix Table 22. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008
hrslleo08at23.csv		Appendix Table 23. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08at24.csv		Appendix Table 24. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008
hrslleo08f01.csv		Figure 1. Primary function of full-time Federal officers with arrest and firearm authority, September 2008
hrslleo08f02.csv		Figure 2. Percent of federal officers with arrest and firearm authority, by department or branch of government, September 2008
hrslleo08f03.csv		Figure 3. Growth in U.S. Border Patrol employment of officers with arrest and firearm authority, 1996 - 2008
hrslleo08f04.csv		Figure 4. Percent of female and minority federal officers with arrest and firearm authority, 1996 and 2008
hrslleo08f05.csv		Figure 5. Primary function of full-time Federal officers with arrest and firearm authority, September 2008
hrslleo08f06.csv		Figure 6. Percent of federal officers with arrest and firearm authority, by department or branch of government, September 2008
hrslleo08f07.csv		Figure 7. Growth in U.S. Border Patrol employment of officers with arrest and firearm authority, 1996 - 2008
hrslleo08f08.csv		Figure 8. Percent of female and minority federal officers with arrest and firearm authority, 1996 and 2008
hrslleo08f09.csv		Figure 9. Percent of female and minority federal officers with arrest and firearm authority, 1996 and 2008
hrslleo08f10.csv		Figure 10. Percent of federal officers with arrest and firearm authority, by department or branch of government, September 2008
hrslleo08f11.csv		Figure 11. Growth in U.S. Border Patrol employment of officers with arrest and firearm authority, 1996 - 2008
hrslleo08f12.csv		Figure 12. Percent of female and minority federal officers with arrest and firearm authority, 1996 and 2008
hrslleo08f13.csv		Figure 13. Percent of female and minority federal officers with arrest and firearm authority, 1996 and 2008
		
		
 		
