Justice Assistance Grant (JAG) Program, 2021  NCJ 304372
																	
This zip archive contains tables in individual  .csv spreadsheets
from Justice Assistance Grant (JAG) Program, 2021  NCJ 304372	
																	
The full report including text and graphics in .pdf format are available
from: https://bjs.ojp.gov/library/publications/justice-assistance-grant-jag-program-2021
																	
This report is one in a series. More recent editions may be available. To view a list of all in the series go to 
https://bjs.ojp.gov/library/publications/list?series_filter=Justice%20Assistance%20Grant%20%28JAG%29%20Program
																	
Filenames	Table names																
jagp21t01.csv	Table 1. Allocations to state and local governments, fiscal year 2021	
jagp21t02.csv	Table 2. Allocations to U.S. territories and the District of Columbia, fiscal year 2021
jagp21t03.csv	Table 3. Sex Offender Registration and Notification Act bonus fund allocations, fiscal year 2021
jagp21t04.csv	Table 4. Prison Rape Elimination Act bonus fund allocations for states, fiscal year 2021
jagp21t05.csv	Table 5. Prison Rape Elimination Act bonus fund allocations for U.S. territories and the District of Columbia, fiscal year 2021	
																	
		Figures																
jagp21f01.csv	Figure 1. Distribution of fiscal year 2021 Justice Assistance Grant program awards