Criminal Victimization, 2003  NCJ # 205455	

This zip archive contains tables in individual .csv spreadsheets
from Criminal Victimization, 2003  NCJ # 205455	
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cv03.htm

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cv

Spreadsheets	

File Name	 
cv03h1.csv	   Highlight 1:  Violent victimizations
cv03h2.csv	   Highlight 2:  Property  victimizations

  			   Tables
cv03t01.csv	   Table 1.  Criminal victimization, numbers and rates, 2002 and 2003
cv03t02.csv	   Table 2.  Criminal victimization, average annual rates, 2000-2001 and 2002-03
cv03t03.csv	   Table 3.  Rates of criminal victimization and percent change, 1993-2003
cv03t04.csv	   Table 4.  Violent victimization rates of selected demographic categories, 1993-2003
cv03t05.csv	   Table 5.  Property crime rates of selected household demographics, 1993-2003
cv03t06.csv	   Table 6.  Rates of violent crime and personal theft, by gender, race, Hispanic origin, and age, 2003
cv03t07.csv	   Table 7.  Rates of violent crime and personal theft, by household income, marital status, region, and location of residence of victims, 2003
cv03t08.csv	   Table 8.  Property crime victimization, by household income, region, residence, and home ownership of households victimized, 2003
cv03t09.csv	   Table 9.  Victim and offender relationship, 2003
cv03t10.csv	   Table 10.  Presence of weapons in violent crimes, 2003
cv03t0203.csv	   Criminal Victimization, 2002-2003
			   Texttables
cv03tt1.csv	   Text Table 1. Violent crime average rate by gender, 2000-2001 to 2002-03
cv03tt2.csv	   Text Table 2. Violent crime average rate by marital status, 2000-2001 to 2002-03
cv03tt3.csv	   Text Table 3. Violent crime average rate by age, 2000-2001 to 2002-03
cv03tt4.csv	   Text Table 4. Violent crime average rate by annual household income, 2000-2001 to 2002-03
cv03tt5.csv	   Text Table 5. Violent crime average rate by region, and residence, 2000-2001 to 2002-03
cv03tt6.csv	   Text Table 6. Property crime average rate by annual household income, 2000-2001 to 2002-03
cv03tt7.csv	   Text Table 7. Property crime average rate by region, residence and ownership, 2000-2001 to 2002-03
cv03tt8.csv	   Text Table 8. Nonfatal firearm incidents and victims, 1993 and 2003
cv03tt9.csv	   Text Table 9. Violent and property crimes reported to the police, 2003
cv03tt10.csv   Text Table 10. Reporting to police by victim characteristics, 2003
cv03tt11.csv   Text Table 11. Impact of 2000 Census population controls

			   Figures        
cv03f1.csv	   Figure 1.  Violent crime
cv03f2.csv	   Figure 2.  Property crime
cv03f3.csv	   Figure 3.  Violent crime and gender
cv03f4.csv	   Figure 4.  Property crime and owned/rented residences
cv03f5.csv	   Figure 5.  Property crime and urbanicity
cv03f6.csv	   Figure 6.  Property crime and region
cv03f7.csv	   Figure 7.  Percent of violent crime reported to the police
cv03f8.csv	   Figure 8.  Percent of robbery and rape.sexual assault reported to the police
cv03f9.csv	   Figure 9.  Percent of aggravated and simple assault reported to the police 
cv03f10.csv	   Figure 10. Percent of property crime reported to the police
cv03f11.csv	   Figure 11.  Percent of burglary reported to the police
cv03f12.csv	   Figure 12.  Percent of household theft reported to the police 
