Crime Against Persons with Disabilities, 2009-2014 - Statistical Tables		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Crime Against Persons with Disabilities, 2009-2014 - Statistical Tables, NCJ 250200  The full report including text		
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5844
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.bjs.gov/index.cfm?ty=pbse&sid=65		
		
Filename	Table title	
capd09-14t01.csv		Rate of violent victimization and average annual number of persons, by victim's disability status and age, 2010-2014
capd09-14t02.csv		Rate of violent victimization against persons with and without disabilities, by type of crime, 2010-2014
capd09-14t03.csv		Rate of violent victimization against persons with and without disabilities, by victim characteristics, 2010-2014
capd09-14t04.csv		Rate of violent victimization against persons with disabilities, by disability type and type of crime, 2010-2014
capd09-14t05.csv		Rate of violent victimization against persons with disabilities, by disability type and sex, 2010-2014
capd09-14t06.csv		Person of violent crime against persons with disabilities, by type of crime and number of disability types, 2010-2014
capd09-14t07.csv		Rate of violent victimization, by number of disability types and type of crime, 2010-2014
capd09-14t08.csv		Victim-offender relationship, by victim's disability status, 2010-2014
capd09-14t09.csv		Time violent crime occurred, by victim's disability status, 2010-2014
capd09-14t10.csv		Percent of violent crime reported to police, by disability status and disability type, 2010-2014
capd09-14t11.csv		Person who notified police of violent crime, by victim's disability status, 2010-2014
capd09-14t12.csv		Reasons for not reporting violent crime to police, by victim's disability status, 2010-2014
capd09-14t13.csv		Percent of violent crime victims who received services from nonpolice victim services agencies, by victim's disability status, 2010-2014
		
Figure		
capd0914f01			Rate of violent victimization, by disability status, 2009-2014
		
Appendix tables		
capd09-14at01.csv		Rates and standard errors for figure 1: Rate of violent victimization, by disability status, 2009-2014
capd09-14at02.csv		Standard errors for table 1: Rate of violent victimization and average annual number of persons, by victim's disability status and age, 2010-2014
capd09-14at03.csv		Standard errors for table 2: Rate of violent victimization against persons with and without disabilities, by type of crime, 2010-2014
capd09-14at04.csv		Standard errors for table 3: Rate of violent victimization against persons with and without disabilities, by victim characteristics, 2010-2014
capd09-14at05.csv		Standard errors for table 4: Rate of violent victimization against persons with disabilities, by disability type and type of crime, 2010-2014
capd09-14at06.csv		Standard errors for table 5: Rate of violent victimization against persons with disabilities, by disability type and sex, 2010-2014
capd09-14at07.csv		Standard errors for table 6: Percent of violent crime against persons with disabilities, by type of crime and number of disability types, 2010-2014
capd09-14at08.csv		Standard errors for table 7: Rate of violent victimization, by number of disability types and type of crime, 2010-2014
capd09-14at09.csv		Standard errors for table 8: Victim-offender relationship, by victim's disability status, 2010-2014
capd09-14at10.csv		Standard errors for table 9: Time violent crime occurred, by victim's disability status, 2010-2014
capd09-14at11.csv		Standard errors for table 10: Percent of violent crime reported to police, by disability status and disability type, 2010-2014
capd09-14at12.csv		Standard errors for table 11: Person who notified police of violent crime, by victim's disability status, 2010-2014
capd09-14at013.csv		Standard errors for table 12: Reasons for not reporting violent crime to police, by victim's disability status, 2010-2014
capd09-14at14.csv		Standard errors for table 13: Percent of violent crime victims who received services from nonpolice victim services agencies, by victim's disability status, 2010-2014
capd09-14at15.csv		Unadjusted rates and standard errors of violent victimization against persons without disabilities, 2009-2014
capd09-14at16.csv		Unadjusted rates and standard errors for violent victimization against persons without disabilities, by type of crime, 2010-2014 
capd09-14at17.csv		Unadjusted rates and standard errors for violent victimization against persons without disabilities, by victim characteristics, 2010-2014
capd09-14at18.csv		U.S. population, according to the U.S. Census Bureau's American Community Survey Public Use Microdata Sample data, by disability status and demographic characteristics, 2010-2014
