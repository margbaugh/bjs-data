Jail Inmates at Midyear 2008  NCJ 225709

This zip archive contains tables in individual .csv spreadsheets
for Jail Inmates at Midyear 2008  NCJ 225709
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jim08st.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jim
 
Tables	
jim07t01.csv	Table 1: Inmates confined in local jails at midyear, average daily jail population, and incarceration rate, 2000-2008
jim07t02.csv	Table 2: Rated capacity of local jails at midyear, annual increase in capacity, and percent of capacity occupied, 2000-2008
jim07t03.csv	Table 3: Inmates confined in local jails at midyear, by size of jurisdiction, 2000 and 2008  
jim07t04.csv	Table 4: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 29, 2007, and June 30, 2008
jim07t05.csv	Table 5: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2000, 2007, and 2008
jim07t06.csv	Table 6: Characteristics of inmates in local jails, midyear 2000 and 2005-2008
jim07t07.csv	Table 7: Characteristics of inmates in local jails, midyear 2000 and 2005-2008
jim07t08.csv	Table 8: Inmate population in jail jurisdictions reporting on the number of confined non-U.S. citizens, midyear 2000-2008
jim07t09.csv	Table 9: Inmate population in jail jurisdictions reporting on confined persons being held for U.S. Immigration and Customs Enforcement, midyear 2002-2008
jim07t10.csv	Table 10: The 50 largest local jail jurisdictions: Number of inmates held, average daily population, and rated capacity, midyear 2006-2008
jim07t11.csv	Table 11: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006-2008
jim07t12.csv	Table 12: Estimated standard errors by confinement status, Annual Survey of Jails, 2008 
jim07t13.csv	Table 13: Estimated standard errors by selected characteristics, Annual Survey of Jails, 2008
jim07t14.csv	Table 14: Estimated percentages of local jail inmates by selected characteristics and ratio estimates, 2008

Figures	
jim07f01.csv	Figure 1: Inmates confined in local jails at midyear and annual percent change in the jail population, 2000-2008
jim07f02.csv	Figure 2: Annual change in the number of inmates confined in local jails and rated capacity at midyear, 2000-2008


 
 
