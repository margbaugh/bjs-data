Suicide and Homicide in State Prisons and Local Jails  NCJ 210036

This zip archive contains tables in individual .csv spreadsheets from Suicide 
and Homicide in State Prisons and Local Jails  NCJ 210036. The full report including 
text and graphics in pdf format are available from:   http://www.ojp.usdoj.gov/bjs/abstract/shsplj.htm            

          Table     
shsplj01.csv        Table  1    State prison jurisdictions: Number of prisoner deaths, suicides and homicides, and mortality rates, per 100,000 prisoners in custody, 2001-02
shsplj02.csv        Table  2    The 50 largest jail jurisdictions: Number of inmate deaths, suicides, and homicides, and mortality rates, per 100,000 inmates, 2000-02
shsplj03.csv        Table  3    Local jail and State prison inmate mortality rates, per 100,000 inmates, by selected characteristics
shsplj04.csv        Table  4    Average annual jail inmate mortality rates, by most serious current offense, 2000-02
shsplj05.csv        Table  5    Average annual State prison inmate mortality rates, by most serious current offense, 2001-2002
shsplj06.csv        Table  6    Time served since admission by jail inmates and State prisoners committing suicide, by selected characteristics
shsplj07.csv        Table  7    Time of day and location of suicide events in local jails and State prisons
shsplj08.csv        Table  8    Time served, time of day, and location of homicide events in State prisons, 2001-02
shsplj09.csv        Table  9    Mortality rates of U.S. resident population and State prison and local jail inmate populations, per 100,000 residents, 2002

shspljtt1.csv        Text Table 1    Local jail inmate mortality rate, per 100,000 inmates, by facility size, 2002
shspljtt2.csv        Text Table 2    Number of local jail inmate and State prisoner deaths, by inmate age
shspljtt3.csv        Text Table 3    Average annual mortality rate, per 100,000 local jail inmates, by offense type, 2000-02
shspljtt4.csv        Text Table 4    Percent of jail inmate suicides, by time served after admission, 2000-02
shspljtt5.csv        Text Table 5    Percent of State prisoner suicides, by time served after admission, 2001-02
shspljtt6.csv        Text Table 6    Percent of local jail inmate homicides, by time served after admission, 2000-02
shspljtt7.csv        Text Table 7    Median time served since admission by homicide victims in State prison, by selected characteristics


shspljbt1.csv        Box Table 1  Local jail inmate mortality rate, per 100,000 inmates, by cause, 1983-2002
shspljbt2.csv        Box Table 2  State prison inmate mortality rate, per 100,000 inmates, by cause, 1980-2002

          Figures        
shspljfh.csv        Figure highlight table   Numbers of local jail inmate (2000-2002) and State prisoner (2001-2002) deaths reported to the BJS Deaths in Custody Reporting Program
shspljf01.csv       Figure highlight 1   Local jail and State prison inmate suicide rates, per 100,000 inmates, 1980-2002
shspljf02.csv       Figure highlight 2   Local jail and State prison inmate homicide rates, per 100,000 inmates, 1980-2002 
