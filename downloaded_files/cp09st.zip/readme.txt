Capital Punishment, 2009 - Statistical Tables  NCJ 231676

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2009 - Statistical Tables  NCJ 231676, electronic only. 
The full electronic report is available at:


These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to:



Tables:
cp09st02.csv		Table 2.  Method of execution, by state, 2009
cp09st03.csv		Table 3.  Federal capital offenses, by statute, 2009
cp09st04.csv		Table 4.  Prisoners under sentence of death, by region, jurisdiction, and race, 2008 and 2009
cp09st05.csv		Table 5.  Demographic characteristics of prisoners under sentence of death, 2009
cp09st06.csv		Table 6.  Women under sentence of death, by region, jurisdiction, and race, 2008 and 2009
cp09st07.csv		Table 7.  Hispanics under sentence of death, by region and jurisdiction, 2008 and 2009
cp09st08.csv		Table 8.  Persons under sentence of death by sex, race, and Hispanic origin, December 31, 2009
cp09st09.csv		Table 9.  Elapsed time since sentencing for inmates under sentence of death, by sex, race, and Hispanic origin, December 31, 2009
cp09st10.csv		Table 10. Criminal history profile of prisoners under sentence of death, by race and Hispanic origin, 2009
cp09st11.csv		Table 11. Inmates removed from under sentence of death, by jurisdiction and method of removal, 2009
cp09st12.csv		Table 12. Average time between sentencing and execution, by year, 1977-2009
cp09st13.csv		Table 13. Number of inmates executed, by race and Hispanic origin, 1977-2009
cp09st14.csv		Table 14. Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2009
cp09st15.csv		Table 15. Number of persons executed by race, Hispanic origin, and method, 1977-2009
cp09st16.csv		Table 16. Number of executions, by jurisdiction and method, 1977-2009
cp09st17.csv		Table 17. Number of persons executed, by jurisdiction, 1930-2009
cp09st18.csv		Table 18. Prisoners under sentence of death, by jurisdiction and year of sentencing, December 31, 2009
cp09st19.csv		Table 19. Prisoners sentenced to death and outcome of the sentence, by year of sentencing, 1973-2009
cp09st20.csv		Table 20. Number sentenced to death and number of removals, by jurisdiction and reason for removal, 1973-2009
cp09st21.csv		Table 21. Advance count of executions: January 1, 2010 � November 30, 2010


