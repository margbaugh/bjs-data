2004 Local Law Enforcement Block Grant Program, 1996-2004																	
NCJ 203096													
																
  													
--------------------------------------------------------------
This zip archive contains tables in individual .wk1 spreadsheets
from 2004 Local Law Enforcement Block Grant Program, 1996-2004																	
NCJ 203096	the full report including text and graphics in .pdf 
format are available from:
http://www.opj.usdoj.gov/bjs/abstract/llebgp04.htm

---------------------------------------------------------------																
																
Filename		Table																
llebg04f1.csv	Figure 1.  Total local law enforcement block grant award amount for FY 1996-2004																
llebg04f2.csv 	Figure 2.  Number of local governments eligible to receive an award, FY 2004													
llebg0401.csv	Table 1.   State and local government allocation amounts, including Territories, FY 2004
llebg0402.csv   Table 2.   Award allocation and percent change, by State, FY 2004 and FY 1996 

