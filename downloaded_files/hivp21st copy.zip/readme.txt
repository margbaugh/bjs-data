HIV in Prisons, 2021 – Statistical Tables   NCJ 305379		
		
This zip archive contains tables in individual .csv spreadsheets		
from HIV in Prisons, 2021 – Statistical Tables   NCJ 305379. The full report including text		
and grahics in pdf format is available from: https://bjs.ojp.gov/library/publications/hiv-prisons-2021-statistical-tables		
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=HIV%20in%20Prisons%20and%20Jails		
		
Filenames		Table titles
hivp21stt01.csv		Table 1. Persons living with HIV in the custody of state and federal correctional authorities, by sex, 2017–2021
hivp21stt02.csv		Table 2. Number of jurisdictions that tested persons in prison for HIV during the intake process and percent of all prison admissions, by HIV testing practices, 2017 and 2021
hivp21stt03.csv		Table 3. Number of jurisdictions that tested persons in prison for HIV while in custody, by HIV testing practices, 2017 and 2021
hivp21stt04.csv		Table 4. Number of jurisdictions that tested persons in prison for HIV during discharge planning and percent of prison releases, by HIV testing practices, 2017 and 2021
		
			Figures
hivp21stf01.csv		Figure 1. Persons living with HIV and rate of HIV per 100,000 persons in the custody of state and federal correctional authorities, yearend 1991–2021
hivp21stf02.csv		Figure 2. Number of persons living with HIV in the custody of state and federal correctional authorities, by reporter type, 1991–2021
		
			Appendix tables
hivp21stat01.csv	Appendix table 1. Estimates for figure 1: Persons living with HIV and rate of HIV per 100,000 persons in the custody of state and federal correctional authorities, yearend 1991–2021
hivp21stat02.csv	Appendix table 2. Persons living with HIV in the custody of state and federal correctional authorities, by jurisdiction, 2017–2021
hivp21stat03.csv	Appendix table 3. Persons living with HIV in the custody of state and federal correctional authorities, by sex and jurisdiction, 2017–2021
hivp21stat04.csv	Appendix table 4. HIV testing and consent practices of state and federal prison systems during the intake process, by jurisdiction, 2017
hivp21stat05.csv	Appendix table 5. HIV testing and consent practices of state and federal prison systems during the intake process, by jurisdiction, 2021
hivp21stat06.csv	Appendix table 6. HIV testing practices of state and federal prison systems while in custody, by jurisdiction, 2017
hivp21stat07.csv	Appendix table 7. HIV testing practices of state and federal prison systems while in custody, by jurisdiction, 2021
hivp21stat08.csv	Appendix table 8. HIV testing practices of state and federal prison systems during discharge planning, by jurisdiction, 2017
hivp21stat09.csv	Appendix table 9. HIV testing practices of state and federal prison systems during discharge planning, by jurisdiction, 2021
hivp21stat10.csv	Appendix table 10. Number of persons in the custody of state and federal correctional authorities, by sex and jurisdiction, 2017–2021
hivp21stat11.csv	Appendix table 11. Estimates for figure 2: Number of persons living with HIV in the custody of state and federal correctional authorities, by reporter type, 1991–2021
