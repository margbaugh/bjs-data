

Filename	Table Title

FF09801.WK1	Firearm suspects declined for prosecution by U.S. attorneys, by reasons for declination, 1998
FF09802.WK1	Defendants charged in U.S. district courts with a firearm offense, by type of offense, 1992-99
FF09803.WK1	Defendants charged in U.S. district courts with a firearm possession offense, 1998
FF09804.WK1	Defendants convicted in U.S. district courts of firearm receipt and transfer offense, 1998
FF09805.WK1	Defendants in cases concluded in U.S. district courts who were charged with using a firearm in relation to a violent or drug trafficking offense (18 U.S.C. 924(c)), 1992-98
FF09806.WK1	Sentence imposed on defendants convicted of a firearm offense in U.S. district courts, by type of firearm offense, 1998
FF09807.WK1	Defendants sentenced as armed career offenders in U.S. district courts, 1992-98
FF09808.WK1	Defendants receiving a sentence enhancement for possessing or using a firearm and additional prison term imposed, by type of enhancement, 1992-98
FF098F1.WK1	Number of suspects investigated for a firearm offense and number U.S. attorneys declined to prosecuted
FF098F2.WK1	Average prison term imposed for Federal firearm offenses, 1992-98
FF098B1.WK1	Type of sentence enhancement sought for defendants using or possessing a firearm, 1992-98
FF098B2.WK1	Defendants charged with firearm offenses in U.S. district courts in the 20 most populous districts, 1997
FF098B3.WK1     Firearm use reported by Federal prison inmates
FF098A1.WK1	ARIMA parameter estimates:  Defendants charged with 18 U.S.C. 924(c), 1992-98
FF098A2.WK1	Base populations for tables and figures, 1998
FF098A3.WK1	Charges of Federal firearm offenses against defendants, by type of violation, 1992-99


Addendum to the Preliminary statistics for 1999
FF09902a.WK1	Defendants charged in U.S. district courts with a firearm offense, by type of offense, 1992-99
FF099B1.WK1	Type of sentence enhancement sought for defendants using or possessing a firearm, 1992-99.
FF099A3.WK1	Charges of Federal firearm offenses against defendants, by type of violation, 1992-99

