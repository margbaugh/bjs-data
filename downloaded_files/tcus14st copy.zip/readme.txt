Tribal Courts in the United States, 2014 - Statistical Tables   NCJ 301214		
		
This .zip archive contains tables in individual  .csv spreadsheets		
Tribal Courts in the United States, 2014 - Statistical Tables   NCJ 301214.  The full report including text		
and graphics in .pdf format is available from: https://bjs.ojp.gov/library/publications/tribal-courts-united-states-2014-statistical-tables
		
Filenames		Table titles	
tcus14stt01a.csv	Table 1a. Tribal court systems, by resident population and P.L. 280 jurisdiction, 2014	
tcus14stt01b.csv	Table 1b. Tribal court systems subject to P.L. 280 jurisdiction, by resident population, 2014	
tcus14stt02.csv		Table 2. Tribal court systems reporting jurisdiction exercised and administrative characteristics, by resident population, 2014	
tcus14stt03.csv		Table 3. Types of courts associated with tribal court systems, by resident population, 2014	
tcus14stt04a.csv	Table 4a. Tribal court systems reporting sources of operational funding, by resident population, 2014	
tcus14stt04b.csv	Table 4b. Number of operational funding sources reported by tribal court systems, by resident population, 2014	
tcus14stt05.csv		Table 5. Tribal court systems handling juvenile and Indian Child Welfare Act matters, by resident population, 2014	
tcus14stt06.csv		Table 6. Tribal court systems with victim services and civil legal services, by resident population, 2014	
tcus14stt07.csv		Table 7. Tribal court systems with prosecutor and public defender programs, by resident population, 2014	
tcus14stt08.csv		Table 8. Tribal court systems with pretrial programs, by resident population, 2014	
tcus14stt09.csv		Table 9. Tribal court systems with probation programs, by resident population, 2014	
		
			Figures	
tcus14stf01.csv		Figure 1. Tribal court systems reporting sources of operational funding, 2014	
tcus14stf02.csv		Figure 2. Integration of federal, state, and tribal court systems in the U.S.	
		
		
		
		
		
		
		
		
		
