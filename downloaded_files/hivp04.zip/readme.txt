"HIV in Prisons, 2004 NCJ 213897"	

Tables	
hivp04t01.csv	"Table 1.  Inmates in custody of State or Federal prison authorities known to be HIV positive, yearend 2002-04"
hivp04t02.csv	"Table 2.  Inmates in custody of State and Federal prison authorities known to be HIV positive, by gender, yearend 2004"
hivp04t03.csv	"Table 3.  Inmates in custody of State or Federal prison authorities known to have confirmed AIDS, yearend 2003-04"
hivp04t04.csv	"Table 4.  Circumstances under which inmates were tested for the antibody to HIV, by jurisdiction, 2004"
hivp04t05.csv	"Table 5.  Inmate deaths in State prisons, by cause, 2004 and 2003"
hivp04t06.csv	"Table 6.  Inmate deaths in Federal prisons, by cause, 2004 and 2003"
hivp04t07.csv	"Table 7. Deaths of State prisoners, 2004"
hivp04t08.csv	"Table 8. Profile of inmates who died from AIDS-related causes in State prisons, 2002-04"
hivp04t09.csv	"Table 9. State and Federal inmates ever tested or tested since admission for HIV and test results, 2004 and 1997"
hivp04t10.csv	"Table 10. Inmates ever tested forHIV and results, by selected characteristics, 2004"
hivp04t11.csv	"Table 11. Inmates ever tested for HIV and results, by offense and prior drug use, 2004"
	
Highlight tables	
hivp04ht01.csv	Highlight table 1.  Number and percent of HIV-positive State and Federal inmates
hivp04ht02.csv	Highlight table 2.  Number and percent of HIV-positive inmates by jurisdiction
hivp04ht03.csv	Highlight table 3. AIDS-related deaths in State Prisons

Text tables	
hivp04tt01.csv	Text table 1. Number of HIV-positive inmates
hivp04tt02.csv	Text table 2. Percent of custody populatin known to be HIV positive
hivp04tt03.csv	"Text table 3. State prison inmates known to be HIV positive, by gender"
hivp04tt04.csv	Text table 4. Number of confirmed AIDS cases in State and Federal Prisons
hivp04tt05.csv	Text table 5. Percent of the general population and prison population with confirmed AIDS
hivp04tt06.csv	Text table 6. Circumstances under which inmates were tested for HIV
hivp04tt07.csv	Text table 7. AIDS-related deaths in State prisons
hivp04tt08.csv	Text table 7. AIDS-related deaths in State prisons
hivp04tt09.csv	Text table 8. AIDS-related deaths as a percent of all deaths

Appendix tables	
	"Appendix table . Standard error estimates for Surveys of State and Federal Correctional Facilities, 2004"
