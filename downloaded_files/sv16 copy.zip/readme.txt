Stalking Victimization, 2016  NCJ 253526														
														
This zip archive contains tables in individual  .csv spreadsheets														
from Stalking Victimization, 2016  NCJ 253526.  														
The full report including text and graphics in pdf format are available														
from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7367


This report is one in a series.  More recent editions																		
may be available.  To view a list of all in the series go to																		
https://www.bjs.gov/index.cfm?ty=pbse&sid=84														
														
Filenames	Table names													
sv16t01.csv	Table 1. Prevalence of stalking, by type of stalking, 2016
sv16t02.csv	Table 2. Number and percent of stalking victims, by component of stalking, 2016
sv16t03.csv	Table 3. Number and percent of victims of traditional stalking, by type of stalking behavior, 2016
sv16t04.csv	Table 4. Number and percent of victims of stalking with technology, by type of stalking behavior, 2016	
sv16t05.csv	Table 5. Number and percent of stalking victims, by demographic characteristics of victims, 2016
sv16t06.csv	Table 6. Percent of stalking victims, by number of offenders and victim-offender relationship, 2016
sv16t07.csv	Table 7. Percent of stalking victims, by duration and frequency of stalking, 2016
sv16t08.csv	Table 8. Percent of stalking victims, by whether the stalking was ongoing, 2016	
sv16t09.csv	Table 9. State criminal laws on stalking, by elements of the crime, 2018	
														
		Figure													
sv16f01.csv	Figure 1. Prevalence of stalking, by type of stalking, 2016	
														
		Appendix tables													
sv16ta01.csv	Appendix table 1. Estimates and standard errors for figure 1: Prevalence of stalking, by type of stalking, 2016	
sv16ta02.csv	Appendix table 2. Standard errors for table 3: Number and percent of victims of traditional stalking, by type of stalking behavior, 2016
sv16ta03.csv	Appendix table 3. Standard errors for table 4: Number and percent of victims of stalking with technology, by type of stalking behavior, 2016
sv16ta04.csv	Appendix table 4. Population estimates for table 5: Number and percent of stalking victims, by demographic characteristics of victims, 2016	