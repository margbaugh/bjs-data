Prison and Jail Inmates at Midyear 2005  NCJ  213133

This zip archive contains tables in individual .csv spreadsheets
from Prison and Jail Inmates at Midyear 2005  NCJ  213133
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/pjim05.htm

Filename          Table title
 
pjim0501.csv      Table 1.  Number of persons held in State or Federal prisons or in local jails, 1995-2005
pjim0502.csv      Table 2.  Prisoners under the jurisdiction of State or Federal correctional authorities, June 30, 2004 to June 30, 2005
pjim0503.csv      Table 3.  Prisoners held in private facilities, June 30, 2004 and June 30, 2005
pjim0504.csv      Table 4.  Prisoners under the jurisdiction of State or Federal correctional authorities, by gender, 1995, 2004, and 2005
pjim0505.csv      Table 5.  Number of inmates under age 18 held in State prisons, by gender, June 30, 1995, and 2000-05
pjim0506.csv      Table 6.  Number of noncitizens held in State or Federal prisons at midyear, 1998-2005
pjim0507.csv      Table 7.  Number of sentenced prisoners admitted and released from State or Federal jurisdiction, by region and jurisdiction, 2000, and 2003-04
pjim0508.csv      Table 8.  Persons under jail supervision, by confinement status and type of program, midyear 1995, 2000, and 2004-05
pjim0509.csv      Table 9.  Average daily population and the number of men, women, and juveniles in local jails, midyear 1995, 2000, and 2004-05
pjim0510.csv      Table 10. Gender, race, Hispanic origin, and conviction status of local jail inmates, midyear 1995, 2000, and 2004-05
pjim0511.csv      Table 11. Rated capacity of local jails and percent of capacity occupied, 1990, and 1995-2005
pjim0512.csv      Table 12. Number of inmates in custody of State or Federal prisons or local jails, June 30, 2005
pjim0513.csv      Table 13. Number of inmates in State or Federal prisons and local jails per 100,000 residents, by gender, race, Hispanic origin, and age, June 30, 2005
pjim0514.csv      Table 14. Number of inmates in State and local jails per 100,000 residents, by gender, race, Hispanic origin, June 30, 2005

pjim05t01.csv     Text table #t1:  Growth rates in Federal prison population at 6-month intervals
pjim05t02.csv     Text table #t2:  Annual increase in the number of prisoners under State or Federal jurisdiction, July 1-June 30
pjim05t03.csv     Text table #t3:  Number of sentenced inmates per 100,000 U.S. residents on December 31
pjim05t04.csv     Text table #t4:  Number of inmates held in privately operated facilities, 12/31/00 to 06/30/05
pjim05t05.csv     Text table #t5:  States holding more than 100 prisoners under age 18, June 30, 2005
pjim05t06.csv     Text table #t6:  Prison jurisdictions holding the highest number of noncitizens, June 30, 2005
pjim05t07.csv     Text table #t7:  State prison admissions, by type, 1990, 1995, and 1998-2004
pjim05t08.csv     Text table #t8:  Jail incarceration rate, 1995 and 2000-2005
pjim05t09.csv     Text table #t9:  Jail incarceration rate, by gender, race, and ethnicity, 2005
 
pjim05ht.csv      Higlight figure #1: The 5 highest and lowest jurisdictions for selected characteristics of the inmate population, June 30, 2005
 
pjim05f1.csv      Figure #1: Percent change during 6-month periods in the number of prisoners under the jurisdiction of State correctional authorities, 1995-2005
pjim05f2.csv      Figure #2: 12-month growth rates for local jails, 1995-2005


 
 
 
 
 
 
 
 
 
 
