Jails in Indian Country, 2017-2018  NCJ 252155		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Jails in Indian Country, 2017-2018  NCJ 252155.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7086		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=32		
		
Filename		Table title
jic1718t01.csv		Table 1. Inmates held, rated capacity, and percent of capacity occupied in jails in Indian country, June 2000, 2010, and 2015-2018  
jic1718t02.csv		Table 2. Number of jails in Indian country, by population measures and percent of rated capacity occupied, June 2018
jic1718t03.csv		Table 3. Inmate population in jails in Indian country, by facility size, midyear 2018
jic1718t04.csv		Table 4. Average daily population, admissions, and expected average length of stay in jails in Indian country, by facility size, June 2017 and 2018
jic1718t05.csv		Table 5. Inmates held in jails in Indian country, by demographic characteristics, conviction status, and offense, midyear 2000, 2010, and 2015-2018  
jic1718t06.csv		Table 6. Persons employed in jails in Indian country, by job function, midyear 2010 and 2015-2018
jic1718t07.csv		Table 7. Survey universe and response rates of jails in Indian country, 2004 and 2007-2018
jic1718t08.csv		Table 8. Imputation for inmate characteristics in table 5
jic1718t09.csv		Table 9. Imputation for facility staff in table 6
		
			Figures
jic1718f01.csv		Figure 1. Inmates held in jails in Indian country, midyear 2000 and 2010-2018
jic1718f02.csv		Figure 2. Percent of rated capacity occupied, by facility size, June 2018
		
			Appendix tables
jic1718at01.csv		Appendix table 1. Inmates held, rated capacity, and percent of rated capacity occupied in jails in Indian country, by facility, June 2018
jic1718at02.csv		Appendix table 2. Inmates held in jails in Indian country, by most serious offense, midyear 2018
jic1718at03.csv		Appendix table 3. Inmates held in jails in Indian country, by conviction status, midyear 2018
jic1718at04.csv		Appendix table 4. Adults and juveniles held in jails in Indian country, by sex, midyear 2018
jic1718at05.csv		Appendix table 5. Inmates held, rated capacity, and percent of rated capacity occupied in jails in Indian country, by facility, June 2017
jic1718at06.csv		Appendix table 6. Inmates held in jails in Indian country, by most serious offense, midyear 2017
jic1718at07.csv		Appendix table 7. Inmates held in jails in Indian country, by conviction status, midyear 2017
jic1718at08.csv		Appendix table 8. Adults and juveniles held in jails in Indian country, by sex, midyear 2017
jic1718at09.csv		Appendix table 9. Reported inmate characteristics for table 5: Inmates held in jails in Indian country, by demographic characteristics, conviction status, and offense, midyear 2000, 2010, and 2015-2018 
jic1718at10.csv		Appendix table 10. Reported number of staff for table 6: Persons employed in jails in Indian country, by job function, midyear 2010 and 2015-2018
