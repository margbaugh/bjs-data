Medical Examiners and Coroners' Offices, 2004
 
This zip archive contains tables in individual .csv spreadsheets
from Medical Examiners and Coroners' Offices, 2004, NCJ 216756.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/meco04.htm

Filename		
			Tables 	
meco04t01.csv		Table 1. Number of medical examiners and coroners' offices in the United States, 2004 
meco04t02.csv		Table 2. Number and percent of cases referred and accepted, and total percent accepted, by size of population served, 2004
meco04t03.csv		Table 3. Use of the FBI's NCIC unidentified persons file by medical examiners and coroners' offices, by size of jurisdiction
meco04t04.csv		Table 4. Estimated average operating budget of medical examiners and corones' offices in the United States, by type of office, 2004

   			Figures   
meco04f01.csv		Figure 1. Percent of full-time employees in medical examiners and coroners' offices serving large jurisdictions (250,000 or more persons), by personnel category, 2004
meco04f02.csv		Figure 2. Total number of human deaths relative to cases referred and accepted in medical examiners and coroners' offices, 2004
meco04f03.csv		Figure 3. Percent of accepted cases in which listed procedures were performed, by size of jurisdiction, 2004
meco04f04.csv		Figure 4. Number of unidentified human decedents reported in a year, remained unidentified and underwent final disposition 

			Text Tables
meco04tt01.csv		Text Table 1: Number of medical examiners and coroners' offices and estimated FTE salaried positions, by size of jurisdiction
meco04tt02.csv		Text Table 2. Average number of FTEs by size of jurisdiction
meco04tt03.csv		Text Table 3. Estimated mean number of referred and accepted cases by type of office
meco04tt04.csv		Text Table 4. Response rate of census by number of offices and size of population
meco04tt05.csv		Text Table 5. Response rate of census by number and type of office

			Box Text Tables
meco04boxtt01.csv	Box Text Table 1. Number of unidentified human decedents on record and percent of offices with retention policies, by population served
meco04boxtt02.csv	Box Text Table 2. Five offices account for more than half of all unidentified human remains on record nationally

			Box Figures
meco04boxf01.csv	Box Figure 1. Average workload per FTE for referred and accepted cases, 2004
	

 
 
 
 
 
 
 
 
