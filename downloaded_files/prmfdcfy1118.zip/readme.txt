Pretrial Release and Misconduct in Federal District Courts, Fiscal Years 2011–2018   NCJ 252837 									
									
This zip archive contains tables in individual  .csv spreadsheets									
from Pretrial Release and Misconduct in Federal District Courts, Fiscal Years 2011–2018   NCJ 252837 									
and graphics in pdf format is available at: https://bjs.ojp.gov/library/publications/pretrial-release-and-misconduct-federal-district-courts-fiscal-years-2011-2018
									
This report is one in a series.  More recent editions may be available.									
To view a list of all in the series go to 									
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Pretrial%20Release%20and%20Misconduct
									
Filenames		Table titles								
prmfdcfy1118t01.csv	Table 1. Defendants released pretrial with cases disposed in federal district courts, by type of hearing and most serious offense, FYs 2011–18		
prmfdcfy1118t02.csv	Table 2. Defendants released pretrial with cases disposed in federal district courts, by most serious offense and demographic characteristics, FYs 2011–18
prmfdcfy1118t03.csv	Table 3. Defendants released pretrial with cases disposed in federal district courts, by most serious offense and criminal history, FYs 2011–18	
prmfdcfy1118t04.csv	Table 4. Defendants released pretrial with cases disposed in federal district courts, by type of release and most serious offense, FYs 2011–18	
prmfdcfy1118t05.csv	Table 5. Defendants released pretrial with cases disposed in federal district courts, by condition of release and most serious offense, FYs 2011–18
prmfdcfy1118t06.csv	Table 6. Defendants detained pretrial with cases disposed in federal district courts, by type of detention and most serious offense, FYs 2011–18
prmfdcfy1118t07.csv	Table 7. Defendants released pretrial with cases disposed in federal district courts, by type of release violation and most serious offense, FYs 2011–18	
prmfdcfy1118t08.csv	Table 8. Defendants released pretrial with cases disposed in federal district courts, by type of release violation and criminal history, FYs 2011–18
prmfdcfy1118t09.csv	Table 9. Defendants released pretrial with cases disposed in federal district courts, by type of release violation and demographic characteristics, FYs 2011–18	
prmfdcfy1118t10.csv	Table 10. Defendants released pretrial with cases disposed in federal district courts, by type of release violation and pretrial release, FYs 2011–18
									
			Figures								
prmfdcfy1118f01.csv	Figure 1. Percent of defendants released pretrial with cases disposed in federal district courts, by most serious offense, FYs 2011–18
prmfdcfy1118f02.csv	Figure 2. Percent of defendants released pretrial with cases disposed in federal district courts, by most serious offense, FYs 2011–2018
									
			Appendix tables								
prmfdcfy1118at01.csv	Appendix table 1. Percentages for figure 2: Percent of defendants released pretrial with cases disposed in federal district courts, by most serious offense, FYs 2011–2018