Federal Prisoner Statistics Collected under the First Step Act, 2020  NCJ 255111		
		
This zip archive contains tables in individual .csv spreadsheets for		
Federal Prisoner Statistics Collected under the First Step Act, 2020  NCJ 255111		
The full report including text and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7247	

This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=82
		
Filename		Table name
fpscfsa20t01.csv	Table 1. Selected characteristics of federal prisoners, 2018 and 2019
fpscfsa20t02.csv	Table 2. Medical conditions, testing, and treatment of federal prisoners, 2018 and 2019
fpscfsa20t03.csv	Table 3. Selected characteristics of federal facilities, 2018 and 2019
fpscfsa20t04.csv	Table 4. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by security level of facility, 2019
fpscfsa20t05.csv	Table 5. Federal prisoners who were cited for prohibited acts that resulted in reductions in rewards, incentives, or time credits, by demographic characteristics, 2018 and 2019
fpscfsa20t06.csv	Table 6. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by facility, 2019
fpscfsa20t07.csv	Table 7. Prisoner assaults on Federal Bureau of Prisons staff, by type of assault and prosecution status, 2019
fpscfsa20t08.csv	Table 8. Volunteer levels in Federal Bureau of Prisons facilities, by facility, December 23, 2019
fpscfsa20t09.csv	Table 9. Recidivism-reduction partnerships in Federal Bureau of Prisons facilities, by facility, 2019
		
