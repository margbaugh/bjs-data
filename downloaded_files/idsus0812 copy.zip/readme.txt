Indigent Defense Services In The United States, FY 2008-2012		
		
 		
This zip archive contains tables in individual .csv spreadsheets from		
Indigent Defense Services In The United States, FY 2008-2012		
		
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5051		
		
Filename		Appendix Table title
idsus0812at01.csv		Appendix table 1. State government indigent defense expenditures, by state, FY 2008�2012 (2012 dollars)
idsus0812at02.csv		Appendix table 2. Source of state government indigent defense expenditures, by state, FY 2008�2012
		
File		Table title
idsus0812t01.csv		Table 1. Alabama state government indigent defense expenditures, FY 2008�201
idsus0812t02.csv		Table 2. Alaska state government indigent defense expenditures, FY 2008�2012
idsus0812t03.csv		Table 3. Arizona state government indigent defense expenditures, FY 2008�2012
idsus0812t04.csv		Table 4. Arizona local government indigent defense expenditures, FY 2008�2012
idsus0812t05.csv		Table 5. Arkansas state government indigent defense expenditures, FY 2008�2012
idsus0812t06.csv		Table 6. California state government indigent defense expenditures, FY 2008�2012
idsus0812t07.csv		Table 7. Colorado state government indigent defense expenditures, FY 2008�2012
idsus0812t08.csv		Table 8. Connecticut state government indigent defense expenditures, FY 2008�2012
idsus0812t09.csv		Table 9. Delaware state government indigent defense expenditures, FY 2008�2012
idsus0812t10.csv		Table 10. Florida state government indigent defense expenditures, FY 2008�2012
idsus0812t11.csv		Table 11. Georgia state government indigent defense expenditures, FY 2008�2012
idsus0812t12.csv		Table 12. Hawaii state government indigent defense expenditures, FY 2008�2012
idsus0812t13.csv		Table 13. Idaho state government indigent defense expenditures, FY 2008�2012
idsus0812t14.csv		Table 14. Illinois state government indigent defense expenditures, FY 2008�2012
idsus0812t15.csv		Table 15. Indiana state government indigent defense expenditures, FY 2008�2012
idsus0812t16.csv		Table 16. Indiana local government indigent defense expenditures, FY 2008�2012
idsus0812t17.csv		Table 17. Iowa state government indigent defense expenditures, FY 2008�2012
idsus0812t18.csv		Table 18. Kansas state government indigent defense expenditures, FY 2008�2012
idsus0812t19.csv		Table 19. Kentucky state government indigent defense expenditures, FY 2008�2012
idsus0812t20.csv		Table 20. Kentucky local government indigent defense expenditures, FY 2008�2012
idsus0812t21.csv		Table 21. Louisiana state government indigent defense expenditures, FY 2008�2012
idsus0812t22.csv		Table 22. Maine state government indigent defense expenditures, FY 2008�2012
idsus0812t23.csv		Table 23. Maryland state government indigent defense expenditures, FY 2008�2012
idsus0812t24.csv		Table 24. Massachusetts state government indigent defense expenditures, FY 2008�2012
idsus0812t25.csv		Table 25. Michigan state government indigent defense expenditures, FY 2008�2012
idsus0812t26.csv		Table 26. Minnesota state government indigent defense expenditures, FY 2008�2012
idsus0812t27.csv		Table 27. Minnesota local government indigent defense expenditures, FY 2008�2012
idsus0812t28.csv		Table 28. Mississippi state government indigent defense expenditures, FY 2008�2012
idsus0812t29.csv		Table 29. Missouri state government indigent defense expenditures, FY 2008�2012
idsus0812t30.csv		Table 30. Montana state government indigent defense expenditures, FY 2008�2012
idsus0812t31.csv		Table 31. Nebraska state government indigent defense expenditures, FY 2008�2012
idsus0812t32.csv		Table 32. Nevada state government indigent defense expenditures, FY 2008�2012
idsus0812t33.csv		Table 33. New Hampshire state government indigent defense expenditures, FY 2008�2012
idsus0812t34.csv		Table 34. New Jersey state government indigent defense expenditures, FY 2008�2012
idsus0812t35.csv		Table 35. New Mexico state government indigent defense expenditures, FY 2008�2012
idsus0812t36.csv		Table 36. New York state government indigent defense expenditures, FY 2008�2012
idsus0812t37.csv		Table 37. North Carolina state government indigent defense expenditures, FY 2008�2012
idsus0812t38.csv		Table 38. North Dakota state government indigent defense expenditures, FY 2008�2012
idsus0812t39.csv		Table 39. Ohio state government indigent defense expenditures, FY 2008�2012
idsus0812t40.csv		Table 40. Ohio local government indigent defense expenditures, FY 2008�2012
idsus0812t41.csv		Table 41. Oklahoma State Government Indigent Defense Expenditures, FY 2008�2012
idsus0812t42.csv		Table 42. Oklahoma local government indigent defense expenditures, FY 2008�2012
idsus0812t43.csv		Table 43. Oregon state government indigent defense expenditures, FY 2008�2012
idsus0812t44.csv		Table 44. Rhode Island state government indigent defense expenditures, FY 2008�2012
idsus0812t45.csv		Table 45. South Carolina state government indigent defense expenditures, FY 2008�2012
idsus0812t46.csv		Table 46. South Dakota state government indigent defense expenditures, FY 2008�2012
idsus0812t47.csv		Table 47. Tennessee state government indigent defense expenditures, FY 2008�2012
idsus0812t48.csv		Table 48. Tennessee local government indigent defense expenditures, FY 2008�2012
idsus0812t49.csv		Table 49. Texas state government indigent defense expenditures, FY 2008�2012
idsus0812t50.csv		Table 50. Texas local government indigent defense expenditures, FY 2008�2012
idsus0812t51.csv		Table 51. Utah state government indigent defense expenditures, FY 2008�2012
idsus0812t52.csv		Table 52. Vermont state government indigent defense expenditures, FY 2008�2012
idsus0812t53.csv		Table 53. Virginia state government indigent defense expenditures, FY 2008�2012
idsus0812t54.csv		Table 54. Washington state government indigent defense expenditures, FY 2008�2012
idsus0812t55.csv		Table 55. Washington local government indigent defense expenditures, FY 2008�2012
idsus0812t56.csv		Table 56. West Virginia state government indigent defense expenditures, FY 2008�2012
idsus0812t57.csv		Table 57. Wisconsin state government indigent defense expenditures, FY 2008�2012
idsus0812t58.csv		Table 58. Wyoming state government indigent defense expenditures, FY 2008�2012
idsus0812t59.csv		Table 59. Wyoming local government indigent defense expenditures, FY 2008�2012
