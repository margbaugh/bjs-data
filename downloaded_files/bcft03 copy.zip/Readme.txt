BACKGROUND CHECKS FOR FIREARM TRANSFERS, PERMANENT BRADY PERIOD, 1999-2003 NCJ 204428																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .wk1 spreadsheets from the
Firearm Inquiry Statistics (FIST) program Bulletin, "Background Checks for
Firearm Transfers, Permanent Brady Period, 1999-2003" NCJ 204428. 
The full report including text and 
graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/bcft03.htm 

This report is one in a series.  Most recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#bcft
----------------------------------------------------------------------------
																	
Filename		Table																
																	
bcft03h1.wk1	Highlights Table 1. Background checks of applications for firearm transfers since implementation of the Brady Act

bcft0301.wk1	Table 1. Number of applications and estimates of rejections for firearm transfer, 1994-2003	
bcft0302.wk1	Table 2. FIST estimates, by type of agency and approval system and total FBI checks, 1999-2003
bcft0303.wk1	Table 3. Rejection rates for selected FBI states, 1999-2003		
bcft0304.wk1	Table 4. Number of firearm purchase applications received and rejected by State agencies, 1999-2003
bcft0305.wk1	Table 5. Reasons for rejection of firearm transfer applications, 1999-2003
bcft0306.wk1	Table 6. Trends in applications, rejections, and reasons for rejection under permanent provisions of the Brady Act, among all agencies conducting such checks, 1999-2003		
bcft0307.wk1	Table 7. Appeals of denied applications, 2003	
bcft0308.wk1	Table 8. Number of appeals reported, by type of agency, 1999-2003
bcft0309.wk1	Table 9. Notification procedures of State points of contact (POC's) regarding denied persons subject to arrest, 2003
bcft0310.wk1	Table 10. Number of arrests reported, by type of agency, 1999-2003
bcft0311.wk1	Table 11. Summary of significant changes in State laws related to firearms sales, effective between January 1, 1999 and December 31, 2003

bcft03t1.wk1	Text Table 1. Applications and rejections for exemptions reported by State agencies to FIST
bcft03t2.wk1	Text Table 2. Local rejection rates by population served and by type of permit, 1999-2003
bcft03t3.wk1	Text Table 3. Local and State reasons for rejection, 1999-2003
bcft03t4.wk1	Text Table 4. Number of arrests reported by States providing arrest data in 2003

bcft02aa.wk1	Appendix Table A. National Instant Criminal Background Check System: Checking agencies - FBI or State point of contact - for firearm transfers, yearend 2003
bcft02ab.wk1	Appendix Table B. State and local agencies conducting background checks for firearm applications, yearend 2003


