"Background Checks for Firearm Transfers, 2012 - Statistical Tables NCJ 247815"		
		
Filename		Table
		
bcft12stt01.csv		"Table 1. Estimated number of applications and denials for firearm transfers or permits since the inception of the Brady Act, 1994�2012"
bcft12stt02.csv		"Table 2. Firearm applications received and denials, by type of agency and type of check, 2012"
bcft12stt03.csv		"Table 3. Firearm applications received and denied by state agencies, by type of check, 2012"
bcft12stt04.csv		"Table 4. Firearm applications received and denied by local agencies, by community size and type of permit, 2012"
bcft12stt05.csv		"Table 5. Reasons for denial of firearm transfer and permit applications, by checking agencies, 2012"
bcft12stt06.csv		"Table 6. Percent change in the number of applications, denials, and reasons for denial, 1999�2012"
bcft12stt07.csv		"Table 7. Bureau of Alcohol, Tobacco, Firearms and Explosives (ATF) investigation of National Instant Criminal Background Check System (NICS) denials by the FBI, 2012"
bcft12stt08.csv		"Table 8. Number of checking agencies in the 2012 FIST survey
		
bcft12stat01.csv	"Appendix table 1. Estimated standard errors for applications and denials by local agencies, 2012"
bcft12stat02.csv	"Appendix table 2. Estimated standard errors for applications and denials in local agencies, by size of community served and type of permit, 2012"
bcft12stat03.csv 	"Appendix table 3. Firearm applications received and denied by jurisdiction, 2012"
bcft12stat04.csv	"Appendix table 4. Reasons for denial of firearm transfer applications, by checking agency, 2012"
bcft12stat05.csv	"Appendix table 5. Appeals, by type of checking agency, 2012"
bctf12stat06.csv	"Appendix table 6. Reported arrests of persons denied a firearm permit or purchase, 2012"
bcft12stat07.csv	"Appendix table 7. Number of National Instant Criminal Background Check System (NICS) Index prohibited person records, 2012"
bcft12stat08.csv	"Appendix table 8. Agencies conducting firearm background checks, December 31, 2012"
bcft12stat09.csv	"Appendix table 9. National Instant Criminal Background Check System (NICS) checking agencies, FBI, or state point of contact (POC) for firearm transfers, 2012"
bcft12stat10.csv	"Appendix table 10.Forums for appeals of firearm transfer and permit denials, 2012"