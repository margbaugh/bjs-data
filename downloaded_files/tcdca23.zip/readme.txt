Tribal Crime Data Collection Activities, 2023   NCJ 307113		
		
This .zip archive contains tables in individual  .csv spreadsheets		
Tribal Crime Data Collection Activities, 2023   NCJ 307113. The full report including text		
and graphics in .pdf format is available from: https://bjs.ojp.gov/library/publications/tribal-crime-data-collection-activities-2023		
		
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to:		
https://bjs.ojp.gov/library/publications/list?series_filter=Tribal%20Crime%20Data%20Collection%20Activities		
		
Filenames	Table titles	
tcdca23t01.csv	Table 1. Number of tribally operated law enforcement agencies and full-time sworn personnel, by size of agency, 2008 and 2018	
tcdca23t02.csv	Table 2. Number of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2012–2022	
tcdca23t03.csv	Table 3. Estimates and standard errors for figure 3: Prior arrest offenses of American Indians and Alaska Natives admitted to state prison in 2014 	
tcdca23t04.csv	Table 4. American Indians and Alaska Native persons in the federal justice system, fiscal years 2012–2021	
		
		Figures	
tcdca23f01.csv	Figure 1. Number of tribally operated law enforcement agencies in the United States, by size of agency, 2008 and 2018	
tcdca23f02.csv	Figure 2. Prior drug and alcohol use and use disorder among American Indian and Alaska Native youth in juvenile facilities, 2008–09, 2012, and 2018	
tcdca23f03.csv	Figure 3. Prior arrest offenses of American Indian and Alaska Native persons admitted to state prison in 2014	
		
