Victim, Perpetrator, and Incident Characteristics of Sexual Victimization of Youth in Juvenile Facilities, 2018 - Statistical Tables NCJ 255446	
	
This zip archive contains tables in individual .csv spreadsheets for	
Victim, Perpetrator, and Incident Characteristics of Sexual Victimization of Youth in Juvenile Facilities, 2018 - Statistical Tables NCJ 255446	
The full electronic report is available at:	
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7146	
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to:	
https://www.bjs.gov/index.cfm?ty=pbse&sid=64	
	
Filename			Table title
vpicsvyjf18stt1.1.csv		Table 1.1. Youth reporting sexual victimization in juvenile facilities, by type of incident and selected youth characteristics, 2018
vpicsvyjf18stt1.2.csv		Table 1.2. Youth reporting sexual victimization in juvenile facilities, by type of incident and selected victim experiences, 2018
vpicsvyjf18stt1.3a.csv		Table 1.3a. Youth reporting sexual victimization in juvenile facilities, by type of incident and reported disability or mental-health status, 2018 
vpicsvyjf18stt1.3b.csv		Table 1.3b. Youth reporting sexual victimization in juvenile facilities, by type of incident and results of mental-health screener, 2018
vpicsvyjf18stt1.4.csv		Table 1.4. Youth-on-youth sexual victimization involving force or coercion in juvenile facilities, by selected victim experiences, 2018
vpicsvyjf18stt1.5.csv		Table 1.5. Staff sexual misconduct in juvenile facilities, by selected victim experiences, 2018
vpicsvyjf18stt2.1.csv		Table 2.1. Perpetrator characteristics in most-serious incidents of youth-on-youth sexual victimization involving force or coercion in juvenile facilities, 2018
vpicsvyjf18stt2.2.csv		Table 2.2. Incident characteristics of most-serious incidents of youth-on-youth sexual victimization involving force or coercion in juvenile facilities, 2018
vpicsvyjf18stt2.3a.csv		Table 2.3a. Sex of perpetrator and use of force or coercion in most-serious incidents of staff sexual misconduct in juvenile facilities, 2018
vpicsvyjf18stt2.3b.csv		Table 2.3b. Sex of staff perpetrator in most-serious incidents of staff sexual misconduct in juvenile facilities, by whether youth reported use of force or coercion, 2018
vpicsvyjf18stt2.3c.csv		Table 2.3c. Among youth reporting staff sexual misconduct by a given sex of perpetrator, percent reporting use of force in most-serious incidents of staff sexual misconduct in juvenile facilities, 2018
vpicsvyjf18stt2.4.csv		Table 2.4. Incident characteristics of most-serious incidents of staff sexual misconduct in juvenile facilities, 2018
