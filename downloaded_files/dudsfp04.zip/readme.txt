Drug Use and Dependence, State and Federal Prisoners, 2004, NCJ 213530
 
 
This zip archive contains tables in individual .csv spreadsheets
from Drug Use and Dependence, State and Federal Prisoners, 2004, NCJ 213530.
The full report including text and graphics in pdf format
are available from: http://www.ojp.usdoj.gov/bjs/abstract/dudsfp04.htm
 
Tables
dudsfp04t01.csv Table 1. Drug use by State prisoners, 1997 and 2004
dudsfp04t02.csv Table 2. Drug use by Federal prisoners, 1997 and 2004
dudsfp04t03.csv Table 3. Drug use in the month before the offense, by selected characteristics of State and Federal prisoners, 1997 and 2004
dudsfp04t04.csv Table 4. Drug use of State and Federal prisoners, by type of offense, 2004
dudsfp04t05.csv Table 5. Prevalence of drug dependence or abuse among State and Federal prison inmates, 2004
dudsfp04t06.csv Table 6. Drug dependence or abuse among State and Federal prisoners, by selected characteristics, 2004
dudsfp04t07.csv Table 7. Criminal history of State and Federal prisoners, by drug dependence or abuse, 2004
dudsfp04t08.csv Table 8. Family background of State and Federal prison inmates, by drug dependence or abuse criteria, 2004
dudsfp04t09.csv Table 9. Drug treatment or program participation since admission among State and Federal prisoners who used drugs in the month before the offense, 1997 and 2004
dudsfp04t10.csv Table 10. Drug treatment or program participation since admission among State and Federal prisoners who met drug dependence or abuse criteria, 2004

Highlight tables 
dudsfp04ht01.csv Highlight table 1. Prior drug use of State and Federal prisoners, 1997 and 2004
dudsfp04ht02.csv Highlight table 2. Drug abuse treatment or program participation, State and Federal prisoners, 2004
dudsfp04ht03.csv Highlight table 3. Methamphetamine use among State and Federal prisoners, by gender and race/Hispanic origin, 2004

Text tables
dudsfp04tt01.csv Text table 1. Drug use of State and Federal prisoners, by type of offense, 1997 and 2004
dudsfp04tt02.csv Text table 2. Percent of inmates who committed offense for money for drugs, by offense, 2004
dudsfp04tt03.csv Text table 3. Percent of U.S. adult residents reporting symptoms of drug dependence and abuse in the past 12 months, 2002
dudsfp04tt04.csv Text table 4. Estimated number of participants in drug treatment and programs since admission, by drug use in the month before the offense, 1997 and 2004

Exhibit tables
dudsfp04ext01.csv Exhibit table 1. Profile of methamphetamine use among State and Federal prisoners, 2004
dudsfp04ext02.csv Exhibit table 2. Profile of State and Federal prisoners held for drug offenses, 2004
dudsfp04ext03.csv Exhibit table 3. Type of drug involved in the current durg offense, 1997 and 2004
dudsfp04ext04.csv Exhibit table 4. Prevalence of drug dependence or abuse symptoms among State and Federal prison inmates, 2004

Appendix tables
dudsfp04at01.csv Appendix table 1. Standard errors of the estimated percentages, State prison inmates, 2004
dudsfp04at02.csv Appendix table 2. Standard errors of the estimated percentages, Federal prison inmates, 2004
dudsfp04at03.csv Appendix table 3. Base estimates for selected characteristics of State and Federal prisoners, 2004

