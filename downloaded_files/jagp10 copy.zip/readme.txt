Justice Assistance Grant (JAG) Program 2010	NCJ 233811
	
This zip archive contains tables in individual .csv spreadsheets	
Justice Assistance Grant (JAG) Program 2010	NCJ 233811
The full report including text and graphics in .pdf format are available from:	
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=2412
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to http://bjs.gov/index.cfm?ty=pbse&sid=71	


Tables	
jagp10t01.csv 	Table 1. State and local allocation amounts, FY 2010
jagp10t02.csv	Table 2. Territories and District of Columbia allocations, FY 2010



Figure	
jagp10f01.csv	Figure 1: Distribution of FY 2010 JAG funds
