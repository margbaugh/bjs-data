Justice Assistance Grant (JAG) Program 2014 NCJ
	
This zip archive contains tables in individual .csv spreadsheets	

Report title:  Justice Assistance Grant (JAG) Program 2014 NCJ 247137

The full report including text and graphics in .pdf format are available from:	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5089

	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=71	


Tables	
jagp14t01.csv 	Table 1. State and local allocation amounts, FY 2014
jagp14t02.csv	Table 2. Territories and District of Columbia allocations, FY 2014
jagp14t03.csv	Table 3. Sex Offender Registration and Notification Act bonus fund allocation, FY2014
jagp14t04.csv   Table 4. Prison Rape Elimination Act bonus fund allocations, FY 2014


Figure	
jagp14f01.csv	Figure 1: Distribution of FY 2014 JAG funds
