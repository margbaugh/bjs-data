Pretrial Release of Felony Defendants in State Courts		

"This zip archive contains tables in individual .csv spreadsheets from Pretrial Release of Felony Defendants in State Courts, NCJ 214994."		
The full report including text and graphics in .pdf format are available at http://www.ojp.usdoj.gov/bjs/abstract/prfdsc.htm		

Tables		
prfdsct01.csv		"Table 1. Type of pretrial release or detention for State court felony defendants in the 75 largest counties, 1990-2004"
prfdsct02.csv		"Table 2. State court felony defendants in the 75 largest counties with bail set at $50,000 or denied bail, 1990-2004"
prfdsct03.csv		"Table 3. Criminal history of released and detained State court felony defendants in 75 largest counties, 1990-2004"
prfdsct04.csv		"Table 4. State court felony defendants in the 75 largest counties released prior to case disposition, 1990-2004 "
prfdsct05.csv		"Table 5. Adjudication outcomes for released and detained State court felony defendants in the 75 largest counties, 1990-2004"
prfdsct06.csv		"Table 6. Time from pretrial release until adjudication of State court felony defendants in the 75 largest counties, 1990-2004"
prfdsct07.csv		"Table 7. State court felony defendants in the 75 largest counties charged with pretrial misconduct, 1990-2004"

Text Tables		
prfdsctt01.csv		Text Table 1:  Type of pretrial release
prfdsctt02.csv		Text Table 2:  Cumulative percent of releases occurring within 1 month
prfdsctt03.csv		Text Table 3:  Cumulative percent of pretrial misconduct occurring within 6 months
prfdsctt04.csv		Text Table 4:  Percent of defendants failing to appear who were fugitives after 1 year

Box Text Table		
prfdscbtt01.csv		Box Text Table 5:  Predicted probability of released defendants being charged with pretrial misconduct

Figures		
prfdscf01.csv		"Figure 1. Detention-release outcomes for State court felony defendants in the 75 largest counties, 1990-2004"
prfdscf02.csv		"Figure 2. Type of pretrial release of State court felony defendants in the 75 largest counties, 1990-2004"
prfdscf03.csv		"Figure 3. Bail amount and release rates for State court felony defendants in the 75 largest counties, 1990-2004"
prfdscf04.csv		"Figure 4. Pretrial misconduct rates for State court felony defendants in the 75 largest counties, 1990-2004"
prfdscf05.csv		"Figure 5. Pretrial misconduct rates for State court felony defendants in the 75 largest counties, 1990-2004"

Highlight figure		
prfdschf01.csv		Highlight figure 1. Percentage of defendants on financial or nonfinancial release

Appendix tables		
prfdscat01.csv		"Appendix table 1. State Court Processing Statistics, participating jurisdictions, 1990-2004"
prfdscat02.csv		Appendix table 2. Logistic regression analysis of pretrial release decision
prfdscat03.csv		Appendix table 3. Logistic regression analysis of pretrial misconduct
prfdscat04.csv		Appendix table 4. Logistic regression analysis of pretrial re-arrest for new offense
prfdscat05.csv		Appendix table 5. Logistic regression analysis of pretrial failure to appear
prfdscat06.csv		Appendix table 6. Logistic regression analysis of pretrial fugitive status
