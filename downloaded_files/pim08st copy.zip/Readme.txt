Readme.TXT

Prison Inmates at Midyear 2008, NCJ 225619

This zip archive contains tables in individual .csv spreadsheets from Prison Inmates at Midyear 2008, NCJ 225619.  These statistical tables in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/pim08.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#pim

    Tables
pim08stt01.csv	Table 1. Prisoners under the jurisdiction of state or federal prisons, imprisonment rates and incarceration rates, December 31, 2000-2007 and June 30, 2007 and 2008
pim08stt02.csv	Table 2. Prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008
pim08stt03.csv	Table 3. Male prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008
pim08stt04.csv	Table 4. Female prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008
pim08stt05.csv	Table 5. Sentenced prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008
pim08stt06.csv	Table 6. Number of sentenced male prisoners under the jurisdiction of state and federal correctional authorities, December 31, 2000-2007, and June 30, 2007 and 2008
pim08stt07.csv	Table 7. Sentenced male prisoners under the jurisdiction of state or federal correctional authorities,  by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008
pim08stt08.csv	Table 8. Number of sentenced female prisoners under the jurisdiction of state or federal correctional authorities, December 31, 2000-2007, and June 30, 2007 and 2008
pim08stt09.csv	Table 9. Sentenced female prisoners under the jurisdiction of state or federal correctional authorities, by jurisdiction, December 31, 2000, 2006 and 2007, and June 30, 2007 and 2008
pim08stt10.csv	Table 10. Imprisonment rates of sentenced prisoners under jurisdiction of state and federal correctional authorities, by gender, region, and jurisdiction, June 30, 2008
pim08stt11.csv	Table 11. Number of prisoners held in private facilities, December 31, 2000-2007, and June 30, 2007 and 2008
pim08stt12.csv	Table 12. Number of state and federal prisoners in private facilities, by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008
pim08stt13.csv	Table 13. Number of prisoners in local facilities, December 31, 2001-2007, and June 30, 2007 and 2008
pim08stt14.csv	Table 14. Number of state and federal prisoners in local jails, by jurisdiction, December 31, 2000, 2006, and 2007, and June 30, 2007 and 2008	
pim08stt15.csv	Table 15. Inmates held in custody in state or federal prisons or local jails, December 31, 2000-2008
pim08stt16.csv	Table 16. Estimated number of inmates held in state or federal prison, or in local jails,by gender, race, and Hispanic origin, June 30, 2000-2008
pim08stt17.csv	Table 17. Estimated number of inmates held in state or federal prisons, or in local jails, by gender, race, Hispanic origin, and age, June 30, 2008
pim08stt18.csv	Table 18. Estimated number of inmates held in state or federal prisons, or in local jails per 100,000 U.S. residents, by gender, race, and Hispanic origin, June 30, 2000-2008
pim08stt19.csv	Table 19. Estimated number of inmates held in state or federal prison, or in local jails per 100,000 U.S. residents, by gender, race, Hispanic origin, and age, June 30, 2008
pim08stt20.csv	Table 20. Reported number of non-U.S. citizens held in state or federal prisons, by gender, region, and jurisdiction, June 30, 2007-2008
pim08stt21.csv	Table 21. Reported number of inmates under age 18 held in state prisons, by gender, region, and jurisdiction, June 30, 2007-2008
