Medical Examiner and Coroner Offices, 2018   NCJ 302051	
	
This zip archive contains tables in individual .csv spreadsheets	
from Medical Examiner and Coroner Offices, 2018   NCJ 302051.	
The full report including text and graphics in .pdf format are available from:	
https://bjs.ojp.gov/library/publications/medical-examiner-and-coroner-offices-2018
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Medical%20Examiner%20and%20Coroner%20Offices
	
Filename	Table titles
meco18t01.csv	Table 1. Number of medical examiner and coroner offices in the U.S., 2018
meco18t02.csv	Table 2. Percent of offices accredited and selected personnel positions certified, by type of office and population served, 2018
meco18t03.csv	Table 3. Cases referred to and accepted by ME/C offices, by type of office and population served, 2018
meco18t04.csv	Table 4. Average number of cases referred, cases accepted, and full autopsies conducted, by population served, 2018
meco18t05.csv	Table 5. Unidentified remains on record, by type of office and population served, 2018
meco18t06.csv	Table 6. Cases referred from tribal lands and percent accepted, 2018
meco18t07.csv	Table 7. Percent of ME/C offices that provide selected functions either internally or externally, by type of office and population served, 2018
meco18t08.csv	Table 8. Average budget of ME/C offices, by type of office and population served, 2018
meco18t09.csv	Table 9. Minimum and maximum starting salaries on average in ME/C offices, by type of office and population served, 2018
meco18t10.csv	Table 10. Percent of offices with computerized record management systems and access to internet separate from a personal device, by type of office and size of population served, 2018
meco18t11.csv	Table 11. Percent of ME/C offices with access to selected technologies, by type of office and population served, 2018
meco18t12.csv	Table 12. ME/C office access to selected trainings, by type of office and population served, 2018
meco18t13.csv	Table 13. Response rates by office type and population served, 2018
	
		Figures
meco18f01.csv	Figure 1. Number of full-time equivalent autopsy pathologists, coroners, and other medical examiners by size of jurisdiction served, 2004 and 2018
meco18f02.csv	Figure 2. Accepted cases per full-time-equivalent employee by size of population served, 2004 and 2018
meco18f03.csv	Figure 3. Percent of ME/C offices with a computerized information management system, by size of population served, 2004 and 2018
	
		Appendix tables
meco18at01.csv	Appendix table 1. Standard errors for table 1: Number of medical examiner and coroner offices in the U.S., 2018
meco18at02.csv	Appendix table 2. Estimates and standard errors for figure 1: Number of full-time equivalent autopsy pathologists, coroners, and other medical examiners by size of jurisdiction served, 2004 and 2018
meco18at03.csv	Appendix table 3. Standard errors for table 2: Percent of offices accredited and selected personnel positions certified, by type of office and population served, 2018
meco18at04.csv	Appendix table 4. Standard errors for table 3: Cases referred to and accepted by ME/C offices, by type of office and population served, 2018
meco18at05.csv	Appendix table 5. Estimates and standard errors for figure 2: Accepted cases per full-time-equivalent employee by size of population served, 2004 and 2018
meco18at06.csv	Appendix table 6. Standard errors for table 4: Average number of cases referred, cases accepted, and full autopsies conducted, by population served, 2018
meco18at07.csv	Appendix table 7. Standard errors for table 5: Unidentified remains on record, by type of office and population served, 2018
meco18at08.csv	Appendix table 8. Standard errors for table 6: Cases referred from tribal lands and percent accepted, 2018
meco18at09.csv	Appendix table 9. Standard errors for table 7: Percent of ME/C offices that provide selected functions either internally or externally, by type of office and population served, 2018
meco18at10.csv	Appendix table 10. Standard errors for table 8: Average budget of ME/C offices, by type of office and population served, 2018
meco18at11.csv	Appendix table 11. Standard errors for table 9: Minimum and maximum starting salaries on average in ME/C offices, by type of office and population served, 2018
meco18at12.csv	Appendix table 12. Estimates and standard errors for figure 3: Percent of ME/C offices with a computerized information management system, by size of population served, 2004 and 2018
meco18at13.csv	Appendix table 13. Standard errors for table 10: Percent of offices with computerized record management systems and access to internet separate from a personal device, by type of office and size of population served, 2018
meco18at14.csv	Appendix table 14. Standard errors for table 11: Percent of ME/C offices with access to selected technologies, by type of office and population served, 2018
meco18at15.csv	Appendix table 15. Standard errors for table 12: ME/C office access to selected trainings, by type of office and population served, 2018
