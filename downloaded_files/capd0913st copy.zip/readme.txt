Crime Against Persons with disabilities, 2009-2013-Statistical Tables,   NCJ 248676
			
This zip archive contains tables in individual  .csv spreadsheets			
Crime Against Persons with disabilities, 2009-2013-Statistical Tables,   NCJ 248676.  The full report including text		
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=tp&tid=5280	
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to	
http://www.bjs.gov/index.cfm?ty=pbse&sid=65	

Figures
capd0913f01.csv			Figure 1. Annual number of violent victimizations, by victim disability status, 2008-2013

Tables
capd0913t01.csv			Table 1.Rates of violent victimization, by victim�s disability status and age, 2009�2013
capd0913t02.csv			Table 2. Rates of violent victimization against persons with and without disabilities, by type of crime, 2009�2013
capd0913t03.csv			Table 3. Rates of violent victimization against persons with and without disabilities, by victim characteristics, 2009�2013
capd0913t04.csv			Table 4. Rates of violent victimization against persons with disabilities, by disability type, 2009�2013
capd0913t05.csv			Table 5. Rates of serious violent victimization against persons with disabilities, by disability type, 2009�2013
capd0913t06.csv			Table 6. Rates of simple assault against persons with disabilities, by disability type, 2009�2013
capd0913t07.csv			Table 7. Rates of violent victimization, by victim�s sex and disability type, 2009�2013
capd0913t08.csv			Table 8. Percent of violence against persons with disabilities that involved victims with multiple disability types, by type of crime, 2009�2013
capd0913t09.csv			Table 9. Rates of violent victimization, by number of disability types and type of crime, 2009�2013
capd0913t10.csv			Table 10. Victim�offender relationship, by victim�s disability status, 2009�2013
capd0913t11.csv			Table 11. Time violent crime occurred, by victim's disability status, 2009�2013
capd0913t12.csv			Table 12. Percent of violent crime reported to police, by victim's disability status, 2009�2013
capd0913t13.csv			Table 13. Person who notified police of violent crime, by victim's disability status, 2009�2013
capd0913t14.csv			Table 14. Reasons for not reporting violent crime to police, by victim�s disability status, 2009�2013
capd0913t15.csv			Table 15. Percent of violent crime victims who received services from nonpolice victim services agencies, by victim's disability status, 2009�2013

Appendix tables	
capd0913at01.csv		Appendix table 1. Estimates for figure 1: Annual number of violent victimizations, by victim�s disability status, 2008�2013
capd0913at02.csv		Appendix table 2. Standard errors for figure 1: Annual number of violent victimizations, by victim�s disability status, 2008�2013
capd0913at03.csv		Appendix table 3. Standard errors for table 1: Rates of violent victimization, by victim�s disability status and age, 2009�2013
capd0913at04.csv		Appendix table 4. Standard errors for table 2: Rates of violent victimization against persons with and without disabilities, by type of crime, 2009�2013
capd0913at05.csv		Appendix table 5. Standard errors for table 3: Rates of violent victimization against persons with and without disabilities, by victim characteristics, 2009�2013
capd0913at06.csv		Appendix table 6. Standard errors for table 4: Rates of violent victimization against persons with disabilities, by disability type, 2009�2013
capd0913at07.csv		Appendix table 7. Standard errors for table 5: Rates of serious violent victimization against persons with disabilities, by disability type, 2009�2013
capd0913at08.csv		Appendix table 8. Standard errors for table 6: Rates of simple assault against persons with disabilities, by disability type, 2009�2013
capd0913at09.csv		Appendix table 9. Standard errors for table 7: Rates of violent victimization, by victim�s sex and disability type, 2009�2013
capd0913at10.csv		Appendix table 10. Standard errors for table 8: Percent of violence against persons with disabilities that involved victims with multiple disability types, by type of crime, 2009�2013
capd0913at11.csv		Appendix table 11. Standard errors for table 9: Rates of violent victimization, by number of disability types and type of crime, 2009�2013
capd0913at12.csv		Appendix table 12. Standard errors for table 10: Victim�offender relationship, by victim�s disability status, 2009�2013
capd0913at13.csv		Appendix table 13. Standard errors for table 11: Time violent crime occurred, by victim�s disability status, 2009�2013
capd0913at14.csv		Appendix table 14. Standard errors for table 12: Percent of violent crime reported to police, by victim's disability status, 2009�2013
capd0913at15.csv		Appendix table 15. Standard errors for table 13: Person who notified police of violent crime, by victim's disability status, 2009�2013
capd0913at16.csv		Appendix table 16. Standard errors for table 14: Reasons for not reporting violent crime to police, by victim�s disability status, 2009�2013
capd0913at17.csv		Appendix table 17. Standard errors for table 15: Percent of violent crime victims who received services from nonpolice victim services agencies, by victim's disability status, 2009�2013
capd0913at18.csv		Appendix table 18. U.S. population, according to the U.S. Census Bureau's ACS PUMS data, by disability status and demographic characteristics, 2013
capd0913at19.csv		Appendix table 19. Rates of violent victimization against persons without disabilities, by type of crime, 2009�2013
capd0913at20.csv		Appendix table 20. Standard errors for appendix table 19: Rates of violent victimization against persons without disabilities, by type of crime, 2009�2013
capd0913at21.csv		Appendix table 21. Rates of violent victimization against persons without disabilities, by victim characteristics, 2009�2013
capd0913at22.csv		Appendix table 22. Standard errors for appendix table 21: Rates of violent victimization against persons without disabilities, by victim characteristics, 2009�2013