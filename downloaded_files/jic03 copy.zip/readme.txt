Jails in Indian Country, 2003, NCJ 208957

This zip archive contains tables in individual .csv spreadsheets
from Jails in Indian Country, 2003, NCJ 208957
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jic03.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic


File name	       Table           	Title
jic0301.csv	           Table 1:	Indian country jail inmate characteristics, midyear 2002-03
jic0302.csv		       Table 2:	Ten largest jails in Indian country, June 30, 2003
jic0303.csv			   Table 3: Jails in Indian country operating above 150% capacity on the peak day during June 2003							
jic0304.csv		       Table 4:	Staff characteristics of jails in Indian country, June 30, 2003				
jic03a01.csv	       Appendix table 1: Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 2003
jic03a02.csv		   Appendix table 2: Adults and juveniles in the custody of jails in Indian country, by gender and conviction status, June 30, 2003
jic03a03.csv	       Appendix table 3: Inmates in jails in Indian country, by seriousness of offense and type of offense, June 30, 2003
jic03h01.csv	       Highlights table 1: Persons under Indian country correctional supervision and inmate admissions, midyear 2002-03 
jic03h02.csv	       Highlights table 2: Inmates, rated capacity, and percent of capacity occupied in Indian country jails, 2001-03
jic03h03.csv	       Highlights table 3: Indian country jail inmates, by type of offense, June 30, 2003 
jic03t01.csv	       Text table 1: American Indians and Alaska Natives under correctional supervision in the United States 
jic03t02.csv	       Text table 2: Persons under community supervision in Indian country, midyear 2002-03 
jic03t03.csv	       Text table 3: Indian country jail inmate admissions and reported suicides, 1998 and 2001-03
jic03t04.csv	       Text table 4: Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, 2001-03
jic03t05.csv	       Text table 5: Percent of capacity occupied on peak day in June 2003 by rated capacity of facility 
jic03f01.csv           Figure 1:  Midyear 2002-03, the inmate population of Indian country jails varied 29% from a high in June 2002 to a low in April 2003
