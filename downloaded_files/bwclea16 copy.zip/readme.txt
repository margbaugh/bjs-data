Body-Worn Cameras in Law Enforcement Agencies, 2016   NCJ 25177		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Body-Worn Cameras in Law Enforcement Agencies, 2016   NCJ 25177.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6426	
		
Filename		Table name
bwclea16t01.csv		Table 1. Agencies that had acquired and started using body-worn cameras, by agency type and size, 2016
bwclea16t02.csv		Table 2. Full-time sworn officers with body-worn cameras, by agency type, 2016
bwclea16t03.csv		Table 3. Reasons why body-worn cameras were acquired, by agency type and size, 2016
bwclea16t04.csv		Table 4. Deployment of body-worn cameras, by agency type and size, 2016
bwclea16t05.csv		Table 5. Policy topics related to body-worn cameras, by agency type and size, 2016
bwclea16t06.csv		Table 6. Events that body-worn cameras are required to record, by agency type, 2016
bwclea16t07.csv		Table 7. Personnel with direct access to video produced by body-worn cameras, by agency type and size, 2016
bwclea16t08.csv		Table 8. Public-use footage requests for agencies with body-worn cameras, by agency type, 2016
bwclea16t09.csv		Table 9. Obstacles encountered with using body-worn cameras or with footage, by agency type, 2016
bwclea16t10.csv		Table 10. Alternative methods of recording police-citizen interactions for agencies without body-worn cameras, by agency type, 2016
bwclea16t11.csv		Table 11. Reasons for not having acquired body-worn cameras, by agency type, 2016
bwclea16t12.csv		Table 12. Response rate, by agency type and size, 2016
bwclea16t13.csv		Table 13. Base weights, non-response adjustment factors, and final analytical weights, by agency type and size, 2016
		
bwclea16f01.csv		Figure 1. General-purpose law enforcement agencies with recording devices, by type of device, 2016
bwclea16f02.csv		Figure 2. Factors determining if an agency would explore body-worn cameras in the next year, by agency type, 2016
		
bwclea16at01.csv	Appendix table 1. Reasons why body-worn cameras have not been fully deployed, by agency type, 2016
bwclea16at02.csv	Appendix table 2. Officer and community support of body-worn cameras, by agency type and size, 2016
bwclea16at03.csv	Appendix table 3. Estimates and standard errors for figure 1: General-purpose law enforcement agencies with recording devices, by type of device, 2016
bwclea16at04.csv	Appendix table 4. Standard errors for table 1: Agencies that had acquired and started using body-worn cameras, by agency type and size, 2016
bwclea16at05.csv	Appendix table 5. Standard errors for table 2: Full-time sworn officers with body-worn cameras, by agency type, 2016
bwclea16at06.csv	Appendix table 6. Standard errors for table 3: Reasons why body-worn cameras were acquired, by agency type and size, 2016
bwclea16at07.csv	Appendix table 7. Standard errors for table 4: Deployment of body-worn cameras, by agency type and size, 2016
bwclea16at08.csv	Appendix table 8. Standard errors for table 5: Policy topics related to body-worn cameras, by agency type and size, 2016
bwclea16at09.csv	Appendix table 9. Standard errors for table 6: Events that body-worn cameras are required to record, by agency type, 2016 
bwclea16at10.csv	Appendix table 10. Standard errors for table 7: Personnel with direct access to video produced by body-worn cameras, by agency type and size, 2016
bwclea16at11.csv	Appendix table 11. Standard errors for table 8: Public-use footage requests for agencies with body-worn cameras, by agency type, 2016
bwclea16at12.csv	Appendix table 12. Standard errors for table 9: Obstacles encountered with using body-worn cameras or with footage, by agency type, 2016
bwclea16at13.csv	Appendix table 13. Standard errors for table 10. Alternative methods of recording police-citizen interactions for agencies without body-worn cameras, by agency type, 2016
bwclea16at14.csv	Appendix table 14. Standard errors for table 11: Reasons for not having acquired body-worn cameras, by agency type, 2016
bwclea16at15.csv	Appendix table 15. Estimates and standard errors for figure 2: Factors determining if an agency would explore body-worn cameras in the next year, by agency type, 2016
