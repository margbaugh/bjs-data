Federal Justice Statistics, 2012 - Statistical Tables  NCJ 248470
											
This zip archive contains tables in individual .csv spreadsheets from 
Federal Justice Statistics, 2012 - Statistical Tables  NCJ 248470
The full report including text and graphics in pdf format are available 
from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5217
 
This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=62
											
											
fjs12stt101.csv		Table 1.1. Suspects arrested for federal offenses and booked by U.S. Marshals Service, by offense, October 1, 2011�September 30, 2012									
fjs12stt102.csv		Table 1.2. Suspects arrested for federal offenses and booked by U.S. Marshals Service, by arresting agency, October 1, 2011�September 30, 2012									
fjs12stt103.csv		Table 1.3. Characteristics of federal arrestees booked by the U.S. Marshals Service, October 1, 2011�September 30, 2012
fjs12stm101.csv		Map 1.1. Suspects arrested for a drug offense, by federal judicial district of arrest, October 1, 2011 - September 30, 2012	
fjs12stt104.csv		Table 1.4. Characteristics of suspects arrested by Drug Enforcement Administration agents, by type of drug, October 1, 2011�September 30, 2012									
fjs12stt105.csv		Table 1.5. Warrants cleared and median days from initiation to clearance, by warrant type, October 1, 2011�September 30, 2012									
fjs12stt106.csv		Table 1.6. Median days  from warrant initiation to clearance, by warrant characteristics, October 1, 2011�September 30, 2012
fjs12stt201.csv		Table 2.1. Suspects in matters received by U.S. attorneys, by offense, October 1, 2011�September 30, 2012
fjs12stm201.csv		Map 2.1. Suspects in drug matters referred by the Drug Enforcement Administration, by federal judicial district, October 1, 2011�September 30, 2012									
fjs12stt202.csv		Table 2.2. Disposition of suspects in matters concluded, by offense, October 1, 2011�September 30, 2012
fjs12stt203.csv		Table 2.3. Reasons U.S. attorneys declined to prosecute suspects in criminal matters, October 1, 2011�September 30, 2012
fjs12stt301.csv		Table 3.1. Defendants released at initial hearing or detention hearing, by offense, October 1, 2011�September 30, 2012
fjs12stt302.csv		Table 3.2. Defendants released at any time prior to case disposition, by defendant characteristics, October 1, 2011�September 30, 2012
fjs12stm301.csv		Map 3.1. Drug defendants with a prior felony conviction at case disposition, by federal judicial district, October 1, 2011�September 30, 2012
fjs12stt303.csv		Table 3.3. Behavior of federal defendants released to the community pending trial, by offense, October 1, 2011�September 30, 2012									
fjs12stt401.csv		Table 4.1. Defendants in criminal cases commenced, by offense, October 1, 2011�September 30, 2012									
fjs12stt402.csv		Table 4.2. Disposition of criminal cases terminated, by offense, October 1, 2011�September 30, 2012
fjs12stm401.csv		Map 4.1. Adjudicated defendants receiving a bench or trial jury, by federal judicial district, October 1, 2011�September 30, 2012
fjs12stt403.csv		Table 4.3. Criminal cases disposed by U.S. magistrates, October 1, 2011�September 30, 2012
fjs12stt404.csv		Table 4.4. Characteristics of convicted offenders, October 1, 2011�September 30, 2012									
fjs12stt501.csv		Table 5.1. Offenders sentenced in criminal cases terminated, by offense, October 1, 2011�September 30, 2012
fjs12stt502.csv		Table 5.2. Type and length of federal sentences imposed, by offense, October 1, 2011�September 30, 2012
fjs12stt503.csv		Table 5.3. Convicted offenders sentenced to incarceration, by offender characteristics, October 1, 2011�September 30, 2012
fjs12stt504.csv		Table 5.4. Average incarceration sentence length, by offense and offender characteristics, October 1, 2011�September 30, 2012
fjs12stm501.csv		Map 5.1. Convicted drug defendants receiving a nonprison sentence, by federal judicial district, October 1, 2011�September 30, 2012
fjs12stt601.csv		Table 6.1. Criminal appeals terminated, by type of criminal case and offense, October 1, 2011�September 30, 2012
fjs12stt602.csv		Table 6.2. Disposition of criminal appeals terminated, by offense, October 1, 2011�September 30, 2012
fjs12stt603.csv		Table 6.3. Criminal appeals cases terminated on the merits, by offense, October 1, 2011�September 30, 2012
fjs12stt701.csv		Table 7.1. Offenders under federal supervision, by offense, September 30, 2012									
fjs12stm701.csv		Map 7.1. Percent of total drug offenders in the Bureau of Prisons on September 30, 2012, by federal judicial district of commitment
fjs12stt702.csv		Table 7.2. Characteristics of offenders under federal supervision, September 30, 2012
fjs12stt703.csv		Table 7.3. Outcomes of offenders terminating probation supervision, by offense, October 1, 2011�September 30, 2012
fjs12stt704.csv		Table 7.4. Outcomes of offenders terminating probation supervision, by offender characteristics, October 1, 2011�September 30, 2012
fjs12stt705.csv		Table 7.5. Outcomes of offenders terminating supervised release, by offense, October 1, 2011�September 30, 2012
fjs12stt706.csv		Table 7.6. Outcomes of offenders terminating supervised release, by offender characteristics, October 1, 2011�September 30, 2012 
fjs12stt707.csv		Table 7.7. Outcomes of offenders terminating parole, by offense, October 1, 2011�September 30, 2012
fjs12stt708.csv		Table 7.8. Outcomes of offenders terminating parole, by offender characteristics, October 1, 2011�September 30, 2012									
fjs12stt709.csv		Table 7.9. Admissions and releases of federal prisoners, by offense, October 1, 2011�September 30, 2012
fjs12stt710.csv		Table 7.10. Characteristics of offenders in the federal prison population, September 30, 2012
fjs12stt711.csv		Table 7.11. Average time to first release and percent of sentence served for federal prisoners released by standard methods, October 1, 2011�September 30, 2012 									
fjs12stt712.csv		Table 7.12. Characteristics of offenders first released from prison, by offense, October 1, 2011�September 30, 2012									
