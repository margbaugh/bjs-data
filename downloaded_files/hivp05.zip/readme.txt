HIV in Prisons, 2005 NCJ 218985	

Tables	
hivp05t01.csv	Table 1. Number of HIV/AIDS cases in State or Federal prisons at yearend, 1999 and 2005
hivp05t02.csv	Table 2. Number of confirmed AIDS cases in State and Federal prisons, at yearend 1999-2005
hivp05t03.csv	Table 3. Percent with confirmed AIDS among State and Federal prisoners and the U.S. general population, 1999-2005
hivp05t04.csv	Table 4. HIV/AIDS cases in State and Federal prisons, by gender, 1999-2005
hivp05t05.csv	Table 5. Profile of inmates who died from AIDS-related causes in State prisons, 2001-2005
hivp05t06.csv	Table 6. Percent of AIDS-related deaths among all deaths in State prison and U.S. general population
hivp05t07.csv	Table 7. Rate of AIDS-related deaths in State prison and U.S. general population
hivp05t08.csv	Table 8. Rate of AIDS-related deaths per 100,000 persons in State prison and the U.S. general population, by age, 2001-2005

Highlight tables	
hivp05ht01.csv	Highlight table 1.  Reported HIV/AIDS cases and AIDS-related deaths, 2004 and 2005

Box tables	
hivp05bt01.csv	Box table 1. State inmates who were ever tested for HIV and reported results, by selected characteristics, 2004 and 1997

Figures	
hivp05f01.csv	Figure 1. HIV/AIDS cases in State and Federal prisons, 1991-2005
hivp05f02.csv	Figure 2. Trends in AIDS-related deaths, 1991-2005

Appendix tables	
hivp05at01.csv	Appendix table 1.  Inmates in custody of State or Federal prison authorities and reported to be positive for the human immunodeficiency virus (HIV) or to have confirmed AIDS, 2003-05
hivp05at02.csv	Appendix table 2.  Inmates in custody of State and Federal prison authorities reported to be positive for the human immunodeficiency virus (HIV) or to have confirmed AIDS, by gender, 2005
hivp05at03.csv	Appendix table 3.  Inmates in custody of State or Federal prison authorities and reported to have confirmed AIDS, yearend 2004 and 2005
hivp05at04.csv	Appendix table 4.  Deaths of State prisoners, 2005
hivp05at05.csv	Appendix table 5.  Circumstances under which inmates were were tested for the antibody to the human immunodeficiency virus (HIV), by jurisdiction, 2005
hivp05at06.csv	Appendix table 6.  Inmate deaths in Federal prisons, by cause, 2004 and 2005
hivp05at07.csv	Appendix table 7.  Standard error estimates for Survey of Inmates in State Correctional Facilities, 1997 and 2004
