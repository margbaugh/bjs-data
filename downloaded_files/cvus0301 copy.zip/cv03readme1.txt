Criminal Victimization in the United States, 2003   NCJ# 207811
 
This zip archive contains tables in individual .csv spreadsheets
from the 2003  National Crime Victimization Survey.
It is one of  a series of files from the National Crime Victimization Survey.
All of the files may be obtained from http://www.ojp.usdoj.gov/bjs/abstract/cvusst.htm
                         
 
Text files: 
cvus03mt.txt --detailed information about the National Crime Victimization Survey and the results
             from the data collection throughout United States (Methodology). 

Spreadsheets
 
File Name    Table Titles
 
             DEMOGRAPHY  OF VICTIMS
cv0301.csv   Table 1: Number, percent distribution, and rate of victimizations, by type of crime
cv0302.csv   Table 2: Number of victimizations and victimization rates for persons age 12 and      
                                   over, by type of crime and gender of victims
cv0303.csv   Table 3: Victimization rates for persons age 12 and over, by type of crime and age    
                                    of victims
cv0304.csv   Table 4: Victimization rates for persons age 12 and over, by gender and age of          
                                     victims and type of crime
cv0305.csv   Table 5: Number of victimizations and victimization rates for persons age 12 and      
                                   over, by type of crime and race of victims
cv0306.csv   Table 6: Number of victimizations and victimization rates for persons age 12 and      
                                   over, by type of crime and gender and race of victims
cv0307.csv   Table 7: Number of victimizations and victimization rates for persons age 12 and      
                                   over, by type of crime and ethnicity of victims
cv0308.csv   Table 8: Victimization rates for persons age 12 and over, by type of crime and
                 ethnicity and gender of victims
cv0309.csv   Table 9: Victimization rates for persons age 12 and over, by race and age of              
                                     victims and type of crime
cv0310.csv   Table 10: Number of victimizations and victimization rates for persons age 12 and    
                                     over, by race, gender, and age of victims and type of crime
cv0311.csv   Table 11: Victimization rates for persons age 12 and over, by type of crime and         
                                      marital status of victims
cv0312.csv   Table 12: Victimization rates for persons age 12 and over, by gender and marital       
                                      status of victims and type of crime
cv0313.csv   Table 13: Victimization rates for persons age 12 and over, by gender of head of
                   household, relationship of victims to head and type of crime
cv0314.csv   Table 14: Victimization rates for persons age 12 and over, by type of crime and         
                                     annual family income of victims
cv0315.csv   Table 15: Victimization rates for persons age 12 and over, by race and annual            
                                     family income of victims and type of crime
cv0316.csv   Table 16: Number of victimizations and victimization rates by type of crime and       
                                     race of head of household
cv0317.csv   Table 17: Number of victimizations and victimization rates by type of crime and
                  ethnicity of head of household
cv0318.csv   Table 18: Number of victimizations and victimization rates on the basis of thefts
                                       per 1,000 households and of thefts per 1,000 vehicles owned, by selected 
                                       household characteristics
cv0319.csv   Table 19: Victimization rates by type of crime and age of head of household
cv0320.csv   Table 20: Victimization rates by type of crime and annual family income
cv0321.csv   Table 21: Victimization rates by race of head of household, annual family income     
                                      and type of household burglary
cv0322.csv   Table 22: Victimization rates by race of head of household, annual family income     
                                      and type of theft
cv0323.csv   Table 23: Victimization rates by race of head of household, annual family income     
                                      and type of motor vehicle theft
cv0324.csv   Table 24: Victimization rates by type of crime and number of persons in household
cv0325.csv   Table 25: Victimization rates by type of crime and number of units in structure
                  occupied by household

Five related archives are also available.  The sections and tables of these archives are listed
below.
   
             VICTIMS AND OFFENDERS
cv0326.csv   Table 26: Number of incidents and victimizations and ratio of victimizations to
                  incidents, by type of crime
cv0327.csv   Table 27: Number and percent distribution of incidents, by type of crime and             
                                     victim-offender relationship
cv0328.csv   Table 28: Number of victimizations and victimization rates for persons age 12 and    
                                     over, by type of crime and victim-offender relationship
cv0329.csv   Table 29: Percent of victimizations involving strangers, by gender and age of            
                                      victims and type of crime
cv0330.csv   Table 30: Percent of victimizations involving strangers, by gender and race of           
                                      victims and type of crime
cv0331.csv   Table 31: Percent of victimizations involving strangers, by gender and marital           
                                     status of victims and type of crime
cv0332.csv   Table 32: Percent distribution of victimizations, by perceived drug or alcohol use      
                                     by offender
cv0333.csv   Table 33: Number of victimizations, by type of crime and relationship to offender
cv0334.csv   Table 34: Percent distribution of victimizations, by type of crime and relationship     
                                      to offender
cv0335.csv   Table 35: Victimization rate by victim-offender relationship, by type of crime and
                  selected victim characteristics
cv0336.csv   Table 36: Percent distribution of incidents, by type of crime and number of victims
cv0337.csv   Table 37: Percent distribution of incidents, by victim-offender relationship, type of
                  crime and number of offenders
cv0338.csv   Table 38: Percent distribution of single-offender victimizations, by type of crime      
                                      and perceived gender of offender
cv0339.csv   Table 39: Percent distribution of single-offender victimizations, by type of crime      
                                      and perceived age of offender
cv0340.csv   Table 40: Percent distribution of single-offender victimizations, by type of crime      
                                      and perceived race of offender
cv0341.csv   Table 41: Percent distribution of single-offender victimizations, by type of crime,     
                                      age of victims and perceived age of offender
cv0342.csv   Table 42: Percent distribution of single-offender victimizations, based on race of
                  victims, by type of crime and perceived race of offender
cv0343.csv   Table 43: Percent distribution of single-offender victimizations, by type of crime      
                                      and detailed victim-offender relationship
cv0343a.csv  Table 43a: Percent distribution of victimizations, by characteristics of victims,
                                          type of crime, and victim/offender relationship
cv0344.csv   Table 44: Percent distribution of multiple-offender victimizations, by type of crime
                  and perceived gender of offender
cv0345.csv   Table 45: Percent distribution of multiple-offender victimizations, by type of crime
                  and perceived age of  offenders
cv0346.csv   Table 46: Percent distribution of multiple-offender victimizations, by type of crime
                  and perceived race of offenders
cv0347.csv   Table 47: Percent distribution of multiple-offender victimizations, by type of             
                                    crime, age of victims and perceived age of offenders
cv0348.csv   Table 48: Percent distribution of multiple-offender victimizations, by type of             
                                    crime, race of victims and perceived race of offenders
cv0349.csv   Table 49: Percent distribution of multiple-offender victimizations, by type of crime
                  and detailed victim-offender relationship
 
             GEOGRAPHY
cv0350.csv   Table 50: Victimization rates for persons age 12 and over, by type of crime and         
                                     number of years lived at current residence
cv0351.csv   Table 51: Victimization rates by type of crime and number of years lived at current
                  residence
cv0352.csv   Table 52: Victimization rates for persons age 12 and over, by type of crime and
                  locality of residence of victims
cv0353.csv   Table 53: Victimization rates, by type of crime and locality of residence
cv0354.csv   Table 54: Victimization rates for persons age 12 and over, by locality of residence,
                  race, gender and ethnicity of victims and type of crime
cv0355.csv   Table 55: Victimization rates by locality of residence, race of head of household       
                                      and type of crime
cv0356.csv   Table 56: Victimization rates by type of crime, form of tenure, race of head of
                                 household, and locality of residence
cv0357.csv   Table 57: Victimization rates for persons age 12 and over, by type of crime, region   
                                      and locality of residence
cv0358.csv   Table 58: Victimization rates by type of crime, region and locality of residence
 
             THE CRIME EVENT
cv0359.csv   Table 59: Percent distribution of incidents, by type of crime and time of occurrence
cv0360.csv   Table 60: Percent distribution of incidents, by type of crime, type of offender and
                  time of occurrence
cv0361.csv   Table 61: Percent distribution of incidents, by type of crime and place of                    
                                     occurrence
cv0362.csv   Table 62: Percent distribution of incidents, by type of crime, type of offender and
                  place of occurrence
cv0363.csv   Table 63: Percent distribution of incidents, by victim-offender relationship, type of
                  crime and place of occurrence
cv0364.csv   Table 64: Percent distribution of incidents, by victim's activity at time of incident
                  and type of crime
cv0365.csv   Table 65: Percent distribution of incidents, by distance from home and type of           
                                     crime
cv0366.csv   Table 66: Percent of incidents, by victim-offender relationship, type of crime and
                  weapons use
cv0367.csv   Table 67: Percent distribution of violent crime victimizations by who was first to      
                                     use or threaten to use physical force
cv0368.csv   Table 68: Percent of victimizations in which victims took self-protective measures,   
                                     by type of crime and victim-offender relationship
cv0369.csv   Table 69: Percent of victimizations in which victims took self-protective measures,   
                                     by characteristics of victims and type of crime
cv0370.csv   Table 70: Percent distribution of self-protective measures employed by victims, by   
                                      type of measure and type of crime
cv0371.csv   Table 71: Percent distribution of self-protective measures employed by victims, by
                  selected characteristics of victims
cv0372.csv   Table 72: Percent victimizations in which self-protective measures employed, by      
                                      person taking the measure, outcome of action and type of crime
cv0373.csv   Table 73: Percent distribution of victimizations in which self-protective measures
                  taken by the victim were helpful
cv0374.csv   Table 74: Percent distribution of victimizations in which self-protective measures
                  taken by the victim were harmful
cv0375.csv   Table 75: Percent of victimizations in which victims sustained physical injury, by
                  selected characteristics of victim and type of crime 
cv0376.csv   Table 76: Percent distribution of victims receiving medical care, by type of crime      
                                     and where care was received
cv0377.csv   Table 77: Percent of victimizations in which victims incurred medical expenses, by
                  selected characteristics of victims and type of crime
cv0378.csv   Table 78: Percent of victimizations in which injured victims had health insurance
                  coverage or were eligible for public medical services, by selected             
                                       characteristics of victims
cv0379.csv   Table 79: Percent of victimizations in which victims received hospital care, by
                  selected characteristics of victims and type of crime
cv0380.csv   Table 80: Percent distribution of victimizations in which injured victims received
                  hospital care, by selected characteristics of victims, type of crime and       
                                       type of  hospital care
cv0381.csv   Table 81: Percent of victimizations resulting in economic loss, by type of crime        
                                      and type of loss
cv0382.csv   Table 82: Total economic loss to victims of crime
cv0383.csv   Table 83: Percent distribution of victimizations resulting in economic loss, by type   
                                      of crime and value of loss
cv0384.csv   Table 84: Percent distribution of victimizations resulting in theft loss, by type of
                  crime and type of property stole
cv0385.csv   Table 85: Percent distribution of victimizations resulting in theft loss, by race of
                  victims, type of crime and value of loss
cv0386.csv   Table 86: Percent distribution of victimizations resulting in theft loss, by race of
                  victims, type of crime and proportion of loss recovered
cv0387.csv   Table 87: Percent of victimizations resulting in loss of time from work, by type of
                  crime
cv0388.csv   Table 88: Percent of victimizations resulting in loss of time from work, by type of
                  crime and race of victims
cv0389.csv   Table 89: Percent distribution of victimizations resulting in loss of time from            
                                      work, by type of crime and number of days lost
cv0390.csv   Table 90: Percent distribution of victimizations resulting in loss of time from            
                                      work, by race of victims, type of crime, and number of days lost
 
             VICTIMS AND THE CRIMINAL JUSTICE SYSTEM
cv0391.csv   Table 91: Percent distribution of victimizations, by type of crime and whether or       
                                     not reported to the police
cv0391b.csv  Table 91b: Percent of victimizations reported to the police, by type of crime and      
                                         gender and race or ethnicity of victims
cv0392.csv   Table 92: Percent of victimizations reported to the police, by selected                        
                                      characteristics of victims and type of crime
cv0393.csv   Table 93: Percent of victimizations reported to the police, by type of crime, victim
                 -offender relationship and gender of victims
cv0393a.csv  Table 93a: Number and percent distribution of victimizations reported to the            
                                         police, by type of crime, and gender of head of household
cv0394.csv   Table 94: Percent of victimizations reported to the police, by type of crime, victim
                 -offender relationship and race of victims
cv0395.csv   Table 95: Percent of victimizations reported to the police, by type of crime, victim
                 -offender relationship and ethnicity of victims
cv0396.csv   Table 96: Percent of victimizations reported to the police, by type of crime and age   
                                    of victims
cv0397.csv   Table 97: Percent of victimizations reported to the police, by type of crime, form      
                                     of tenure, and race and ethnicity of head of household
cv0398.csv   Table 98: Percent of victimizations reported to the police, by type of crime and         
                                      form of tenure
cv0399.csv   Table 99: Percent of victimizations reported to the police, by type of crime and         
                                      annual family income
cv03100.csv  Table 100: Percent of victimizations reported to the police, by value of loss and       
                                         type of crime
cv03101.csv  Table 101: Percent of reasons for reporting victimizations to the police, by type of
                     crime
cv03102.csv  Table 102: Percent of reasons for not reporting victimizations to the police, by         
                                         type of crime
cv03103.csv  Table 103: Percent of reasons for not reporting victimizations to the police, by         
                                         race of victims and type of crime
cv03104.csv  Table 104: Percent of reasons for not reporting victimizations to the police, by         
                                         victim-offender relationship and type of crime
cv03105.csv  Table 105: Percent of reasons for not reporting victimizations to the police, by         
                                         race of head of household and type of crime
cv03106.csv  Table 106: Percent distribution of police response to a reported incident, by type      
                                        of crime
cv03107.csv  Table 107: Percent distribution of incidents where police came to the victim, by       
                                        police response time and type of crime
cv03108.csv  Table 108: Percent distribution of incidents, by police activity during initial              
                                        contact with victim and type of crime
cv03109.csv  Table 109: Percent distribution of the kind of agency providing assistance by type    
                                        of crime
 
             SERIES VICTIMIZATIONS
cv03110.csv  Table 110: Number and percent distribution of series victimizations and of
                     victimizations not in series, by type of crime
 
 
 
 
 
 
 
 





