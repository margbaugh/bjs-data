Victims of Identity Theft, 2008	
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Victims of Identity Theft, 2008 NCJ 231680		
The full report including text and graphics in pdf format is available at:              		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2222		
		
		
vit08f01.csv		Figure 1. Percentage of persons age 16 or older who experienced at least one attempted or successful incident of identity theft during the past 2 years, 2008
vit08f02.csv		Figure 2. Most common ways offenders obtained personal information from the 4.5 million identity theft victims who knew how the theft occurred, by type of theft, 2008
vit08f03.csv		Figure 3. Total out-of-pocket loss for identity theft victims who experienced a direct or indirect financial loss from identity theft during a 2-year period, 2008
vit08f04.csv		Figure 4. Length of time spent clearing up problems associated with identity theft, by type of theft, 2008
vit08f05.csv		Figure 5. Percentage of identity theft victims who contacted a credit bureau about an identity theft incident during the past 2 years, by action taken, 2008
vit08f06.csv		Figure 6. Percentage of identity theft victims during the past 2 years who reported an identity theft incident to a law enforcement agency, by type of identity theft, 2008
vit08f07.csv		Figure 7. Percentage of identity theft victims and victims of violent offenses who reported experiencing work or relationship problems as a result of the victimization, 2008 and 2009
vit08f08.csv		Figure 8. Level of emotional distress reported by victims of identity theft and victims of violent crimes, 2008 and 2009
vit08f09.csv		Figure 9. Percentage of victims reporting work/school or relationship problems and distress resulting from identity theft, by length of time spent resolving financial and credit problems associated with the theft, 2008
		
vit08t01.csv		Table 1. Number and percentage of persons age 16 or older who experienced at least one attempted or successful identity theft incident in a 2-year period, 2008
vit08t02.csv		Table 2. Percentage of persons who experienced at least one attempted or successful incident of identity theft during the past 2 years, by victim characteristics, 2008
		
vit08a01.csv		Appendix Table 1. Number and percentage of persons age 16 or older who experienced at least one attempted or successful incident of identity theft during the previous 2 years, 2008
vit08a02.csv		Appendix Table 2. Percentage of persons who experienced at least one attempted or successful incident of identity theft during the past 2 years, by victim characteristics, 2008
vit08a03.csv		Appendix Table 3. Percentage of victims who experienced an attempted or successful identity theft incident during the previous 2 years and knew how their information was stolen, by type of identity theft and offender method of obtaining identifying information, 2008
vit08a04.csv		Appendix Table 4. Financial loss from identity theft among victims who experienced at least one attempted or successful identity theft incident during the previous 2 years, by type of theft and type of loss, 2008
vit08a05.csv		Appendix Table 5. Length of time victims spent clearing up problems associated with any attempted or successful identity theft incident that occurred during the past 2 years, 2008
vit08a06.csv		Appendix Table 6. Percentage of identity theft victims who experienced at least one attempted or successful incident of identity theft during the past 2 years and contacted an organization about the theft, by type of theft, type of organization, and credit bureau action, 2008
vit08a07.csv		Appendix Table 7. Percentage of victims who experienced at least one attempted or successful identity theft incident during the past 2 years and reported the incident to a law enforcement agency, by type of identity theft and reasons for not reporting, 2008
vit08a08.csv		Appendix Table 8. Percentage of victims who experienced at least one identity theft incident during the previous 2 years or a violent crime incident during the prior year and experienced emotional or physical problems as a result of the incident, by type of identity theft or violent crime, 2008 and 2009
		
vit08at01_se.csv		Appendix Table 1e. Standard errors for the number and percentage of persons age 16 or older who experienced at least one attempted or successful incident of identity theft during the previous 2 years, 2008
vit08at02_se.csv		Appendix Table 2e. Standard errors for the percentage of persons who experienced at least one attempted or successful incident of identity theft during the previous 2 years, by victim characteristics, 2008
vit08at03_se.csv		Appendix Table 3e. Standard errors for the percentage of victims who experienced an attempted or successful identity theft incident during the previous 2 years and knew how their information was stolen, by type of identity theft and offender method of obtaining identifying information, 2008
vit08at04_se.csv		Appendix Table 4e. Standard errors for financial loss from identity theft among victims who experienced at least one attempted or successful identity theft incident during the previous 2 years, by type of theft and type of loss, 2008
vit08at05_se.csv		Appendix Table 5e. Standard errors for the length of time victims spent clearing up problems associated with any attempted or successful identity theft incident that occurred during the previous 2 years, 2008
vit08at06_se.csv		Appendix Table 6e. Standard errors for the percentage of identity theft victims who experienced at least one attempted or successful incident of identity theft during the previous two years and contacted an organization about the theft, by type of theft, type of organization, and credit bureau action, 2008
vit08at07_se.csv		Appendix Table 7e. Standard errors for the percent of victims who experienced at least one attempted or successful identity theft incident during the previous two years and reported the incident to a law enforcement agency, by type of identity theft and reasons for not reporting, 2008
vit08at08_se.csv		Appendix Table 8e. Standard errors for the percent of victims who experienced at least one identity theft incident during the previous 2 years or a violent crime incident during the prior year and experienced emotional or physical problems as a result of the incident, by type of identity theft or violent crime, 2008 and 2009
