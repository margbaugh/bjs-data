Indicators of School Crime and Safety:  2006  NCJ 214262

This Zip archive contains tables in individual .csv spreadsheets			
From Indicators of School Crime and Safety:  2006  NCJ 214262
the full report including text and graphics in .pdf format are available from:			
http://www.ojp.usdoj.gov/bjs/abstract/iscs06.htm			

This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#iscs			


Tables			
iscs06s02-1.csv		Table S2.1.�Standard errors for number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location: 1992�2005 
iscs06s02-2.csv		Table S2.2.�Standard errors for the number of student-reported nonfatal crimes against students ages 12�18 at school and rate of crimes per 1,000 students, by selected student characteristics: 2004 
iscs06s02-3.csv		Table S2.3.�Standard errors for the number of student-reported nonfatal crimes against students ages 12�18 away from school and rate of crimes per 1,000 students, by selected student characteristics: 2004  
iscs06s03-1.csv		Table S3.1.�Standard errors for the percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student and school characteristics: Various years, 1995�2005 
iscs06s04-1.csv		Table S4.1.�Standard errors for the percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by selected student and school characteristics: Various years, 1993�2005
iscs06s04-2.csv		Table S4.2.�Standard errors for the percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by state: 2003 and 2005 
iscs06s05-1.csv		Table S5.1.�Standard errors for the percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs06s05-2.csv		Table S5.2.�Standard errors for the percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs06s05-3.csv		Table S5.3.�Standard errors for the percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: 1993�94, 1999�2000, and 2003�04
iscs06s05-4.csv		Table S5.4.�Standard errors for the percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: 1993�94, 1999�2000, and 2003�04 
iscs06s06-1.csv		Table S6.1.�Standard errors for the percentage of public schools experiencing and reporting incidents of crime that occurred at school, number of incidents, and the rate per 1,000 students, by type of crime: 1999�2000 and 2003�04
iscs06s06-2.csv		Table S6.2.�Standard errors for the percentage of public schools experiencing incidents of crime that occurred at school, number of incidents, and the rate of crimes per 1,000 students, by selected school characteristics: 2003�04
iscs06s06-3.csv		Table S6.3.�Standard errors for the percentage of public schools reporting incidents of crime that occurred at school to the police, number of incidents, and the rate of crimes per 1,000 students, by selected school characteristics: 2003�04 
iscs06s07-1.csv		Table S7.1.�Standard errors for the percentage of public schools that reported selected discipline problems that occurred at school, by frequency and school characteristics: 2003�04 
iscs06s08-1.csv		Table S8.1.�Standard errors for the percentage of students ages 12�18 who reported that gangs were present at school during the previous 6 months, by urbanicity and selected student and school characteristics: 2001, 2003, and 2005
iscs06s09-1.csv		Table S9.1.�Standard errors for the percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by selected student and school characteristics: Various years, 1993�2005
iscs06s09-2.csv		Table S9.2.�Standard errors for the percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by state: 2003 and 2005
iscs06s010-1.csv	Table S10.1.�Standard errors for the percentage of students ages 12�18 who reported being targets of hate-related words and seeing hate-related graffiti at school during the previous 6 months, by selected student and school characteristics: Various years, 1999�2005
iscs06s010-2.csv	Table S10.2.�Standard errors for the percentage of students ages 12�18 who reported being targets of hate-related words at school during the previous 6 months, by selected student and school characteristics: 2005
iscs06s011-1.csv	Table S11.1.�Standard errors for the percentage of students ages 12�18 who reported selected bullying problems at school during the previous 6 months, by selected student and school characteristics: 2005
iscs06s011-2.csv	Table S11.2.�Standard errors for the percentage of students ages 12�18 who reported being bullied at school during the previous 6 months, by location of bullying, injury, and selected student and school characteristics: 2005
iscs06s011-3.csv	Table S11.3.�Standard errors for the percentage of students ages 12�18 who reported selected bullying problems at school during the previous 6 months and percentage distribution of the frequency of bullying reports, by selected student and school characteristics: 2005
iscs06s012-1.csv	Table S12.1.�Standard errors for the percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and selected student and school characteristics: Various years, 1993�2005
iscs06s012-2.csv	Table S12.2.�Standard errors for the percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and state: 2003 and 2005
iscs06s013-1.csv	Table S13.1.�Standard errors for the percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2005
iscs06s013-2.csv	Table S13.2.�Standard errors for the percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and state: 2003 and 2005
iscs06s014.1.csv	Table S14.1.�Standard errors for the percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2005 
iscs06s014-2.csv	Table S14.2.�Standard errors for the percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and state: 2003 and 2005
iscs06s015-1.csv	Table S15.1.�Standard errors for the percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2005
iscs06s015-2.csv	Table S15.2.�Standard errors for the percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and state: 2003 and 2005
iscs06s016-1.csv	Table S16.1.�Standard errors for the percentage of students ages 12�18 who reported being afraid of attack or harm during the previous 6 months, by location and selected student and school characteristics: Various years, 1995�2005 
iscs06s017-1.csv	Table S17.1.�Standard errors for the percentage of students ages 12�18 who reported avoiding school activities or one or more places in school during the previous 6 months because of fear of attack or harm: Various years, 1995�2005
iscs06s017-2.csv	Table S17.2.�Standard errors for the percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months because of fear of attack or harm, by selected student and school characteristics: Various years, 1995�2005
iscs06s018-1.csv	Table S18.1.�Standard errors for the number and percentage of public schools that took a serious disciplinary action, number of serious actions taken, and percentage distribution of serious actions, by type of action and type of offense: 2003�04 
iscs06s019-1.csv	Table S19.1.�Standard errors for the percentage of public schools that used selected safety and security measures, by school characteristics: 2003�04
iscs06s020-1.csv	Table S20.1.�Standard errors for the percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999�2005


iscs0601-1.csv		Table 1.1.�Number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location: 1992�2005
icsc0601-2.csv		Table 1.2.�Number of school-associated violent deaths of students, staff, and nonstudents, by type: 1992�2005
iscs0602-1.csv		Table 2.1.�Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students, by location and year: 1992�2004
iscs0602-2.csv		Table 2.2.�Number of student-reported nonfatal crimes against students ages 12�18 at school and rate of crimes per 1,000 students, by selected student characteristics: 2004
iscs0602-3.csv		Table 2.3.�Number of student-reported nonfatal crimes against students ages 12�18 away from school and rate of crimes per 1,000 students, by selected student characteristics: 2004
iscs0603-1.csv		Table 3.1.�Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student and school characteristics: Various years, 1995�2005
iscs0604-1.csv		Table 4.1.�Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by selected student and school characteristics: Various years, 1993�2005
iscs0604-1.csv		Table 4.2.�Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by state: 2003 and 2005
iscs0605-1.csv		Table 5.1.�Percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs0605-2.csv		Table 5.2.�Percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs0605-3.csv		Table 5.3.�Percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: 1993�94, 1999�2000, and 2003�04
iscs0605-4.csv		Table 5.4.�Percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: 1993�94, 1999�2000, and 2003�04
iscs0606-1.csv		Table 6.1.�Percentage of public schools experiencing and reporting incidents of crime that occurred at school, number of incidents, and the rate per 1,000 students, by type of crime: 1999�2000 and 2003�04
iscs0606-2.csv		Table 6.2.�Percentage of public schools experiencing incidents of crime that occurred at school, number of incidents, and the rate of crimes per 1,000 students, by selected school characteristics: 2003�04
iscs0606-3.csv		Table 6.3.�Percentage of public schools reporting incidents of crime that occurred at school to the police, number of incidents, and the rate of crimes per 1,000 students, by selected school characteristics: 2003�04
iscs0607-1.csv		Table 7.1.�Percentage of public schools that reported selected discipline problems that occurred at school, by frequency and school characteristics: 2003�04
iscs0608-1.csv		Table 8.1.�Percentage of students ages 12�18 who reported that gangs were present at school during the previous 6 months, by urbanicity and selected student and school characteristics: 2001, 2003, and 2005
iscs0609-1.csv		Table 9.1.�Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by selected student and school characteristics: Various years, 1993�2005
iscs0609-2.csv		Table 9.2.�Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by state: 2003 and 2005
iscs06010-1.csv		Table 10.1.�Percentage of students ages 12�18 who reported being targets of hate-related words and seeing hate-related graffiti at school during the previous 6 months, by selected student and school characteristics: Various years, 1999�2005
iscs06010-2.csv		Table 10.2.�Percentage of students ages 12�18 who reported being targets of hate-related words at school during the previous 6 months, by selected student and school characteristics: 2005
iscs06011-1.csv		Table 11.1.�Percentage of students ages 12�18 who reported selected bullying problems at school during the previous 6 months, by selected student and school characteristics: 2005
iscs06011-2.csv		Table 11.2.�Percentage of students ages 12�18 who reported being bullied at school during the previous 6 months, by location of bullying, injury, and selected student and school characteristics: 2005
iscs06011-3.csv		Table 11.3.�Percentage of students ages 12�18 who reported selected bullying problems at school during the previous 6 months and percentage distribution of the frequency of bullying reports, by selected student and school characteristics: 2005
iscs06012-1.csv		Table 12.1.�Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and selected student and school characteristics: Various years, 1993�2005
iscs06012-2.csv		Table 12.2.�Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and state: 2003 and 2005
iscs06013-1.csv		Table 13.1.�Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2005
iscs06013-2.csv		Table 13.2.�Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and state: 2003 and 2005
iscs06014-1.csv		Table 14.1.�Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2005
iscs06014-2.csv		Table 14.2.�Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and state: 2003 and 2005
iscs06015-1.csv		Table 15.1.�Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2005
iscs06015-2.csv		Table 15.2.�Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and state: 2003 and 2005
iscs06016-1.csv		Table 16.1.�Percentage of students ages 12�18 who reported being afraid of attack or harm during the previous 6 months, by location and selected student and school characteristics: Various years, 1995�2005
iscs06017-1.csv		Table 17.1.�Percentage of students ages 12�18 who reported avoiding school activities or one or more places in school during the previous 6 months because of fear of attack or harm: Various years, 1995�2005
iscs06017-2.csv		Table 17.2.�Percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months because of fear of attack or harm, by selected student and school characteristics: Various years, 1995�2005
iscs06018-1.csv		Table 18.1.�Number and percentage of public schools that took a serious disciplinary action, number of serious actions taken, and percentage distribution of serious actions, by type of action and type of offense: 2003�04
iscs06019-1.csv		Table 19.1.�Percentage of public schools that used selected safety and security measures, by school characteristics: 2003�04
iscs06020-1.csv		Table 20.1.�Percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999�2005


Figures			
iscs060fig1-1.csv	Figure 1.1.�Number of homicides and suicides of youth ages 5�18, by location: 2003-04
iscs060fig1-2.csv	Figure 1.2.�Number of homicides and suicides of youth ages 5�18 at school: 1992�2005
iscs060fig2-1.csv	Figure 2.1.�Rate of student-reported nonfatal crimes against students ages 12-18 per 1,000 students, by type of crime and location, 1992-2004
iscs060fig2-2.csv	Figure 2.2.�Rate of student-reported nonfatal crimes against students ages 12-18 at school per 1,000 students, by type of crime and selected student characteristics: 2004
iscs060fig2-3.csv	Figure 2.3.�Rate of student-reported nonfatal crimes against students ages 12-18 away from school per 1,000 students, by type of crime and selected student characteristics: 2004
iscs060fig3-1.csv	Figure 3.1.�Percentage of students ages 12-18 who reported criminal victimization at school during the previous 6 months, by type of victimization:  Various years, 1995-2005
iscs060fig4-1.csv	Figure 4.1.�Percentage of students in grades 9-12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by sex: Various years, 1993-2005
iscs060fig4-2.csv	Figure 4.2.�Percentage of students in grades 9-12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by grade: 2005
iscs060fig5-1.csv	Figure 5.1.�Percentage of public and private school teachers who reported that they were threatened with injury or that they were physically attacked by a student from school during the previous 12 months, by urbanicity:  1993-94, 1999-2000, and 2003-04
iscs060fig5-2.csv	Figure 5.2.�Percentage of public and private school teachers who reported that they were threatened with injury or that they were physically attacked by a student from school during the previous 12 months, by urbanicity and school sector: 2003-04
iscs060fig6-1.scv	Figure 6.1.�Percentage of public schools experiencing and reporting incidents of crime that occurred at school and the rate per 1,000 students, by type of crime: 2003-04
iscs060fig6-2.csv	Figure 6.2.�Percentage of public schools experiencing and reporting incidents of  crime that occurred at school,  by type of crime and school level:  2003-04
iscs060fig6-3.csv	Figure 6.3.�Percentage of public schools experiencing and reporting incidents of crime that occurred at school, by type of crime and urbanicity: 2003-04
iscs060fig7-1.csv	Figure 7.1.�Percentage of public schools reporting selected dicipline problems that occurred at school, by school level, 2003-04
iscs060fig8-1.csv	Figure 8.1.�Percentage of students ages 12-18 who reported that gangs were present at school during the previous 6 months, by urbanicity:  2001-2005
iscs060fig8-2.csv	Figure 8.2.�Percentage of students ages 12-18 who reported that gangs were present at school during the previous 6 months, by urbanicity and race/ethnicity: 2005
iscs060fig9-1.csv	Figure 9.1.�Percentage of students in grades 9-12 who reported drugs were made available to them on school property during the previous 12 months, by sex: Various years 1993-2005
iscs060fig9-2.csv	Figure 9.2.�Percentage of students in grades 9-12 who reported drugs were made available to them on school property during the previous 12 months, by race/ethnicity: 2005
iscs060fig10-1.csv	Figure 10.1.�Percentage of students ages 12-18 who reported being targets of hate-related words or seeing hate-related graffiti at school during the previous 6 months, by selected student and school characteristics: 2005
iscs060fig11-1.csv	Figure 11.1.�Percentage of students ages 12-18 who reported selected bullying problems at school during the previous 6 months, by type of bullying: 2005
iscs060fig11-2.csv	Figure 11.2.�Percentage of students ages 12-18 who reported being bullied at school during the previous 6 months, by location of bullying and injury: 2005
iscs060fig12-1.csv	Figure 12.1.�Percentage of students in grades 9-12 who reported having been in a physical fight during the previous 12 months, by location and sex:  Various years 1993-2005
iscs060fig12-2.csv	Figure 12.2.�Percentage of students in grades 9-12 who reported having been in a physical fight during the previous 12 months, by location and grade: 2005
iscs060fig13-1.csv	Figure 13.1.�Percentage of students in grades 9-12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and sex:  Various years 1993-2005
iscs060fig13-2.csv	Figure 13.2.�Percentage of students in grades 9-12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and race/ethnicity: 2005
iscs060fig14-1.csv	Figure 14.1.�Percentage of students in grades 9-12 who reported using alcohol during the previous 30 days, by location and sex: Various years 1993-2005
iscs060fig14-2.csv	Figure 14.2.�Percentage of students in grades 9-12 who reported using alcohol during the previous 30 days, by location and grade: 2005
iscs060fig15-1.csv	Figure 15.1.�Percentage of students in grades 9-12 who reported using marijuana during the previous 30 days, by location and sex: Various years 1993-2005
iscs060fig15-2.csv	Figure 15.2.�Percentage of students in grades 9-12 who reported using marijuana during the previous 30 days, by location and grade: 2005
iscs060fig16-1.csv	Figure 16.1.�Percentage of students ages 12�18 who reported being afraid of attack or harm during the previous 6 months, by location and selected student and school characteristics: Varopis years, 1995�2005
iscs060fig16-2.csv	Figure 16.2.�Percentage of students ages 12-18 who reported being afraid of attack or harm during the previous 6 months, by location and race/ethnicity: 2005
iscs060fig17-1.csv	Figure 17.1.�Percentage of students ages 12�18 who reported avoiding school activities or one or more places in school during the previous 6 months because of fear of attack or harm: Various years, 1995�2005
iscs0efig17-2.csv	Figure 17.2.�Percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months because of fear of attack or harm, by selected student and school characteristics: 2005
iscs060fig18-1.csv	Figure 18.1.�Percentage distribution of serious disciplinary actions taken by public schools, (for specific offenses) by type of action:  2003-2004
iscs060fig18-2.csv	Figure 18.2.�Percentage of public schools that took a serious disciplinary action for selected offenses, by type of offense: 2003-04
iscs060fig19-1.csv	Figure 19.1.�Percentage of public schools that used selected safety and security measures, by school level: 2003-2004
iscs060fig20-1.csv	Figure 20.1.�Percentage of students ages 12�18 who reported selected security measures at school: 1999-2005
