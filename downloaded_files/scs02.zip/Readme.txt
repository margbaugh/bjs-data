State Court Sentencing of Convicted Felons, 2002 - Statistical Tables, NCJ 208910

This zip archive contains tables in individual .csv spreadsheets
from State Court Sentencing of Convicted Felons, 2002 - Statistical Tables, NCJ 208910.
The full report including text and graphics in pdf format are available from:
https://bjs.ojp.gov/library/publications/state-court-sentencing-convicted-felons-2002-statistical-tables 

These tables are part of a series. For a list of all in this series see:
https://bjs.ojp.gov/library/publications/list?series_filter=State%20Court%20Sentencing%20of%20Convicted%20Felons

scs0211.csv		Table 1.1 Estimated number of felony convictions in State courts, 2002
scs0212.csv		Table 1.2 Distribution of types of felony sentences imposed in State courts, by offense, 2002
scs0213.csv		Table 1.3 Average felony sentence lengths in State courts, by offense and type of sentence, 2002
scs0214.csv		Table 1.4 Estimated percent of felons sentenced to life in State prison, by offense, 2002
scs0215.csv		Table 1.5 Estimated time to be served in State prison, by offense, 2002
scs0216.csv		Table 1.6 Distribution of the number of felony convictions for persons sentenced in State courts, by most serious offense, 2002
scs0217.csv		Table 1.7 Convicted felons sentenced to prison in State courts, by number of convictions, 2002
scs0218.csv		Table 1.8 Mean sentence lengths for State felony sentences imposed, by the number and category of the conviction offense, 2002
scs0219.csv		Table 1.9 Felons sentenced to an additional penalty in State courts, by offense, 2002

scs0221.csv		Table 2.1 Demographic characteristics of persons convicted of felonies in State courts, by offense, 2002
scs0222.csv		Table 2.2 Offense distribution of felons convicted in State courts, by gender, race, and age of felons, 2002
scs0223.csv		Table 2.3 Average age of convicted felons in State courts, by offense, 2002
scs0224.csv		Table 2.4 Distribution of types of felony sentences imposed in State courts, by gender of felons and offense, 2002
scs0225.csv		Table 2.5 Distribution of types of felony sentences imposed in State courts, by race of felons and offense, 2002
scs0226.csv		Table 2.6 Mean length of felony State court sentences imposed, by offense and gender of felons, 2002
scs0227.csv		Table 2.7 Mean length of felony State court sentences imposed, by offense and race of felons, 2002
scs0228.csv		Table 2.8 Offense distribution of felons sentenced to incarceration or prison in State courts, by gender or race of felons, 2002
scs0229.csv		Table 2.9 Offense distribution of felons sentenced to jail or probation in State courts, by gender or race of felons, 2002
scs02210.csv	Table 2.10 Percent of convicted felons sentenced in State courts to incarceration or prison, by gender, race, and offense, 2002
scs02211.csv	Table 2.11 Percent of convicted felons sentenced in State courts to jail or probation, by gender, race, and offense, 2002
scs02212.csv	Table 2.12 Mean length of State felony sentences to incarceration or prison, by gender, race, and offense, 2002 
scs02213.csv	Table 2.13 Mean length of State felony sentences to jail or probation, by gender, race, and offense, 2002


scs0231.csv		Table 3.1 Among felons convicted in State courts in 2002, percent sentenced to probation, by offense; and offense distribution, by type of sentence
scs0232.csv 	Table 3.2 Distribution of types of State felony sentences to probation or incarceration, by offense, 2002
scs0233.csv		Table 3.3 Average probation sentence lengths of felons convicted in State courts, by offense, 2002
scs0234.csv		Table 3.4 Average incarceration sentence lengths for felons receiving sentences with or without probation, by offense, 2002
scs0235.csv		Table 3.5 Distribution of the number of felony convictions for persons sentenced to probation in State courts, by offense, 2002
scs0236.csv		Table 3.6 Offense distribution of convicted felons receiving sentences with or without probation in State courts, by gender of felons, 2002
scs0237.csv		Table 3.7 Offense of felons receiving probation or a sentence without probation in State courts, by gender of felons, 2002
scs0238.csv		Table 3.8 Offense of felons receiving probation or a sentence without probation in State courts, by race of felons, 2002
scs0239.csv		Table 3.9 Offense distribution of convicted felons receiving sentences with or without probation in State courts, by race of felons, 2002
scs02310.csv 	Table 3.10 Average age of felons receiving probation or a sentence without probation in State courts, by offense, 2002
scs02311.csv	Table 3.11 Felons sentenced to probation in State courts, by offense and age at sentencing, 2002

scs0241.csv		Table 4.1 Estimated number of felony convictions in State courts, by offense and type of conviction, 2002
scs0242.csv		Table 4.2 Distribution of types of felony convictions in State courts, by offense, 2002
scs0243.csv		Table 4.3 Offense distribution of felons convicted in State courts, by type of conviction, 2002
scs0244.csv		Table 4.4 Distribution of types of felony sentences imposed in State courts, by type of conviction and offense, 2002
scs0245.csv		Table 4.5 Average felony sentence lengths in State courts, by the type of conviction, type of sentence imposed, and offense, 2002
scs0246.csv		Table 4.6 Distribution of types of sentences imposed on felons convicted of murder or nonnegligent manslaughter, by type of conviction, 2002
scs0247.csv		Table 4.7 Distribution of the number of felony convictions for persons sentenced in State courts, by type of conviction, 2002
scs0248.csv		Table 4.8 Distribution of types of sentences imposed in State courts, by number of felony convictions and type of conviction, 2002
scs0249.csv		Table 4.9 Time between arrest and felony conviction in State courts, by offense and type of conviction, 2002
scs02410.csv	Table 4.10 Time between felony conviction and sentencing in State courts, by offense and type of conviction, 2002
scs02411.csv    	Table 4.11 Time between arrest and sentencing for persons convicted of a felony in State courts, by offense and type of conviction, 2002
scs02412.csv	Table 4.12 Average felony sentence lengths in State courts, by number of felony convictions, type of conviction, and type of sentence, 2002