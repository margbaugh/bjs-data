Immigration, Citizenship, and the Federal Justice System, 1998-2018  NCJ 253116		
		
This zip archive contains tables in individual .csv spreadsheets		
from Immigration, Citizenship, and the Federal Justice System, 1998-2018		
The full electronic report is available at: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6666		
		
Filename			Table name
icfjs9818t01.csv		Table 1. Number of federal arrests by offense type, FY 1998-2018
icfjs9818t02.csv		Table 2. Number of non-U.S. citizen arrests by immigration and other offense types, FY 1998-2018
icfjs9818t03.csv		Table 3. Number of federal arrests in the five federal judicial districts along the U.S.-Mexico border, by offense type, FY 1998-2018
icfjs9818t04.csv		Table 4. Number of federal arrests by country of citizenship, FY 1998-2018
icfjs9818t05.csv		Table 5. Number of federal arrests in the five U.S.-Mexico border districts by country of citizenship, FY 1998-2018 
icfjs9818t06.csv		Table 6. Federal arrests in U.S.-Mexico border districts and other federal judicial districts, FY 2018
icfjs9818t07a.csv		Table 7a. Federal arrests by citizenship and federal judicial districts, by offense type (row percentages), FY 2018
icfjs9818t07b.csv		Table 7b. Federal arrests by citizenship and federal judicial districts, by offense type (column percentages), FY 2018
icfjs9818t08a.csv		Table 8a. Federal arrests in U.S.-Mexico border districts and other federal judicial districts, by most serious offense (row percentages), FY 2018
icfjs9818t08b.csv		Table 8b. Federal arrests in U.S.-Mexico border districts and other federal judicial districts, by most serious offense (column percentages), FY 2018
icfjs9818t09.csv		Table 9. Federal immigration arrests by sex, age, citizenship, and country of citizenship, FY 1998, 2008, 2017, and 2018
icfjs9818t10.csv		Table 10. Federal immigration arrests by sex and age, FY 2017 and FY 2018
icfjs9818t11.csv		Table 11. Suspects arrested for federal criminal immigration offenses by Customs and Border Protection in the nine southwest border patrol sectors, FY 2013-2018
icfjs9818t12.csv		Table 12. Suspects in matters concluded by federal prosecutors, by offense type, FY 1998-2018
icfjs9818t13.csv		Table 13. Suspects prosecuted in U.S. district court by citizenship and offense type, FY 2018
icfjs9818t14.csv		Table 14. Suspects prosecuted in U.S. district court by offense type and citizenship, FY 2018
icfjs9818t15.csv		Table 15. Immigration suspects in matters concluded by federal prosecutors, by type of immigration offense and federal judicial districts, FY 2018
icfjs9818t16.csv		Table 16. Immigration suspects in matters concluded by federal prosecutors, by type of court, FY 1998-2018
icfjs9818t17.csv		Table 17. Immigration suspects in matters concluded by federal prosecutors, by type of immigration offense, FY 1998-2018
icfjs9818t18.csv		Table 18. Among all immigration suspects who were federally prosecuted, percent prosecuted in U.S. district court, by type of immigration offense, FY 1998-2018
		
icfjs9818f01.csv		Figure 1. Percent of all federal arrests, by citizenship status, FY 1998-2018
