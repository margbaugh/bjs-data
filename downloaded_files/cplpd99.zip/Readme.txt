COMMUNITY POLICING IN LOCAL POLICE DEPARTMENTS, 1997 and 1999
NCJ 184794																	
																	
This zip archive contains tables in individual .wk1 spreadsheets 
from the 1999 Law Enforcement and Administrative Statistics (LEMAS)
Special Report, "Community Policing in Local Police Departments,
1997 and 1999"
																	
Spreadsheets:																	
																	
cplp9901.wk1	Table 1. Local police departments and full-time
             personnel, by size of population served, 1999																
cplp9902.wk1	Table 2. Full-time community policing officers in 
             local police departments, by size of population
		served, 1997 and 1999
cplp9903.wk1	Table 3. Local police departments with at least
		half of full-time sworn personnel regularly engaged
		in community policing activities, 1997 and 1999
cplp9904.wk1	Table 4. Community policing training for new officer
		recruits in local police departments, by size of
		population served, 1997 and 1999
cplp9905.wk1	Table 5. Community policing training for in-service
		sworn personnel in local police departments, by size
		of population served, 1997 and 1999
cplp9906.wk1	Table 6. Local police departments with a community
		policing plan, by size of population served, 1997
		and 1999
cplp9907.wk1	Table 7. Local police departments using routine foot
		or bicycle patrol, by size of population served,
		1997 and 1999
cplp9908.wk1	Table 8. Geographic assignments for patrol officers
		and detectives in local police departments, by size
		of population served, 1997 and 1999
cplp9909.wk1	Table 9. Support for officer problem-solving projects
		in local police departments, by size of population 
		served, 1997 and 1999
cplp9910.wk1	Table 10. Community oriented activities of local
		police departments, by size of population served, 1999
cplp9911.wk1	Table 11. Surveying of citizens by local police 
		departments, by size of population served, 1997
		and 1999
cplp9912.wk1	Table 12. Local police departments providing citizen
		access to crime statistics or crime maps, by size of
		population served, 1997 and 1999
cplp9913.wk1	Table 13. Use of computers for crime mapping, by size
		of population served, 1997 and 1999
cplp9914.wk1	Table 14. Local police departments with an Internet
		home page, by size of population served, 1997 and 1999
cplp9915.wk1	Table 15. Local police departments using in-field
		computers, by size of population served, 1997 and 1999																
																	
														
