Felony Sentences in State Courts, 2004
 
This zip archive contains tables in individual .csv spreadsheets
from Felony Sentences in State Courts, 2004, NCJ 215646.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/fssc04.htm

		
Filename		Table number	
	
			Text tables
fssc04tt01.csv		Text table 1.  Most serious conviction offense for persons convicted of a felony in State courts, 1994 and 2004
fssc04tt02.csv		Text table 2.  Estimated number of felony convictions in State courts, 2004
fssc04tt03.csv		Text table 3.  Comparison of felony conviction offenses in State and Federal courts, 2004
fssc04tt04.csv		Text table 4.  Demographic characteristics of persons convicted of felonies in State courts, by offense, 2004
fssc04tt05.csv		Text table 5.  Distribution of types of felony sentences imposed in State courts, by offense, 2004
fssc04tt06.csv		Text table 6.  Average felony sentence lengths in State courts, by offense and type of sentence, 2004

			Figure tables
fssc04f01.csv		Figure 1.  Number of persons convicted of a felony in State courts, 1994 to 2004
fssc04f02.csv		Figure 2.  Percent of felony arrests leading to felony convictions, by offense, 1994 to 2004
fssc04f03.csv		Figure 3.  Mean State prison sentence and time served for violent felonies, 1994 to 2004
