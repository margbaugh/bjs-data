Pretrial Detention and Misconduct in Federal District Courts, 1995-2010		
		
This zip archive contains tables in individual  .csv spreadsheets		
from  Pretrial Detention and Misconduct in Federal District Courts, 1995-2010  NCJ 239673.  
The full report including text and graphics in pdf format is available 
at: http://www.bjs.gov//index.cfm?ty=pbdetail&iid=4595		
		
Filename		Table titles
		
pdmfdc9510t01.csv		Table 1. Defendants detained pretrial for cases disposed in federal district courts, by most serious offense charged, FY 1995�2010
pdmfdc9510t02.csv		Table 2. Decomposition of the 184% increase in number of defendants detained pretrial for cases disposed in federal district courts, by offense type, FY 1995�2010
pdmfdc9510t03.csv		Table 3. Criminal history of defendants detained pretrial for cases disposed in federal district courts, FY 1995, 2000, 2005, and 2010
pdmfdc9510t04.csv		Table 4. Percent of defendants released pretrial who committed pretrial misconduct for cases disposed in federal district courts, FY 1995-2010
		
		Figure titles
pdmfdc9510f01.csv		Figure 1. Number of defendants with cases disposed in federal district courts and percent detained pretrial, FY 1995�2010 
pdmfdc9510f02.csv		Figure 2. Detention period of defendants for cases disposed in federal district courts, FY 1995�2010
pdmfdc9510f03.csv		Figure 3. Number of defendants detained and released pretrial for cases disposed in federal district courts, FY 1995�2010 
pdmfdc9510f04.csv		Figure 4. Number of defendants detained pretrial for cases disposed in federal district courts, by offense type, FY 1995�2010 
pdmfdc9510f05.csv		Figure 5. Arrest history of defendants in cases disposed in federal district courts, FY 1995�2010
pdmfdc9510f06.csv		Figure 6. Conviction history of defendants in cases disposed in federal district courts, FY 1995�2010
pdmfdc9510f07.csv		Figure 7. Nature of prior felony convictions of defendants in cases disposed in federal district courts, FY 1995�2010
