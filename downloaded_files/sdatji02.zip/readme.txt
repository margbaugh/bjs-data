Substance Dependence, Abuse, and Treatment of Jail Inmates, 2002  NCJ  209588

This zip archive contains tables in individual .csv spreadsheets
from Substance Dependence, Abuse, and Treatment of Jail Inmates, 2002  NCJ  209588
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/sdatji02.htm




Filename          Table title
 
sdatji0201.csv      Table 1.  Prevalance of substance dependence or abuse among jail inmates, 2002
sdatji0202.csv      Table 2.  Substance dependence orabuse among jail inmates, by selected characteristics, 2002
sdatji0203.csv      Table 3.  Family background of jail inmates, by substance dependence or abuse, 2002
sdatji0204.csv      Table 4.  Criminal history of jail inmates, by substance dependence or abuse, 2002
sdatji0205.csv      Table 5.  Prior drug use of jail inmates, by type of drug, 2002 and 1996
sdatji0206.csv      Table 6.  Prior alcohol or drug use and dependence or abuse among convicted jail inmates, by selected characteristics, 2002
sdatji0207.csv      Table 7.  Prior alcohol or drug use at the time of the offense among convicted jail inmates, by type of offense, 2002
sdatji0208.csv      Table 8.  Substance dependence or abuse among convicted jail inmates, by type of substance and offense, 2002
sdatji0209.csv      Table 9.  Substance use treatment or programs among jail inmates who met the criteria for substance dependence or abuse, 2002
sdatji0210.csv      Table 10. Substance treatment or programs under correctional supervision among convicted jail inmates who used alcohol or drugs, 2002 and 1996
sdatji0211.csv      Table 11. Alcohol treatment or programs following admission of convicted inmates who used alcohol or met dependence or abuse criteria
sdatji0212.csv      Table 12. Drug treatment or programs after admission among convicted jail inmates who used drugs or met drug dependence or abuse criteria, 2002
sdatji0213.csv      Table 13. Substance treatment or programs ever or under correctional supervision among convicted jail inmates who met substance dependence or abuse criteria, by gender and race, 2002

sdatji02tt01.csv     Text table #t1:  Prevalence of dependence and abuse symptoms of jail inmates, by type of substance
sdatji02tt02.csv     Text table #t2:  Symptoms of dependence and abuse among jail inmates
sdatji02tt03.csv     Text table #t3:  Prevalence of substance dependence or abuse in the U.S. resident  population
sdatji02tt04.csv     Text table #t4:  Percent of jail inmates who used alcohol.
sdatji02tt05.csv     Text table #t5:  Percent of convicted inmates who committed offense to get money for drugs
sdatji02tt06.csv     Text table #t6:  Percent of jail inmates who had ever participated in substance abuse treatment or other programs
sdatji02tt07.csv     Text table #t7:  Percent of alcohol or drug-involved convicted jail inmates

sdatji02h1.csv      Higlight figure #1: Prevalence of substance dependence or abuse among jail inmates, 2002
sdatji02h2.csv      Highlight figure #2: Substance dependence/abuse among jail inmates, by offense, 2002. 
sdatji02h3.csv      Highlight figure #3: Substance dependence/abuse status of jail inmates by prior criminal record, 2002
sdatji02h1.csv      Higlight figure #4: Substance dependence or abuse status of jail inmates by participation in substance abuse treatment or other programs, 2002

sdatji02s01.csv      Standard error table 1. Standard errors for prevalence of substance dependence or abuse among jail inmates, 2002    
sdatji02s02.csv      Standard error table 2. Standard errors for substance dependence or abuse among jail inmates,  by selected characteristics, 2002
sdatji02s03.csv      Standard error table 3.Standard Errors for Family background of jail inmates, by substance dependence  or abuse, 2002
sdatji02s04.csv      Standard error table 4. Standard errors for criminal history of jail inmates, by substance dependence or abuse, 2002
sdatji02s05.csv      Standard error table 5. Standard errors on prior drug use of jail inmates, by type of drug, 2002 
sdatji02s06.csv      Standard error table 6. Standard errors for prior alcohol or drug use at offense and dependence or abuse among convicted jail inmates, by selected characteristics, 2002
sdatji02s07.csv      Standard error table 7. Standard errors for prior alcohol or drug use at time of offense among convicted jail inmates, by type of offense, 2002
sdatji02s08.csv      Standard error table 8. Standard errors for substance dependence or abuse among convicted jail inmates, by type of substance and offense, 2002
sdatji02s09.csv      Standard error table 9. Standard errors for substance use treatment or programs among jail inmates who met the criteria for substance dependence or abuse, 2002
sdatji02s10.csv      Standard error table 10. Standard errors for substance treatment or programs under correctional supervision among convicted jail inmates who used alcohol or drugs, 2002
sdatji02s11.csv      Standard error table 11. Standard errors for alcohol treatment or programs since admission of convicted inmates who used alcohol or met alcohol dependence or abuse criteria, 2002
sdatji02s12.csv      Standard error table 12.  Standard errors for drug treatment or programs since admission among convicted jail inmates who used drugs or met drug dependence or abuse criteria, 2002

sdatji02sh01.csv     Standard error highlights figure 1. Standards errors for prevalence of substance dependence or abuse among jail inmates, 2002
sdatji02sh02.csv     Standard error highlights figure 2. Standard errors for substance dependence/abuse mong jail inmates, by offense, 2002. 
sdatji02sh03.csv     Standard error highlights figure 3. Standard errors for substance dependence/abuse status of jail inmates by prior criminal record, 2002
sdatji02sh04.csv     Standard error highlights figure 4. Standard errors for substance dependence or abuse status of jail inmates by participation in substance abuse treatment or other programs, 2002
sdatji02stt01.csv    Standard error text table #t1:  Prevalence of dependence and abuse symptoms of jail inmates, by type of substance
sdatji02stt02.csv    Standard error text table #t7:  Percent of alcohol or drug-involved convicted jail inmates

 
 
 
 
 
 
 
