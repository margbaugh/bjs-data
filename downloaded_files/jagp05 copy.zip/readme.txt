Justice Assistance Grant (JAG) Program, 2005   NCJ 209333


---------------------------------------------------------------
This file is text only without graphics and many of the tables.
A Zip archive of the tables in this report in spreadsheet format
(.wk1) and the full report including tables and graphics in
.pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jagp05.htm

---------------------------------------------------------------



jagp0501.csv 	Table 1. State and local allocation amounts, FY 2005
jagp0502.csv	Table 2.  Territories and District of Columbia allocations, FY 2005
