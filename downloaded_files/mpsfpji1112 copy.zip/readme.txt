Medical Problems of State and Federal Prisoners and Jail Inmates, 2011-12 NCJ 248491		
		
This zip archive contains tables in individual .csv spreadsheets from Medical Problems of State and Federal Prisoners and Jail Inmates, 2011-12 NCJ 248491.	The full report, including text and graphics, in pdf format is available from: 		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5219		

This report is a special report.		
		
Tables		
mpsfpji1112t01.csv		Table 1. Prevalence of ever having a chronic condition or infectious disease among state and federal prisoners and the general population (standardized), 2011�12
mpsfpji1112t02.csv		Table 2. Prevalence of ever having a chronic condition or infectious disease among jail inmates and the general population (standardized), 2011�12
mpsfpji1112t03.csv		Table 3. Prevalence of ever having a chronic condition or infectious disease among state and federal prisoners and jail inmates, by demographic characteristics, 2011�12
mpsfpji1112t04.csv		Table 4. Prevalence of ever having multiple chronic conditions and infectious diseases among state and federal prisoners and jail inmates, 2011�12
mpsfpji1112t05.csv		Table 5. Body mass index of state and federal prisoners and local jail inmates, 2011�12
mpsfpji1112t06.csv		Table 6. Health care services and medical tests received by state and federal prisoners and jail inmates while incarcerated, 2011�12
mpsfpji1112t07.csv		Table 7. Prevalence of prescription medication use and other treatment among prisoners and jail inmates with a current chronic condition or infectious disease, 2011�12
mpsfpji1112t08.csv		Table 8. Satisfaction with health care services received by state and federal prisoners and jail inmates, 2011�12
		
Appendix tables		
mpsfpji1112at01.csv		Appendix table 1. State and federal prisoners with HIV or AIDS, by jurisdiction, yearend 2010, 2011, and 2011
mpsfpji1112at02.csv		Appendix table 2. Body mass index of prisoners, by demographic characteristics, 2011�12
mpsfpji1112at03.csv		Appendix table 3. Body mass index of jail inmates, by demographic characteristics, 2011�12
mpsfpji1112at04.csv		Appendix table 4. HIV testing practices and consent received for state and federal prisoners during the intake process, by jurisdiction, 2011
mpsfpji1112at05.csv		Appendix table 5. HIV testing practices for state and federal prisoners while in custody, by jurisdiction, 2011
mpsfpji1112at06.csv		Appendix table 6. HIV testing practices for state and federal prisoners during discharge planning, by jurisdiction, 2011
mpsfpji1112at07.csv		Appendix table 7. Prevalence of a current chronic condition among state and federal prisoners and jail inmates, 2011�12
mpsfpji1112at08.csv		Appendix table 8. Standard errors for table 3: Prevalence of ever having a chronic condition or infectious disease among state and federal prisoners and jail inmates, by demographic characteristics, 2011�12
mpsfpji1112at09.csv		Appendix table 9. Standard errors for figure 2: Rates of ever having a chronic condition among state and federal prisoners, 2004 and 2011�12
mpsfpji1112at10.csv		Appendix table 10. Standard errors for figure 3: Rate of ever having a chronic condition among jail inmates, 2002 and 2011�12
mpsfpji1112at11.csv		Appendix table 11. State and federal prisoners and jail inmates, by demographic characteristics, 2011�12
		
Figures		
mpsfpji1112f01.csv		Figure 1. Prevalence of ever having a chronic condition or infectious disease among state and federal prisoners and jail inmates, 2011�12
mpsfpji1112f02.csv		Figure 2. Rate of ever having a chronic condition among state and federal prisoners, 2004 and 2011�12
mpsfpji1112f03.csv		Figure 3. Rate of ever having a chronic condition among jail inmates, 2002 and 2011�12
mpsfpji1112f04.csv		Figure 4. Rate of HIV or AIDS cases among state and federal prisoners, 2001�2011
mpsfpji1112f05.csv		Figure 5. Prevalence of any chronic condition at admission and since admission among state and federal prisoners and jail inmates who reported ever having a condition, 2011�12
