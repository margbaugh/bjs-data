						readme.txt

Contents of zip archive scs9603.zip
Tables from Section 3 of State Court Sentencing of Convicted Felons, 1996, NCJ 175708

scs9631.wk1		Table 3.1 Estimated number of felony convictions in State courts, by whether
                   	sentenced to probation and by offense, 1996
scs9632.wk1 		Table 3.2 Felony convictions in State courts, by type of sentence to probation or
                   	incarceration and offense, 1996
scs9633.wk1		Table 3.3 Average probation sentence of felons convicted in State courts, by
                   	offense, 1996
scs9634.wk1		Table 3.4 Average State court sentence to incarceration for felons receiving
                   	sentences with or without probation, by offense, 1996
scs9635.wk1		Table 3.5 Percent of conviction offenses for felons sentenced to probation in State
                   	courts, by offense, 1996
scs9636.wk1		Table 3.6 Gender of felons sentenced to probation or to incarceration without
                    	probation in State courts, by offense, 1996
scs9637.wk1		Table	3.7 Offense of felons sentenced to probation or to incarceration without
                    	probation in State courts, by gender, 1996
scs9638.wk1		Table 3.8 Offense of felons sentenced to probation or to incarceration without
                    	probation in State courts, by race, 1996
scs9639.wk1		Table 3.9 Race of felons sentenced to probation or to incarceration without
                    	probation in State courts, by offense, 1996
scs96310.wk1 		Table 3.10 Average age of felons sentenced to probation or to incarceration without
                    	probation in State courts, by offense, 1996
scs96311.wk1		Table 3.11 Felons sentenced to probation in State courts, by offense and age at
                    	sentencing, 1996
