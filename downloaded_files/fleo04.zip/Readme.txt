
Federal Law Enforcement Officers, 2004  NCJ 212750

This zip archive contains tables in individual .csv spreadsheets 
from Federal Law Enforcement Officers, 2004, NCJ 212750. The full report 
including text and graphics in pdf format are available 
from: http://www.ojp.usdoj.gov/bjs/abstract/fleo2004

This report is one in a series. More recent editions may be available. 
To view a list of all in the series 
go to http://www.ojp.usdoj.gov/bjs/pubalp2.htm#fleo

fl04t01.csv	Table: 1		Federal agencies employing 500 or more full-time officers with authority to carry firearms and make arrests, September 2004
fl04t02.csv	Table: 2		Federal agencies employing at least 100 but fewer than 500 full-time personnel authorized to make arrests and carry firearms, September 2004
fl04t03.csv	Table: 3		Employment by offices of inspector general of full-time personnel authorized to make arrests and carry firearms, September 2004
fl04t04.csv	Table: 4		Gender and race or ethnicity of Federal officers with arrest and firearm authority, agencies employing 500 or more full-time officers, September 2004
fl04t05.csv	Table: 5		Female and minority representation among personnel with arrest and firearm authority in non-Inspector General agencies with at least 100 but fewer than 500 full-time officers, September 2004
fl04t06.csv	Table: 6		Female and minority representation among personnel with arrest and firearm authority in offices of inspector general with at least 100 but fewer than 500 full-time investigators, September 2004
fl04t07.csv	Table: 7		Number of full-time Federal officers with arrest and firearm authority and number per 100,000 residents, by State of employment, September 2004
fl04t08.csv	Table: 8		Major States of employment for Federal agencies employing 500 or more full-time officers with arrest and firearm authority, September 2004

fl04tt01.csv	Text Table: 1		Federal agencies employing fewer than 100 personnel with arrest and firearm authority
fl04tt02.csv	Text Table: 2		Types of assaults on Federal officers, 2004
fl04tt03.csv	Text Table: 3		Circumstance of assaults on Federal officers, 2004
fl04tt04.csv	Text Table: 4		Assaults on Federal officers with arrest and firearm authority, 2004

fl04at01.csv	Appendix Table: 1	Federal personnel with arrest and firearm authority in the U.S. Territories, by location, function and agency, September 2004

fl04f01.csv	Figure: 1		Primary function of full-time Federal officers with arrest and firearm authority, September 2004
fl04f02.csv	Figure: 2		Gender and race of full-time Federal officers with arrest and firearm authority, September 2004
fl04f03.csv	Figure: 3		Number of Immigration and Customs Officers in the United States, by selected functions, 1996-2004

fl04fhi01.csv	Highlights Figure: 1	Federal Law Enforcement Officers, 2004