Juveniles Charged in Adult Criminal Courts, 2014   NCJ 309096	
	
This zip archive contains tables in individual .csv spreadsheets for	
Juveniles Charged in Adult Criminal Courts, 2014   NCJ 309096	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/juveniles-charged-adult-criminal-courts-2014	
	
Filenames		Table names
jcacc14t01.csv	Table 1. Severity of arrest charges in 23 states, by age of offender and state upper age of juvenile court jurisdiction, 2014
jcacc14t02.csv	Table 2. Most serious offense at arrest in 23 states, by age of offender and state upper age of juvenile court jurisdiction, 2014
jcacc14t03.csv	Table 3. Most serious offense at arrest in 23 states, by demographic characteristics, 2014
jcacc14t04.csv	Table 4. Most serious offense at disposition in 23 states, by age of offender and state upper age of juvenile court jurisdiction, 2014
jcacc14t05.csv	Table 5. Most serious offense at disposition in 23 states, by demographic characteristics, 2014
jcacc14t06.csv	Table 6. Outcome for persons ages 12 to 17 charged in adult criminal courts in 23 states, by severity of charge and most serious charge at disposition, 2014
jcacc14t07.csv	Table 7. Outcome for persons ages 12 to 17 charged in adult criminal courts in 23 states, by severity of charge and age of defendant, 2014
jcacc14t08.csv	Table 8. Most serious offense at conviction in 23 states, by demographic characteristics, 2014
jcacc14t09.csv	Table 9. Method of conviction for persons ages 12 to 17 in 23 states, by age of offender, 2014
jcacc14t10.csv	Table 10. Percent of persons ages 12 to 17 sentenced in adult criminal courts in 23 states, by most serious offense at disposition, 2014
jcacc14t11.csv	Table 11. Percent of persons ages 12 to 17 sentenced in adult criminal courts in 23 states, by demographic characteristics, 2014

			Figures
jcacc14f01.csv	Figure 1. U.S. residents ages 12 to 17 arrested and charged in adult criminal courts in 23 states, 2014 
jcacc14f02.csv	Figure 2. Percent of cases for persons ages 12 to 17 in 23 states where most serious offense at disposition was the same type as the offense at arrest, 2014
	
			Maps
jcacc14m01.csv	Map 1. Upper age of juvenile court jurisdiction, by U.S. state, 2014
	
			Appendix tables
jcacc14at01.csv	Appendix table 1. Counts for figure 1: U.S. residents ages 12 to 17 arrested and charged in adult criminal courts in 23 states, 2014 
jcacc14at02.csv	Appendix table 2. Counts for map 1: Upper age of juvenile court jurisdiction, by U.S. state, 2014
jcacc14at03.csv	Appendix table 3. Counts for figure 2: Percent of cases for persons ages 12 to 17 in 23 states where most serious offense at disposition was the same type as the offense at arrest, 2014
