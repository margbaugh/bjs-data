Probation and Parole in the United States, 2013
-------------------------------------------------------

This zip archive contains tables in individual .csv spreadsheets
Probation and Parole in the United States, 2013  NCJ 248029
The full report including text and graphics in .pdf format are available from:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5135

This report is one in a series. More recent editions 
may be available. To view a list of all in the series 
go to http://www.bjs.gov/index.cfm?ty=pbse&sid=42
-------------------------------------------------------

ppus13at01.csv	Appendix table 1. Adults under community supervision, 2013
ppus13at02.csv	Appendix table 2. Adults on probation, 2013
ppus13at03.csv	Appendix table 3. Characteristics of adults on probation, 2000, 2012, and 2013 
ppus13at04.csv	Appendix table 4. Adults on parole, 2013
ppus13at05.csv	Appendix table 5. Adults entering parole, by type of entry, 2013
ppus13at06.csv	Appendix table 6. Characteristics of adults on parole, 2000, 2012, and 2013
ppus13at07.csv	Appendix table 7. Adults exiting parole, by type of exit, 2013
ppus13at08.csv	Appendix table 8. Percent of parole exits, by type of exit, 2008-2013
ppus13f01.csv	Figure 1. Adults under community supervision at yearend, 2000-2013
ppus13f02.csv	Figure 2. Adults on probation at yearend, 2000-2013
ppus13f03.csv	Figure 3. Adults on parole at yearend, 2000-2013
ppus13f04.csv	Figure 4. Estimated probation entries and exits, 2000-2013
ppus13f05.csv	Figure 5. Estimated percent of the at-risk probation population incarcerated, 2000-2013
ppus13f06.csv	Figure 6. California adult parole population, 2010 and 2013
ppus13f07.csv	Figure 7. California parole entries, 2010 and 2013
ppus13f08.csv	Figure 8. California parole exits, 2010 and 2013
ppus13f09.csv	Figure 9. Estimated parole entries and exits, 2000-2013
ppus13f10.csv	Figure 10. Estimated percent of the at-risk parole population returned to incarceration, 2000-2013
ppus13t01.csv	Table 1. U.S. adult residents on community supervision, probation, and parole, 2000-2013
ppus13t02.csv	Table 2. U.S. adult residents on community supervision, probation, and parole, 2000, 2005-2013
ppus13t03.csv	Table 3. Rate of probation exits, by type of exit, 2008-2013
ppus13t04.csv	Table 4. Probationers who exited supervision, by type of exit, 2008-2013
ppus13t05.csv	Table 5. California adult probation population, 2010 and 2013
ppus13t06.csv	Table 6. Rate of parole exits, by type of exit, 2008-2013
ppus13t07.csv	Table 7. Parolees on probation excluded from the January 1 and December 31 community supervision populations, 2008-2013
ppus13t08.csv	Table 8. Change in the number of adults on probation based on reporting changes, 2000-2012
ppus13t09.csv	Table 9. Change in the number of adults on parole based on reporting changes, 2000-2012
