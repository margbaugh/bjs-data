Justice Expenditure And Employment Extracts, 2011 - Final     NCJ 250631			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Justice Expenditure and Employment Extracts, 2011 - Final  NCJ 250631.  The full report including text		
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=6204		
			
This report is one in a series.  More recent editions may be available. To view a list of all in the series go to: http://www.bjs.gov/index.cfm?ty=pbse&sid=33			

Filename			Table name		
jeee11t01.csv			Table 1. Percent distribution of expenditure for the justice system by type of government, fiscal 2011
jeee11t02.csv			Table 2. Percent distribution of employment and payrolls for the justice system by level of government, March 2011
jeee11t03.csv			Table 3. Percent distribution of expenditure for the justice system by type of government, fiscal 2011
jeee11t04.csv			Table 4. Justice system expenditure by character, state and type of government, fiscal 2011
jeee11t05.csv			Table 5. Justice system employment and percent distribution of full-time equivalent employment, by state and type of government, March 2011
jeee11t06.csv			Table 6. Percent distribution of justice system payrolls by state and type of government, March 2011
jeee11t07.csv			Table 7. Police protection sworn and nonsworn employment and payrolls and percent distribution of full-time equivalent employment by state and type of government, March 2011
jeee11t08.csv			Table 8. Per capita justice expenditure (fiscal 2011) and full-time equivalent justice employment per 10,000 population (July 2011) of state and local governments by activity and State
jeee11t09.csv			Table 9. Justice system expenditure of state governments by activity and character and object, fiscal 2011
jeee11t10.csv			Table 10. Detail of direct expenditure for correctional activities of state governments by character and object, fiscal 2011
jeee11t11.csv			Table 11. Justice system employment and payrolls of state governments by activity, March 2011
jeee11t12.csv			Table 12. Justice system expenditures of 68 large county governments by activity and character and object, fiscal 2011
jeee11t13.csv			Table 13. Justice system expenditures of 68 large county governments by sectors, fiscal 2011
jeee11t14.csv			Table 14. Police protection sworn and nonsworn employment and payrolls and percent distribution of full-time equivalent employment of 68 large county governments, March 2011
jeee11t15.csv			Table 15. Justice system expenditures of 49 large city governments by activity and character and object, fiscal 2011
jeee11t16.csv			Table 16. Justice system employment and payrolls of 49 large city governments by activity, March 2011
jeee11t17.csv			Table 17. Police protection sworn and nonsworn employment and payrolls and percent distribution of full-time equivalent employment of 49 large city governments, March 2011
jeee11t18.csv			Table 18. Supplemental data for state governments
jeee11t19.csv			Table 19. Supplemental data for 68 large county governments
jeee11t20.csv			Table 20. Supplemental data for 49 large city governments
