"Justice Expenditures and Employment, FY 1982-2007-Statistical Tables"		
		
This zip archive contains tables in individual  .csv spreadsheets               		
"from Justice Expenditures and Employment, FY 1982-2007-Statistical Tables, NCJ 236218"		
The full report including text and graphics in pdf format is available at:              		
		
		
Tables		
jeeus8207t01.csv		"""Table 1. Total justice expenditures, by level of government, FY 1982-2007 (real dollars)"""
jeeus8207t02.csv		"""Table 2. Total justice expenditures, by justice function, FY 1982-2007 (real dollars)"""
jeeus8207t03.csv		"""Table 3. Distribution of judicial and legal services expenditures, by level of government, FY 1982-2007 (real dollars)"""
jeeus8207t04.csv		"""Table 4. Distribution of police protection expenditures, by level of government, FY 1982-2007 (real dollars)"""
jeeus8207t05.csv		"""Table 5. Distribution of corrections expenditures, by level of government, FY 1982-2007 (real dollars)"""
jeeus8207t06.csv		"""Table 6. Per capita justice expenditures, by function, FY 1982-2007 (real dollars)"""
jeeus8207t07.csv		"""Table 7. Total justice employment, by level of government, FY 1982-2007"""
jeeus8207t08.csv		"""Table 8. Total justice employment, by justice function, FY 1982-2007"""
jeeus8207t09.csv		"""Table 9. Employment distribution for judicial and legal services, by level of government, FY 1982-2007"""
jeeus8207t10.csv		"""Table 10. Employment distribution for corrections, by level of government, FY 1982-2007"""
jeeus8207t11.csv		"""Table 11. Employment distribution for police protection, by level of government, FY 1982-2007"""
jeeus8207t12.csv		"""Table 12. Rate of justice employment, by function, FY 1982-2007"""
		
Appendix tables		
jeeus8207at01.csv		"""Appendix Table 1. Total justice expenditures, nominal and real dollars, FY 1982-2007"""
		
Figures		
jeeus8207f01.csv		"""Figure 1. Justice expenditures, by function, FY 2007"""
jeeus8207f02.csv		"""Figure 2. Justice employees, by function, FY 1982-2007"""
