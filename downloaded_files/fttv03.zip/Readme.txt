Federal Tort Trials and Verdicts, 2002-03  NCJ  208713

This zip archive contains tables in individual .csv spreadsheets from Federal
Tort Trials and Verdicts, 2002-03,  NCJ 208713. The full report including text and graphics in
pdf format are available from:   http://www.ojp.usdoj.gov/bjs/abstract/fttv03.htm            

This report is one in a series.  More recent editions 
may be available.  To view a list of all in the series go to               
http://www.ojjp.usdoj.gov/bjs/pubalp2.htm#Torts              


          Table     
fttv0301.csv        Table  1    Type of jurisdiction for tort trials terminated in U.S. district courts, 2002-03
fttv0302.csv        Table  2    The origin of tort trials terminated in U.S. district courts, 2002-03
fttv0303.csv        Table  3    The nature of suit in tort trials terminated in U.S. district courts, 2002-03
fttv0304.csv        Table  4    Comparing bench and jury tort trials terminated in U.S. district courts, by jurisdiction, 2002-03
fttv0305.csv        Table  5    Comparing bench and jury tort trials terminated in U.S. district courts, by nature of suit, 2002-03
fttv0306.csv        Table  6    Plaintiff winners in tort cases, terminated by trial in U.S. district courts by nature of suit, 2002-03
fttv0307.csv        Table  7    Award amounts for plaintiff winners, by nature of suit, for tort cases terminated by trial in U.S. district courts, 2002-03
fttv0308.csv        Table  8    Plaintiff winners, damage award amounts, and case processing times for bench and jury tort trials terminated in U.S. district courts, 2002-03
fttv0309.csv        Table  9    Plaintiffs and defendants in diversity of citizenship tort trials terminated in U.S. district courts, 2002-03
fttv0310.csv        Table 10    Plaintiff winners and award amounts in tort trials involving diversity of citizenship terminated in U.S. district courts, 2002-03
fttv0311.csv        Table 11    Plaintiff winners and award amounts in tort trials involving  the U.S. Government as defendant in U.S. district courts, 2002-03
fttv0312.csv        Table 12    Plaintiff winners and damage awards in nonasbestos product liability trials terminated in U.S. district courts, 1990-2003
fttv0313.csv        Table 13    Plaintiff winners and number of cases with damage awards  in asbestos product liability trials terminated in U.S. district courts, 1990-2003


fttv03bt.csv        Box Table   Medical malpractice trials in U.S. district courts, 1990-03

          Figures        
fttv03fh.csv        Figure highlight table -  Number of tort cases terminated in U.S. district courts, 1970-2003
fttv03f01.csv       Figure 1  Number of tort trials in Federal district courts 
fttv03f02.csv       Figure 2  Percent of tort trials terminated  
fttv03f03.csv       Figure 3  Percent of Federal tort trials in U.S. district courts terminated     
