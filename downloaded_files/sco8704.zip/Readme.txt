State Court Organization 1987-2004		

This zip archive contains tables in individual .csv spreadsheets		
from State Court Organization 1987-2004, NCJ 217996.		
The full report including text and graphics in .pdf format are available at		
http://www.ojp.usdoj.gov/bjs/abstract/sco8704.htm		

Filename		Table number
sco8704t01.csv		Table 1. State court case filings by jurisdictional level of court, 1987-2004
sco8704t02.csv		Table 2. State court judges and clerks by jursidictional level of court, 1987-2004
sco8704t03.csv		Table 3. Percent of state appellate courts using expedited procedures, 1993-2004.
sco8704t04.csv		Table 4. Trial court types and judges by jurisdictional level, 1987-2004.
sco8704t05.csv		Table 5. Trial court budgets funded entirely by state government, 1987 and 2004
sco8704t06.csv		Table 6. State judicial education requirements for trial and appellate courts, 1993-2004
sco8704t07.csv		Table 7: Methods of state judicial selection to fill initial term positions, 1987-2004.
sco8704t08.csv		Table 8: Methods of retention for state court judges, 1987-2004.
sco8704t09.csv		Table 9: General jurisdiction trial court felony and civil jury trial regulations, 1987-2004

		Text Table
sco8704tt01.csv		Text Table 1: Use of specialized jurisdiction courts expanded
sco8704tt02.csv		Text Table 2: Few states adopted unified court systems
sco8704tt03.csv		Text Table 3: More states required judges to have law degrees.
sco8704tt04.csv		Text Table 4: Use of active sentencing commissions fluctuated
sco8704tt05.csv		Text Table 5: Increased use of judicial nominating committees to select judges

		Box Text Tables
sco8704btt01.csv	Box Text Table 01. Intermediate Appellate Courts established to alleviate caseload burdens on Courts of Last Resort.
sco8704btt02.csv	Box Text Table 02. California adopts a statewide system

		Figure
sco8704f01.csv		Figure 1. Percent change in total number of judges, 1987-2004.
