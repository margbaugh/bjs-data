"Criminal Victimization, 2014      NCJ 248973"			
			
This zip archive contains tables in individual  .csv spreadsheets			
"from Criminal Victimization, 2013, NCJ 247648.  The full report including text"			
and graphics in pdf format is available from: https://ojprdcweb58.ojp.usdoj.gov:8500/index.cfm?ty=pbdetail&iid=5442			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=6			
			
			
Filename			Table title
cv14t01.csv			"Table 1. Violent victimization, by type of violent crime, 2005, 2013, and 2014"
cv14t02.csv			"Table 2. Firearm victimizations, 2005�2014"
cv14t03.csv			"Table 3. Property victimization, by type of property crime, 2005, 2013, and 2014"
cv14t04.csv			"Table 4. Number of victims and prevalence rate, by type of crime, 2005, 2013, and 2014"
cv14t05.csv			"Table 5. Prevalence of violent crime, by victim demographic characteristics, 2005, 2013, and 2014"
cv14t06.csv			"Table 6. Percent of victimizations reported to police, by type of crime, 2005, 2013, and 2014"
cv14t07.csv			"Table 7. Rates of victimizations reported and not reported to police, by type of crime, 2005, 2013, and 2014"
cv14t08.csv			"Table 8. Violent crime victims who received assistance from a victim service agency, by type of crime, 2005, 2013, and 2014"
cv14t09.csv			"Table 9. Rate of violent victimization, by victim demographic characteristics, 2005, 2013, and 2014"
cv14t10.csv			"Table 10.Violent and property victimization, by household location, 2005, 2013, and 2014"
cv14t11.csv			"Table 11.Percent change in the number of crimes reported in the UCR and the NCVS, 2013�2014"
cv14at12.csv			"Table 12.Distribution of types of rape and sexual assault victimizations, 2005-2014"


Appendix tables			
cv14at01.csv			"Appendix table 1. Estimates and standard errors for figure 1: Violent and property victimization, 1993�2014"
cv14at02.csv			"Appendix table 2. Standard errors for table 1: Violent victimization, by type of violent crime, 2005, 2013, and 2014"
cv14at03.csv			"Appendix table 3. Standard errors for table 2: Firearm victimizations, 2005�2014"
cv14at04.csv			"Appendix table 4  Standard errors for table 3: Property victimization, by type of property crime, 2005, 2013, and 2014"
cv14at05.csv			"Appendix table 5. Standard errors for table 4: Number of victims and prevalence rate, by type of violent crime, 2005, 2013, and 2014"
cv14at06.csv			"Appendix table 6. Standard errors for table 5: Prevalence of violent crime, by victim demographic characteristics, 2005, 2013, and 2014"
cv14at07.csv			"Appendix table 7. Standard errors for table 6: Percent of victimizations reported to police, by type of crime, 2005, 2013, and 2014"
cv14at08.csv			"Appendix table 8. Standard errors for table 7: Rates of victimizations reported and not reported to police, by type of crime, 2005, 2013, and 2014"
cv14at09.csv			"Appendix table 9. Standard errors for table 8: Violent crime victims who received assistance from a victim service agency, by type of crime, 2005, 2013, and 2014"
cv14at10.csv			"Appendix table 10.Standard errors for table 9: Rate of violent victimization, by victim demographic characteristics, 2005, 2013, and 2014"
cv14at11.csv			"Appendix table 11.Standard errors for table 10: Rate of violent and property victimization, by household location, 2005, 2013, and 2014"
cv14at12.csv		        "Appendix table 12.Standard errors for table 12: Distribution of types of rape and sexual assault victimizations, 2005-2014

