Mortality in Local Jails, 2000-2014 -Statistical Tables	  NCJ 250169
		
This zip archive contains tables in individual  .csv spreadsheets		
from Mortality in Local Jails, 2000-2014 -Statistical Tables	  NCJ 250169  The full report including text		
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5865

This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to	https://www.bjs.gov/index.cfm?ty=pbse&sid=76
		
		
Filename			Table title	
mlj0014stt20.csv		Table 20. Number of local jail jurisdictions reporting one or more deaths to the Deaths in Custody Program, by state, 2000 and 2005�2014											
mlj0014st01.csv			Table 1. Number of local jail inmate deaths, by cause of death, 2000�2014			
mlj0014st02.csv			Table 2. Number of local jail inmate deaths, by cause of death, 2000 and 2005�2014
mlj0014st03.csv		 	Table 3. Percent of local jail inmate deaths, by cause of death, 2000 and 2005�2014
mlj0014st04.csv	 		Table 4. Mortality rate per 100,000 local jail inmates, by cause of death, 2000 and 2005�2014
mlj0014st05.csv			Table 5. Number of local jail inmate deaths, by selected decedent characteristics, 2000 and 2005�2014
mlj0014st06.csv			Table 6. Percent of local jail inmate deaths, by selected decedent characteristics, 2000 and 2005�2014											
mlj0014st07.csv			Table 7. Mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000 and 2005�2014																	
mlj0014st08.csv			Table 8. Number of local jail inmate deaths, by cause of death and selected decedent characteristics, 2000�2014
mlj0014st09.csv			Table 9. Average annual mortality rate per 100,000 local jail inmates, by cause of death and selected decedent characteristics, 2000�2014
mlj0014stt10.csv		Table 10. Cause of death for local jail inmates, by time served before death, 2000�2014
mlj0014stt11.csv 		Table 11. Offenses of deceased local jail inmates, by time served before death, 2000�2014
mlj0014stt12.csv 		Table 12.Offenses of deceased local jail inmates, by conviction status and time served before death, 2000�2014
mlj0014stt13.csv		Table 13. Death location of local jail inmates, by cause of death, 2000�2014
mlj0014stt14.csv		Table 14. Number, percent, average daily population, and mortality rate per 100,000 local jail inmate deaths, by hold status, 2014
mlj0014stt15.csv		Table 15. Number and percent of local jail jurisdictions reporting to the Deaths in Custody Program, by number of deaths reported each year, 2000�2014
mlj0014stt16.csv		Table 16. Number of local jail inmates held on an average day, by state, 2000 and 2005�2014
mlj0014stt17.csv		Table 17. Number of local jail deaths, by state, 2000 and 2005�2014
mlj0014stt18.csv		Table 18. Mortality rate per 100,000 local jail inmates, by state, 2000 and 2005�2014
mlj0014stt19.csv		Table 19. Number of local jail jurisdictions reporting to the Deaths in Custody Reporting Program, by state, 2000 and 2005�2014
mlj0014stt20.csv		Table 20. Number of local jail jurisdictions reporting one or more deaths to the Deaths in Custody Program, by state, 2000 and 2005�2014
mlj0014stt21.csv		Table 21. Prelimary number and percent of jail inmate deaths, by select causes, 2015

Figure		
mlj0014stf01.csv		Figure 01. Mortality rate per 100,000 local jail inmates, by selected causes of death, 2005�2014
		
Appendix tables		
mlj0014stat01.csv		Appendix Table 1. Estimated number of local jail inmates in custody on an average day, by selected inmate characteristics, 2000 and 2005�2014
mlj0014stat02.csv		Appendix Table 2. Illness mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2005�2014
mlj0014stat03.csv		Appendix Table 03.Heart disease mortality rate per 100,000 local jail inmates, by selected characteristics, 2005�2014
mlj0014stat04.csv		Appendix Table 04. Suicide mortality rate per 100,000 local jail inmates, by selected characteristics, 2005�2014
mlj0014stat05.csv		Appendix Table 05. Mortality rate for all other unnatural deaths per 100,000 local jail inmates, by selected characteristics, 2005�2014
