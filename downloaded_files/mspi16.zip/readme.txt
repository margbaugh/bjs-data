Methodology: Survey of Prison Inmates, 2016  NCJ 252210	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Methodology: Survey of Prison Inmates, 2016  NCJ 252210 	
The full report including text and graphics in pdf format is available from:	
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6606	
	
Filename	Table name
mspi16t01.csv	Table 1. Number of facilities and prisoners in the universe and sample for the Survey of Prison Inmates, by stratum, 2016
mspi16t02.csv	Table 2. Number of facilities and prisoners sampled in the Survey of Prison Inmates, by outcome and jurisdiction, 2016
mspi16t03.csv	Table 3. Number of prisoners not interviewed in the Survey of Prison Inmates, by type of non-interview and jurisdiction, 2016
mspi16t04.csv	Table 4. Consent rates among prisoners who participated in the Survey of Prison Inmates, by type and jurisdiction, 2016
