Data on Maternal Health and Pregnancy Outcomes from Prisons and Jails: Results from a Feasibility Study   NCJ 307326														
														
This zip archive contains tables in individual  .csv spreadsheets														
from Data on Maternal Health and Pregnancy Outcomes from Prisons and Jails: Results from a Feasibility Study   NCJ 307326.  														
The full report including text and graphics in pdf format is available from: 														
https://bjs.ojp.gov/library/publications/data-maternal-health-and-pregnancy-outcomes-prisons-and-jails-results														
														
Filenames	Table titles													
dmhpopjt01.csv	Table 1. Data elements housed in CMS, by site type													
dmhpopjt02.csv	Table 2. Challenges to reporting aggregate-level maternal health data, by site type													
dmhpopjt03.csv	Table 3. Challenges to reporting individual-level maternal health data, by site type													
dmhpopjt04.csv	Table 4. Burden to extract aggregate-level maternal health data, by site type													
														
		Appendix tables													
dmhpopjat01.csv	Appendix Table 1. Data elements included in the semi-structured interview													
														
														
														
														
