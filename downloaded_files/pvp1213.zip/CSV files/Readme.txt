"Police Vehicle Pursuits, 2012-2013, NCJ 250545"															
															
This zip archive contains tables in individual  .csv spreadsheets															
"from Police Vehicle Pursuits, 2012-2013, NCJ 250545.  The full report including text"															
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=5906 														
															
This report is one in a series.  More recent editions may be available. 															
To view a list of all in the series go to															
https://www.bjs.gov/index.cfm?ty=pbse&sid=34 													
															
pvp1212t01.csv	"Table 1. General purpose state and local law enforcement agencies that conducted vehicle pursuits, 2012"														
pvp1212t02.csv	"Table 2. Number of vehicle pursuits conducted by general purpose state and local law enforcement agencies, 2012. "														
pvp1212t03.csv	"Table 3. Vehicle pursuit rates for general purpose state and local law enforcement agencies, 2012"														
pvp1212t04.csv	"Table 4. Written vehicle pursuit policies of general purpose state and local law enforcement agencies, 2013"														
pvp1212t05.csv	"Table 5. Sworn personnel employed by general purpose state and local law enforcement agencies, by type of written vehicle pursuit policy, 2013 "														
pvp1212t06.csv	"Table 6. Pursuits conducted by general purpose state and local law enforcement agencies, by type of written pursuit policy, 2012 "														
															
pvp1212f01	"Figure 1. Vehicle pursuits conducted by general purpose state and local law enforcement agencies, 2012"														
pvp1212f02	"Figure 2. Vehicle pursuits conducted per 100 officers employed in local law enforcement agencies, by size of population served, 2012"														
pvp1212f03	"Figure 3. Distribution of sworn officers in general purpose state and local law enforcement agencies, by type of written pursuit policy, 1997 and 2013"														
pvp1212f04	"Figure 4. Vehicle pursuits conducted by general purpose state and local law enforcement agencies per 100 sworn personnel employed, by type of pursuit policy, 2012"														
pvp12125f05	"Figure 5. Fatal vehicle crashes and fatalities related to police pursuits, 1996?2015"														
pvp1212f06	"Figure 6. Primary reasons for stop preceding police vehicle pursuits among 115 agencies, 2009?2013"														
pvp1212f07	"Figure 7. Primary reasons for termination of police vehicle pursuits among 115 agencies, 2009?2013"														
															
pvp1212at01.csv	"Appendix Table 1. General purpose state and local law enforcement agencies maintaining formal records of vehicle pursuit incidents, 2013 "														
pvp1212at02.csv	"Appendix Table 2. Standard errors for appendix table 1: General purpose state and local law enforcement agencies maintaining formal records of vehicle pursuit incidents, 2013 "														
pvp1212at03.csv	"Appendix Table 3. General purpose state and local law enforcement agencies with a written foot pursuit policy, 2013 "														
pvp1212at04.csv	"Appendix Table 4. Standard errors for appendix table 3: General purpose state and local law enforcement agencies with a written foot pursuit policy, 2013 "														
pvp1212at05.csv	"Appendix table 5. Restrictions included in the written foot pursuit policies of general purpose state and local law enforcement agencies, 2013"														
prdv0615at06.csv	"Appendix table 6. Standard errors for appendix table 5: Restrictions included in the written foot pursuit policies of general purpose  state and local law enforcement agencies, 2013"														
pvp1212at07.csv	"Appendix Table 7. Written foot pursuit policies that encouraged the use  of containment tactics, 2013"														
pvp1212at08.csv	"Appendix Table 8. Standard errors for appendix table 7: Written foot pursuit policies that encouraged the use of containment tactics, 2013"														
pvp1212at09.csv	"Appendix table 9. Pursuit-related fatalities, by state, 1996-2015"														
pvp1212at10.csv	"Appendix table 10. Base weights, nonresponse adjustment factors, and final analytical weights for local police departments, Law Enforcement Management and Administrative Statistics Survey, 2013"														
pvp1212at11.csv	"Appendix table 11. Base weights, nonresponse adjustment factors, and final analytical weights for sheriffs' offices, 2013"														
pvp1212at12.csv	"Appendix table 12. Estimates and standard errors for figure 1: Vehicle pursuits conducted by general purpose state and local law enforcement agencies, 2012"														
pvp1212at13.csv	"Appendix table 13. Standard errors for table 1: General purpose state and local law enforcement agencies that conducted vehicle pursuits, 2012"														
pvp1212at14.csv	"Appendix Table 14. Standard errors for table 2: Vehicle pursuits conducted by general purpose state and local law enforcement agencies, 2012"														
pvp1212at15.csv	"Appendix Table 15. Standard errors for table 3: Vehicle pursuit rates for general purpose state and local law enforcement agencies, 2012"														
pvp1212at16.csv	"Appendix table 16. Estimates and standard errors for figure 2: Vehicle pursuits conducted per 100 officers employed in local law enforcement agencies, by size of population served, 2012 "														
pvp12125at17.csv	"Appendix Table 17. Standard errors for table 4: Written vehicle pursuit policies of general purpose state and local law enforcement agencies, 2013"														
pvp1212at18.csv	"Appendix table 18. Standard errors for table 5: Sworn personnel employed by general purpose state and local law enforcement agencies, by type of written vehicle pursuit policy, 2013"														
pvp1212at19.csv	"Appendix table 19. Percentages and standard errors for figure 3: Distribution of sworn personnel in general purpose state and local law enforcement agencies, by type of written pursuit policy, 1997 and 2013"														
pvp1212at20.csv	"Appendix table 20. Standard errors for table 6: Pursuits conducted by general purpose state and local law enforcement agencies, by type of written pursuit policy, 2012"														
pvp1212at21.csv	"Appendix table 21. Estimates and standard errors for figure 4: Vehicle pursuits conducted by general purpose state and local law enforcement agencies per 100 sworn personnel employed, by type of pursuit policy, 2012"														
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
															
