Tribal Law Enforcement in the United States, 2018   NCJ 306022	
	
This .zip archive contains tables in individual  .csv spreadsheets	
Tribal Law Enforcement in the United States, 2018   NCJ 306022. The full report including text	
and graphics in .pdf format is available from: https://bjs.ojp.gov/library/publications/tribal-law-enforcement-united-states-2018
	
Filenames	Table titles
tleus18t01.csv	Table 1. Number of tribally operated law enforcement agencies and full-time sworn officers, by size of agency, 2008 and 2018
tleus18t02.csv	Table 2. Percent of tribally operated law enforcement agencies, by size of agency and source of funding, 2018
tleus18t03.csv	Table 3. Percent of tribally operated law enforcement agencies, by size of agency and arrest or citation authority, 2018
tleus18t04.csv	Table 4. Percent of tribally operated law enforcement agencies, by size of agency and agency functions, 2018
tleus18t05.csv	Table 5. Percent of tribally operated law enforcement agencies, by size of agency and officer duties, 2018
tleus18t06.csv	Table 6. Percent of tribally operated law enforcement agencies, by size of agency and characteristics of cross-deputization agreement, 2018
tleus18t07.csv	Table 7. Percent of full-time sworn officers in tribally operated law enforcement agencies, by size of agency and officer race or ethnicity, 2018
tleus18t08.csv	Table 8. Percent of tribally operated law enforcement agencies, by size of agency and officer skills training provided, 2018
tleus18t09.csv	Table 9. Percent of tribally operated law enforcement agencies, by size of agency and officer equipment provided, 2018
tleus18t10.csv	Table 10. Number of calls for service received and arrests made by tribally operated law enforcement agencies, by size of agency, 2018
tleus18t11.csv	Table 11. Percent of tribally operated law enforcement agencies, by technological resources, 2018
tleus18t12.csv	Table 12. Percent of tribally operated law enforcement agencies, by size of agency and criminal justice data sharing, 2018
tleus18t13.csv	Table 13. Percent of Bureau of Indian Affairs law enforcement agencies, by person-level and subject matter jurisdiction, 2018
tleus18t14.csv	Table 14. Full-time employees and operating budgets in Bureau of Indian Affairs law enforcement agencies, 2018
tleus18t15.csv	Table 15. Number of calls for service received and arrests made by Bureau of Indian Affairs law enforcement agencies, 2018
tleus18t16.csv	Table 16. Percent of Bureau of Indian Affairs law enforcement agencies, by type of arrests made, 2018
tleus18t17.csv	Table 17. Percent of Bureau of Indian Affairs law enforcement agencies, by access to transportation or vehicles, 2018
tleus18t18.csv	Table 18. Percent of Bureau of Indian Affairs law enforcement agencies, by task force participation, 2018
tleus18t19.csv	Table 19. Person-level jurisdiction, agency functions, and officer duties of the Alaska Village Public Safety Officer Program, 2018
tleus18t20.csv	Table 20. Race of full-time sworn officers and number of calls for service received in the Alaska Village Public Safety Officer Program, 2018
	
		Figures
tleus18f01.csv	Figure 1. Number of tribally operated law enforcement agencies in the United States, by size of agency, 2008 and 2018
tleus18f02.csv	Figure 2. Number of full-time sworn officers in tribally operated law enforcement agencies, by size of agency, 2008 and 2018
tleus18f03.csv	Figure 3. Percent of full-time sworn officers in tribally operated law enforcement agencies, by race or ethnicity, 2018
tleus18f04.csv	Figure 4. Percent of tribally operated law enforcement agencies, by type of arrests made, 2018
	
		Appendix tables
tleus18at01.csv	Appendix table 1. Tribal law enforcement agencies in the United States, by census response status and type of agency or program, 2018
tleus18at02.csv	Appendix table 2. CTLEA resident population categories, tribally operated agency universe and nonresponse adjustment weights, 2018
tleus18at03.csv	Appendix table 3. Estimates for map 1: Tribally operated and Bureau of Indian Affairs law enforcement agencies in the United States, by census response status and state, 2018
tleus18at04.csv	Appendix table 4. Standard errors for figure 1: Number of tribally operated law enforcement agencies in the United States, by size of agency, 2008 and 2018; and table 1: Number of tribally operated law enforcement agencies and full-time sworn officers, by size of agency, 2008 and 2018
tleus18at05.csv	Appendix table 5. Standard errors for table 2: Percent of tribally operated law enforcement agencies, by size of agency and source of funding, 2018
tleus18at06.csv	Appendix table 6. Standard errors for table 3: Percent of tribally operated law enforcement agencies, by size of agency and arrest or citation authority, 2018
tleus18at07.csv	Appendix table 7. Standard errors for table 4: Percent of tribally operated law enforcement agencies, by size of agency and agency functions, 2018
tleus18at08.csv	Appendix table 8. Standard errors for table 5: Percent of tribally operated law enforcement agencies, by size of agency and officer duties, 2018
tleus18at09.csv	Appendix table 9. Standard errors for table 6: Percent of tribally operated law enforcement agencies, by size of agency and characteristics of cross-deputization agreement, 2018
tleus18at10.csv	Appendix table 10. Standard errors for figure 3: Percent of full-time sworn officers in tribally operated law enforcement agencies, by race or ethnicity, 2018; and table 7: Percent of full-time sworn officers in tribally operated law enforcement agencies, by size of agency and officer race or ethnicity, 2018
tleus18at11.csv	Appendix table 11. Standard errors for table 8: Percent of tribally operated law enforcement agencies, by size of agency and officer skills training provided, 2018
tleus18at12.csv	Appendix table 12. Standard errors for figure 4: Percent of tribally operated law enforcement agencies, by type of arrests made, 2018
tleus18at13.csv	Appendix table 13. Standard errors for table 9: Percent of tribally operated law enforcement agencies, by size of agency and officer equipment provided, 2018
tleus18at14.csv	Appendix table 14. Standard errors for table 10: Number of calls for service received and arrests made by tribally operated law enforcement agencies, by size of agency, 2018
tleus18at15.csv	Appendix table 15. Standard errors for table 11: Percent of tribally operated law enforcement agencies, by technological resources, 2018
tleus18at16.csv	Appendix table 16. Standard errors for table 12: Percent of tribally operated law enforcement agencies, by size of agency and criminal justice data sharing, 2018
