Recidivism of Females Released from State Prison, 2012–2017   NCJ 306141	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Recidivism of Females Released from State Prison, 2012–2017   NCJ 306141. The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/recidivism-females-released-state-prison-2012-2017

This report is one in a series. More recent editions may be available.	
To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Recidivism%20of%20Prisoners%20Released	
	
Filenames		Table titles
rfrsp1217t01.csv	Table 1. Criminal history of persons released from state prison in 34 states in 2012, by sex
	
			Figures
rfrsp1217f01.csv	Figure 1. Persons released from state prison in 2012 who were arrested, convicted, or returned to prison within 5 years, by most serious commitment offense and sex
rfrsp1217f02.csv	Figure 2. Persons released from state prison in 34 states in 2012 who were arrested within 5 years, by post-release arrest offense and sex
	
			Appendix tables
rfrsp1217at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Persons released from state prison in 2012 who were arrested, convicted, or returned to prison within 5 years, by most serious commitment offense and sex
rfrsp1217at02.csv	Appendix table 2. Estimates and standard errors for figure 2: Persons released from state prison in 34 states in 2012 who were arrested within 5 years, by post-release arrest offense and sex
