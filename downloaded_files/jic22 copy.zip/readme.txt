Jails in Indian Country, 2022   NCJ 306307		
		
This zip archive contains tables in individual .csv spreadsheets		
from Jails in Indian Country, 2022   NCJ 306307.		
The full report including text and graphics in pdf format is available from: 		
https://bjs.ojp.gov/library/publications/jails-indian-country-2022
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=Jails%20in%20Indian%20Country		
		
Filenames		Table titles
jic22t01.csv		Table 1. Persons held, rated capacity, and percent of rated capacity occupied in Indian country jails in June, 2012–2022
jic22t02.csv		Table 2. Indian country jails and persons held, by facility size, midyear 2022
jic22t03.csv		Table 3. Average daily population, admissions, and average length of stay in Indian country jails, by facility size, June 2022
jic22t04.csv		Table 4. Capacity of Indian country jails, by facility size, midyear 2022
jic22t05.csv		Table 5. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2022
jic22t06.csv		Table 6. Number of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2012–2022
jic22t07.csv		Table 7. Percent of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2012–2022
jic22t08.csv		Table 8. Number of persons employed in Indian country jails, by job function, midyears 2012–2022
jic22t09.csv		Table 9. Percent of persons employed in Indian country jails, by job function, midyears 2012–2022
jic22t10.csv		Table 10. Survey universe and response rates of Indian country jails, 2012–2022
		
			Figures
jic22f01.csv		Figure 1. Number of persons held in Indian country jails, midyear 2012–2022
jic22f02.csv		Figure 2. Number of admissions and average length of stay in Indian country jails, June 2012–2022
		
			Appendix tables
jic2at01.csv		Appendix table 1. Estimates for figure 2: Number of admissions and average length of stay in Indian country jails, June 2012–2022
jic2at02.csv		Appendix table 2. Imputation for table 6: Number of persons held in Indian country jails, by demographic and criminal justice characteristics, midyears 2012–2022
jic2at03.csv		Appendix table 3. Imputation for table 8: Number of persons employed in Indian country jails, by job function, midyears 2012–2022
