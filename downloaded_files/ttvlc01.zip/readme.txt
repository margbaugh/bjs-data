Tort Trials and Verdicts in Large Counties, 2001	
	
This zip archive contains tables in individual .csv spreadsheets 	
from Tort Trials and Verdicts in Large Counties, 2001, NCJ 206240	
the full report including text and graphics in .pdf format are available from:	
http://www.ojp.usdoj.gov/bjs/abstract/ttvlc01.htm	

This report is one in a series.  More recent editions 
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#ttvlc

File name		Table number	
ttvlc01t1.csv	Table 1. Tort cases disposed of by trial in State courts in the  Nation's 75 largest counties, 2001
ttvlc01t2.csv	Table 2. Pairings of primary litigants in tort trial cases, by case type,  in State courts in the Nation's 75 largest counties, 2001
ttvlc01t3.csv	Table 3. Tort trial plaintiff winners in State courts in the Nation's  75 largest counties, 2001
ttvlc01t4.csv	Table 4. Final award amounts for tort trials with plaintiff winners in State courts in the Nation's 75 largest counties, 2001
ttvlc01t5.csv	Table 5. Punitive damages awarded to plaintiff winners in tort trials  in State courts in the Nation's 75 largest counties, 2001
ttvlc01t6.csv	Table 6. Plaintiff winners with awards reduced in tort trials due to contributory or comparative negligence in State courts in the Nation's 75 largest counties, 2001
ttvlc01t7.csv	Table 7. Comparing tort jury trials in State courts  in the Nation's 75 largest counties, 1992 to 2001 
ttvlc01t8.csv	Table 8. Type of post verdict relief sought by plaintiffs or defendants  in tort trials in State courts in the Nation's 75 largest counties, 2001
ttvlc01t9.csv	Table 9. Type of post verdict relief granted to plaintiffs or defendants in tort trials in State courts in the Nation's 75 largest counties, 2001
ttvlc01t10.csv	Table 10. Tort trials in which plaintiff or defendant gave notice of appeal  in State courts in the Nation's 75 largest counties, 2001

ttvlc01hi.csv	Highlights: Median final damage awards in tort trials with individual plaintiff winners 

ttvlc01f1.csv	Figure 1:  Median number of months to dispose of tort trial sfrom filing to disposition, 2001

ttvlc01tt1.csv	Text table 1: Sixty-three percent of the tort jury trials with data on the nature of the jury's decision resulted in a unanimous verdict for the plaintiff or the defendant
ttvlc01tt2.csv	Text table 2:  Defective products in product liability trials, 2001

ttvlc01a.csv	Appendix A. Selected estimates, standard errors, and confidence intervals, civil trial 2001 survey
ttvlc01b.csv	Appendix B. Tort trial winners in State courts by sampled counties, 2001
ttvlc01c.csv	Appendix C. Final and punitive damage awards for plaintiff winners in tort trials, by sampled counties, 2001
