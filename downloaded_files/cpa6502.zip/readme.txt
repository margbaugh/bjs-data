Crimes against Persons Age 65 or Older, 1993-2002   NCJ 206154		

This zip archive contains tables in individual .csv spreadsheets
from Crimes against Persons Age 65 or Older, 1993-2002   NCJ 206154.
 The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cpa6502.htm 

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cpa

Spreadsheets		

File Name			Highlight	
cpa6502h.csv		Highlight 1.  The elderly, age 65 or older, had lower violent victimization rates than other age groups, when comparing race and gender

	Table Titles	
cpa6502t1.csv		Table 1.  Personal and household victimizations, by type of crime and age, 1993-2002	
cpa6502t2.csv		Table 2.  Nonfatal violent victimizations, 1993-2002	
cpa6502t3.csv		Table 3.  Characteristics of crimes, 1993-2002	

	Text Table Titles		
cpa6502tt1.csv		Text Table 1.	Offenders in violent crimes, 1993-2002

	Figure Titles		
cpa6502f1.csv		Figure 1.  Percent of violent and property crimes, by age of victim, 1993-2002	
cpa6502f2.csv		Figure 2.  Purse snatching and pocket picking, as a percentage of all crimes against persons, by age of victim, 1993-2002	
cpa6502f3.csv		Figure 3.  Rates of violent crime victimization per 1,000 persons, by age of victim, 1993-2002	
cpa6502f4.csv		Figure 4.  Murder rates per 10,000 persons, by age of victim, 1993-2002	
cpa6502f5.csv		Figure 5.  Property crime rates per 1,000 households, by age, 1993-2002	
cpa6502f6.csv		Figure 6.  On average each year 1993-2002, of persons age 65 or older who reported being a victim of violence, 22% were injured and 1% were hospitalized overnight	
