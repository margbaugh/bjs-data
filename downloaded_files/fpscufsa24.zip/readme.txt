Federal Prisoner Statistics Collected Under the First Step Act, 2024  NCJ 309537	
	
This zip archive contains tables in individual .csv spreadsheets for	
Federal Prisoner Statistics Collected Under the First Step Act, 2023  NCJ 309537	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/federal-prisoner-statistics-collected-under-first-step-act-2024	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Prisoner%20Statistics%20Collected%20Under%20the%20First%20Step%20Act	
	
Filenames		Table titles
fpscufsa24t01.csv	Table 1. Selected characteristics of federal prisoners, 2019–2023
fpscufsa24t02.csv	Table 2. Medical conditions, testing, and treatment of federal prisoners, 2019–2023
fpscufsa24t03.csv	Table 3. Selected characteristics of federal facilities, 2019–2023
fpscufsa24t04.csv	Table 4. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by security level of facility, 2023
fpscufsa24t05.csv	Table 5. Federal prisoners who were cited for prohibited acts that resulted in reductions in rewards, incentives, or time credits, by demographic characteristics, 2019–2023
fpscufsa24t06.csv	Table 6. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by facility, 2023
fpscufsa24t07.csv	Table 7. Prisoner assaults on Federal Bureau of Prisons staff, by type of assault and prosecution status, 2023
fpscufsa24t08.csv	Table 8. Volunteer levels in Federal Bureau of Prisons facilities, by facility, December 31, 2023
fpscufsa24t09.csv	Table 9. Recidivism reduction partnerships in Federal Bureau of Prisons facilities, by facility, 2023
fpscufsa24t10.csv	Table 10. Recidivism risk classification of persons in federal prison, by demographic and sentence characteristics, 2023
fpscufsa24t11.csv	Table 11. Approved Evidence-Based Recidivism Reduction Programs and Productive Activities, by facility availability and prisoner needs met, 2023
	
*Not included in report	
fpscufsa24t12.csv	Table 12. Enrollment and completion of Evidence-Based Recidivism Reduction Programs and Productive Activities, by FBOP facility, program or activity, and recidivism risk level, 2023
