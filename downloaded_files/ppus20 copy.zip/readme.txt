Probation and Parole in the United States, 2020   NCJ 303102									
									
This zip archive contains tables in individual .csv spreadsheets from									
Probation and Parole in the United States, 2020   NCJ 303102.  The full report including text									
and graphics in pdf format is available from https://bjs.ojp.gov/library/publications/probation-and-parole-united-states-2020

This report is one in a series.  More recent editions may be available.									
To view a list of all in the series go to 									
https://bjs.ojp.gov/library/publications/list?series_filter=Probation%20and%20Parole%20Populations									
									
Filenames	Table titles								
ppus20t01.csv	Table 1. Adults under community supervision, 2005–2020								
ppus20t02.csv	Table 2. Decrease in probation population, by jurisdiction, 2020								
ppus20t03.csv	Table 3. Increase in parole population, by jurisdiction, 2020								
ppus20t04.csv	Table 4. Community supervision rate of U.S. adult residents, 2005–2020								
ppus20t05.csv	Table 5. Exits from probation, by type of exit, 2005–2020								
ppus20t06.csv	Table 6. Exits from parole, by type of exit, 2005–2020								
ppus20t07.csv	Table 7. Quarterly probation population and percent change for reporting agencies, 2020								
ppus20t08.csv	Table 8. Quarterly parole population and percent change for reporting agencies, 2020								
ppus20t09.csv	Table 9. Adults supervised on both parole and probation excluded from the January 1 and December 31 community supervision population, 2007–2020								
ppus20t10.csv	Table 10. One-day difference based on reporting changes for probation and parole, 2007–2020								
									
		Figures								
ppus20t01.csv	Figure 1. Adults on probation or parole, 2005–2020								
ppus20t02.csv	Figure 2. Annual percent change of adults on probation, 2005–2020								
ppus20t03.csv	Figure 3. Annual percent change of adults on parole, 2005–2020								
ppus20t04.csv	Figure 4. Estimated total probation movements, entries, and exits, 2005–2020								
ppus20t05.csv	Figure 5. Estimated total parole movements, entries, and exits, 2005–2020								
									
		Appendix tables								
ppus20at01.csv	Appendix table 1. Estimates for figure 2: Annual percent change of adults on probation, 2005–2020								
ppus20at02.csv	Appendix table 2. Estimates for figure 3: Annual percent change of adults on parole, 2005–2020								
ppus20at03.csv	Appendix table 3. Estimates for figure 4: Estimated total probation movements, entries, and exits, 2005–2020								
ppus20at04.csv	Appendix table 4. Estimates for figure 5: Estimated total parole movements, entries, and exits, 2005–2020								
ppus20at05.csv	Appendix table 5. Adults under community supervision, 2020								
ppus20at06.csv	Appendix table 6. Adults on probation, 2020								
ppus20at07.csv	Appendix table 7. Adults exiting probation, by type of exit, 2020								
ppus20at08.csv	Appendix table 8. Characteristics of adults on probation, 2005 and 2020								
ppus20at09.csv	Appendix table 9. Adults on parole, 2020								
ppus20at10.csv	Appendix table 10. Adults exiting parole, by type of exit, 2020								
ppus20at11.csv	Appendix table 11. Characteristics of adults on parole, 2005 and 2020								
									
