Criminal Victimization, 2009     NCJ  231327			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization,  2009,   NCJ  231327.  The full report including text			
and graphics in pdf format is available from: http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2217		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=6			
			
			
Filename			Table title
cv09t01.csv			Table 1. Criminal victimization, numbers, rates, and percent change, by type of crime, 2008 and 2009
cv09t02.csv			Table 2. Rates of criminal victimization and percent change, by type of crime, 2000 and 2009
cv09t03.csv			Table 3. National crime victimization rates and percent change in rates, by type of crime, 2007-2009
cv09t04.csv			Table 4. Percent changes in the rates of crimes reported in the UCR, 2008-2009
cv09t05.csv			Table 5. Rates of violent crime, by gender, race, Hispanic origin, and age of victim, 2009
cv09t06.csv			Table 6. Property crime rates, by household income and household size, 2009
cv09t07.csv			Table 7. Relationship between victim and offender, by gender of victim, 2009
cv09t08.csv			Table 8. Number and rate of intimate partner violence, by gender of victims' gender, 2008 and 2009
cv09t09.csv			Table 9. Presence of weapons in violent incidents, by type, 2009
cv09t10.csv			Table 10. Firearm use in violent crime, 2000 and 2009
cv09t11.csv			Table 11. Percent of violent and property crimes reported to police, 2009
cv09t12.csv			Table 12. Percent of crimes reported to the police, by gender, race, and Hispanic origin, 2009
cv09t13.csv			Table 13. Rates and percent change of crimes reported to the police, by type of crime, 2008 and 2009
			
Figures			
cv09f01.csv			Figure 1. Violent crime rates overall fell by 39% from 2000 to 2009
cv09f02.csv			Figure 2. Property crime rates overall fell by 29% from 2000 to 2009
cv09f03.csv			Figure 3. Reporting of violent crime has remained stable since 2000
			
Appendix tables			
cv09at01.csv			Appendix Table 1. Standard errors for criminal victimization, numbers and rates, by type of crime, 2008 and 2009
cv09at02.csv			Appendix Table 2. Standard errors for criminal victimization, by type of crime, 2008 and 2009
cv09at03.csv			Appendix Table 3. Standard errors for national crime victimization rates, by type of crime, 2007-2009
cv09at04.csv			Appendix Table 4. Standard errors for rates of violent crime, by gender, race, Hispanic origin, and age of victim, 2009
cv09at05.csv			Appendix Table 5. Standard errors for property crime rates, by household income and household size, 2009
cv09at06.csv			Appendix Table 6. Standard errors for relationship between victim and offender, by gender of victim, 2009
cv09at07.csv			Appendix Table 7. Standard errors for number and rate of intimate partner violence, by victims' gender, 2008 and 2009
cv09at08.csv			Appendix Table 8. Standard errors for presence of weapons in violent incidents, by type, 2009
cv09at09.csv			Appendix Table 9. Standard errors for percent of violent and property crimes reported to police, 2009
cv09at10.csv			Appendix Table 10. Standard errors for crimes reported to the police, by gender, race, and Hispanic origin, 2009
cv09at11.csv			Appendix Table 11. Standard errors for rates of crimes reported to the police, by type of crime, 2008 and 2009
