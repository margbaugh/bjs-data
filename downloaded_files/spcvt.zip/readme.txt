Seasonal Patterns in Criminal Victimization Trends,NCJ 245959
	
 		
This zip archive contains tables in individual .csv spreadsheets from		
Seasonal Patterns in Criminal Victimization Trends, NCJ 245959
		
		
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5028		
		
Filename		Appendix Table title
spcvtat01.csv		Appendix table 1. Results of regression analyses of seasonal patterns in household property crime victimization, by type of property crime, 1993?2010
spcvtat02.csv		Appendix table 2. Results of regression analyses of seasonal patterns in violent victimization, by type of crime, 1993?2010
spcvtat03.csv		Appendix table 3. Results of regression analyses of seasonal patterns in violent victimization involving intimate partners, weapon use, and injury, 1993?2010
spcvtat04.csv		Appendix table 4. Expanded detail of regression model results for seasonal burglary rates, 1994?2010
		
File		        Figure title
spcvtf01.csv		Figure 1. Seasonal rates of household property victimization, 1993?2010
spcvtf02.csv		Figure 2. Seasonal rates of burglary, 1993?2010
spcvtf03.csv		Figure 3. Seasonal rates of motor vehicle theft, 1993?2010
spcvtf04.csv		Figure 4. Seasonal rates of household larceny, 1993?2010
spcvtf05.csv		Figure 5. Seasonal rates of total violent victimization, 1993?2010
spcvtf06.csv		Figure 6. Seasonal rates of serious violent victimization, 1993?2010
spcvtf07.csv		Figure 7. Seasonal rates of rape and sexual assault, 1993?2010
spcvtf08.csv		Figure 8. Seasonal rates of robbery, 1993?2010
spcvtf09.csv		Figure 9. Seasonal aggravated assault rates, 1993?2010
spcvtf010.csv		Figure 10. Seasonal rates of simple assault, 1993?2010
spcvtf011.csv		Figure 11. Seasonal rates of simple assault for youth and adults, 1993-2010
spcvtf012.csv		Figure 12. Seasonal rates of intimate partner violence, 1993?2010
spcvtf013.csv		Figure 13. Seasonal rates of serious violent crime involving weapons, 1993?2010
spcvtf014.csv		Figure 14. Seasonal rates of serious violent crime resulting in injury, 1993?2010
		
File		Table title
spcvtt01.csv		Table 1. Average percent difference in seasonal rate of household victimization, by type of crime, 1993?2010
spcvtt02.csv		Table 2. Average percent difference in seasonal rate of violent victimization, by type of crime, 1993?2010
spcvtt03.csv		Table 3. Average percent difference in the seasonal rate of violent victimization involving intimate partners, weapon use, and injury, 1993?2010
