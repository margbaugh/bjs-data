Characteristics of State Parole Supervising Agencies, 2006, NCJ 222180

 
This zip archive contains tables in individual .csv spreadsheets from Characteristics of State Parole Supervising Agencies, 2006, NCJ 222180
The full report including text and graphics in pdf format is available at: http://www.ojp.usdoj.gov/bjs/abstract/cspsa06.htm
 

     Tables 
cspsa06t01.csv      Table 1. Number of state adult parole supervising agencies, offices, and adult parole and probation population, by type of agency, June 30, 2006
cspsa06t02.csv      Table 2. Characteristics of adult parole supervising agencies, June 30, 2006
cspsa06t03.csv      Table 3. Full-time and part-time employees of state adult parole supervising agencies, by type of agency and staff, June 30, 2006
cspsa06t04.csv      Table 4. Full-time equivalent (FTE) positions supervising active parolees, and average adult parolee caseload per FTE position, by type of agency, June 30, 2006
cspsa06t05.csv      Table 5. Levels and status of adults on parole, state adult parole supervising agencies, June 30, 2006
cspsa06t06.csv      Table 6. State adult parole supervising agencies that considered prisoners for release, set the terms/conditions of supervision, or conducted parole revocation hearings, June 30, 2006
cspsa06t07.csv      Table 7. States in which adult parole supervising agencies considered prisoners for release, June 30, 2006
cspsa06t08.csv      Table 8. Adults on parole returned to incarceration, July 1, 2005, to June 30, 2006, as a result of a drug violation detected during agency testing
cspsa06t09.csv      Table 9. Adult supervising agencies' ues of drug treatment programs, by type of program, June 30, 2006
cspsa06t10.csv      Table 10. Adult supervising agencies' use of sex offender and mental health treatment programs, by type of program, June 30, 2006
cspsa06t11.csv      Table 11. Housing and employment assistance programs provided by adult parole agencies, June 30, 2006
cspsa06t12.csv      Table 12. Number of formal housing assistance programs offered by adult parole supervising agencies, June 30, 2006
cspsa06t13.csv      Table 13. Number of employment assistance programs offered by adult parole supervising agencies, June 30, 2006
cspsa06t14.csv      Table 14. Comparison of 2006 Census of State Parole Supervising Agency and 2006 Annual Parole Survey data collections
cspsa06t15.csv      Table 15. Adult parole supervising agency staff, by type, June 30, 2006
cspsa06t16.csv      Table 16. Adult parole supervising agency staff, by gender, June 30, 2006
cspsa06at01.csv      Appendix table 1. Persons under supervision by adult parole supervising agencies, 6/30/2006
cspsa06at02.csv      Appendix table 2. Adults on parole, by status of supervision, full-time equivalent employees, average active supervision caseload, 6/30/2006
cspsa06at03.csv      Appendix table 3. Adults on parole, by supervision level, 6/30/2006
cspsa06at04.csv      Appendix table 4. Agencies that consider prisoners for releases, number of releases, and that set the terms/conditions of adult parole supervision
cspsa06at05.csv      Appendix table 5. Agency responsibility for conducting adult parole revocation hearings,6/30/2006
cspsa06at06.csv      Appendix table 6. Drug abuse testing of adult parolees, returns to incarceration, and drug treatment programs, 6/30/2006
cspsa06at07.csv      Appendix table 7. Adult parole agency use of sex offender and mental health treatment programs, 6/30/2006
cspsa06at08.csv      Appendix table 8. Adult parole agency use of housing assistance programs, 6/30/2006
cspsa06at09.csv      Appendix table 9. Adult parole agency use of employment assistance programs, 6/30/2006
