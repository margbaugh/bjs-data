Sexual Violence Reported by Correctional Authorities, 2004   NCJ   210333


This zip archive contains tables in individual .csv spreadsheets
from Sexual Violence Reported by Correctional Authorities,  2004   NCJ  210333. 
The full report including text
and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/svrca04.htm



svrca0401.csv	Table 1.	  Facilities selected for the Survey on Sexual Violence, 2004
svrca0402.csv	Table 2.	  Reporting capabilities of adult and juvenile correctional authorities to provide data on sexual violence, 2004
svrca0403.csv	Table 3.	  Allegations of sexual violence per 1,000 inmates, by type of facility, 2004
svrca0404.csv	Table 4.	  Responsibility for investigating allegations of nonconsensual sexual acts and staff sexual misconduct, by type of facility, 2004
svrca0405.csv	Table 5.	  Allegations of sexual violence in State prisons, local jails, and private prisons and jails, 2004
svrca0406.csv	Table 6.	  Allegations of sexual violence in State juvenile systems and local or private juvenile facilities, 2004
svrca0407.csv	Table 7.	  Characteristics of victims and perpetrators in substantiated incidents of sexual violence in adult correctional facilities, by type, 2004	
svrca0408.csv	Table 8.	  Characteristics of victims and perpetrators in substantiated incidents of sexual violence in juvenile correctional facilities, by type, 2004	
svrca0409.csv	Table 9.	  Sanctions imposed on perpetrators of inmate-on-inmate and youth-on-youth sexual violence, by type of correctional facility, 2004	
svrca0410.csv	Table10.	  Sanctions imposed on perpetrators of staff sexual misconduct and staff sexual harassment, by type of correctional facility, 2004	


			Highlights tables		
svrca04h01.csv	Highlights table 1. Coverage of the Survey on Sexual Violence, 2004
svrca04h02.csv	Highlights table 2. Allegations of sexual violence, by type of correctional facility, 2004
svrca04h03.csv	Highlights table 3. Substantiated incidents of sexual violence per 1,000 inmates, by type of correctional facility, 2004


	Appendix tables
svrcaap01a.csv	Appendix table 1a. Allegations of inmate-on-inmate sexual violence reported by State or Federal prison authorities, by type, 2004
svrcaap01b.csv	Appendix table 1b. Allegations of staff sexual misconduct with inmates reported by State and Federal prison authorities, by type, 2004
svrcaap02a.csv	Appendix table 2a. Allegations of inmate-on-inmate sexual violence reported by local jail authorities,  by type, 2004
svrcaap02b.csv	Appendix table 2b. Allegations of staff sexual misconduct with inmates  reported by local jail authorities, by type, 2004
svrcaap02c.csv	Appendix table 2c. Local jail jurisdictions with no allegations of inmate-on-inmate sexual violence and staff sexual misconduct, 2004
svrcaap03a.csv	Appendix table 3a. Allegations of inmate-on-inmate sexual violence   reported in private prisons and jails, by type, 2004
svrcaap03b.csv	Appendix table 3b. Allegations of staff sexual misconduct with inmates reported in private prisons and jails, by type, 2004
svrcaap04a.csv	Appendix table 4a. Allegations of inmate-on-inmate sexual violence  reported in other correctional facilities, by type, 2004
svrcaap04b.csv	Appendix table 4b. Allegations of staff sexual misconduct with inmates reported in other correctional facilities, by type, 2004
svrcaap05a.csv	Appendix table 5a. Allegations of youth-on-youth sexual violence reported by State juvenile administrators, by type, 2004
svrcaap05b.csv	Appendix table 5b. Allegations of staff sexual misconduct with youth reported by State juvenile administrators, by type, 2004
svrcaap06a.csv	Appendix table 6a. Allegations of youth-on-youth sexual violence reported in local  and privately operated juvenile facilities, by type, 2004
svrcaap06b.csv	Appendix table 6b. Allegations of staff sexual misconduct with youth reported in local  and privately operated juvenile facilities, by type, 2004
svrcaap06c.csv	Appendix table 6c. Private and local juvenile facilities with no allegations of youth-on-youth sexual violence and staff sexual misconduct, 2004
