Criminal Victimization, 2019  NCJ 255113		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Criminal Victimization, 2019  NCJ 255113.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7046		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=6		
		
Filename		Table title
cv19t01.csv		Table 1. Number and rate of violent victimizations, by type of crime, 2015-2019
cv19t02.csv		Table 2. Number and rate of property victimizations, by type of crime, 2015-2019
cv19t03.csv		Table 3. Number and rate of violent victimizations, by selected characteristics of violent crime, 2018 and 2019
cv19t04.csv		Table 4. Rate of completed, attempted, and threatened violent victimizations, 2015-2019
cv19t05.csv		Table 5. Rates of crime reported to police in the Uniform Crime Reporting program and in the National Crime Victimization Survey, 2018 and 2019
cv19t06.csv		Table 6. Percent and rate of victimizations reported to police, by type of crime, 2018 and 2019
cv19t07.csv		Table 7. Rate of violent victimization reported and not reported to police, by completed, attempted, and threatened crimes, 2015-2019
cv19t08.csv		Table 8. Percent of violent victimizations for which victims received assistance from a victim-service agency, by type of crime, 2018 and 2019
cv19t09.csv		Table 9. Rate of violent victimization, by type of crime and demographic characteristics of victims, 2018 and 2019
cv19t10.csv		Table 10. Percent and rate of violent victimizations reported to police, by type of crime and demographic characteristics of victims, 2019
cv19t11.csv		Table 11. U.S. residents� sense of where they live, per the American Housing Survey
cv19t12.csv		Table 12. Rate of victimization, by type of crime and location of residence, 2018 and 2019
cv19t13.csv		Table 13. Percent and number of violent incidents, by total population victim, and offender demographic characteristics, 2019
cv19t14.csv		Table 14. Percent of violent incidents, by victim and offender sex, 2019
cv19t15.csv		Table 15. Number of violent incidents, by victim and offender race or ethnicity, 2019
cv19t16.csv		Table 16. Percent of violent incidents, by victim and offender race or ethnicity, 2019
cv19t17.csv		Table 17. Percent of violent incidents and percent of the U.S. population, by victim and offender race or ethnicity, 2019
cv19t18.csv		Table 18. Number and percent of persons who were victims of violent crime, by type of crime, 2015-2019
cv19t19.csv		Table 19. Number and percent of persons who were victims of violent crime, by demographic characteristics of victims, 2018 and 2019
cv19t20.csv		Table 20. Number and percent of households victimized, by type of property crime, 2015-2019
cv19t21.csv		Table 21. Number and percent of persons who were victims of serious crime, 2015-2019
cv19t22.csv		Table 22. Number and percent of persons who were victims of serious crime, by demographic characteristics of victims, 2018 and 2019
cv19t23.csv		Table 23. Percent of violent victimizations reported to police, by completed, attempted, and threatened crimes, 2015-2019
cv19t24.csv		Table 24. Number and rate of violent victimizations, by victim�s veteran and citizenship status, 2018 and 2019
cv19t25.csv		Table 25. Firearm violence, 2018 and 2019
cv19t26.csv		Table 26. Percent and number of violent incidents excluding simple assault, by total population victim, and offender demographic characteristics, 2019
cv19t27.csv		Table 27. Percent of violent incidents excluding simple assault, by victim and offender sex, 2019
cv19t28.csv		Table 28. Number of violent incidents excluding simple assault, by victim and offender race or ethnicity, 2019
cv19t29.csv		Table 29. Percent of violent incidents excluding simple assault, by victim and offender race or ethnicity, 2019
cv19t30.csv		Table 30. Percent of violent incidents excluding simple assault and percent of the U.S. population, by victim and offender race or ethnicity, 2019
cv19t31.csv		Table 31. Population and number of households, by old and new definition of location of residence, 2019
cv19t32.csv		Table 32. Significant differences in the rate of victimizations, by variance-estimation method and type of crime, 2014-2017 versus 2018
		
			Figures
cv19f01.csv		Figure 1. Percent of U.S. residents age 12 or older who were victims of violent crime excluding simple assault
cv19f02.csv		Figure 2. Percent of U.S. households who were victims of burglary, 1993-2019
cv19f03.csv		Figure 3. Rate of violent victimization excluding simple assault and rate of violent victimization excluding simple assault, 1993-2019
			Figure 4. [map]
cv19f05.csv		Figure 5. Location-of-residence classification, by source of classification
		
			Appendix tables
cv19at01.csv		Appendix table 1. Estimates and standard errors for figure 1: Percent of U.S. residents age 12 or older who were victims of violent crime excluding simple assault, 1993-2019
cv19at02.csv		Appendix table 2. Estimates and standard errors for figure 2: Percent of U.S. households who were victims of burglary, 1993-2019
cv19at03.csv		Appendix table 3. Estimates and standard errors for figure 3: Rate of violent victimization excluding simple assault and rate of violent victimization reported to police, excluding simple assault, 1993-2019
cv19at04.csv		Appendix table 4. Estimates for figure 5: Location of residence classification, by source of classification
cv19at05.csv		Appendix table 5. Standard errors for table 1: Number and rate of violent victimizations, by type of crime, 2015-2019
cv19at06.csv		Appendix table 6. Standard errors for table 2: Number and rate of property victimizations, by type of crime, 2015-2019
cv19at07.csv		Appendix table 7. Standard errors for table 3: Number and rate of violent victimizations, by selected characteristics of violent crime, 2018 and 2019
cv19at08.csv		Appendix table 8. Standard errors for table 4: Rate of completed, attempted, and threatened violent victimizations, 2015-2019
cv19at09.csv		Appendix table 9. Standard errors for table 5: Rates of crime reported to police in the Uniform Crime Reporting program and in the National Crime Victimization Survey, 2018 and 2019
cv19at10.csv		Appendix table 10. Standard errors for table 6: Percent and rate of victimizations reported to police, by type of crime, 2018 and 2019
cv19at11.csv		Appendix table 11. Standard errors for table 7: Rate of violent victimization reported and not reported to police, by completed, attempted, and threatened crimes, 2015-2019
cv19at12.csv		Appendix table 12. Standard errors for table 8: Percent of violent victimizations for which victims received assistance from a victim-service agency, by type of crime, 2018 and 2019
cv19at13.csv		Appendix table 13. Standard errors for table 9: Rate of violent victimization, by type of crime and demographic characteristics of victims, 2018 and 2019
cv19at14.csv		Appendix table 14. Standard errors for table 10: Percent and rate of violent victimizations reported to police, by type of crime and demographic characteristics of victims, 2019
cv19at15.csv		Appendix table 15. Standard errors for table 12: Rate of victimization, by type of crime and location of residence, 2018 and 2019 
cv19at16.csv		Appendix table 16. Standard errors for table 13: Percent and number of violent incidents, by total population victim, and offender demographic characteristics, 2019
cv19at17.csv		Appendix table 17. Standard errors for table 14: Percent of violent incidents, by victim and offender sex, 2019
cv19at18.csv		Appendix table 18. Standard errors for table 15: Number of violent incidents, by victim and offender race or ethnicity, 2019
cv19at19.csv		Appendix table 19. Standard errors for table 16: Percent of violent incidents, by victim and offender race or ethnicity, 2019
cv19at20.csv		Appendix table 20. Standard errors for table 17: Percent of violent incidents and percent of the U.S. population, by victim race or ethnicity, 2019
cv19at21.csv		Appendix table 21. Standard errors for table 18: Number and percent of persons who were victims of violent crime, by type of crime, 2015-2019
cv19at22.csv		Appendix table 22. Standard errors for table 19: Number and percent of persons who were victims of violent crime, by demographic characteristics of victims, 2018 and 2019
cv19at23.csv		Appendix table 23. Standard errors for table 20: Number and percent of households victimized, by type of property crime, 2015-2019
cv19at24.csv		Appendix table 24. Standard errors for table 21: Number and percent of persons who were victims of serious crime, 2015-2019
cv19at25.csv		Appendix table 25. Standard errors for table 22: Number and percent of persons who were victims of serious crime, by demographic characteristics of victims, 2018 and 2019
cv19at26.csv		Appendix table 26. Standard errors for table 23: Percent of violent victimizations reported to police, by completed, attempted, and threatened crimes, 2015-2019
cv19at27.csv		Appendix table 27. Standard errors for table 24: Number and rate of violent victimizations, by victim�s veteran and citizenship status, 2018 and 2019
cv19at28.csv		Appendix table 28. Standard errors for table 25: Firearm violence, 2018 and 2019
cv19at29.csv		Appendix table 29. Standard errors for table 26: Percent and number of violent incidents excluding simple assault, by total population victim, and offender demographic characteristics, 2019
cv19at30.csv		Appendix table 30. Standard errors for table 27: Percent of violent incidents excluding simple assault, by victim and offender sex, 2019
cv19at31.csv		Appendix table 31. Standard errors for table 28: Number of violent incidents excluding simple assault, by victim and offender race or ethnicity, 2019
cv19at32.csv		Appendix table 32. Standard errors for table 29: Percent of violent incidents excluding simple assault, by victim and offender race or ethnicity, 2019
cv19at33.csv		Appendix table 33. Standard errors for table 30: Percent of violent incidents excluding simple assault and percent of the U.S. population, by victim and offender race or ethnicity, 2019
cv19at34.csv		Appendix table 34. Population size for persons age 12 or older, by demographic characteristics, 2015-2019
cv19at35.csv		Appendix table 35. Household population size, 2015-2019
cv19at36a.csv		Appendix table 36a: Urban places under the new NCVS definition that are listed in the name of a 500,000-person, Census-designated urbanized area
cv19at36b.csv		Appendix table 36b: Other urban places under the new NCVS definition, by Census-designated urbanized area
