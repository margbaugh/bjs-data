Capital Punishment, 2017: Selected Findings NCJ 253060
		
This zip archive contains tables in individual .csv spreadsheets		
from Capital Punishment, 2017: Selected Findings		
The full electronic report is available at: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6586
		
These statistical tables are in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://www.bjs.gov/index.cfm?ty=pbse&sid=1		
		
cp17sff01.csv		Figure 1. Annual number of prisoners executed under civil authority in the United States, 1977�2017
cp17sft01.csv		Table 1. Status of the death penalty, December 31, 2017
cp17sft02.csv		Table 2. Prisoners under sentence of death, by region, jurisdiction, and race, 2016 and 2017
cp17sft03.csv		Table 3. Average time between sentencing and execution, 1977�2017