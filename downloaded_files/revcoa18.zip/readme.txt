Race and Ethnicity of Violent Crime Offenders and Arrestees, 2018		
		
This .zip archive contains tables in individual .csv spreadsheets from		
Race and Ethnicity of Violent Crime Offenders and Arrestees, 2018 NCJ 255969.  The full report including text 		
and graphics in pdf format is available from https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7226		
		
Filename		Table name
revcoa18t01.csv		Table 1. Race or ethnicity of the U.S. resident population and of persons arrested for nonfatal violent crimes, 2018
revcoa18t02.csv		Table 2. Race or ethnicity of offenders in the NCVS and of persons arrested for nonfatal violent crimes, 2018
revcoa18t03.csv		Table 3. Race or ethnicity of offenders in the NCVS and of persons arrested for serious nonfatal violent crimes, 2018
revcoa18t04.csv		Table 4. Reported race or ethnicity of violent crime offender by race or ethnicity of victim, NCVS 2018
revcoa18t05.csv		Table 5. Number of violent crime incidents and number of offenders, by race or ethnicity of offender, NCVS 2018
revcoa18t06.csv		Table 6. Percentage of single- and multiple-offender violent crime incidents, by race or ethnicity of victim, NCVS 2018
revcoa18t07.csv		Table 7. Percentage of offenders by race or ethnicity in single- and multiple-offender violent crime incidents, NCVS 2018
revcoa18t08.csv		Table 8. Percentage of offenders in violent crime incidents by type of crime and race or ethnicity compared to the U.S. resident population, 2018
		
			Appendix tables
revcoa18at01.csv	Appendix table 1. Estimating the number of persons arrested for violent offenses by race/ethnicity, UCR 2018
revcoa18at02.csv	Appendix table 2. Standard errors for tables 2 and 3: Race or ethnicity of violent crime offenders in the NCVS, 2018
revcoa18at03.csv	Appendix table 3. Standard errors for table 4: Reported race or ethnicity of violent crime offender by race or ethnicity of victim, NCVS 2018
revcoa18at04.csv	Appendix table 4. Standard errors for table 5: Number of violent crime incidents and number of offenders, by race or ethnicity of offender, NCVS 2018
revcoa18at05.csv	Appendix table 5. Standard errors for table 6: Percentage of single- and multiple-offender violent crime incidents, by race or ethnicity of victim, NCVS 2018
revcoa18at06.csv	Appendix table 6. Standard errors for table 7: Percentage of offenders by race or ethnicity in single- and multiple-offender violent crime incidents, NCVS 2018
revcoa18at07.csv	Appendix table 7. Standard errors for table 8: Percentage of offenders in violent crime incidents by type of crime and race or ethnicity compared to the U.S. resident population, 2018
