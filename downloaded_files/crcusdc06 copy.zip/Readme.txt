"Civil Rights Complaints in U.S. District Courts, 1990-2006        "		

This zip archive contains tables in individual  .csv spreadsheets               		
"from Civil Rights Complaints in U.S. District Courts, 1990-2006 ,  NCJ 222989"		
The full report including text and graphics in pdf format is available at:              		
http://www.ojp.usdoj.gov/bjs/abstract/crcusdc06.htm           		

This report is one in a series.  More recent editions            		
may be available.  To view a list of all in the series go to               		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#crcusdc 		

crcusdc06t01.csv		"Table 1. Federal subject matter jurisdiction of civil rights complaints filed in U.S. district courts, 1990 - 2006"
crcusdc06t02.csv		"Table 2. Types of civil rights complaints involving a private suit filed in U.S. district courts, 1990 - 2006"
crcusdc06t03.csv		"Table 3. Civil rights complaints with the U.S. Government involved as plaintiff or defendant filed in U.S. district courts, by type, 1990 - 2006"
crcusdc06t04.csv		"Table 4. Civil rights cases concluded in U.S. district courts, by disposition, 1990-2006"
crcusdc06t05.csv		"Table 5.  Disposition of civil rights complaints concluded by trial by case type in U.S. district courts, 1990 and 2006"
crcusdc06t06.csv		"Table 6.  Plaintiff winners and award amounts in civil rights complaints concluded by trial in U.S. district courts, 1990-2006"
crcusdc06t07.csv		"Table 7. Plaintiff winners and median awards for civil rights cases concluded by trial or case type in U.S. district courts, 2000-2006"
crcusdc06t08.csv		"Table 8. Number of months from filing of complaint to disposition among civil rights cases concluded in U.S. district courts, 1990-2006"

crcusdc06f01.csv		"Figure 1. Civil rights jury trials increasingly more common than bench trials in U.S. district courts, 1990 - 2006"
crcusdc06f02.csv		"Figure 2. Since 2003, civil rights cases have represented a declining proportion of federal civil caseloads"
crcusdc06f03.csv		"Figure 3. Civil rights cases involving employment discrimination demonstrated the same trend as civil rights cases overall, 1990 - 2006"
crcusdc06f04.csv		"Figure 4. Housing, voting rights, and welfare claims filed in U.S. district courts, 1990 - 2006"
crcusdc06f05.csv		Figure 5. State prison petitions declined after the Prison Litigation Reform Act of 1996
crcusdc06f06.csv		"Figure 6. Federal prisoner petitions filed in U.S. distrcit courts ranged from a low of 910 in 1992 to a high of 1,334 in 2004"
