Mortality in Local Jails, 2000-2018 - Statistical Tables  NCJ 256002																
																
This zip archive contains tables in individual  .csv spreadsheets																
from Mortality in Local Jails, 2000-2018 - Statistical Tables  NCJ 256002  The full report including text																
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7386																
																
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to																
https://www.bjs.gov/index.cfm?ty=pbse&sid=76																
																
Filenames		Table titles															
mlj0018stt01.csv	Table 1. Number of deaths of local jail inmates, by cause of death, 2000 and 2008–2018															
mlj0018stt02.csv	Table 2. Percent of deaths of local jail inmates, by cause of death, 2000 and 2008–2018															
mlj0018stt03.csv	Table 3. Mortality rate per 100,000 local jail inmates, by cause of death, 2000 and 2008–2018															
mlj0018stt04.csv	Table 4. Crude and adjusted mortality rate per 100,000 U.S. residents, by cause of death, 2018															
mlj0018stt05.csv	Table 5. Number of deaths of local jail inmates, by decedent characteristics, 2000 and 2008–2018															
mlj0018stt06.csv	Table 6. Percent of deaths of local jail inmates, by decedent characteristics, 2000 and 2008–2018															
mlj0018stt07.csv	Table 7. Mortality rate per 100,000 local jail inmates within each demographic group, by decedent characteristics, 2000 and 2008–2018	
mlj0018stt08.csv	Table 8. Number of deaths of local jail inmates and mortality rate per 100,000 local jail inmates, by cause of death, 2000–2018	
mlj0018stt09.csv	Table 9. Number of deaths of local jail inmates, by cause of death and decedent characteristics, 2000–2018			
mlj0018stt10.csv	Table 10. Average annual mortality rate per 100,000 local jail inmates, by cause of death and decedent characteristics, 2000–2018
mlj0018stt11.csv	Table 11. Cause of death of local jail inmates, by time served before death, 2000–2018
mlj0018stt12.csv	Table 12. Offenses of decedents, by time served before death, 2000–2018															
mlj0018stt13.csv	Table 13. Death location of local jail inmates, by cause of death, 2000–2018															
mlj0018stt14.csv	Table 14. Number of deaths and mortality rate per 100,000 local jail inmates, by hold status, 2014–2018															
mlj0018stt15.csv	Table 15. Number of deaths of local jail inmates, by size of jurisdiction, 2000 and 2008–2018															
mlj0018stt16.csv	Table 16. Mortality rate per 100,000 local jail inmates, by size of jurisdiction, 2000 and 2008–2018															
mlj0018stt17.csv	Table 17. Number and percent of local jail jurisdictions reporting to Mortality in Correctional Institutions, by number of deaths reported each year, 2000–2018	
mlj0018stt18.csv	Table 18. Number of local jail inmates held on an average day, by state, 2000 and 2008–2018															
mlj0018stt19.csv	Table 19. Number of deaths of local jail inmates, by state, 2000 and 2008–2018															
mlj0018stt20.csv	Table 20. Mortality rate per 100,000 local jail inmates, by state, 2000 and 2008–2018															
mlj0018stt21.csv	Table 21. Number of local jail jurisdictions reporting to Mortality in Correctional Institutions, by state, 2000 and 2008–2018	
mlj0018stt22.csv	Table 22. Number of local jail jurisdictions reporting one or more deaths to the Mortality in Correctional Institutions, by state, 2000 and 2008–2018	
mlj0018stt23.csv	Table 23. Preliminary number and percent of deaths in local jails, by selected causes of death, 2019															
																
			Figures															
mlj0018stf01.csv	Figure 1. Mortality rate per 100,000 local jail inmates, by cause of death, 2000–2018															
mlj0018stf02.csv	Figure 2. Percent of deaths of local jail inmates due to illness, by type of illness, 2000, 2010, and 2018
mlj0018stf03.csv	Figure 3. Number of jail inmate deaths, 2000, 2010, and 2018															
mlj0018stf04.csv	Figure 4. Adjusted mortality rate per 100,000 U.S. residents, by cause of death, 2018															
mlj0018stf05.csv	Figure 5. Number of deaths of local jail inmates, by cause of death, 2010 and 2018															
																
			Appendix tables															
mlj0018stat01.csv	Appendix table 1. Estimated number of local jail inmates in custody on an average day, by inmate characteristics, 2000–2018
mlj0018stat02.csv	Appendix table 2. Illness mortality rate per 100,000 local jail inmates within each demographic group, by decedent characteristics, 2008–2018 (3-year rolling averages)	
mlj0018stat03.csv	Appendix table 3. Heart disease mortality rate per 100,000 local jail inmates within each demographic group, by decedent characteristics, 2008–2018 (3-year rolling averages)
mlj0018stat04.csv	Appendix table 4. Suicide mortality rate per 100,000 local jail inmates within each demographic group, by decedent characteristics, 2008–2018 (3-year rolling averages)	
mlj0018stat05.csv	Appendix table 5. Mortality rate from accidents, homicides, or drug or alcohol intoxication per 100,000 local jail inmates within each demographic group, by decedent characteristics, 2008–2018 (3-year rolling averages)															
mlj0018stat06.csv	Appendix table 6. Rates for figure 1: Mortality rate per 100,000 local jail inmates, by cause of death, 2000–2018															
																
																
																
																
																
