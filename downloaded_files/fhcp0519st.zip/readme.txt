Federal Hate Crime Prosecutions, 2005-19 – Supplemental Tables   NCJ 301556	
	
This zip archive contains tables in individual  .csv spreadsheets	
Federal Hate Crime Prosecutions, 2005-19 – Supplemental Tables   NCJ 301556.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/federal-hate-crime-prosecutions-2005-19-supplemental-tables
	
Filename		Appendix table title
fhcp0519stat3a.csv	Appendix table 3a. Number of hate crime suspects referred to U.S. attorneys and hate crime defendants convicted in U.S. district court, by federal judicial district, fiscal years 2005–19
fhcp0519stat3b.csv	Appendix table 3b. Number of hate crime suspects referred to U.S. attorneys, by state or territory, fiscal years 2005–2019
fhcp0519stat3c.csv	Appendix table 3c. Number of hate crime defendants convicted in U.S. district court, by state or territory, fiscal years 2005–2019
