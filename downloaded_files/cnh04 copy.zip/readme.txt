Crime and the Nation's Households, 2004   NCJ  211511	

This zip archive contains tables in individual .csv spreadsheets
from Crime and the Nation's Households, 2004   NCJ  211511
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cnh04.htm

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cnh


Spreadsheets	

File Name	
	Highlights
cnh04ht.cvs	Highlight 1.  Percent of U. S. households experiencing violent or property crime

	Table Titles
cnh0401.cvs	Table 1.  Households experiencing crime, by type of crime, 2004
cnh0402.cvs	Table 2.  Households experiencing crime, by race of the household head, 2004
cnh0403.cvs	Table 3.  Households experiencing crime, by urban, suburban, and rural location, 2004
cnh0404.cvs	Table 4.  Households experiencing crime, by number of household members, 2004
cnh0405.cvs	Table 5.  Households experiencing crime, by type of crime, 1994 and 2004

	Text Titles
cnh04tt1.cvs	Text Table 1. Violent and Property Crime, 2003-2004
cnh04tt2.cvs	Text Table 2. Hispanic and Non-Hispanic, percent of households
cnh04tt3.cvs	Text Table 3. Percent of crimes by region, 2004

	Figures Titles
cnh04f1.cvs	Figure 1. Violence by strangers or burglary, 1994-2004
cnh04f2.cvs	Figure 2. Intimate partner violence, 1994-2004
