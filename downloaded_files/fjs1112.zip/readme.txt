Federal Justice Statistics, 2011-12 NCJ 248493

This zip archive contains tables in individual .csv spreadsheets		
from Federal Justice Statistics, 2011-12 NCJ 248493.
The full report including text and graphics in .pdf format is available at		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5218

This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=62			

File name		Table number
fjs1112t01.csv	    Table 1. Offenders in federal confinement or under federal supervision in the community, 2011 and 2012
fjs1112t02.csv      Table 2. Suspects arrested and booked by the U.S. Marshals Service, by offense and federal judicial district at arrest, 2010, 2011, and 2012
fjs1112t03.csv      Table 3. Suspects arrested and booked by the U.S. Marshals Service, by arresting agency, 2008, 2011, and 2012
fjs1112t04.csv      Table 4. Characteristics of suspects arrested by the Drug Enforcement Administration, by type of drug, 2012
fjs1112t05.csv      Table 5. Suspects in matters concluded by U.S. attorneys, by referring authority, 2001, 2008, 2011, and 2012
fjs1112t06.csv      Table 6. Suspects in matters concluded by U.S. attorneys, by offense type, 2008, 2011, and 2012
fjs1112t07.csv      Table 7. Outcome and case processing time of suspects in matters concluded, 2012
fjs1112t08.csv      Table 8. Outcomes of suspects in matters concluded by Department of Homeland Security and Department of Justice, 2012
fjs1112t09.csv      Table 9. Defendants detained at any time prior to case termination, 2012
fjs1112t10.csv      Table 10. Demographic characteristics of federal defendants charged in U.S. district court, by sex, 2012
fjs1112t11.csv      Table 11. Disposition and case processing time of defendants in cases terminated in U.S. district court, 2012
fjs1112t12.csv      Table 12. Disposition and sentence received in cases terminated in U.S. district court, 2008, 2011, and 2012
fjs1112t13.csv      Table 13. Defendants convicted and sentenced to a federal prison term, by type of offense, 2008 and 2012
fjs1112t14.csv      Table 14. Characteristics of federally sentenced offenders in the custody of the Federal Bureau of Prisons, 2002, 2011, and 2012
fjs1112t15.csv      Table 15. Offenders returning to federal prison within 3 years of release from a U.S. district court commitment, 2012
fjs1112t16.csv      Table 16. Characteristics of offenders under post-conviction federal supervision, 2012

File name		Map number
fjs1112m01.csv	    Map 1. Number of suspects arrested and booked by the U.S. Marshals Service, 2012
fjs1112m02.csv	    Map 2. Number of suspects arrested and booked by the U.S. Marshals Service for an immigration offense by district of arrest, 2008-2012
fjs1112m03.csv	    Map 3. Number of suspects arrested and booked by the U.S. Marshals Service for a federal sex offense by district of arrest, 2008-2012
fjs1112m04.csv	    Map 4. Suspects arrested for federal drug offense as a percent of the total arrests in a federal judicial district, 2008-2012
fjs1112m05.csv	    Map 5. Number of suspects referred to U.S. attorneys, 2012
fjs1112m06.csv	    Map 6. Percent of felony cases disposed in U.S. district court ending in a guilty plea by federal judicial district, 2012
fjs1112m07.csv	    Map 7. Offenders in federal prison by judicial district of commitment, 2012
fjs1112m08.csv	    Map 8. Percent of offenders returning to federal prison within 3 years by federal district of commitments: 2010 release cohort, new offense only
fjs1112m09.csv	    Map 9. Percent of offenders returning to federal prison within 3 years by federal district of commitments: 2010 release cohort, supervision violations only

File name		Figure number
fjs1112f01.csv	    Figure 1. Suspects and defendants processed in the federal justice system, 1994�2012
fjs1112f02.csv	    Figure 2. Suspects arrested and booked by the U.S. Marshals Service for an immigration offense, 1994�2012
fjs1112f03.csv	    Figure 3. Suspects arrested and booked by the U.S. Marshals Service for a federal sex offense, 1994�2012
fjs1112f04.csv	    Figure 4. Suspects arrested and booked by the U.S. Marshals Service for a drug offense, 1994�2012
fjs1112f05.csv	    Figure 5. Suspects arrested by the Drug Enforcement Administration, by drug type, 1994�2012
fjs1112f06.csv	    Figure 6. Females arrested by the DEA, by race and Hispanic origin, 1994�2012
fjs1112f07.csv	    Figure 7. Males arrested by the DEA, by race and Hispanic origin, 1994�2012
fjs1112f08.csv	    Figure 8. Median days from receipt of matter to disposition, 1994�2012
fjs1112f09.csv	    Figure 9. Defendants in cases filed in U.S. district court, by most serious offense, 1994�2012
fjs1112f10.csv	    Figure 10. Country of citizenship of offenders charged in U.S. district court, 2012
fjs1112f11.csv	    Figure 11. Median days from felony case filing to case termination by mode of disposition, 1994�2012
fjs1112f12.csv	    Figure 12. Median days from case filing to case termination for guilty pleas, by offense and U.S.-Mexico border district, 2012
fjs1112f13.csv	    Figure 13. Median prison sentence imposed, by most serious offense at sentencing, 1994�2012
fjs1112f14.csv	    Figure 14. Federally sentenced prisoners in the custody of the Federal Bureau of Prisons, by offense, 2002 and 2012
fjs1112f15.csv	    Figure 15. Federally sentenced offenders in the custody of the Federal Bureau of Prisons, by country of citizenship, 2012
fjs1112f16.csv	    Figure 16. Percent of offenders returning to federal prison after release from a U.S. district court commitment, by time to return, 1998�2012
fjs1112f17.csv	    Figure 17. Percent of offenders returning to federal prison within 3 years of release, by type of offense at release and type of return, 2010
fjs1112f18.csv	    Figure 18. Offenders under federal supervision, by type of offense, 2002 and 2012 







