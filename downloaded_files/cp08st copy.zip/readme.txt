Capital Punishment, 2008 - Statistical Tables  NCJ 228662

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2008 - Statistical Tables  NCJ 228662, electronic only. 
The full electronic report is available at:
http://www.bjs.ojp.usdoj.gov/?cp07st.htm

These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://ojp.usdoj.gov/bjs/pubalp2.htm#cp


Tables:
cp08st04.csv		Table 4.  Prisoners under sentence of death, by region, jurisdiction, and race, 2007 and 2008
cp08st05.csv		Table 5.  Demographic characteristics of prisoners under sentence of death, 2008
cp08st06.csv		Table 6.  Persons of Hispanic origin and women under sentence of death, by jurisdiction, 2007 and 2008
cp08st07.csv		Table 7.  Age at time of arrest for capital offense and age of prisoners under sentence of death at yearend 2008
cp08st08.csv		Table 8.  Criminal history profile of prisoners under sentence of death, by race and Hispanic origin, 2008
cp08st09.csv		Table 9.  Number of persons executed, by jurisdiction, 1930-2008
cp08st10.csv		Table 10. Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2008
cp08st11.csv		Table 11. Time under sentence of death and execution, by race, 1977-2008
cp08st12.csv		Table 12. Women under sentence of death, by race and jurisdiction, 12/31/08
cp08st13.csv		Table 13. Persons under sentence of death, by gender, race, and Hispanic origin, 12/31/08
cp08st14.csv		Table 14. Number of inmates received under sentence of death, 1995-2008
cp08st15.csv		Table 15. Number of persons executed, 1977-2008
cp08st16.csv		Table 16. Number of persons executed by race, Hispanic origin, and method, 1977-2008
cp08st17.csv		Table 17. Elapsed time since sentencing for inmates under sentence of death on 12/31/08, by gender, race, and Hispanic origin
cp08st18.csv		Table 18. Advance count of executions, by jurisdiction, January 1, 2009 - December 31, 2009

