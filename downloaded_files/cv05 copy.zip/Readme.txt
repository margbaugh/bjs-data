Criminal Victimization, 2005     NCJ  214644			

This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization,  2005,   NCJ  214644.  The full report including text			
and graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/cv05.htm			

This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cv			


Filename			Table title
cv05t01.cvs			Table  1:   Criminal victimization, number and rates, 2004 and 2005
cv05t02.cvs			Table  2:   Criminal victimization, average annual rates, 2002-2003 and 2004-05
cv05t03.cvs			Table  3:   Rates of criminal victimization and percent change, 1993-2005
cv05t04.cvs			Table  4:   Violent victimization rates of selected demographic categories, 1993-2005
cv05t05.cvs			Table  5:   Property crime rates of selected household demographics, 1993-2005
cv05t06.cvs			Table  6:   Rates of violent crime and personal theft, by gender, race, Hispanic origin, and age, 2005
cv05t07.cvs			Table  7:   Rates of violent crime and personal theft, by household income, marital status, region, and location of residence of victims, 2005
cv05t08.cvs			Table  8:   Property crime victimization, by household income, region, residence, and home ownership of households victimized, 2005
cv05t09.cvs			Table  9:   Victim and offender relationship, 2005
cv05t10.cvs			Table 10:  Presence of weapons in violent incidents, 2005


Highlights tables			
cv05h01.cvs			Highlight table  1:    Violent victimizations
cv05h02.cvs			Highlight table  2:    Property  victimizations

			Figures
cv05f01.cvs			Figure   1:   Violent crime
cv05f02.cvs			Figure   2:   Property crimes
cv05f03.cvs			Figure   3:   Violent crime and gender
cv05f04.cvs			Figure   4:   Property crimes and owned/rented residences
cv05f05.cvs			Figure   5:   Property crimes and urbanicity
cv05f06.cvs			Figure   6:   Property crimes and region
cv05f07.cvs			Figure   7:   Percent of violent and property crimes reported to the police 
cv05f08.cvs			Figure   8:   Percent of robberies and rapes/sexual assaults reported to the police
cv05f09.cvs			Figure   9:   Percent of aggravated and simple assaults reported to the police
cv05f10.cvs			Figure  10:   Percent of burglaries reported to the police 
cv05f11.cvs			Figure  11:   Percent of motor vehicle theft reported to the police  
cv05f12.cvs			Figure  12:   Percent of household thefts reported to the police

			Text tables
cv05tt01.cvs			Text Table  1:   Violent crime average rate by gender, 2002-2003 to 2004-05
cv05tt02.cvs			Text Table  2:   Violent crime average rate by marital status, 2002-2003 to 2004-05
cv05tt03.cvs			Text Table  3:   Violent crime average rate by age, 2002-2003 to 2004-05
cv05tt04.cvs			Text Table  4:   Violent crime average rate by annual household income, 2002-2003 to 2004-05
cv05tt05.cvs			Text Table  5:   Violent crime average rate by region, and residence, 2002-2003 to 2004-05
cv05tt06.cvs			Text Table  6:   Property crime average rate by annual household income, 2002-2003 to 2004-05
cv05tt07.cvs			Text Table  7:   Property crime average rate by region, residence and ownership, 2002-2003 to 2004-05
cv05tt08.cvs			Text Table  8:   Nonfatal firearm incidents and victims, 1993 and 2005
cv05tt09.cvs			Text Table  9:   Violent and property crimes reported to the police, 2005
cv05tt10.cvs			Text Table 10:  Reporting to the police by victim characteristics, 2005
