Census of Publicly Funded Forensic Crime Laboratories, 2005		

This zip archive contains tables in individual .csv spreadsheets		
from Census of Publicly Funded Forensic Crime Laboratories, 2005, NCJ 222181.		
The full report including text and graphics in .pdf format are available at		
http://www.ojp.usdoj.gov/bjs/abstract/cpffcl05.htm		

Filename		Table number
cpffcl05t01.csv		Table 1. Full-time employees in the nation's publicly funded crime laboratories in 2005 and 2002, by type of jurisdiction
cpffcl05t02.csv		Table 2. Positions of employees in publicly funded crime laboratories in 2005, by type of jurisdiction 
cpffcl05t03.csv		Table 3. Total operating budget (in millions) for publicly funded crime laboratories in 2005 and 2002, by type of jurisdiction
cpffcl05t04.csv		Table 4. Median base salaries of employees in publicly funded crime laboratories in 2005, by type of jurisdiction
cpffcl05t05.csv		Table 5. Percent of crime laboratories accredited by a professional organization in 2005 and 2002
cpffcl05t06.csv		Table 6. Forensic functions performed by crime laboratories in 2005, by type of jurisdiction
cpffcl05t07.csv		Table 7. Cases received by publicly funded crime laboratories during 2005 and 2002, by type of jurisdiction
cpffcl05t08.csv		Table 8. Cases backlogged in publicly funded crime laboratories at yearend 2005 and 2002, by type of jurisdiction
cpffcl05t09.csv		Table 9. Median number of requests for forensic services and yearend backlog in 2005, by type of request
cpffcl05t10.csv		Table 10. Percent of total forensic requests backlogged at yearend 2005 and 2002, by type of request
cpffcl05t11.csv		Table 11. Percent of crime laboratories with a Laboratory Information Management System (LIMS) in 2005 and 2002, by type of jurisdiction
cpffcl05t12.csv		Table 12. Percent of publicly funded crime laboratories outsourcing requests for forensic services in 2005 and 2002
cpffcl05t13.csv		Table 13. Response rates for the Census of Publicly Funded Forensic Crime Laboratories, 2005 and 2002
cpffcl05t14.csv		Table 14. Imputation procedures for national estimates

			Figure number
cpffcl05f01.csv		Figure 1. The nation's crime laboratories experienced an increase in the median number of backlogged requests during 2005
cpffcl05f02.csv		Figure 2. Types of requests backlogged at the end of 2005
cpffcl05f03.csv		Figure 3. Mean number of requests completed per full-time examiner in 2005
cpffcl05f04.csv		Figure 4. Percent increase in full-time examiners needed to achieve a 30-day turnaround on all requests in 2005

			Appendix table number
cpffcl05at01.csv	Appendix table 1. Number of requests for forensic services and yearend backlog in 2005, by type of request
cpffcl05at02.csv	Appendix table 2. Mean number of requests completed per full-time examiner in 2005, by type of request 
cpffcl05at03.csv	Appendix table 3. Percent increase in full-time examiners needed to achieve a 30-day turnaround on all requests in 2005, by type of request

