Correctional Populations in the United States, 2019 - Statistical Tables  NCJ 300655		
		
This zip archive contains tables in individual .csv spreadsheets		
from Correctional Populations in the United States, 2019 - Statistical Tables  NCJ 300655		
The full report including text and graphics in pdf format is available from:		
https://bjs.ojp.gov/library/publications/correctional-populations-united-states-2019-statistical-tables		
		
These statistical tables are in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://bjs.ojp.gov/library/publications/list?series_filter=Correctional%20Populations%20in%20the%20United%20States		
		
			Tables names	
cpus19stt01.csv		Table 1. Number of persons supervised by adult correctional systems in the U.S., by correctional status, 2009-2019	
cpus19stt02.csv		Table 2. Change in the number of persons supervised by adult correctional systems in the U.S., 2009-2019	
cpus19stt03.csv		Table 3. Composition of the adult correctional system in the U.S., by correctional status, 2009 and 2019 	
cpus19stt04.csv		Table 4. Rate of persons supervised by adult correctional systems in the U.S., by correctional status, 2009–2019	
cpus19stt05.csv		Table 5. Number of offenders with dual correctional statuses at year-end, 2009-2019	
		
			Figure	
cpus19stf01.csv		Figure 1. Number of persons under the supervision of adult correctional systems in the U.S., 2009-2019	
		
			Appendix tables	
cpus19stat01.csv	Appendix Table 1. Number and rate of persons supervised by adult correctional systems in the U.S., by jurisdiction and correctional status, 2019	
cpus19stat02.csv	Appendix Table 2. Number of persons incarcerated by other adult correctional systems, 2009 and 2018-2019	
cpus19stat03.csv	Appendix Table 3. Custody counts of adults in state or federal prisons or local jails, 2009 and 2018-2019	
cpus19stat04.csv	Appendix Table 4. Standard errors for local jail inmates at midyear, 2009-2019	
