Stalking Victimization in the United States     NCJ  224527			
			
This zip archive contains tables in individual  .csv spreadsheets			
"from Stalking Victimization in the United States, NCJ  224527.  "			
The full report including text and graphics in pdf format are available			
from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=1211			
			
			
Filename			Table title
svusrevt01.csv			Table 1. Distribution of spam in unweighted prevalence estimates of stalking and harassment
svusrevt02.csv			Table 2. Populations for persons ages 12 or older and 18 or older by selected characteristics
svusrevt03.csv			Table 3. Prevalence of stalking and harassment over the 12 months prior to interview
svusrevt04.csv			Table 4. Nature of stalking and harassment behaviors experienced by victims
svusrevt05.csv			Table 5. Characteristics of stalking and harassment victims
svusrevt06.csv			Table 6. Victim-offender relationship in stalking and harassment
			
			
svusrevat01.csv		Appendix table 1. Standard errors for table 3: Prevalence of stalking and harassment over the 12 months prior to interview	
svusrevat02.csv		Appendix table 2. Standard errors for figure 1: Duration of stalking and harassment victimization	
svusrevat03.csv		Appendix table 3. Standard errors for table 4: Nature of stalking and harassment behaviors experienced by victims	
svusrevat04.csv		Appendix table 4. Standard errors for table 5: Characteristics of stalking and harassment victims	
svusrevat05.csv		Appendix table 5. Standard errors for table 6: Victim-offender relationship in stalking and harassment	
			
Figures			
svusrevf01.csv			Figure 1. Duration of stalking and harassment victimization 
