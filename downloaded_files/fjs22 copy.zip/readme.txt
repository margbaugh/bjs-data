Federal Justice Statistics, 2022  NCJ 307553	
	
This zip archive contains tables in individual .csv spreadsheets	
from Federal Justice Statistics, 2022  NCJ 307553.	
The full report including text and graphics in .pdf format is available at	
https://bjs.ojp.gov/library/publications/federal-justice-statistics-2022	
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Justice%20Statistics	
	
Filenames	Table titles
fjs22t01.csv	Table 1. Persons in federal confinement or under federal supervision in the community, fiscal year-end 2012, 2021, and 2022
fjs22t02.csv	Table 2. Federal arrests, by most serious offense and judicial district, FY 2021 and FY 2022
fjs22t03.csv	Table 3. Suspects in matters opened by U.S. attorneys, by referring authority, FY 2012, FY 2021, and FY 2022
fjs22t04.csv	Table 4. Outcome and case-processing time of suspects in matters concluded, by lead charge and judicial district, FY 2022
fjs22t05.csv	Table 5. Defendants charged in U.S. district court, by sex and demographic characteristics, FY 2022
fjs22t06.csv	Table 6. Disposition and case-processing time of defendants in cases adjudicated in U.S. district court, by most serious offense and judicial district, FY 2022
fjs22t07.csv	Table 7. Type and length of sentence imposed for convicted defendants, by most serious offense and judicial district, FY 2022
fjs22t08.csv	Table 8. Type and length of sentence imposed for convicted defendants, by demographic characteristics, FY 2022
fjs22t09.csv	Table 9. Federally sentenced persons admitted to and released from the Federal Bureau of Prisons, by most serious commitment offense, FY 2022
fjs22t10.csv	Table 10. Federally sentenced persons in the custody of the Federal Bureau of Prisons, by demographic characteristics, fiscal year-end 2012 and 2022
fjs22t11.csv	Table 11. Federally sentenced persons in the custody of the Federal Bureau of Prisons, by most serious commitment offense and race or ethnicity, fiscal year-end 2022
fjs22t12.csv	Table 12. Time served by persons released by standard means from the Federal Bureau of Prisons, by commitment offense and demographic characteristics, FY 2022
fjs22t13.csv	Table 13. Persons under post-conviction federal supervision, by demographic characteristics, fiscal year-end 2022
	
		Figures
fjs22f01.csv	Figure 1. Suspects and defendants processed in the federal criminal justice system, FY 2000–2022
fjs22f02.csv	Figure 2. Suspects investigated and arrested in the federal criminal justice system, October 1, 2019–September 30, 2022
fjs22f03.csv	Figure 3. Defendants charged, convicted, and sentenced to prison in the federal criminal justice system, October 1, 2019–September 30, 2022
fjs22f04.csv	Figure 4. Federal and state arrests by the Drug Enforcement Administration involving powder cocaine, crack cocaine, heroin, and other opioids, FY 2012–2022
fjs22f05.csv	Figure 5. Federal and state arrests by the Drug Enforcement Administration involving marijuana, methamphetamine, and other nonopioids, FY 2012–2022
fjs22f06.csv	Figure 6. Defendants in criminal cases filed in U.S. district court, by most serious offense, FY 2012–2022
fjs22f07.csv	Figure 7. Defendants charged in U.S. district court, by sex and most serious offense, FY 2022
fjs22f08.csv	Figure 8. Federally sentenced persons in the custody of the Federal Bureau of Prisons, by most serious commitment offense, fiscal year-end 2012 and 2022
fjs22f09.csv	Figure 9. Federally sentenced persons released by standard means from the Federal Bureau of Prisons, by most serious commitment offense and time served, FY 2022
fjs22f10.csv	Figure 10. Persons under federal supervision in the community, by commitment offense, fiscal year-end 2012 and 2022
fjs22f11.csv	Figure 11. Universe of prisoners held under the Federal Bureau of Prisons’ jurisdiction, fiscal year-end 2022
	
		Appendix tables
fjs22at01.csv	Appendix Table 1. Counts for figure 1: Suspects and defendants processed in the federal criminal justice system, FY 2000–2022
fjs22at02.csv	Appendix Table 2. Counts for figures 2 and 3: Suspects investigated and arrested and defendants charged, convicted, and sentenced to prison in the federal criminal justice system, October 1, 2019–September 30, 2022
fjs22at03.csv	Appendix Table 3. Counts for figures 4 and 5: Federal and state arrests by the Drug Enforcement Administration involving powder cocaine, crack cocaine, heroin, other opioids, marijuana, methamphetamine, and other nonopioids, FY 2012–2022
fjs22at04.csv	Appendix Table 4. Counts for map 1: Federal arrests, by judicial district, FY 2022
fjs22at05.csv	Appendix Table 5. Counts for figure 6: Defendants in criminal cases filed in U.S. district court, by most serious offense, FY 2012–2022
fjs22at06.csv	Appendix Table 6. Percentages for figure 7: Defendants charged in U.S. district court, by sex and most serious offense, FY 2022
fjs22at07.csv	Appendix Table 7. Percentages for figure 8: Federally sentenced persons in the custody of the Federal Bureau of Prisons, by most serious commitment offense, fiscal year-end 2012 and 2022
fjs22at08.csv	Appendix Table 8. Counts for map 2: Federally sentenced persons in the custody of the Federal Bureau of Prisons, by judicial district of commitment, fiscal year-end 2022
fjs22at09.csv	Appendix Table 9. Percentages for figure 9: Federally sentenced persons released by standard means from the Federal Bureau of Prisons, by most serious commitment offense and time served, FY 2022
fjs22at10.csv	Appendix Table 10. Percentages for figure 10: Persons under federal supervision in the community, by commitment offense, fiscal year-end 2012 and 2022
