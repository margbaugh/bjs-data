Bureau of Justice Statistics
Law Enforcement Management and Administrative Statistics, 1999:
Data for Individual State and Local Agencies with 100 or more Officers
By Brian A. Reaves, Ph.D. and Timothy C. Hart, BJS Statisticians

Contents of Zip archive lema993b.zip.  This file contains the tables from one section of the
report.  Additional tables are available at www.ojp.usdoj.gov/bjs/abstract/lemas99.htm.

STATE AGENCIES

III.  OPERATIONS                

lem9908b.wk1 Number of district/precinct stations separate from headquarters, and types of
patrol used, 1999                    

lem9909b.wk1 Number and percent of officers assigned to respond to calls for service, type of 
9-1-1 system, and number of telephone calls for service received, 1999   
                  
lem9910b.wk1 Criminal investigation and investigative support function, 1999

lem9911b.wk1  Traffic and vehicle-related functions, 1999

lem9912b.wk1  Special operations, special enforcement, and 
special public safety functions, 1999

lem9913b.wk1  Court-related, detention-related, dispatch, and training academy functions, 1999

