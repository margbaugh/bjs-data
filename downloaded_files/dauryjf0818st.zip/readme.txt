Drug and Alcohol Use Reported by Youth in Juvenile Facilities, 2008–2018 – Statistical Tables   NCJ 305814
																		
This .zip archive contains tables in individual  .csv spreadsheets																		
Drug and Alcohol Use Reported by Youth in Juvenile Facilities, 2008–2018 – Statistical Tables   NCJ 305814. The full report including text
and graphics in .pdf format is available from: https://bjs.ojp.gov/library/publications/drug-and-alcohol-use-reported-youth-juvenile-facilities-2008-2018-statistical
								
Filenames		Table titles																	
dauryjf0818stt01.csv	Table 1. Youth drug and alcohol use, by survey year, 2008–09, 2012, and 2018																	
dauryjf0818stt02.csv	Table 2. Youth drug and alcohol use, by sex and age admitted to juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stt03.csv	Table 3. Youth drug and alcohol use, by race or Hispanic origin, 2008–09, 2012, and 2018
dauryjf0818stt04.csv	Table 4. Youth drug and alcohol use, by sexual orientation and gender identity, 2008–09, 2012, and 2018
dauryjf0818stt05.csv	Table 5. Youth drug and alcohol use, by prior experience of sexual victimization, 2008–09, 2012, and 2018
dauryjf0818stt06.csv	Table 6. Youth drug and alcohol use, by most serious sentencing offense and length of stay in juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stt07.csv	Table 7. Youth drug and alcohol use, by agency operating juvenile facility and U.S. Census region, 2008–09, 2012, and 2018
dauryjf0818stt08.csv	Table 8. Youth drug use, by type of drug, sex, and age admitted to juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stt09.csv	Table 9. Youth drug use, by type of drug and race or Hispanic origin, 2008–09, 2012, and 2018
dauryjf0818stt10.csv	Table 10. Youth substance or alcohol use disorder, by survey year, 2008–09, 2012, and 2018
dauryjf0818stt11.csv	Table 11. Youth substance or alcohol use disorder, by sex and age admitted to juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stt12.csv	Table 12. Youth substance or alcohol use disorder, by race or Hispanic origin, 2008–09, 2012, and 2018
dauryjf0818stt13.csv	Table 13. Youth substance or alcohol use disorder, by sexual orientation and gender identity, 2008–09, 2012, and 2018
dauryjf0818stt14.csv	Table 14. Youth substance or alcohol use disorder, by prior experience of sexual victimization, 2008–09, 2012, and 2018
dauryjf0818stt15.csv	Table 15. Youth substance or alcohol use disorder, by most serious sentencing offense and length of stay in juvenile facility, 2008–09, 2012, and 2018
																	
			Figures																	
dauryjf0818stf01.csv	Figure 1. Prior drug and alcohol use and use disorder among youth in juvenile facilities, 2008–09, 2012, and 2018
																		
			Appendix tables																	
dauryjf0818stat01.csv	Appendix table 1. DSM-5 criteria and NSYC-A questions to determine substance and alcohol use disorder in youth in juvenile facilities
dauryjf0818stat02.csv	Appendix table 2. Standard errors for table 1: Youth drug and alcohol use, by survey year,  2008–09, 2012, and 2018
dauryjf0818stat03.csv	Appendix table 3. Standard errors for table 2: Youth drug and alcohol use, by sex and age admitted to juvenile facility,  2008–09, 2012, and 2018
dauryjf0818stat04.csv	Appendix table 4. Standard errors for table 3: Youth drug and alcohol use, by race or Hispanic origin,  2008–09, 2012, and 2018
dauryjf0818stat05.csv	Appendix table 5. Standard errors for table 4: Youth drug and alcohol use, by sexual orientation and gender identity, 2008–09, 2012, and 2018
dauryjf0818stat06.csv	Appendix table 6. Standard errors for table 5: Youth drug and alcohol use, by prior experience of sexual victimization, 2008–09, 2012, and 2018
dauryjf0818stat07.csv	Appendix table 7. Standard errors for table 6: Youth drug and alcohol use, by most serious sentencing offense and length of stay in juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stat08.csv	Appendix table 8. Standard errors for table 7: Youth drug and alcohol use, by agency operating juvenile facility and U.S. Census region, 2008–09, 2012, and 2018
dauryjf0818stat09.csv	Appendix table 9. Standard errors for table 8: Youth drug use, by type of drug, sex, and age admitted to juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stat10.csv	Appendix table 10. Standad errors for table 9: Youth drug use, by type of drug and race or Hispanic origin, 2008–09, 2012, and 2018
dauryjf0818stat11.csv	Appendix table 11. Standard errors for table 10: Youth substance or alcohol use disorder, by survey year, 2008–09, 2012, and 2018
dauryjf0818stat12.csv	Appendix table 12. Standard errors for table 11: Youth substance or alcohol use disorder, by sex and age admitted to juvenile facility, 2008–09, 2012, and 2018
dauryjf0818stat13.csv	Appendix table 13. Standard errors for table 12: Youth substance or alcohol use disorder, by race or Hispanic origin, 2008–09, 2012, and 2018
dauryjf0818stat14.csv	Appendix table 14. Standard errors for table 13: Youth substance or alcohol use disorder, by sexual orientation and gender identity, 2008–09, 2012, and 2018
dauryjf0818stat15.csv	Appendix table 15. Standard errors for table 14: Youth who met criteria for a substance or alcohol use disorder, by prior experience of sexual victimization, 2008–09, 2012, and 2018
dauryjf0818stat16.csv	Appendix table 16. Standard errors for table 15: Youth substance or alcohol use disorder, by most serious sentencing offense and length of stay in juvenile facility, 2008–09, 2012, and 2018