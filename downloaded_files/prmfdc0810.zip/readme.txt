Pretrial Release and Misconduct in Federal District Courts, 2008-2010		
		
This zip archive contains tables in individual  .csv spreadsheets		
from  Pretrial Release and Misconduct in Federal District Courts, 2008-2010  NCJ 239243.  The full report including text		
and graphics in pdf format is available at: http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=4535		
		
Filename		Table titles
		
prmfdc0810t01.csv		Table 1. Defendants released pretrial for cases disposed in federal district courts, by offense type and stage of appearance, FY 2008�2010
prmfdc0810t02.csv		Table 2. Defendants released pretrial for cases in federal courts and in state courts in the 75 most populous counties, by most serious offense charged 
prmfdc0810t03.csv		Table 3. Types of pretrial release for cases disposed in federal district courts, by offense type, FY 2008�2010
prmfdc0810t04.csv		Table 4. Type of pretrial detention for cases disposed in federal district courts, by offense type, FY 2008�2010
prmfdc0810t05.csv		Table 5. Pretrial conditions imposed on defendants released for cases disposed in federal district courts, by offense type, FY 2008�2010
prmfdc0810t06.csv		Table 6. Types of pretrial conditions imposed on defendants released for cases disposed in federal district courts, by type of offense, FY 2008�2010
prmfdc0810t07.csv		Table 7. Average length of stay in detention for persons booked by the U.S. Marshals Service, by offense at booking, FY 2008�2010
prmfdc0810t08.csv		Table 8. Defendants released pretrial for cases disposed in federal district courts, by criminal history and most serious offense charged, FY 2008�2010
prmfdc0810t09.csv		Table 9. Defendants released pretrial for cases disposed in federal district courts, by demographic characteristics, citizenship status, and most serious offense charged, FY 2008�2010
prmfdc0810t10.csv		Table 10. Race and ethnicity of defendants for cases disposed in federal district courts, by criminal history and citizenship status, FY 2008�2010
prmfdc0810t11.csv		Table 11. Behavior of defendants released pretrial for cases disposed in federal district courts, by offense type, FY 2008�2010
prmfdc0810t12.csv		Table 12. Misconduct of defendants released pretrial for cases disposed in federal district courts, by criminal history, FY 2008�2010
prmfdc0810t13.csv		Table 13. Misconduct of defendants released pretrial for cases disposed in federal district courts, by demographic characteristics and citizenship status, FY 2008�2010
prmfdc0810t14.csv		Table 14. Misconduct of defendants released pretrial for cases disposed in federal district courts, by type of pretrial release, FY 2008�2010
		
		Figure titles
prmfdc0810f01.csv		Figure 1. Defendants released pretrial for cases disposed in federal district courts, by offense type, FY 2008�2010
prmfdc0810f02.csv		Figure 2. Types of pretrial release for cases disposed in federal district courts, FY 2008�2010
prmfdc0810f03.csv		Figure 3. Defendants released at initial appearance and released after period of detention for cases disposed in federal district courts, by type of pretrial release, FY 2008�2010
prmfdc0810f04.csv		Figure 4. Pretrial conditions imposed on released defendants for cases disposed in federal district courts, by type of pretrial release, FY 2008�2010
prmfdc0810f05.csv		Figure 5. Percent of defendants released pretrial for cases disposed in federal district courts, by age of defendant, FY 2008�2010
