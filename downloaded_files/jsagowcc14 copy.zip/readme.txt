Jurisdiction of State Attorneys General Offices over White-Collar Crime, 2014		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Jurisdiction of State Attorneys General Offices over White-Collar Crime, 2014, NCJ 251144. The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6866		
		
		
Filename		Table title
jsagowcc14t01.csv	Table 1. Number of attorneys general offices that reported handling criminal white-collar offenses, by type of offense, 2014
jsagowcc14t02.csv	Table 2. Number of attorneys general offices that reported handling civil white-collar offenses, by type of offense, 2014
jsagowcc14t03.csv	Table 3. Number of attorneys general offices that reported sanctions for criminal white-collar offenses with findings of guilt, by type of sanction, 2014
jsagowcc14t04.csv	Table 4. Number of attorneys general offices that reported sanctions for civil white-collar offenses with findings of liability, by type of sanction, 2014
jsagowcc14t05.csv	Table 5. Number of attorneys general offices that received referrals of criminal or civil white-collar cases, by source of referral, 2014
jsagowcc14t06.csv	Table 6. Number of attorneys general offices referring criminal or civil white-collar cases, by recipient of referral, 2014
jsagowcc14t07.csv	Table 7. Number of attorneys general offices, by white-collar specializations and responsibilities, 2014
		
		
			Appendix tables
jsagowcc14at01.csv	Appendix table 1. Criminal white-collar cases handled by attorneys general offices, by type of case and state, 2014
jsagowcc14at02.csv	Appendix table 2. Civil white-collar offenses handled by attorneys general offices, by type of case and state, 2014
jsagowcc14at03.csv	Appendix table 3. Sanctions in criminal white-collar cases handled by attorneys general offices with findings of guilt, by type of sanction and state, 2014
jsagowcc14at04.csv	Appendix table 4. Sanctions in civil white-collar cases handled by attorneys general offices with findings of liability, by type of sanction and state, 2014
jsagowcc14at05.csv	Appendix table 5. Referrals of criminal or civil white-collar cases to attorneys general offices, by criminal justice source of referral and state, 2014
jsagowcc14at06.csv	Appendix table 6. Referrals of criminal or civil white-collar cases to attorneys general offices, by non-criminal justice source of referral and state, by state, 2014
jsagowcc14at07.csv	Appendix table 7. Reasons attorneys general offices referred white-collar cases to the Office of the U.S. Attorney, by state, 2014
jsagowcc14at08.csv	Appendix table 8. Reasons attorneys general offices referred white-collar cases to local prosecutors, by state, 2014
jsagowcc14at09.csv	Appendix table 9. Reasons attorneys general offices referred white-collar cases to state regulatory agencies, by state, 2014
jsagowcc14at10.csv	Appendix table 10. White-collar specializations and responsibilities of attorneys general offices, by state, 2014
