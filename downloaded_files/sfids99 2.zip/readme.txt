State-Funded Indigent Defense Services, 1999,   NCJ 188464

This zip archive contains tables in individual .wk1 spreadsheets
from State-Funded Indigent Defense Services, 1999,   NCJ 188464.
The full report including text and graphics in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/sfids99.htm 

Filename	   Table

sfids1.wk1     Table 1.   State-funded indigent criminal defense services 1982 and 1999
sfids2.wk1     Table 2.   Expenditures for State-funded indigent criminal defense services, by type of program, 1999
sfids3.wk1     Table 3.   Characteristics of State-funded public defender programs, 1999
sfids4.wk1     Table 4.  Characteristics of chief public defenders in State-funded  systems, 1999
sfids5.wk1     Table 5.   Annual salary of assistant public defenders and supervisory attorneys in State-funded systems, 1999
sfids6.wk1     Table 6.   State-funded public defender programs, by type of staff, 1999
sfids7.wk1     Table 7.   Cases received by State-funded public defender programs, 1999
sfids8.wk1     Table 8.   Source of appointment for private attorneys to provide indigent criminal defense services in State-funded systems, 1999
sfids9.wk1     Table 9.   Private attorney roster in State-funded assigned counsel programs, 1999
sfids10.wk1    Table 10.   Private attorney appointments and cases received by assigned counsel programs in State-funded systems, 1999
sfids11.wk1    Table 11.   Contract attorney programs in State-funded systems, 1999
sfids12.wk1    Table 12.   Contracts awarded in State-funded systems, 1999
sfids13.wk1    Table 13.   Cases received by contract attorneys in State-funded systems, 1999
