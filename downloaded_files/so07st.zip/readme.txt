Sheriffs' Offices, 2007 - Statistical Tables     NCJ  238558
			
This zip archive contains tables in individual  .csv spreadsheets			
from Sheriffs' Offices, 2007 - Statistical Tables NCJ  238558. The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4555	

This report is one in series. More recent editions may be available. To view a list 
of all reports in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=45		
			
			
			
Filename			Table title
so07stt01.csv			Table 1. General purpose state and local law enforcement agencies sworn and civilian personnel, by employment status and type of agency, 2007
so07stt02.csv			Table 2. Sheriffs� offices and full-time personnel, by number of sworn personnel, 2007 
so07stt03.csv			Table 3. Sheriffs� offices and full-time personnel, by size of population served, 2007
so07stt04.csv			Table 4. Annual operating budget of sheriffs' offices, by size of population served, 2007
so07stt05.csv			Table 5. Drug asset forfeiture receipts of sheriffs' offices, by size of population served, 2006
so07stt06.csv			Table 6. Average base annual salary for selected full-time positions in sheriffs' offices, by size of population served, 2007
so07stt07.csv			Table 7. Special pay and benefits for full-time sworn personnel in sheriffs' offices, by size of population served, 2007
so07stt08.csv			Table 8. Education requirements for new deputies in sheriffs� offices, by size of population served, 2007
so07stt09.csv			Table 9. Background and record check methods used in selection of new deputy recruits in sheriffs' offices, by size of population served, 2007
so07stt10.csv			Table 10. Personal attribute screening methods used in the selection of new deputy recruits in sheriffs� offices, by size of population served, 2007													
so07stt11.csv			Table 11. Physical attribute screening methods used in the selection of new deputy recruits in sheriffs� offices, by size of population served, 2007
so07stt12.csv			Table 12. Screening methods related to community policing used in the selection of new deputy recruits for sheriffs� offices, by size of population served, 2007	
so07stt13.csv			Table 13. Workplace policies of sheriffs� offices, by size of population served, 2007
so07stt14.csv			Table 14. Training requirements for new deputy recruits in sheriffs� offices, by size of population served, 2007
so07stt15.csv			Table 15. In-service training requirements for sworn personnel in sheriffs� offices, by size of population served, 2007
so07stt16.csv			Table 16. Race and ethnicity of full-time sworn personnel in sheriffs� offices, by size of population served, 2007
so07stt17.csv			Table 17. Sex of full-time sworn personnel in sheriffs� offices, by size of population served, 2007
so07stt18.csv			Table 18. Sheriffs� deputies assigned to respond to calls for service, by size of population served, 2007
so07stt19.csv			Table 19. Emergency 9-1-1 system participation of sheriffs� offices, by size of population served, 2007
so07stt20.csv			Table 20. Wireless capabilities of emergency 9-1-1 systems in sheriffs� offices, by size of population served, 2007
so07stt21.csv			Table 21. Types of regularly scheduled patrols other than automobile used by sheriffs� offices, by size of population served, 2007
so07stt22.csv			Table 22. Special population and situational policies of sheriffs� offices, by size of population served, 2007 
so07stt23.csv			Table 23. Number of motorized land vehicles operated by sheriffs� offices and percent unmarked, by size of population served, 2007
so07stt24.csv			Table 24. Motorized vehicles operated by sheriffs� offices, by size of population served, 2007
so07stt25.csv			Table 25. Vehicle use policies for sworn personnel in sheriffs� offices, by size of population served, 2007
so07stt26.csv			Table 26. Off-land vehicles operated by sheriffs� offices, by size of population served, 2007
so07stt27.csv			Table 27. Use of animals by sheriffs� offices for law enforcement purposes, by size of population served, 2007
so07stt28.csv			Table 28. Types of sidearms authorized for use by sworn personnel in sheriffs� offices, by size of population served, 2007
so07stt29.csv			Table 29. Types of batons authorized for use by sworn personnel in sheriffs� offices, by size of population served, 2007
so07stt30.csv			Table 30. Less-than-lethal weapons authorized for use by a majority of sheriffs� offices, by size of population served, 2007
so07stt31.csv			Table 31. Less-than-lethal weapons or actions authorized for use by fewer than half of sheriffs� offices, by size of population served, 2007
so07stt32.csv			Table 32. Use-of-force policies and procedures in sheriffs� offices, by size of population served, 2007
so07stt33.csv			Table 33. Body armor requirements for field officers in sheriffs� offices, by size of population served, 2007
so07stt34.csv			Table 34. Use of video cameras by sheriffs� offices, by size of population served, 2007
so07stt35.csv			Table 35. General functions of computers in sheriffs� offices, by size of population served, 2007
so07stt36.csv			Table 36. Analytic functions of computers in sheriffs� offices, by size of population served, 2007
so07stt37.csv			Table 37. Types of in-field computers or terminals used by sheriffs� offices, by size of population served, 2007
so07stt38.csv			Table 38. Use of in-field computers or terminals by sheriffs� offices, by size of population served, 2007
so07stt39.csv			Table 39. Use of in-field computers for reports and communications by sheriffs� offices, by size of population served, 2007
so07stt40.csv			Table 40. Types of computerized information accessible to in-field deputies in sheriffs� offices, by size of population served, 2007
so07stt41.csv			Table 41. Methods used by sheriffs� offices for transmitting criminal incident reports to a central information system, by size of population served, 2007
so07stt42.csv			Table 42. Automated Fingerprint Identification Systems (AFIS) in sheriffs� offices, by size of population served, 2007
so07stt43.csv			Table 43. Community policing policies of sheriffs� offices, by size of population served, 2007
so07stt44.csv			Table 44. Community policing training for new deputy recruits in sheriffs� offices, by size of population served, 2007
so07stt45.csv			Table 45. Community-oriented policies for patrol officers in sheriffs� offices, by size of population served, 2007
so07stt46.csv			Table 46. Community policing activities of sheriffs� offices, by size of population served, 2007
so07stt47.csv			Table 47. Full-time community policing officers and units in sheriffs� offices, by size of population served, 2007
so07stt48.csv			Table 48. Full-time school resource officers in sheriffs� offices, by size of population served, 2007
so07stt49.csv			Table 49. Drug task force participation of sheriffs� offices, by size of population served, 2007
so07stt50.csv			Table 50. Gang task force participation of sheriffs� offices, by size of population served, 2007
so07stt51.csv			Table 51. Human trafficking task force participation of sheriffs� offices, by size of population served, 2007
so07stt52.csv			Table 52. Anti-terrorism task force participation of sheriffs� offices, by size of population served, 2007
so07stt53.csv			Table 53. Preparedness activities of sheriffs� offices, by size of population served, 2007
so07stt54.csv			Table 54. Full-time intelligence personnel in sheriffs� offices with primary duties related to terrorist activities, by size of population served, 2007

		
			
Figures			
so07stf01.csv			Figure 1. Full-time employees of sheriffs� offices, 1987�2007

			
Appendix tables			
so07stat01.csv			Appendix table 1. Fifty largest sheriffs� offices in the United States, by number of full-time sworn personnel, 2007
so07stat02.csv			Appendix table 2. Standard errors of the estimated percentages for sheriffs� offices, by size of population served, 2007
so07stat03.csv			Appendix table 3. Standard errors for estimated personnel counts in sheriffs� offices, 2007
so07stat04.csv			Appendix table 4. Standard errors for estimated operating budgets in sheriffs� offices, 2007
so07stat05.csv			Appendix table 5. Standard errors for starting salaries for entry-level deputies in sheriffs� offices, 2007