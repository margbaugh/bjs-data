Crimes Against People with Disabilities, 2008     NCJ  231328			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Crimes Against People with Disabilities, 2008     NCJ  231328.  The full report including text			
and graphics in pdf format is available from: http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2019			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=65.			
			
			
Filename			Table title
capd08t01.csv			Table 1. Estimated number of violent and property crimes against persons, by type of crime and victim disability status, 2008
capd08t02.csv			Table 2. Violent victimization rates, by type of crime and disability status, 2008
capd08t03.csv			Table 3. Violent victimization rates, by age and disability status, 2008
capd08t04.csv			Table 4. Violent victimization rates by gender, race, Hispanic origin, and disability status, 2008
capd08t05.csv			Table 5. Victim /offender relationship in violent crimes, by disability status, 2008
capd08t06.csv			Table 6. Victim resistance in violent crimes, by disability status, 2008
capd08t07.csv			Table 7. Violent crime, by offender weapon use and disability status, 2008
capd08t08.csv			Table 8. Injury and medical treatment as a result of violent crime, by disability status, 2008
capd08t09.csv			Table 9. Violent crime reported to police, by type of crime and disability status, 2008
capd08t10.csv			Table 10. Violent crime victims who used non-police victim advocacy agencies, by disability status and type of agency, 2008
capd08t11.csv			Table 11. Violent victimization rates of persons with disabilities, by type of crime and type of disability, 2008
capd08t12.csv			Table 12. Violent victimization rates of persons with disabilities, by type of disability and gender, 2008
capd08t13.csv			Table 13. Property crime occurring in households, by type of crime and disability status, 2008
capd08t14.csv			Table 14. Property crime reported to police, by type of crime and household disability status, 2008			

			
Appendix tables			
capd08at01.csv			Appendix Table 1. Standard errors for estimated number of violent and property crimes against persons, by type of crime and disability status, 2008
capd08at02.csv			Appendix Table 2. Standard errors for violent victimization rates, by type of crime and disability status, 2008
capd08at03.csv			Appendix Table 3. Standard errors for violent victimization rates of persons, by age and disability status, 2008
capd08at04.csv			Appendix Table 4. Standard errors for violent victimization rates by gender, race, Hispanic origin, and disability status, 2008
capd08at05.csv			Appendix Table 5. Standard errors for victim/offender relationship in violent crime, by disability status, 2008
capd08at06.csv			Appendix Table 6. Standard errors for victim resistance in violent crimes against persons, by disability status, 2008
capd08at07.csv			Appendix Table 7. Standard errors for violent crime, by offender weapon use and disability status, 2008
capd08at08.csv			Appendix Table 8. Standard errors for injury and medical treatment as a result of violent crime, by disability status, 2008
capd08at09.csv			Appendix Table 9. Standard errors for violent crime reported to police, by type of crime and victim disability status, 2008
capd08at10.csv			Appendix Table 10. Standard errors for victims who used non-police victim advocacy agencies, by disability status and type of agency, 2008
capd08at11.csv			Appendix Table 11. Standard errors for violent victimization rates of persons with disabilities, by type of crime and type of disability, 2008
capd08at12.csv			Appendix Table 12. Standard errors for violent victimization rates of persons with disabilities, by type of disability and gender, 2008
capd08at13.csv			Appendix Table 13. Standard errors for property crime occurring in households, by type of crime and disability status, 2008
capd08at14.csv			Appendix Table 14. Standard errors for property crime reported to police, by type of crime, and household disability status, 2008
capd08at15.csv			Appendix Table 15. U.S. population by gender, race, Hispanic origin, and age, and by disability status, 2008
