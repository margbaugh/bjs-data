Federal Law Enforcement Officers, 2016 - Statistical Tables  NCJ 251922		
		
This zip archive contains tables in individual  .csv spreadsheets		
Federal Law Enforcement Officers, 2016 - Statistical Tables  NCJ 251922  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6708		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=25		
		
		
Filename		Tables
fleo16stt01.csv		Table 1. Distribution of full-time federal law enforcement officers, by department or branch, 2016
fleo16stt02.csv		Table 2. Full-time federal law enforcement officers in federal agencies, 2008 and 2016
fleo16stt03.csv		Table 3. Full-time federal law enforcement officers in Offices of Inspectors General, 2008 and 2016
fleo16stt04.csv		Table 4. Percent of full-time federal law enforcement officers, by primary function, 2016
fleo16stt05.csv		Table 5. Percent of full-time federal law enforcement officers, by sex and race or ethnicity, 2008 and 2016
fleo16stt06.csv		Table 6. Sex and race or ethnicity of full-time federal law enforcement officers in agencies employing 50 or more officers, other than Offices of Inspectors General, 2016
fleo16stt07.csv		Table 7. Sex and race or ethnicity of full-time federal law enforcement officers in Offices of Inspectors General employing 50 or more officers, 2016
fleo16stt08.csv		Table 8. Assaults on federal law enforcement officers, 2008 and 2016
		
			Figures
fleo16stf01.csv		Figure 1. Distribution of full-time federal law enforcement officers, by department or branch, 2016
fleo16stf02.csv		Figure 2. Percent of full-time federal law enforcement officers, by primary function, 2016
fleo16stf03.csv		Figure 3. Percent of full-time federal law enforcement officers, by sex and race or ethnicity, 2008 and 2016
