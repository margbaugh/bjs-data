Sexual Victimization in State and Federal Prisons Reported by Inmates, 2007  NCJ 219414


This file is text only without graphics and many of the		
tables. A Zip archive of the tables in this report in 		
spreadsheet format (.csv) and the full report including 		
tables and graphics in .pdf format are available from:		
http://www.ojp.usdoj.gov/bjs/abstract/svsfpri07.htm		


Tables
svsfpri07t01.csv		Table 1. Prison facilities with highest and lowest prevalence of sexual victimization, National Inmate Survey, 2007
svsfpri07t02.csv		Table 2. Prison facilities with the highest prevalence of sexual victimization, by another inmate or staff, National Inmate Survey, 2007
svsfpri07t03.csv		Table 3. Prison facilities with the highest prevalence of sexual victimization, by type, National Inmate Survey, 2007
svsfpri07t04.csv		Table 4. Prison facilities with the highest prevalence of sexual assault, by another inmate or staff and by level of force and injury, National Inmate Survey, 2007
svsfpri07t05.csv		Table 5. Prison facilities with the highest number of incidents of nonconsensual sexual acts per 1,000 inmates, National Inmate Survey, 2007


Highlights		
svsfpri07ht01.csv		Highlights Table. State and Federal prisoners reporting sexual victimization, 2007

Appendix tables		
svsfpri07at01.csv		Appendix table 1. Characteristics of State and Federal facilities selected in the National Inmate Survey, 2007
svsfpri07at02.csv		Appendix table 2.  Percent of prison inmates reporting sexual victimization and estimated standard error, by facility, National Inmate Survey, 2007
svsfpri07at03.csv		Appendix table 3. Percent of prison inmates reporting nonconsensual sexual acts and abusive sexual contacts, by facility, National Inmate Survey, 2007
svsfpri07at04.csv		Appendix table 4. Percent of prison inmates reporting sexual victimization, by type of incident and facility, National Inmate Survey, 2007
svsfpri07at05.csv		Appendix table 5. Percent of prison inmates reporting nonconsensual sexual acts, by type of incident and facility, National Inmate Survey, 2007
svsfpri07at06.csv		Appendix table 6. Percent of prison inmates reporting sexual victimization by type of incident and level of coercion, by facility, National Inmate Survey, 2007
svsfpri07at07.csv		Appendix table 7. Percent of prison inmates reporting sexual victimization and percent injured, by type of incident and facility, National Inmate Survey, 2007
svsfpri07at08.csv		Appendix table 8. Number of incidents of inmate-on-inmate sexual victimization per 1,000 inmates, by facility, National Inmate Survey, 2007
svsfpri07at09.csv		Appendix table 9. Number of incidents of staff-on-inmate sexual victimization per 1,000 inmates, by facility, National Inmate Survey, 2007
