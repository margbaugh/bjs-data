Publicly Funded Forensic Crime Laboratories, 2020    NCJ 306473
	
This zip archive contains tables in individual  .csv spreadsheets		
from Publicly Funded Forensic Crime Laboratories, 2020    NCJ 306473 
The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/publicly-funded-forensic-crime-laboratories-2020
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to:
https://bjs.ojp.gov/library/publications/list?series_filter=Census%20of%20Publicly%20Funded%20Forensic%20Crime%20Laboratories

Filenames		Table titles
pffcl20t01.csv		Table 1. Requests received and completed by publicly funded forensic crime laboratories, by type of request, 2009, 2014, and 2020
pffcl20t02.csv		Table 2. Percent of publicly funded forensic crime laboratories, by jurisdiction of lab and forensic function performed, 2020
pffcl20t03.csv		Table 3. Percent of requests received by publicly funded forensic crime laboratories, by jurisdiction of lab and type of request, 2020
pffcl20t04.csv		Table 4. Backlogged requests in publicly funded forensic crime laboratories, by type of request, yearend 2009, 2014, and 2020
pffcl20t05.csv		Table 5. Percent of publicly funded forensic crime laboratories that outsourced requests, by type of request, 2020
pffcl20t06.csv		Table 6. Percent of full-time-equivalent employees in publicly funded forensic crime laboratories, by jurisdiction of lab and type of employee, 2020
pffcl20t07.csv		Table 7. Full-time-equivalent employees, hires, separations, and job vacancies in publicly funded forensic crime laboratories, by jurisdiction and size of lab, 2020
pffcl20t08.csv		Table 8. Number of full-time-equivalent employees in and requests received by publicly funded forensic crime laboratories, by jurisdiction of lab, 2019 and 2020
pffcl20t09.csv		Table 9. Annual operating budgets of publicly funded forensic crime laboratories, by jurisdiction and size of lab, 2020
pffcl20t10.csv		Table 10. Percent of publicly funded forensic crime laboratories, by selected types of funding received and jurisdiction and size of lab, 2020
pffcl20t11.csv		Table 11. Percent of publicly funded forensic crime laboratories with resources directed primarily to research, by jurisdiction and size of lab, 2002, 2009, 2014, and 2020
pffcl20t12.csv		Table 12. Percent of publicly funded forensic crime laboratories, by selected employee safety and wellness resources and jurisdiction and size of lab, 2020
pffcl20t13.csv		Table 13. Percent of publicly funded forensic crime laboratories accredited by a professional organization, by jurisdiction and size of lab, 2014 and 2020
pffcl20t14.csv		Table 14. Percent of publicly funded forensic crime laboratories, by proficiency and competency testing performed and jurisdiction and size of lab, 2020
pffcl20t15.csv		Table 15. Percent of publicly funded forensic crime laboratories, by technical reviews performed and jurisdiction and size of lab, 2020
pffcl20t16.csv		Table 16. Percent of publicly funded forensic crime laboratories, by selected operational procedures and jurisdiction and size of lab, 2020
pffcl20t17.csv		Table 17. Percent of publicly funded forensic crime laboratories with a written code of ethics, by jurisdiction and size of lab, 2020
pffcl20t18.csv		Table 18. Response rates of publicly funded forensic crime laboratories, by jurisdiction of lab, 2020
pffcl20t19.csv		Table 19. Nonresponse adjustment weights for publicly funded forensic crime laboratories, by stratum, 2020

			Figures
pffcl20f01.csv		Figure 1. Number of requests received by publicly funded forensic crime laboratories, 2009, 2014, and 2020
pffcl20f02.csv		Figure 2. Requests received by publicly funded forensic crime laboratories, by jurisdiction of lab, 2020
pffcl20f03.csv		Figure 3. Percent of publicly funded forensic crime laboratories that outsourced requests, by jurisdiction of lab, 2002, 2005, 2009, 2014, and 2020
pffcl20f04.csv		Figure 4. Number of full-time-equivalent employees in publicly funded forensic crime laboratories, by jurisdiction of lab, yearend 2002, 2005, 2009, 2014, and 2020
pffcl20f05.csv		Figure 5. Annual operating budgets of publicly funded forensic crime laboratories, by jurisdiction of lab, 2002, 2005, 2009, 2014, and 2020
pffcl20f06.csv		Figure 6. Percent of publicly funded forensic crime laboratories with a laboratory information management system, 2002, 2005, 2009, 2014, and 2020


			Appendix tables
pffcl20at01.csv		Appendix Table 1. Standard errors for table 1: Requests received and completed by publicly funded forensic crime laboratories, by type of request, 2009, 2014, and 2020
pffcl20at02.csv		Appendix Table 2. Standard errors for table 2: Percent of publicly funded forensic crime laboratories, by jurisdiction of lab and forensic function performed, 2020
pffcl20at03.csv		Appendix Table 3. Standard errors for table 3: Percent of requests received by publicly funded forensic crime laboratories, by jurisdiction of lab and type of request, 2020
pffcl20at04.csv		Appendix Table 4. Standard errors for table 4: Backlogged requests in publicly funded forensic crime laboratories, by type of request, yearend 2009, 2014, and 2020
pffcl20at05.csv		Appendix Table 5. Estimates and standard errors for figure 3: Percent of publicly funded forensic crime laboratories that outsourced requests, by jurisdiction of lab, 2002, 2005, 2009, 2014, and 2020
pffcl20at06.csv		Appendix Table 6. Standard errors for table 5: Percent of publicly funded forensic crime laboratories that outsourced requests, by type of request, 2020
pffcl20at07.csv		Appendix Table 7. Estimates and standard errors for figure 4: Number of full-time-equivalent employees in publicly funded forensic crime laboratories, by jurisdiction of lab, yearend 2002, 2005, 2009, 2014, and 2020
pffcl20at08.csv		Appendix Table 8. Standard errors for table 6: Percent of full-time-equivalent employees in publicly funded forensic crime laboratories, by jurisdiction of lab and type of employee, 2020
pffcl20at09.csv		Appendix Table 9. Standard errors for table 7: Full-time-equivalent employees, hires, separations, and job vacancies in publicly funded forensic crime laboratories, by jurisdiction and size of lab, 2020
pffcl20at10.csv		Appendix Table 10. Standard errors for table 8: Number of full-time-equivalent employees in and requests received by publicly funded forensic crime laboratories, by jurisdiction of lab, 2019 and 2020
pffcl20at11.csv		Appendix Table 11. Standard errors for table 9: Annual operating budgets of publicly funded forensic crime laboratories, by jurisdiction and size of lab, 2020
pffcl20at12.csv		Appendix Table 12. Estimates and standard errors for figure 5: Annual operating budgets of publicly funded forensic crime laboratories, by jurisdiction of lab, 2002, 2005, 2009, 2014, and 2020
pffcl20at13.csv		Appendix Table 13. Standard errors for table 10: Percent of publicly funded forensic crime laboratories, by selected types of funding received and jurisdiction and size of lab, 2020
pffcl20at14.csv		Appendix Table 14. Estimates and standard errors for figure 6: Percent of publicly funded forensic crime laboratories with a laboratory information management system, 2002, 2005, 2009, 2014, and 2020
pffcl20at15.csv		Appendix Table 15. Standard errors for table 11: Percent of publicly funded forensic crime laboratories with resources directed primarily to research, by jurisdiction and size of lab, 2002, 2009, 2014, and 2020
pffcl20at16.csv		Appendix Table 16. Standard errors for table 12: Percent of publicly funded forensic crime laboratories, by selected employee safety and wellness resources and jurisdiction and size of lab, 2020
pffcl20at17.csv		Appendix Table 17. Standard errors for table 13: Percent of publicly funded forensic crime laboratories accredited by a professional organization, by jurisdiction and size of lab, 2014 and 2020
pffcl20at18.csv		Appendix Table 18. Standard errors for table 14: Percent of publicly funded forensic crime laboratories, by proficiency and competency testing performed and jurisdiction and size of lab, 2020
pffcl20at19.csv		Appendix Table 19. Standard errors for table 15: Percent of publicly funded forensic crime laboratories, by technical reviews performed and jurisdiction and size of lab, 2020
pffcl20at20.csv		Appendix Table 20. Standard errors for table 16: Percent of publicly funded forensic crime laboratories, by selected operational procedures and jurisdiction and size of lab, 2020
pffcl20at21.csv		Appendix Table 21. Standard errors for table 17: Percent of publicly funded forensic crime laboratories with a written code of ethics, by jurisdiction and size of lab, 2020

