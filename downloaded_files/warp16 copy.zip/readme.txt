Work Assignments Reported by Prisoners, 2016   NCJ 306021	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Work Assignments Reported by Prisoners, 2016   NCJ 306021. The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/work-assignments-reported-prisoners-2016
	
Filenames	Table titles
warp16t01.csv	Table 1. Percent of prisoners in the United States, by type of work assignment and prison population, 2016
	
		Figures
warp16f01.csv	Figure 1. Percent of prisoners in the United States, by work assignment status and prison population, 2016
warp16f02.csv	Figure 2. Percent of prisoners in the United States with a work assignment, by requirement status and prison population, 2016
warp16f03.csv	Figure 3. Reasons prisoners in the United States chose to have a work assignment that was not a requirement, by importance of reason and prison population, 2016
	
		Appendix tables
warp16at01.csv	Appendix table 1. Standard errors for figure 1: Percent of prisoners in the United States, by work assignment status and prison population, 2016 and table 1: Percent of prisoners in the United States, by type of work assignment and prison population, 2016
warp16at02.csv	Appendix table 2. Percentages and standard errors for figure 2: Percent of prisoners in the United States with a work assignment, by requirement status and prison population, 2016
warp16at03.csv	Appendix table 3. Percentages and standard errors for figure 3: Reasons prisoners in the United States chose to have a work assignment that was not a requirement, by importance of reason and prison population, 2016
