Criminal Victimization, 2010     NCJ  235508			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization,  2010,   NCJ  235508.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2224		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=6			
			
			
Filename			Table title
cv10t01.csv			Table 1. Number of criminal victimizations and percent change, by type of crime, 2001, 2009, and 2010
cv10t02.csv			Table 2. Rates of criminal victimization and percent change, by type of crime, 2001, 2009, and 2010
cv10t03.csv			Table 3. Percent changes in the number of crimes reported in the UCR and the NCVS, 2009�2010
cv10t04.csv			Table 4. Violent victimizations involving a weapon, by type of crime and type of weapon, 2010
cv10t05.csv			Table 5. Violent victimizations, by type of crime and victim-offender relationship, 2010
cv10t06.csv			Table 6. Intimate partner violence, by sex of victim, 2009 and 2010
cv10t07.csv			Table 7. Violent and property victimizations reported to police, 2010
cv10t08.csv			Table 8. Victimizations reported to the police, by sex, race, and Hispanic origin of victim, 2010
cv10t09.csv			Table 9. Violent victimizations, by type of crime, sex, race, Hispanic origin, and age of victim, 2010
cv10t10.csv			Table 10. Property crime victimizations, by type of crime, by household income and size, 2010
			
Figures			
cv10f01.csv			Figure 1. Total violent and serious violent victimizations, 2001-2010
cv10f02.csv			Figure 2. Total violent and serious violent victimizations, 1993-2010
cv10f03.csv			Figure 3. Violent victimization with series victimizations included and excluded, 1993-2010
cv10f04.csv			Figure 4. Property crime victimizations, 1993-2010
cv10f05.csv			Figure 5. Total violent and serious violent victimizations involving injury, 2001-2010
cv10f06.csv			Figure 6. Total violent and serious violent victimizations involving a weapon, 2001-2010
cv10f07.csv			Figure 7. Total violent and serious violent victimizations involving a firearm, 2001-2010
cv10f08.csv			Figure 8. Violent victimizations perpetrated by strangers and nonstrangers, 2001-2010
cv10f09.csv			Figure 9. Violent and property victimizations reported to the police, 2001-2010
			
Appendix tables			
cv10at01.csv			Appendix Table 1. Standard errors for total violent and serious violent victimizations, 2001�2010 
cv10at02.csv			Appendix Table 2. Standard errors for number of criminal victimizations and percent change, by type of crime, 2001, 2009, and 2010
cv10at03.csv			Appendix Table 3. Standard errors for total violent and serious violent victimizations, 1993�2010
cv10at04.csv			Appendix Table 4. Standard errors for rates of criminal victimization and percent change, by type of crime, 2001, 2009, and 2010
cv10at05.csv			Appendix Table 5. Standard errors for violent victimization with series victimizations included and excluded, 1993�2010
cv10at06.csv			Appendix Table 6. Standard errors for property victimizations, 1993�2010
cv10at07.csv			Appendix Table 7. Standard errors for total violent and serious violent victimizations involving injury, 2001�2010
cv10at08.csv			Appendix Table 8. Standard errors for violent victimizations involving a weapon, by type of crime and type of weapon, 2010
cv10at09.csv			Appendix Table 9. Standard errors for total violent and serious violent victimizations involving a weapon, 2001�2010
cv10at10.csv			Appendix Table 10. Standard errors for total violent and serious violent victimizations involving a firearm, 2001�2010
cv10at11.csv			Appendix Table 11. Standard errors for violent victimizations perpetrated by strangers and nonstrangers, 2001�2010
cv10at12.csv			Appendix Table 12. Standard errors for violent victimizations, by type of crime and victim-offender relationship, 2010
cv10at13.csv			Appendix Table 13.  Standard errors for intimate partner violence, by sex of victim, 2009 and 2010
cv10at14.csv			Appendix Table 14. Standard errors for violent and property victimizations reported to police, 2010
cv10at15.csv			Appendix Table 15. Standard errors for violent and property victimizations reported to the police, 2001�2010
cv10at16.csv			Appendix Table 16. Standard errors for victimizations reported to the police, by sex of victim, race, and Hispanic origin of victim, 2010
cv10at17.csv			Appendix Table 17. Standard errors for violent victimizations, by type of crime, by sex, race, Hispanic origin, and age of victim, 2010
cv10at18.csv			Appendix Table 18. Standard error for property crime victimizations, by type of crime, by household income and size, 2010
