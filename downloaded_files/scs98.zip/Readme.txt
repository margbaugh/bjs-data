State Court Sentencing of Convicted Felons, 1998, NCJ 190637 

This zip archive contains tables in individual .csv spreadsheets
from State Court Sentencing of Convicted Felons, 1998, NCJ 190637.
The full report including text and graphics in pdf format are available from:
https://bjs.ojp.gov/library/publications/state-court-sentencing-convicted-felons-1998-statistical-tables

This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to:
https://bjs.ojp.gov/library/publications/list?series_filter=State%20Court%20Sentencing%20of%20Convicted%20Felons

File name		Title
scs9811.csv		Table 1.1 Estimated number of felony convictions in State courts, 1998
scs9812.csv		Table 1.2 Type of felony sentences imposed by State courts, by offense 1998
scs9813.csv		Table 1.3 Length of felony sentence imposed by State courts, by offense and type of sentence, 1998
scs9814.csv		Table 1.4 Estimated percent of felons sentenced to life in State prison, by offense, 1998
scs9815.csv		Table 1.5 Estimated time to be served in State prison, by offense, 1998
scs9816.csv		Table 1.6 Number of offenses for felons convicted and sentenced in State courts, by most serious felony conviction offense, 1998
scs9817.csv		Table 1.7 Convicted felons sentenced to prison by State courts, by number of conviction offenses, 1998
scs9818.csv		Table 1.8 Mean sentence lengths for State felony sentences imposed, by the number and category of the conviction offense, 1998
scs9819.csv		Table 1.9 Felons sentenced to an additional penalty by State courts, by offense, 1998
