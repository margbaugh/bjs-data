Federal Justice Statistics, 2019  NCJ 301158	
	
This zip archive contains tables in individual .csv spreadsheets	
from Federal Justice Statistics, 2019  NCJ 301158	
The full report including text and graphics in .pdf format is available at	
https://bjs.ojp.gov/library/publications/federal-justice-statistics-2019
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Justice%20Statistics	
	
Filename	Table names
fjs19t01.csv	Table 1. Persons in federal confinement or under federal supervision in the community, fiscal year-end 2009, 2018, and 2019
fjs19t02.csv	Table 2. Federal arrests, by most serious offense and federal district, FY 2018–2019
fjs19t03.csv	Table 3. Suspects in matters opened by U.S. attorneys, by referring authority, FY 2009 and FY 2017–2019
fjs19t04.csv	Table 4. Outcome and case processing time of suspects in matters concluded, FY 2019
fjs19t05.csv	Table 5. Demographic characteristics of defendants charged in U.S. district court, by sex of defendant, FY 2019
fjs19t06.csv	Table 6. Disposition and case processing time of defendants in cases terminated in U.S. district court, FY 2019
fjs19t07.csv	Table 7. Type and length of sentence imposed for convicted defendants, by offense and district, FY 2019
fjs19t08.csv	Table 8. Characteristics of sentenced persons, FY 2019
fjs19t09.csv	Table 9. Admissions and releases of federal prisoners, by offense, FY 2019
fjs19t10.csv	Table 10. Demographic characteristics of federally sentenced persons in the custody of the Federal Bureau of Prisons, fiscal year-end 2009 and 2019
fjs19t11.csv	Table 11. Demographic characteristics of persons under post-conviction federal supervision, fiscal year-end 2019
	
		Figures
fjs19f01.csv	Figure 1. Suspects and defendants processed in the federal justice system, FY 1994–2019
fjs19f02.csv	Figure 2. Federal and state arrests by the Drug Enforcement Administration, by powder cocaine, crack cocaine, heroin, and other opioids, FY 2009–2019
fjs19f03.csv	Figure 3. Federal and state arrests by the Drug Enforcement Administration, by marijuana, methamphetamine, and other non-opioids, FY 2009–2019
fjs19f04.csv	Figure 4. Defendants in criminal cases filed in U.S. district court, by offense type, FY 2009–2019
fjs19f05.csv	Figure 5. Percent of defendants charged in U.S. district court, by sex and most serious offense, FY 2019
fjs19f06.csv	Figure 6. Percent of persons in the custody of the Federal Bureau of Prisons, by most serious commitment offense, fiscal year-end 2009 and 2019
fjs19f07.csv	Figure 7. Race or ethnicity of federally sentenced persons in the custody of the Federal Bureau of Prisons, by most serious commitment offense, fiscal year-end 2019
fjs19f08.csv	Figure 8. Persons under federal supervision in the community, by type of commitment offense, fiscal year-end 2009 and 2019
fjs19f09.csv	Figure 9. Universe of prisoners held under the Federal Bureau of Prisons jurisdiction and federally sentenced prisoners in custody, fiscal year-end 2019
	
		Appendix tables
fjs19at01.csv	Appendix Table 1. Estimates for figure 1: Suspects and defendants processed in the federal justice system, FY 1994–2019
fjs19at02.csv	Appendix Table 2. Estimates for figure 2 and 3: Estimates for figure 2: Federal and state arrests by the Drug Enforcement Administration, by powder cocaine, crack cocaine, heroin, and other opioids, FY 2009–2019; and figure 3: Federal and state arrests by the Drug Enforcement Administration, by marijuana, methamphetamine, and other non-opioids, FY 2009–2019
fjs19at03.csv	Appendix Table 3. Estimates for figure 4: Defendants in criminal cases filed in U.S. district court, by offense type, FY 2009–2019
fjs19at04.csv	Appendix Table 4. Estimates for figure 5: Percent of defendants charged in U.S. district court, by sex and most serious offense, FY 2019
fjs19at05.csv	Appendix Table 5. Estimates for figure 6: Percent of prisoners in the custody of the Federal Bureau of Prisons, by most serious commitment offense, fiscal year-end 2009 and 2019
fjs19at06.csv	Appendix Table 6. Estimates for figure 7: Race or ethnicity of federally sentenced persons in the custody of the Federal Bureau of Prisons, by most serious commitment offense, fiscal year-end 2019
fjs19at07.csv	Appendix Table 7. Estimates for figure 8: Persons under federal supervision in the community, by type of commitment offense, fiscal year-end 2009 and 2019
fjs19at08.csv	Appendix Table 8. Estimates for figure 9: Universe of prisoners held under the Federal Bureau of Prisons’ jurisdiction and federally sentenced prisoners in the bureau’s custody, fiscal year-end 2019
