State Court Sentencing of Convicted Felons, 2004 - Statistical Tables
 
This zip archive contains tables in individual .csv spreadsheets
from State Court Sentencing of Convicted Felons, 2004 - Statistical Tables, NCJ 217995.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/scscfst.htm

		
Filename		Table number
	
scs0411.csv		Table 1.1.  Estimated number of felony convictions in State courts, 2004
scs0412.csv		Table 1.2.  Distribution of types of felony sentences imposed in State courts, by offense, 2004
scs0413.csv		Table 1.3.  Average felony sentence lengths in State courts, by offense and type of sentence, 2004
scs0414.csv		Table 1.4.  Estimated percent of felons sentenced to life in State prison, by offense, 2004
scs0415.csv		Table 1.5.  Estimated time to be served in State prison, by offense, 2004
scs0416.csv		Table 1.6.  Distribution of the number of felony convictions for persons sentenced in State courts, by most serious offense, 2004
scs0417.csv		Table 1.7.  Convicted felons sentenced to prison in State courts, by number of convictions, 2004
scs0418.csv		Table 1.8.  Felony convictions and sentences in State courts relative to the number of arrests, 2004  
scs0419.csv		Table 1.9.  Felons sentenced to an additional penalty in State courts, by offense, 2004
scs04110.csv		Table 1.10.  Comparison of felony convictions in State and Federal courts, 2004

scs0421.csv		Table 2.1.  Demographic characteristics of persons convicted of felonies in State courts, by offense, 2004
scs0422.csv		Table 2.2.  Offense distribution of felons convicted in State courts, by gender, race and age of felons, 2004
scs0423.csv		Table 2.3.  Average age of convicted felons in State courts, 2004
scs0424.csv		Table 2.4.  Distribution of types of felony sentences imposed in State courts, by offense and gender of felons, 2004
scs0425.csv		Table 2.5.  Distribution of types of felony sentences imposed in State courts, by offense and race of felons, 2004
scs0426.csv		Table 2.6.  Mean length of felony sentences imposed in State courts, by offense and gender of felons, 2004
scs0427.csv		Table 2.7.  Mean length of felony sentences imposed in State courts, by offense and race of felons, 2004
scs0428.csv		Table 2.8.  Mean length of felony sentences imposed in State courts, by offense and combined categories of race and gender, 2004

scs0441.csv		Table 4.1.  Distribution of types of felony convictions in State courts, by offense, 2004
scs0442.csv		Table 4.2.  Offense distribution of felons convicted in State courts, by type of conviction, 2004
scs0443.csv		Table 4.3.  Distribution of types of felony sentences imposed in State courts, by offense and type of conviction, 2004
scs0444.csv		Table 4.4.  Mean length of felony sentences imposed in State courts, by offense and type of conviction, 2004
scs0445.csv		Table 4.5.  Distribution of types of sentences imposed on felons convicted of murder or nonnegligent manslaughter, by type of conviction, 2004
scs0446.csv		Table 4.6.  Time between arrest and sentencing for persons convicted of a felony in State courts, by offense, 2004

			Standard error tables
scs04se11.csv		Estimate of 1 standard error for table 1.1, 2004
scs04se12.csv		Estimate of 1 standard error for table 1.2, 2004
scs04se13.csv		Estimate of 1 standard error for table 1.3, 2004
scs04se21.csv		Estimate of 1 standard error for table 2.1, 2004


		
	
			
 
 
 
 
 
