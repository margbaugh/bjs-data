Mortality in State Prisons, 2001-2014 - Statistical Tables       NCJ 250150			
This zip archive contains tables in individual  .csv spreadsheets			
from Mortality in Local Jails, 2000-2014 -Statistical Tables   NCJ 250169  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5866		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to	https://www.bjs.gov/index.cfm-ty=pbse&sid=76		
			
Filename				Table title
msp0114stat01.csv			Appendix Table 1. Estimated number of state and federal prisoners in custody, by selected inmate characteristics, 2001 and 2005-2014
msp0114stat02.csv			Appendix Table 2. Illness mortality rate per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stat03.csv			Appendix Table 3. Cancer mortality rate per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stat04.csv			Appendix Table 4. Heart disease mortality rate per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stat05.csv			Appendix Table 05. Liver disease mortality rate per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stat06.csv			Appendix Table 06. Respiratory disease mortality rate per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stat07.csv			Appendix Table 07. Mortality rate for all other illnesses per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stat08.csv			Appendix Table 08. Mortality rate for unnatural deaths per 100,000 state prison inmates, by selected characteristics, 2003 and 2005-2014
msp0114stt01.csv			Table 01. Number of state and federal prison inmate deaths, by cause of death, 2001-2014
msp0114stt02.csv			Table 2. Number of state and federal prisoner deaths, by cause of death, 2001 and 2005-2014
msp0114stt03.csv			Table 03. Percent of state prisoner deaths, by cause of death, 2001 and 2005-2014
msp0114stt04.csv			Table 04. Mortality rate per 100,000 state prisoners, by cause of death, 2001 and 2005-2014
msp0114stt05.csv			Table 05. Mortality rate per 100,000 federal prisoners, by select cause of death, 2001 and 2005-2014
msp0114stt06.csv			Table 06. Number of state prisoner deaths, by selected decedent characteristics, 2001 and 2005-2014
msp0114stt07.csv			Table 07. Percent of state prisoner deaths, by selected decedent characteristics, 2001 and 2005-2014
msp0114stt08.csv			Table 08. Mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001 and 2005-2014
msp0114stt09.csv			Table 09. Number of state prisoner deaths, by cause and selected decedent characteristics, 2001-2014
msp0114stt10.csv			Table 10. Average annual mortality rate per 100,000 state prisoners, by cause of death and selected decedent characteristics, 2001-2014
msp0114stt11.csv			Table 11. Number of state and federal prisoner deaths, by jurisdiction, 2001 and 2005-2014
msp0114stt12.csv			Table 12. Mortality rate per 100,000 state and federal prisoners, by jurisdiction, 2001 and 2005-2014
msp0114stt13.csv			Table 13. Number of state and federal prisoner deaths, by cause and jurisdiction, 2001-2014
msp0114stt14.csv			Table 14. Average annual mortality rate per 100,000 state and federal prisoners, by cause of death and jurisdiction, 2001-2014
msp0114stt15.csv			Table 15. Preliminary count of the number of deaths in state prisons, 2015
msp0114stf01.csv			Figure 1. Number of state and federal prisoners deaths, 2001�2014