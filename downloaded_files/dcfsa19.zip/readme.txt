Data Collected Under the First Step Act, 2019   NCJ 254268		
		
This zip archive contains tables in individual .csv spreadsheets		
Data Collected Under the First Step Act, 2019   NCJ 254268  

The full report including text and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6806		
		
		
Filename		Tables
dcfsa19t01.csv		Table 1. Selected characteristics of federal prisoners, 2018
dcfsa19t02.csv		Table 2. Medical conditions, testing, and treatment of federal prisoners, 2018
dcfsa19t03.csv		Table 3. Selected characteristics of federal facilities, 2018
dcfsa19t04.csv		Table 4. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by security level of facility, 2018
dcfsa19t05.csv		Table 5. Federal prisoners who were cited for prohibited acts that resulted in reductions in rewards, incentives, or time credits, by demographic characteristics, 2018
dcfsa19t06.csv		Table 6. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by facility, 2018
dcfsa19t07.csv		Table 7. Prisoner assaults on Federal Bureau of Prisons staff, by type of assault and prosecution status, 2018
dcfsa19t08.csv		Table 8. Volunteer levels in Federal Bureau of Prisons facilities, by facility, June 30, 2019
