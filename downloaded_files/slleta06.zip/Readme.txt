State and local law enforcement training academies, 2006 	NCJ 222987	

This zip archive contains tables in individual .csv spreadsheets		
from State and Local Law Enforcement Agencies, 2006, NCJ 222987		
The full report including text and graphics in .pdf format is available at		
http://www.ojp.usdoj.gov/bjs/abstract/slleta06.htm		

This report is one in a series. More recent editions may
be available. To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#slleta.

Filename		Table number
slleta06t01.csv		Table 1. State and local law enforcement training academies and instructors, by type of operating agency, 2006
slleta06t02.csv		Table 2. State and local law enforcement training academies and instructors, by size of academy, 2006
slleta06t03.csv		Table 3. Types of instructors in state and local law enforcement training academies, 2006
slleta06t04.csv		Table 4. Average size of state and local law enforcement training academies, by type of operating agency, 2006
slleta06t05.csv		Table 5. Minimum years of law enforcement experience required for full-time instructors in state and local law enforcement training academies, 2006
slleta06t06.csv		Table 6. College degree requirements for full-time  instructors in state and local law enforcement training academies, 2006
slleta06t07.csv		Table 7. Certification and refresher training requirements for full-time instructors in state and local law enforcement training academies, 2006
slleta06t08.csv		Table 8. Facilities and resources of state and local law enforcement training academies, 2006
slleta06t09.csv		Table 9. Operating expenditures of state and local law enforcement training academies, by type of operating agency, FY 2005
slleta06t10.csv		Table 10. Duration of basic recruit training, by type of academy, 2006
slleta06t11.csv		Table 11. Topics included in basic training of state and local law enforcement training academies, 2006
slleta06t12.csv		Table 12. Median number of basic recruit classes and median class size, by type of academy, 2005-06
slleta06t13.csv		Table 13. Number of recruits starting basic training in state and local law enforcement training academies, by type of academy, 2005
slleta06t14.csv		Table 14. Types of tests used to evaluate basic recruits in state and local law enforcement training academies, 2006
slleta06t15.csv		Table 15. Completion rates for basic recruits in state and local law enforcement training academies, by type of academy, 2005-06
slleta06t16.csv		Table 16. Completion rates for recruits in state and local law enforcement training academies, by size of academy, 2005-06
slleta06t17.csv		Table 17. Race and gender of recruits who started and completed basic training in state and local law enforcement training academies, 2005
slleta06t18.csv		Table 18. Completion rates for recruits in state and local law enforcement training academies, by race and gender, 2005-06
slleta06t19.csv		Table 19. Training environment of state and local law enforcement training academies, 2006
slleta06t20.csv		Table 20. Training environment of state and local law enforcement training academies, by type of operating agency, 2006

		        Appendix table number
slleta06at01.csv	Appendix table 1. Firearms training conditions used in state and local law enforcement training academies, by type of academy, 2006
slleta06at02.csv	Appendix table 2. Control/defensive tactics training in state and local law enforcement training academies, by type of academy, 2006
slleta06at03.csv	Appendix table 3. Use of reality-based (mock) scenarios in state and local law enforcement training academies, by type of academy, 2006
slleta06at04.csv	Appendix table 4. Number of recruits starting basic training in state and local law enforcement training academies, by size of academy, 2005-06
slleta06at05.csv	Appendix table 5. Specialized training provided by state and local law enforcement training academies, by type of academy, 2006
slleta06at06.csv	Appendix table 6. Special patrol operations training provided by state and local law enforcement training academies, by type of academy, 2006
slleta06at07.csv	Appendix table 7. Special facilities security training provided by state and local law enforcement training academies, by type of academy, 2006
slleta06at08.csv	Appendix table 8. Disciplinary actions that may be taken in response to violations of disciplinary code, 2006

			Text table number
slleta06tt01.csv	Text table 1. Completion rates by training environment

			Figure number
slleta06f01.csv		Figure 1. Types of personnel trained by state and local law enforcement training academies, 2006
slleta06f02.csv		Figure 2. Types of certification required for full-time instructors in state and local law enforcement training academies, 2006
slleta06f03.csv		Figure 3. Methods used to evaluate the performance of full-time instructors in state and local law enforcement training academies, 2006
slleta06f04.csv		Figure 4. Per-recruit operating expenditures of state and local law enforcement training academies, by size of academy, FY 2005
slleta06f05.csv		Figure 5. Sources of funding for state and local law enforcement training academies, 2006
slleta06f06.csv		Figure 6. Curriculum development methods used by state and local law enforcement training academies, 2006
slleta06f07.csv		Figure 7. Community policing topics in state and local law enforcement training academies, 2002 and 2006
slleta06f08.csv		Figure 8. Terrorism-related topics in state and local law enforcement training academies, 2002 and 2006
slleta06f09.csv		Figure 9. Race and Hispanic origin of recruits starting basic training in state and local law enforcement training academies, 2005
slleta06f10.csv		Figure 10. Completion rates for recruits in state and local law enforcement training academies, by race and gender, 2005-06
slleta06f11.csv		Figure 11. Completion rates male and female recruits in state and local law enforcement training academies, by type of training environment, 2005-06
