SEXUAL ASSAULT OF YOUNG CHILDREN AS REPORTED TO LAW ENFORCEMENT
NCJ 182990

Contents of zip archive
 
saycrl01.wk1      Table 1. Age profile of the victims of sexual assault
 
saycrl02.wk1      Table 2. Female proportion of sexual assault victims
 
saycrl03.wk1      Table 3. Proportion of sexual assault victims victimized alone
 
saycrl04.wk1      Table 4. Percent of sexual assault occurring within a residence
 
saycrl05.wk1      Table 5. Age profile of sexual assault offenders
 
saycrl06.wk1      Table 6. Victim-offender relationship in sexual assault
 
saycrl07.wk1      Table 7. Victim-offender relationship in sexual assault, by victim gender
 
saycrl08.wk1      Table 8. Offender probabilities in a typical 1,000 cases of sexual assault against
 
saycrl09.wk1      Table 9. Offender probabilities in a typical 1,000 cases of sexual assault against
 
saycrlf1.wk1      Figure 1.Age distribution of victims of sexual assault
 
saycrlf2.wk1      Figure 2.Age profiles of sexual assault victims, by offense category
 
saycrlf3.wk1      Figure 3.Female proportion of all sexual assault victims
 
saycrlf4.wk1      Figure 4.Age distribution of sexual assault victims, by gender
 
saycrlf5.wk1      Figure 5.Temporal distribution of sexual assault within victim age categories
 
saycrlf6.wk1      Figure 6.Age profile of sexual assault offenders
 
saycrlf7.wk1      Figure 7.Age profiles of sexual assault offenders within victim age categories
 
saycrlf8.wk1      Figure 8.Identified offenders arrested or cleared, by offender age
 
saycrlap.wk1      Figure A.Age distribution of offenders before and after smoothing
 
 
 
 
 
 
