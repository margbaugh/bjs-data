Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2012   NCJ 247448

This zip archive contains tables in individual .csv spreadsheets
Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2012   NCJ 247448
The full report including text and graphics in .pdf format are available from:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5115

This report is one in a series. More recent editions 
may be available. To view a list of all in the series 
go to http://bjs.gov/index.cfm?ty=pbse&sid=76 


 
Tables	
mljsp0012stt01.csv	Table 1. Number of local jail inmate deaths, by cause of death, 2000�2012 
mljsp0012stt02.csv	Table 2. Percent of local jail inmate deaths, by cause of death, 2000�2012
mljsp0012stt03.csv	Table 3. Mortality rate per 100,000 local jail inmates, by cause of death, 2000�2012
mljsp0012stt04.csv	Table 4. Number of local jail inmate deaths, by selected decedent characteristics, 2000�2012
mljsp0012stt05.csv	Table 5. Percent of local jail inmate deaths, by selected decedent characteristics, 2000�2012
mljsp0012stt06.csv	Table 6. Mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2012
mljsp0012stt07.csv	Table 7. Number of local jail inmate deaths, by cause of death and selected decedent characteristics, 2000-2012
mljsp0012stt08.csv	Table 8. Average annual mortality rate per 100,000 local jail inmates, by cause of death and selected decedent characteristics, 2000�2012
mljsp0012stt09.csv	Table 9. Number and percent of local jail jurisdictions reporting to the Deaths in Custody Program, by number of deaths reported each year, 2000�2012
mljsp0012stt10.csv	Table 10. Number of local jail deaths, by state, 2000�2012
mljsp0012stt11.csv	Table 11. Number of local jail inmates held on an average day, by state, 2000�2012
mljsp0012stt12.csv	Table 12. Mortality rate per 100,000 local jail inmates, by state, 2000�2012
mljsp0012stt13.csv	Table 13. Number of local jail jurisdictions reporting to the Deaths in Custody Reporting Program, by state, 2000�2012
mljsp0012stt14.csv	Table 14. Percent of local jail jurisdictions reporting one or more deaths to the Deaths in Custody Reporting Program, by state, 2000-2012
mljsp0012stt15.csv	Table 15. Number of state prisoner deaths, by cause of death, 2001�2012
mljsp0012stt16.csv	Table 16. Percent of state prisoner deaths, by cause of death, 2001�2012
mljsp0012stt17.csv	Table 17. Mortality rate per 100,000 state prisoners, by cause of death, 2001�2012
mljsp0012stt18.csv	Table 18. Number of state prisoner deaths, by selected decedent characteristics, 2001�2012
mljsp0012stt19.csv	Table 19. Percent of state prisoner deaths, by selected decedent characteristics, 2001�2012
mljsp0012stt20.csv	Table 20. Mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2012
mljsp0012stt21.csv	Table 21. Number of state prisoner deaths, by cause of death and selected decedent characteristics, 2001�2012
mljsp0012stt22.csv	Table 22. Average annual mortality rate per 100,000 state prisoners, by cause of death and selected decedent characteristics, 2001�2012
mljsp0012stt23.csv	Table 23. Estimated number of state and federal prisoners in custody, by selected inmate characteristics, 2001�2012
mljsp0012stt24.csv	Table 24. Number of state and federal prisoner deaths, by location, 2001�2012
mljsp0012stt25.csv	Table 25. Mortality rate per 100,000 state and federal prisoners, by location, 2001�2012
mljsp0012stt26.csv	Table 26. Number of state and federal prisoner deaths, by cause of death and location, 2001�2012
mljsp0012stt27.csv	Table 27. Average annual mortality rate per 100,000 state and federal prisoners, by cause of death and location, 2001�2012

Figures
mljsp0012stf01.csv	Figure 1. Local jail inmate and state prisoner deaths in custody, 2001�2012
mljsp0012stf02.csv	Figure 2. Average annual local jail inmate deaths in custody, by average daily inmate population, 2000�2012

Appendix tables
mljsp0012stat01.csv	Appendix table 1. Estimated number of local jail inmates in custody on an average day, by selected inmate characteristics, 2000�2012
mljsp0012stat02.csv	Appendix table 2. Illness mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2012
mljsp0012stat03.csv	Appendix table 3. Heart disease mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2012
mljsp0012stat04.csv	Appendix table 4. Suicide mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2012
mljsp0012stat05.csv	Appendix table 5. Mortality rate for all other unnatural deaths per 100,000 local jail inmates, 2000�2012
mljsp0012stat06.csv	Appendix table 6. Illness mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2012
mljsp0012stat07.csv	Appendix table 7. Cancer mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2012
mljsp0012stat08.csv	Appendix table 8. Heart disease mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2012
mljsp0012stat09.csv	Appendix table 9. Liver disease mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2012
mljsp0012stat10.csv	Appendix table 10. Respiratory disease mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2012
mljsp0012stat11.csv	Appendix table 11. Mortality rate for all other illnesses per 100,000 state prisoners, by selected decedent characteristics, 2001�2012

 




