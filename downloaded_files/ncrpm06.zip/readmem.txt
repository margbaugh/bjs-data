2006 National Corrections Reporting Program

This is one of a series of files from the National Corrections Reporting Program.  
All of the available files back to 1993 may be obtained from
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=36. 

Three groups of tables -- sentence length, time served and most serious offense of state
prisoners-- are archived for each year.

Data for 2006 for some states were estimated to provide continuity.

In addition to the list of tables in this file, the tables in the related archives are listed below.*

This Zip archive, Most serious offense of state prisoners, NCJ 230186
contains the following tables:          

ncrp0601.csv        State prison admissions: offense, by admission type
ncrp0602.csv        New court commitments to state prisons: offense, by age at admission
ncrp0603.csv        Parole violators returned to state prison: offense, by age at admission
ncrp0604.csv        New court commitments to state prisons: offense, by sex, race, and
Hispanic origin
ncrp0605.csv        Parole violators returned to state prison: offense, by sex, race, and
Hispanic origin
ncrp0612.csv        First entries to parole supervision from state prison: method of prison release,
by offense
ncrp0613.csv        First entries to parole supervision from state prison: offense, by sex, race,
and  Hispanic origin
ncrp0614.csv        State parole discharges: method of parole discharge, by offense 

*Note:  Beginning in 1999, Table 7 (New court commitments to state prison:  
sentence length and minimum time to be served, by offense) 
was discontinued.
               
Two related archives are also available.  The tables in these
archives are listed below.

Time served in state prison, 2006 (NCJ 230185)

   File name      Contents

ncrp0608.csv        State prison releases: time served in prison, by offense and release type
ncrp0609.csv        First releases from state prison: sentence length, time served, and percent of
sentence served, by offense
ncrp0610.csv        First releases from state prison: sentence length and time served in prison, by
offense and sex
ncrp0611.csv        First releases from state prison: sentence length and time served in prison, by
offense and race
ncrp0615.csv        Successful first state parole discharges: sentence length and time served, by
offense
ncrp0616.csv        Unsuccessful first state parole discharges: sentence length and time served, by
offense
                               
Sentence length of state prisoners (NCJ 230187)

ncrp0606.csv   State prison admissions: sentence length by offense and admission type 
ncrp0609.csv   First releases from state prison: sentence length, time served, and percent of
sentence served in prison, by
offense
ncrp0610.csv   First releases from state prison: sentence length and time served in prison, by
offense, and sex
ncrp0611.csv   First releases from state prison: sentence length and time served in prison, by
offense, and race 
ncrp0615.csv   Successful first state parole discharges: sentence length and time served, by
offense
ncrp0616.csv   Unsuccessful first state parole discharges: sentence length and time served, by
offense
