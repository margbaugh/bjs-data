Murder in Families,   NCJ  143498
 
This zip archive contains tables in individual .wk1 spreadsheets
from Murder in Families,  NCJ  143498
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/mif.htm 
 
mf1.wk1      Table #:   1   Muder victims and defendants in the 75 largest urban counties, by victim-assailant family relationship, 1988
mf2.wk1      Table #:   2   Sex, race, and age, by the family relationship of murder victims and defendants, 1988
mf3.wk1      Table #:   3   Alcohol use at the time of the murder, history of mental illness, unemployment, and homelessness, by the family relationship of murder victims and defendants, 1998
mf4.wk1      Table #:   4   Murder defendants with a victim of the same sex, by their family relationship, 1988
mf5.wk1      Table #:   5   Murder committed with a firearm, during daytime, or at home, by victim-assailant family relationship, 1988
mf6.wk1      Table #:   6   Multiple victims and assailants, by their family relationship, 1988
mf7.wk1      Table #:   7   Criminal history of murder victims and defendants, by their family relationship, 1988
mf8.wk1      Table #:   8   Criminal history of murder victims and offenders within the same case, by their family relationship, 1988
mf9.wk1      Table #:   9   Level of murder charges filed against persons arrested for murder, by victim-assailant family relationship, 1988
mf10.wk1     Table #:  10  Time to arrest and disposition for murder cases, by victim-assiliant family relationship, 1988
mf11.wk1     Table #:  11  Outcome of prosecution of murder defendants, by victim-assailiant family relationship, 1988
mf12.wk1     Table #:  12  The most serious conviction offense of murder defendants, by victim-assiliant family relationship, 1988
mf13.wk1     Table #:  13  Sentences received by murder defendants convicted of murder or other crime, by victim-assailiant family relationship, 1988
 
 
mfttpg3.wk1  Text table 3:  Family murder victims and defendants
mfttpg4.wk1  Text table 4:  Armed victims and victim-precipitated murders
mfttpg5a.wk1 Text table 5a: Percent of murder victims
mfttpg5b.wk1 Text table 5b: Percent of family murder victims with most likely assailant
mfttpg5c.wk1 Text table 5c: Victims who were children under age 12
mfttpg6.wk1  Text table 6:  Murder weapons used against young children and elderly parents
mfttpg9.wk1  Text table 9:  Coding of circumstances and victim-killer relationships
 
mf2se.wk1    Estimates of 1 standard error for table 2
mf3se.wk1    Estimates of 1 standard error for table 3
mf4se.wk1    Estimates of 1 standard error for table 4
mf5se.wk1    Estimates of 1 standard error for table 5
mf6se.wk1    Estimates of 1 standard error for table 6
mf7se.wk1    Estimates of 1 standard error for table 7
mf8se.wk1    Estimates of 1 standard error for table 8
mf9se.wk1    Estimates of 1 standard error for table 9
mf10se.wk1   Estimates of 1 standard error for table 10
mf11se.wk1   Estimates of 1 standard error for table 11
mf12se.wk1   Estimates of 1 standard error for table 12
mf13se.wk1   Estimates of 1 standard error for table 13
 
mf1se.wk1    Estimates of 1 standard error for text table 3 
mf4ttse.wk1  Estimates of 1 standard error for text table 4
mf5ttse.wk1  Estimates of 1 standard error for text table 5a
mf6ttse.wk1  Estimates of 1 standard error for text table 6
mf5ttbse.wk1 Estimates of 1 standard error for text table 5b
mf5ttcse.wk1 Estimates of 1 standard error for text table 5c
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
