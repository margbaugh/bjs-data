Criminal Victimization, 2020 – Supplemental Statistical Tables  NCJ 303936	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Criminal Victimization, 2020 – Supplemental Statistical Tables  NCJ 303936.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/criminal-victimization-2020-supplemental-statistical-tables
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Criminal%20Victimization	
	
Filenames	Table titles
cv20sstt01.csv	Table 1. Number and percent of persons who were victims of violent crime, by type of crime, 2016–2020
cv20sstt02.csv	Table 2. Number and percent of persons who were victims of violent crime, by demographic characteristics of victims, 2019 and 2020
cv20sstt03.csv	Table 3. Number and percent of households that were victims of property crime, by type of crime, 2016–2020
cv20sstt04.csv	Table 4. Percent of violent incidents, by sex of victims and offenders, 2020
cv20sstt05.csv	Table 5. Percent of violent incidents, by race or ethnicity of victims and offenders, 2020
cv20sstt06.csv	Table 6. Percent of violent victimizations for which victims received assistance from a victim service provider, by type of crime, 2019 and 2020
cv20sstt07.csv	Table 7. Number and rate of violent victimizations, by veteran and citizenship status of victims, 2019 and 2020
cv20sstt08.csv	Table 8. Percent and rate of violent victimizations reported to police, by demographic characteristics of victims, 2019 and 2020
	
		Figures
cv20sstf01.csv	Figure 1. Percent of persons age 12 or older who were victims of violent crime and violent crime excluding simple assault, 1993–2020
	
		Appendix tables
cv20sstat01.csv	Appendix table 1. Estimates and standard errors for figure 1: Percent of persons age 12 or older who were victims of violent crime and violent crime excluding simple assault, 1993–2020
cv20sstat02.csv	Appendix table 2. Standard errors for table 1: Number and percent of persons who were victims of violent crime, by type of crime, 2016–2020
cv20sstat03.csv	Appendix table 3. Standard errors for table 2: Number and percent of persons who were victims of violent crime, by demographic characteristics of victims, 2019 and 2020
cv20sstat04.csv	Appendix table 4. Standard errors for table 3: Number and percent of households that were victims of property crime, by type of crime, 2016–2020
cv20sstat05.csv	Appendix table 5. Standard errors for table 4: Percent of violent incidents, by sex of victims and offenders, 2020
cv20sstat06.csv	Appendix table 6. Standard errors for table 5: Percent of violent incidents, by race or ethnicity of victims and offenders, 2020
cv20sstat07.csv	Appendix table 7. Standard errors for table 6: Percent of violent victimizations for which victims received assistance from a victim service provider, by type of crime, 2019 and 2020
cv20sstat08.csv	Appendix table 8. Standard errors for table 7: Number and rate of violent victimizations, by veteran and citizenship status of victims, 2019 and 2020
cv20sstat09.csv	Appendix table 9. Standard errors for table 8: Percent and rate of violent victimization reported to police, by type of crime and demographic characteristics of victims, 2019 and 2020
cv20sstat10.csv	Appendix table 10. Population of persons age 12 or older, by demographic characteristics, 2016–2020
cv20sstat11.csv	Appendix table 11. Population of households, 2016–2020
	
	
	
