Public Defender Offices, 2007 - Statistical Tables   NCJ 228538

-------------------------------------------------------------------------------

This zip archive contains tables in individual  .csv spreadsheets			
from Public Defender Offices, 2007 - Statistical Tables   NCJ 228538. 
The full report including text and graphics in pdf format are available from: 
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=1758
-------------------------------------------------------------------------------


Table 1. Public defender offices, 2007 
Table 2a. General characteristics of state-based public defender programs, by state, 2007
Table 2b. General characteristics of county-based public defender offices, by funding source and caseload volume, 2007
Table 3a. Criteria state-based programs used to determine whether a defendant qualified for public counsel representation, by state, 2007
Table 3b. Criteria county-based public defender offices used to determine whether a defendant qualified for representation, by funding source and caseload volume, 2007
Table 4a. Formal standards or written guidelines used by state-based public defender programs, by state, 2007
Table 4b. Formal standards or written guidelines used in the hybrid and county-based public defender offices, by funding source and office size, 2007
Table 5a. Cases received in state-based public defender programs, by state and type of case, 2007.
Table 5b. Cases received in county-based public defender offices, by funding source and office size, 2007
Table 6a. Staff employed by state-based public defender programs, by state and position title, 2007
Table 6b. Staff employed by county-based public defender offices, by funding source, office size, and position title, 2007



