"Jails in Indian Country, 2014       NCJ 248974"			
			
This zip archive contains tables in individual  .csv spreadsheets			
"from Jails in Indian Country, 2014  NCJ 248974.   The full report including text			
and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=5414		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=32			
			
			
Filename			Table title
jic14t01.csv			"Table 1. Number of inmates, rated capacity, and percent of capacity occupied in Indian country jails, June 2000, 2004, and 2007�2014"
jic14t02.csv			"Table 2. Indian country jails and percent of inmate population, by facility size, midyear 2014"
jic14t03.csv			"Table 3. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2014"
jic14t04.csv			"Table 4. Admissions and expected length of stay in Indian country jails, by facility size, June 2014"
jic14t05.csv			"Table 5. Admissions and expected length of stay in 69 Indian country jails, by facility size, June 2013 and 2014"
jic14t06.csv			"Table 6. Inmates confined in Indian country jails, by demographic characteristics, conviction status, and offense, midyear 2000 and 2010�2014"
jic14t07.csv			"Table 7. Persons employed in Indian country jails, by job function, midyear 2010, 2013, and 2014"
jic14t08			"Table 8. Indian country jail survey universe and response rates, 2004 and 2007�2014"


Figure Tables
jic14f01.csv                    "Figure 1. Inmates confined in Indian country jails, midyear 2000�2004 and 2007�2014"
jic14f02.csv			"Figure 2. Percent of rated capacity occupied, by facility size, June 2014"

Appendix tables			
jic14at01.csv			"Appendix table 1. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, by facility, June 2014"
jic14at02.csv			"Appendix table 2. Inmates in Indian country jails, by type of offense, midyear 2014"
jic14at03.csv			"Appendix table 3. Inmates in Indian country jails, by conviction status, midyear 2014"
jic14at04.csv			"Appendix table 4. Adults and juveniles in the custody of Indian country jails, by sex, midyear 2014"
jic14at05.csv			"Appendix table 5. Reported inmate characteristics for table 6: Inmates confined in Indian country jails, by demographic characteristics, conviction status, and offense, midyear 2000 and 2010�2014"
jic14at06.csv			"Appendix table 6. Reported number of staff for table 7: Persons employed in Indian country jails, by job function, midyear 2010 and 2013�2014"
	       

