"Criminal Appeals in State Courts      NCJ 248874"	

This zip archive contains tables in individual  .csv spreadsheets			
"from Criminal Appeals in State Courts, NCJ 248874.  The full report including text"			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5368		
			

Filename			Table title
casct01.csv			"Table 1. Percent of criminal appeals disposed in courts of last resort, by appeal characteristics, 2010"
casct02.csv			"Table 2. Percent of criminal appeals disposed in intermediate appellate courts, by appeal characteristics, 2010"
casct03.csv			"Table 3. Percent of criminal appeals reviewed on the merits, by court structure, 2010"
casct04.csv			"Table 4. Number of appeals from death penalty cases, by court, 2010"
			

Figure Tables
cascf01.csv			"Figure 1. Criminal appellate decisions, 2010"
cascf02.csv			"Figure 2. Percent of intermediate appellate court appeals accepted for subsequent court of last resort review, by appeal characteristics, 2010"	
cascf03.csv			"Figure 3. Reversal rates for top 10 issues addressed on appeal, 2010"
cascf04.csv			"Figure 4. Reversal rates for appeals of top 10 most serious offense types in trial case, 2010"
cascf05.csv			"Figure 5. Median days for time on appeal, by milestone, 2010"
cascf06.csv			"Figure 6. Time to resolve appeals, by court structure, 2010"
cascf07.csv			"Figure 7. Time to resolve appeals reviewed on the merits, by court structure, 2010"
cascf08.csv			"Figure 8. Time from appeals start to resolution, by severity of offense, 2010"

Appendix tables			
cascat01.csv			"Appendix table 1. Characteristics of state appellate courts with criminal jurisdiction, by court structure, 2010"
cascat02.csv			"Appendix table 2. Initial and revised sample sizes, by type of case or court, 2010"
cascat03.csv			"Appendix table 3. Standard errors for figure 1: Criminal appellate decisions, 2010"
cascat04.csv			"Appendix table 4. Standard errors for table 1: Percent of criminal appeals disposed in courts of last resort, by appeal characteristics, 2010"
cascat05.csv			"Appendix table 5. Standard errors for table 2: Percent of criminal appeals disposed in intermediate appellate courts, by appeal characteristics, 2010"
cascat06.csv			"Appendix table 6. Standard errors for figure 2: Percent of intermediate appellate court appeals accepted for subsequent court of last resort review, by appeal characteristics, 2010"
cascat07.csv			"Appendix table 7. Standard errors for figure 3: Reversal rates for top 10 issues addressed on appeal, 2010"
cascat08.csv			"Appendix table 8. Standard errors for figure 4: Reversal rates for appeals of top 10 offense types, 2010"
cascat09.csv			"Appendix table 9. Standard errors for figure 5: Median days for time on appeal, by milestone, 2010"
cascat10.csv			"Apendix table 10. Standard errors for figure 6: Time to resolve appeals, by court structure, 2010"
cascat11.csv			"Appendix table 11. Standard errors for figure 7: Time to resolve appeals reviewed on the merits, by court structure, 2010"
cascat12.csv		        "Appendix table 12. Standard errors for table 3: Percent of criminal appeals reviewed on the merits, by court structure, 2010"
cascat13.csv			"Appendix table 13. Standard errors for figure 8: Time from appeals start to resolution, by severity of offense, 2010"