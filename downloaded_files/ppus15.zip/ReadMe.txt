Probation and Parole in the United States, 2015			
			
This zip archive contains tables in individual  .csv spreadsheets			
Probation and Parole in the United States, 2015  NCJ 250230  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5784			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=42			
			
			
Filename			 Table title
ppus15t01.csv		Table 1. Adults under community supervision on probation or parole, yearend 2005?2015	
ppus15t02.csv		Table 2. Rates of U.S. adult residents on community supervision, probation, and parole, 2005-2015	
ppus15t03.csv		Table 3. Rate of probation exits, by type of exit, 2005 and 2010-2015	
ppus15t04.csv		Table 4. Characteristics of adults on probation, 2005, 2014, and 2015	
ppus15t05.csv		Table 5. Rate of parole exits, by type of exit, 2005 and 2010-2015	
ppus15t06.csv		Table 6. Characteristics of adults on parole, 2005, 2014, and 2015	
			
Figure Tables			
ppus15f01.csv		Figure 1. Adults under community supervision on December 31 and annual percent change, 2005-2015	
ppus15f02.csv		Figure 2 . Adults on probation at yearend, 2005-2015	
ppus15f03.csv		Figure 3 . Adults on parole at yearend, 2005-2015	
ppus15f04.csv		Figure 4. Probation entries and exits, 2005-2015	
ppus15f05.csv		Figure 5. Estimated parole entries and exits, 2005-2015	
			
Appendix Tables			
ppus15at01.csv		Appendix Table 1. Adults under community supervision, 2015	
ppus15at02.csv		Appendix Table 2. Adults on probation, 2015	
ppus15at03.csv		Appendix Table 3. Adults exiting probation, by type of exit, 2015	
ppus15at04.csv		Appendix Table 4. Adults on parole, 2015	
ppus15at05.csv		Appendix Table 5. Adults entering parole, by type of entry, 2015	
ppus15at06.csv		Appendix Table 6. Adults exiting parole, by type of exit, 2015	
