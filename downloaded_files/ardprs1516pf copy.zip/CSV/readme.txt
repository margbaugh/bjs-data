Arrest-Related Deaths Program Redesign Study, 2015-16: Preliminary Findings       NCJ 250112			
			
This zip archive contains tables in individual  .csv spreadsheets			
Arrest-Related Deaths Program Redesign Study, 2015-16: Preliminary Findings NCJ 250112.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5864		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=74	
			
			
Filename			 Table title
ardprs1516pft01.csv		Table 1. Arrest-Related Deaths program scope compared to other sources, by manner of death, June 2015�March 2016
ardprs1516pft02.csv		Table 2. Agency-level survey response for deaths identified in June�August 2015
ardprs1516pft03.csv		Table 3. Decedent-level survey response for deaths identified in June�August 2015
ardprs1516pft04.csv		Table 4. Number of deaths according to the Arrest-Related Deaths program, by state, June�August 2015
ardprs1516pft05.csv		Table 5. Manner of death by identification source, June-August, 2015
	

Figure Tables
ardprs1516pff01.csv		Figure 1. Potential arrest-related deaths identified through open source review, June 2015�March 2016
ardprs1516pff02.csv		Figure 2. Arrest-Related Deaths program redesign study coding and classification process
ardprs1516pff03.csv		Figure 3. Percent of potential arrest-related deaths identified through open source review, by number of articles per decedent, June 2015�March 2016

