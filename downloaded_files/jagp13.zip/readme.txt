Justice Assistance Grant (JAG) Program 2013 NCJ
	
This zip archive contains tables in individual .csv spreadsheets	

Report title:  Justice Assistance Grant (JAG) Program 2013 NCJ 242412

The full report including text and graphics in .pdf format are available from:http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4717	

	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=71	


Tables	
jagp13t01.csv 	Table 1. State and local allocation amounts, FY 2013
jagp13t02.csv	Table 2. Territories and District of Columbia allocations, FY 2013
jagp13t03.csv	Table 3. Sex Offender Registration and Notification Act bonus fund allocation, FY2013


Figure	
jagp13f01.csv	Figure 1: Distribution of FY 2013 JAG funds
