Effects of NIBRS on Crime Statistics
NCJ 178890

Contents of this zip archive


encs01.wk1	Table 1.  Agencies with 12 months of NIBRS reporting and nonzero population, by the number of years of reporting, 1991-96 

encs04.wk1	Table 4.  Percent of large cases (population over 25,000), by percent difference in violent crime rate comparing NIBRS to Summary UCR, by type of crime, 1991-96 

encs05.wk1	Table 5.  Percent of large cases (population over 25,000), by percent difference in property crime rate comparing NIBRS to Summary UCR, by type of crime, 1991-96 

encs06.wk1	Table 6.  Number of incidents, by type of crime and concurrent offense(s), single victim, single offender, 1996

encsf1.wk1	Figure 1.  Agencies and population covered, by year, for agencies with with 12 months of NIBRS reporting and nonzero population, 1991-96 

encsf2.wk1	Figure 2.  Average percent difference in crime rates when comparing NIBRS to Summary UCR, by type of crime, 1991-96

encsf3.wk1	Figure 3.  Percent difference in Index crime rates when comparing NIBRS to Summary UCR, by number of cases, 1991-96

encsf4.wk1	Figure 4.  Percent difference in violent and property crime rates when comparing NIBRS to Summary UCR, by number of cases, 1991-96

encsf5.wk1	Figure 5.  Average percent difference in crime rates for large jurisdictions (population over 25,000) when comparing NIBRS to Summary UCR, by type of crime, 1991-96