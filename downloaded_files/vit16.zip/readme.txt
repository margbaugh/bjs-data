Victims of Identity Theft, 2016  NCJ 251147	
	
This zip archive contains tables in individual .csv spreadsheets	
from Victims of Identity Theft, 2016  NCJ 251147. The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6323	
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://www.bjs.gov/index.cfm?ty=tp&tid=42	
	
Filename	Table name
vit16t01.csv	Table 1. Prevalence of identity theft in continuing counties and full sample, by type of identity theft, 2014 and 2016
vit16t02.csv	Table 2. Persons age 16 or older who had experienced at least one identity-theft incident during the past 12 months, by victim characteristics and type of theft, 2016
vit16t03.csv	Table 3. The most recent incident of identity theft, by type of theft, 2016
vit16t04.csv	Table 4. The most common ways victims had discovered identity theft, by type of theft, 2016
vit16t05.csv	Table 5. Identity-theft victims who knew something about the offender, by type of theft, 2016
vit16t06.csv	Table 6. Financial loss among victims who had experienced at least one attempted or successful identity-theft incident in the past 12 months, by type of loss and theft, 2016
vit16t07.csv	Table 7. Victims who had experienced financial or legal problems as a result of identity theft, by type of theft, 2016
vit16t08.csv	Table 8. Identity-theft victims who had experienced emotional distress, by type of theft, 2016
vit16t09.csv	Table 9. Victims who did and did not report identity theft to police, by type of theft and reason for not reporting, 2016
vit16t10.csv	Table 10. Identity-theft victims, by type of theft and type of organization contacted, 2016
vit16t11.csv	Table 11. Identity-theft victims who contacted a credit bureau, by type of theft and action taken, 2016
vit16t12.csv	Table 12. Actions persons age 16 or older had taken during the past 12 months to reduce the risk of identity theft, by whether the action was taken in response to experiencing identity theft, 2016
vit16t13.csv	Table 13. Persons age 16 or older who experienced identity theft in their lifetime, by type of identity theft experienced outside the past year and ongoing problems from identity theft, 2016
	
vit16f01.csv	Figure 1. Persons age 16 or older who had experienced at least one identity-theft incident in the past 12 months, by type of theft, 2016
vit16f02.csv	Figure 2. Identity-theft victims who knew how their personal information was obtained, by type of theft, 2016
vit16f03.csv	Figure 3. Total out-of-pocket loss for identity-theft victims experiencing a loss of $1 or more, 2016
vit16f04.csv	Figure 4. Victims of identity theft who had experienced work/school and family/friend problems as a result of the victimization, by type of theft, 2016
vit16f05.csv	Figure 5. Length of time spent resolving financial and credit problems associated with identity theft, by type of theft, 2016
vit16f06.csv	Figure 6. Identity-theft victims who reported severe emotional distress due to the crime, by length of time spent resolving associated financial and credit problems, 2016
	
vit16at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Persons age 16 or older who had experienced at least one identity-theft incident in the past 12 months, by type of theft, 2016
vit16at02.csv	Appendix table 2. Standard errors for table 1: Prevalence of identity theft in continuing counties and full sample, by type of identity theft, 2014 and 2016
vit16at03.csv	Appendix table 3. Standard errors for table 2: Persons age 16 or older who had experienced at least one identity-theft incident during the past 12 months, by victim characteristics and type of theft, 2016
vit16at04.csv	Appendix table 4. Standard errors for table 3: The most recent incident of identity theft, by type of theft, 2016
vit16at05.csv	Appendix table 5. Standard errors for table 4: The most common ways victims had discovered identity theft, by type of theft, 2016
vit16at06.csv	Appendix table 6. Estimates and standard errors for figure 2: Identity-theft victims who knew how their personal information was obtained, by type, 2016
vit16at07.csv	Appendix table 7. Standard errors for table 5: Identity-theft victims who knew something about the offender, by type of theft, 2016
vit16at08.csv	Appendix table 8. Standard errors for table 6: Financial loss among victims who had experienced at least one attempted or successful identity-theft incident in the past 12 months, by type of loss and theft, 2016
vit16at09.csv	Appendix table 9. Estimates and standard errors for figure 3: Total out-of-pocket loss for identity-theft victims experiencing a loss of $1 or more, 2016
vit16at10.csv	Appendix table 10. Standard errors for table 7: Victims who had experienced financial or legal problems as a result of identity theft, by type of theft, 2016
vit16at11.csv	Appendix table 11. Estimates and standard errors for figure 4: Victims of identity theft who had experienced work/school and family/friend problems as a result of the victimization, by type of theft, 2016
vit16at12.csv	Appendix table 12. Standard errors for table 8: Identity-theft victims who had experienced emotional distress, by type of theft, 2016
vit16at13.csv	Appendix table 13. Estimates for figure 5: Length of time spent resolving financial and credit problems associated with identity theft, by type of theft, 2016
vit16at14.csv	Appendix table 14. Standard errors for figure 5: Length of time spent resolving financial and credit problems associated with identity theft, by type of theft, 2016
vit16at15.csv	Appendix table 15. Estimates and standard errors for figure 6: Identity-theft victims who reported severe emotional distress due to the crime, by length of time spent resolving associated financial and credit problems, 2016
vit16at16.csv	Appendix table 16. Standard errors for table 9: Victims who did and did not report identity theft to police, by type of theft and reason for not reporting, 2016
vit16at17.csv	Appendix table 17. Standard errors for table 10: Identity-theft victims, by type of theft and type of organization contacted, 2016
vit16at18.csv	Appendix table 18. Standard errors for table 11: Identity-theft victims who contacted a credit bureau, by type of theft and action taken, 2016
vit16at19.csv	Appendix table 19. Standard errors for table 12: Actions persons age 16 or older had taken during the past 12 months to reduce the risk of identity theft, by whether the action was taken in response to experiencing identity theft, 2016
vit16at20.csv	Appendix table 20. Standard errors for table 13: Persons age 16 or older who experienced identity theft in their lifetime, by type of identity theft experienced outside the past year and ongoing problems from identity theft, 2016
vit16at21.csv	Appendix table 21. U.S. residential population age 16 or older, by demographic characteristics, 2016
vit16at22.csv	Appendix table 22. Persons age 16 or older who had a credit card or a bank account during the past 12 months, by demographic characteristics, 2016
