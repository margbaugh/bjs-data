Violent Victimization by Race or Ethnicity, 2005-2019  NCJ 255578		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Violent Victimization by Race or Ethnicity, 2005-2019  NCJ 255578. The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7126		
		
Filenames		Table names
vvre0519sft01.csv	Table 1. Rate of violent victimizations, by victim race or ethnicity, 2005-2019
vvre0519sft02.csv	Table 2. Number of violent victimizations, by victim race or ethnicity, 2005-2019
		
			Appendix tables
vvre0519sfat01.csv	Appendix table 1. Standard errors for table 1: Rate of violent victimizations, by victim race or ethnicity, 2005-2019
vvre0519sfat02.csv	Appendix table 2. Standard errors for table 2: Number of violent victimizations, by victim race or ethnicity, 2005-2019
		
		
		
		
		
