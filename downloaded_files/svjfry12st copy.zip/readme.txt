 Supplemental tables from National Survey of Youth in Custody (NSYC) data collection		
		
 		
This zip archive contains tables in individual .csv spreadsheets created from		
National Survey of Youth in Custody (NSYC) data collection.  		
		
The full electronic version of the report Sexual Victimization in Juvenile Facilities Reported by Youth, 2012 see		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4656		
		
		
Filename		Table title
svjfry12t01.csv		Table 1. Prevalence of any sexual victimization, by race, Hispanic origin,and sexual orientation, National Survey of Youth in Custody, 2012
svjfry12t02.csv		Table 2. Prevalence of  sexual victimization by another youth, by victims' race, Hispanic origin, and sexual victimization, National Survey of Youth in Custody, 2012
svjfry12t03.csv		Table 3. Prevalence of  sexual victimization by facility staff, by victims' race, Hispanic origin, and sexual orientation, National Survey of Youth in Custody, 2012
