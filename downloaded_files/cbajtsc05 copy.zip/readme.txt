Contract Bench and Jury Trials in State Courts, 2005	NCJ 225634

This zip archive contains tables in individual  .csv spreadsheets			
from Contract Bench and Jury Trials in State Courts, 2005, NCJ 225634. The full report including text	
and graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/cbajtsc05.htm



			
Filename			Table title
cbajtsc05t01.csv		Table 1. Selected characteristics of state court contract trials in the nation's 75 largest counties, 1996 and 2005
cbajtsc05t02.csv		Table 2. Contract trials disposed of in state courts, by case type, 2005
cbajtsc05t03.csv		Table 3. Plaintiffs and defendants in state court contract trials, by case type, 2005
cbajtsc05t04.csv		Table 4. Contract jury and bench trials in state courts, by primary litigant pairings, 2005
cbajtsc05t05.csv		Table 5. Unrepresented plaintiffs and defendants in state court contract trials, by case type, 2005
cbajtsc05t06.csv		Table 6. Winning plaintiffs in state court contract trials, by case type, 2005
cbajtsc05t07.csv		Table 7. Final award amounts in state court contract bench and jury trials with plaintiff winners, by case type, 2005
cbajtsc05t08.csv		Table 8. Final awards to plaintiff winners of state court contract trials, by case type and litigant pairing, 2005
cbajtsc05t09.csv		Table 9. Award amounts for plaintiffs awarded punitive damages in state court contract trials, by case type, 2005
cbajtsc05t10.csv		Table 10. Post-verdict relief sought by plaintiffs or defendants in state court contract trials, by winners, 2005
cbajtsc05t11.csv		Table 11. Post-verdict relief granted to plaintiffs or defendants in state court contract trials, by winners, 2005
cbajtsc05t12.csv		Table 12. State court contract trials in which plaintiff or defendant gave notice of appeal, by case type, 2005
cbajtsc05at01.csv		Appendix table 1. Selected estimates, standard errors, and confidence intervals
cbajtsc05at02.csv		Appendix table 2. Percentage of plaintiff winners, by sampled county, 2005
cbajtsc05at03.csv		Appendix table 3. Final and punitive damage awards for plaintiff winners in state court contract trials, by sampled county,2005
cbajtsc05at04.csv		Appendix table 4. Post-verdict relief sought in state court contract trials, 2005, by sampled county
cbajtsc05at05.csv		Appendix table 5. Notice of appeal filed with trial court in state court contract trials, 2005, by sampled county


			
Figures			
cbajtsc05f01.csv		Figure 1: Percent of plaintiff winners in select contract cases disposed of by trial in state general jurisdiction courts, 2005
cbajtsc05f02.csv		Figure 2: In 11 jurisdictions, 99% of contract cases were disposed without trial


			
Text tables			
cbajtsc05tt01.csv		Text table 1. Winning plaintiffs in state court contract trials by selected litigant pairings