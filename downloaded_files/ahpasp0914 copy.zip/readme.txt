Arrest History of Persons Admitted to State Prison in 2009 and 2014  NCJ 305022		
		
This zip archive contains tables in individual .csv spreadsheets		
from Arrest History of Persons Admitted to State Prison in 2009 and 2014  NCJ 305022.		
The full report including text and graphics in .pdf format is available at:		
https://bjs.ojp.gov/library/publications/arrest-history-persons-admitted-state-prison-2009-and-2014

This report is part of a series and there may be a more recent version. See 
https://bjs.ojp.gov/library/publications/list?series_filter=Recidivism%20of%20Prisoners%20Released
		
Filenames		Table titles	
ahpasp0914t01.csv	Table 1. Demographic characteristics of persons admitted to state prison in 2009 and 2014	
ahpasp0914t02.csv	Table 2. Type of admission and most serious commitment offense of persons admitted to state prison in 2009 and 2014	
ahpasp0914t03.csv	Table 3. Demographic characteristics of persons admitted to state prison in 2014, by type of admission	
ahpasp0914t04.csv	Table 4. Age at first arrest and criminal history length of persons admitted to state prison in 2009 and 2014	
ahpasp0914t05.csv	Table 5. Criminal history length of persons admitted to state prison in 34 states in 2014, by age at admission	
ahpasp0914t06.csv	Table 6. Criminal history of persons admitted to state prison in 2009 and 2014	
ahpasp0914t07.csv	Table 7. Prior out-of-state arrests of persons admitted to state prison in 2009 and 2014	
ahpasp0914t08.csv	Table 8. Persons admitted to state prison in 2009 and 2014 who had at least one prior out-of-state arrest, by demographic characteristics	
ahpasp0914t09.csv	Table 9. Prior arrest offenses of persons admitted to state prison in 2009 and 2014 	
ahpasp0914t10.csv	Table 10. Prior arrest offenses of persons admitted to state prison in 34 states in 2014, by demographic characteristics	
ahpasp0914t11.csv	Table 11. Prior arrest offenses of persons admitted to state prison in 26 states in 2009 and 2014, by demographic characteristics	
ahpasp0914t12.csv	Table 12. Release status of persons admitted to state prison in 2009 and 2014, by year and type of release	
ahpasp0914t13.csv	Table 13. Persons admitted to state prison in 2009 who were arrested in the first 2 years following release, by demographic characteristics	
ahpasp0914t14.csv	Table 14. Persons admitted to state prison in 2014 who were arrested in the first 2 years following release, by demographic characteristics 
ahpasp0914t15.csv	Table 15. Persons admitted to state prison in 2009 who were arrested in the first 2 years following release, by type of post-release arrest offense
ahpasp0914t16.csv	Table 16. Persons admitted to state prison in 2014 who were arrested in the first 2 years following release, by type of post-release arrest offense
		
			Figures	
ahpasp0914f01.csv	Figure 1. Prior arrests of persons admitted to state prison in 2009 and 2014	
ahpasp0914f02.csv	Figure 2. Age at first arrest of persons admitted to state prison in 26 states in 2009 and 2014	
ahpasp0914f03.csv	Figure 3. Persons admitted to state prison in 34 states in 2014 who accounted for all prior arrests	
ahpasp0914f04.csv	Figure 4. Prior arrests of persons admitted to state prison in 34 states in 2014	
ahpasp0914f05.csv	Figure 5. Prior arrests of persons admitted to state prison in 34 states in 2014, by sex	
ahpasp0914f06.csv	Figure 6. Prior arrests of persons admitted to state prison in 34 states in 2014, by race or Hispanic origin	
		
			Appendix tables	
ahpasp0914at01.csv	Appendix table 1. Persons admitted to state prison in 29 states in 2009 who were included in the study sample and whose criminal history data were collected, by state	
ahpasp0914at02.csv	Appendix table 2. Persons admitted to state prison in 34 states in 2014 who were included in the study sample and whose criminal history data were collected, by state	
ahpasp0914at03.csv	Appendix table 3. Standard errors for table 1: Demographic characteristics of persons admitted to state prison in 2009 and 2014	
ahpasp0914at04.csv	Appendix table 4. Standard errors for table 2: Type of admission and most serious commitment offense of persons admitted to state prison in 2009 and 2014	
ahpasp0914at05.csv	Appendix table 5. Standard errors for table 3: Demographic characteristics of persons admitted to state prison in 2014, by type of admission	
ahpasp0914at06.csv	Appendix table 6. Standard errors for table 4: Age at first arrest and criminal history length of persons admitted to state prison in 2009 and 2014	
ahpasp0914at07.csv	Appendix table 7. Estimates and standard errors for figure 2: Age at first arrest of persons admitted to state prison in 26 states in 2009 and 2014	
ahpasp0914at08.csv	Appendix table 8. Standard errors for table 5: Criminal history length of persons admitted to state prison in 34 states in 2014, by age at admission	
ahpasp0914at09.csv	Appendix table 9. Standard errors for table 6: Criminal history of persons admitted to state prison in 2009 and 2014	
ahpasp0914at10.csv	Appendix table 10. Estimates for figure 3: Persons admitted to state prison in 34 states in 2014 who accounted for all prior arrests	
ahpasp0914at11.csv	Appendix table 11. Estimates and standard errors for figure 4: Prior arrests of persons admitted to state prison in 34 states in 2014	
ahpasp0914at12.csv	Appendix table 12. Estimates and standard errors for figure 5: Prior arrests of persons admitted to state prison in 2014, by sex 	
ahpasp0914at13.csv	Appendix table 13. Prior arrests of persons admitted to state prison in 34 states in 2014, by sex	
ahpasp0914at14.csv	Appendix table 14. Standard errors for appendix table 13: Prior arrests of persons admitted to state prison in 34 states in 2014, by sex	
ahpasp0914at15.csv	Appendix table 15. Estimates and standard errors for figure 6: Prior arrests of persons admitted to state prison in 2014, by race or Hispanic origin	
ahpasp0914at16.csv	Appendix table 16. Prior arrests of persons admitted to state prison in 34 states in 2014, by race or Hispanic origin	
ahpasp0914at17.csv	Appendix table 17. Standard errors for appendix table 16: Prior arrests of persons admitted to state prison in 34 states in 2014, by race or Hispanic origin	
ahpasp0914at18.csv	Appendix table 18. Estimates and standard errors for figure 7: Prior arrests of persons admitted to state prison in 34 states in 2014, by type of admission	
ahpasp0914at19.csv	Appendix table 19. Prior arrests of persons admitted to state prison in 34 states in 2014, by type of admission	
ahpasp0914at20.csv	Appendix table 20. Standard errors for appendix table 19: Prior arrests of persons admitted to state prison in 34 states in 2014, by type of admission	
ahpasp0914at21.csv	Appendix table 21. Standard errors for table 7: Prior out-of-state arrests of persons admitted to state prison in 2009 and 2014	
ahpasp0914at22.csv	Appendix table 22. Standard errors for table 8: Persons admitted to state prison in 2009 and 2014 who had at least one prior out-of-state arrest, by demographic characteristics   	
ahpasp0914at23.csv	Appendix table 23. Standard errors for table 9: Prior arrest offenses of persons admitted to state prison in 2009 and 2014 	
ahpasp0914at24.csv	Appendix table 24. Standard errors for table 10: Prior arrest offenses of persons admitted to state prison in 34 states in 2014, by demographic characteristics	
ahpasp0914at25.csv	Appendix table 25. Standard errors for table 11: Prior arrest offenses of persons admitted to state prison in 26 states in 2009 and 2014, by demographic characteristics	
ahpasp0914at26.csv	Appendix table 26. Standard errors for table 12: Release status of persons admitted to state prison in 2009 and 2014, by year and type of release	
ahpasp0914at27.csv	Appendix table 27. Standard errors for table 13: Persons admitted to state prison in 2009 who were arrested in the first 2 years following release, by demographic characteristics	
ahpasp0914at28.csv	Appendix table 28. Standard errors for table 14: Persons admitted to state prison in 2014 who were arrested in the first 2 years following release, by demographic characteristics   	
ahpasp0914at29.csv	Appendix table 29. Standard errors for table 15: Persons admitted to state prison in 2009 who were arrested in the first 2 years following release, by type of post-release arrest offense	
ahpasp0914at30.csv	Appendix table 30. Standard errors for table 16: Persons admitted to state prison in 2014 who were arrested in the first 2 years following release, by type of post-release arrest offense 