Tribal Crime Data-Collection Activities, 2020  NCJ 254789		
		
This .zip archive contains tables in individual  .csv spreadsheets		
Tribal Crime Data-Collection Activities, 2020  NCJ 254789.  The full report including text		
and graphics in .pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6966		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://www.bjs.gov/index.cfm?ty=pbse&sid=77		
		
Filename		Table name
tcdca20t01.csv		Table 1. Universe and response rates for the Census of Tribal Law Enforcement Agencies, by type of agency, 2019
tcdca20t02.csv		Table 2. Jail incarceration rates, by race or ethnicity, 2010-2018
tcdca20t03.csv		Table 3. Annual percent of prisoners released across 30 states in 2005 who were arrested following release, by race or ethnicity and year after release, 2005-2014
tcdca20t04.csv		Table 4. Offenders sentenced in U.S. district courts, by race, FY 2012-2016 
		
			Figures
tcdca20f01.csv		Figure 1. Jail incarceration rates, by race or ethnicity, 2010-2018
tcdca20f02.csv		Figure 2. Cumulative percent of prisoners released across 30 states in 2005 who were arrested following release, by year after release, 2005-2014
		
			Appendix tables
tcdca20at01.csv		Appendix table 1. Standard errors for table 2: Jail incarceration rates, by race or ethnicity, 2010-2018
tcdca20at02.csv		Appendix table 2. Estimates for figure 2: Cumulative percent of prisoners released across 30 states in 2005 who were arrested following release, by year after release, 2005-2014
tcdca20at03.csv		Appendix table 3. Standard errors for figure 2: Cumulative percent of prisoners released across 30 states in 2005 who were arrested following release, by year after release, 2005-2014
tcdca20at04.csv		Appendix table 4. Standard errors for table 3: Annual percent of prisoners released across 30 states in 2005 who were arrested following release, by race or ethnicity and year after release, 2005-2014
