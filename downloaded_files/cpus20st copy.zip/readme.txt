Correctional Populations in the United States, 2020 – Statistical Tables   NCJ 303184 	
	
This zip archive contains tables in individual .csv spreadsheets	
from Correctional Populations in the United States, 2020 – Statistical Tables   NCJ 303184 	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/correctional-populations-united-states-2020-statistical-tables
	
These statistical tables are in a series.  More recent editions	
may be available.  To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Correctional%20Populations%20in%20the%20United%20States	
	
Filenames		Table titles
cpus20stt01.csv		Table 1. Number of persons supervised by adult correctional systems in the United States, by correctional status, 2010–2020
cpus20stt02.csv		Table 2. Change in the number of persons supervised by adult correctional systems in the United States, 2010–20
cpus20stt03.csv		Table 3. Composition of the adult correctional system in the United States, by correctional status, 2010 and 2020
cpus20stt04.csv		Table 4. Rate of persons supervised by adult correctional systems in the United States, by correctional status, 2010–2020
cpus20stt05.csv		Table 5. Number of persons with dual correctional statuses at yearend, 2010–2020
	
			Figures
cpus20stf01.csv		Figure 1. Number of persons under the supervision of adult correctional systems in the United States, 2010–2020
	
			Appendix tables
cpus20stat01.csv	Appendix table 1. Number of persons incarcerated by other adult correctional systems, 2010, 2019, and 2020
cpus20stat02.csv	Appendix table 2. Custody counts of adults in state or federal prisons or local jails, 2010, 2019, and 2020
cpus20stat03.csv	Appendix table 3. Standard errors for local jail inmates at midyear, 2010–2020
