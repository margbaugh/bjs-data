Substantiated Incidents of Sexual Victimization Reported by Adult Correctional Authorities, 2016–2018  NCJ 304834	
	
This zip archive contains tables in individual .csv spreadsheets	
from Substantiated Incidents of Sexual Victimization Reported by Adult Correctional Authorities, 2016–2018  NCJ 304834	
The full report including text and graphics in pdf format is available from 	
https://bjs.ojp.gov/library/publications/substantiated-incidents-sexual-victimization-reported-adult-correctional
	
This report is one in a series.  More recent editions	
may be available. To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Publications	
	
Filenames		Table titles
sisvraca1618t01.csv	Table 1. Incidents involving single or multiple victims or perpetrators, by type of victimization, 2016–18
sisvraca1618t02.csv	Table 2. Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t03.csv	Table 3. Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2016–18
sisvraca1618t04.csv	Table 4. Demographic characteristics of victims in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t05.csv	Table 5. Demographic characteristics of perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t06.csv	Table 6. Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18 
sisvraca1618t07.csv	Table 7. Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2016–18 
sisvraca1618t08.csv	Table 8. Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t09.csv	Table 9. Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2016–18
sisvraca1618t10.csv	Table 10. Demographic characteristics of victims in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t11.csv	Table 11. Demographic characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t12.csv	Table 12. Employment characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618t13.csv	Table 13. Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18 
sisvraca1618t14.csv	Table 14. Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2016–18 
sisvraca1618t15.csv	Table 15. Selected characteristics of substantiated incidents of inmate-on-inmate sexual harassment, by type of facility, 2016–18
sisvraca1618t16.csv	Table 16. Demographic characteristics of victims and perpetrators in substantiated incidents of inmate-on-inmate sexual harassment, 2016–18
sisvraca1618t17.csv	Table 17. Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual harassment, by type of facility, 2016–18
	
			Figures
sisvraca1618f01.csv	Figure 1: Number of substantiated incidents of sexual victimization, by type of victimization, 2016–18
	
			Appendix tables
sisvraca1618at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Number of substantiated incidents of sexual victimization, by type of victimization, 2016–18
sisvraca1618at02.csv	Appendix table 2. Standard errors for table 1: Incidents involving single or multiple victims or perpetrators, by type of victimization, 2016–18 
sisvraca1618at03.csv	Appendix table 3. Standard errors for table 2: Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at04.csv	Appendix table 4. Standard errors for table 3: Selected characteristics of substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2016–18
sisvraca1618at05.csv	Appendix table 5. Standard errors for table 4: Demographic characteristics of victims in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at06.csv	Appendix table 6. Standard errors for table 5: Demographic characteristics of perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at07.csv	Appendix table 7. Standard errors for table 6: Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization, 2016–18 
sisvraca1618at08.csv	Appendix table 8. Standard errors for table 7: Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of victimization and facility, 2016–18 
sisvraca1618at09.csv	Appendix table 9. Standard errors for table 8: Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at10.csv	Appendix table 10. Standard errors for table 9: Selected characteristics of substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2016–18
sisvraca1618at11.csv	Appendix table 11. Standard errors for table 10: Demographic characteristics of victims in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at12.csv	Appendix table 12. Standard errors for table 11: Demographic characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at13.csv	Appendix table 13. Standard errors for table 12: Employment characteristics of perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18
sisvraca1618at14.csv	Appendix table 14. Standard errors for table 13: Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization, 2016–18 
sisvraca1618at15.csv	Appendix table 15. Standard errors for table 14: Outcomes for victims and perpetrators in substantiated incidents of staff-on-inmate sexual victimization, by type of victimization and facility, 2016–18 
sisvraca1618at16.csv	Appendix table 16. Standard errors for table 15: Selected characteristics of substantiated incidents of inmate-on-inmate sexual harassment, by type of facility, 2016–18
sisvraca1618at17.csv	Appendix table 17. Standard errors for table 16: Demographic characteristics of victims and perpetrators in substantiated incidents of inmate-on-inmate sexual harassment, 2016–18
sisvraca1618at18.csv	Appendix table 18. Standard errors for table 17: Outcomes for victims and perpetrators in substantiated incidents of inmate-on-inmate sexual harassment, by type of facility, 2016–18
