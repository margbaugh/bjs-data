Trends and Patterns in Firearm Violence, 1993-2018  NCJ 251663	
	
This .zip archive contains tables in individual  .csv spreadsheets	
Trends and Patterns in Firearm Violence, 1993-2018  NCJ 251663.  The full report including text	
and graphics in .pdf format is available from:	
https://bjs.ojp.gov/library/publications/trends-and-patterns-firearm-violence-1993-2018	
	
Filenames		Table titles
tpfv9318t01.csv		Table 1. Firearm homicide, 1993–2018
tpfv9318t02.csv		Table 2. Nonfatal firearm victimization against persons age 12 or older, 1993–2018
tpfv9318t03.csv		Table 3. Percent of fatal and nonfatal violence involving a firearm, by type of crime, 1993–2018
tpfv9318t04.csv		Table 4. Firearm homicide, by type of firearm, 1993–2018
tpfv9318t05.csv		Table 5. Nonfatal firearm victimization, by type of firearm, 1995–2018 (3-year rolling averages)
tpfv9318t06.csv		Table 6. Firearm homicide against persons age 12 or older, by victim characteristics, 2014–18
tpfv9318t07.csv		Table 7. Nonfatal firearm victimization against persons age 12 or older, by victim characteristics, 2014–18
tpfv9318t08.csv		Table 8. Nonfatal violence excluding simple assault, by presence of firearm and victim-offender relationship, 2014–18
tpfv9318t09.csv		Table 9. Nonfatal violence excluding simple assault, by presence of firearm and location of crime, 2014–18
tpfv9318t10.csv		Table 10. Nonfatal violence excluding simple assault, by presence of firearm, injury, and treatment received, 2014–18
tpfv9318t11.csv		Table 11. Nonfatal violence excluding simple assault, by presence of firearm, reporting to police, and reason for not reporting, 2014–18
tpfv9318t12.csv		Table 12. Self-protective behaviors of victims, by type of crime, 2014–18
tpfv9318t13.csv		Table 13. Incidents of nonfatal firearm violence, by characteristics of U.S. population, offender, and victim, 2014–18
	
			Figures
tpfv9318f01.csv		Figure 1. Rate of firearm homicide per 100,000 persons, 1993–2018
tpfv9318f02.csv		Figure 2. Rate of nonfatal firearm victimization per 1,000 persons age 12 or older, 1993–2018
tpfv9318f03.csv		Figure 3. Nonfatal victimizations involving the theft of a firearm, 1993–2018
	
			Appendix tables
tpfv9318at01.csv	Appendix table 1. Population estimates for figure 1: Rate of firearm homicide per 100,000 persons, 1993–2018; and for table 1: Firearm homicide, 1993–2018
tpfv9318at02.csv	Appendix table 2. Population estimates and standard errors for figure 2: Rate of nonfatal firearm victimization per 100,000 persons age 12 or older, 1993–2018; and for table 2: Nonfatal firearm victimization against persons age 12 or older, 1993–2018
tpfv9318at03.csv	Appendix table 3. Standard errors for table 3: Percent of fatal and nonfatal violence involving a firearm, by type of crime, 1993–2018
tpfv9318at04.csv	Appendix table 4. Standard errors for table 5: Nonfatal firearm victimization, by type of firearm, 1995–2018 (3-year rolling averages)
tpfv9318at05.csv	Appendix table 5. Population estimates for table 6: Firearm homicide against persons age 12 or older, by victim characteristics, 2014–18
tpfv9318at06.csv	Appendix table 6. Population estimates and standard errors for table 7: Nonfatal firearm victimization against persons age 12 or older, by victim characteristics, 2014–18
tpfv9318at07.csv	Appendix table 7. Standard errors for table 8: Nonfatal violence excluding simple assault, by presence of firearm and victim-offender relationship, 2014–18
tpfv9318at08.csv	Appendix table 8. Standard errors for table 9: Nonfatal violence excluding simple assault, by presence of firearm and location of crime, 2014–18
tpfv9318at09.csv	Appendix table 9. Estimates and standard errors for figure 3: Nonfatal victimizations involving the theft of a firearm, 1993–2018
tpfv9318at10.csv	Appendix table 10. Standard errors for table 10: Nonfatal violence excluding simple assault, by presence of firearm, injury, and treatment received, 2014–18
tpfv9318at11.csv	Appendix table 11. Standard errors for table 11: Nonfatal violence excluding simple assault, by presence of firearm, reporting to police, and reason for not reporting, 2014–18
tpfv9318at12.csv	Appendix table 12. Standard errors for table 12: Self-protective behaviors of victims, by type of crime, 2014–18
tpfv9318at13.csv	Appendix table 13. Standard errors for table 13: Incidents of nonfatal firearm violence, by characteristics of U.S. population, offender, and victim, 2014–18
	
	
	
	
	
	
