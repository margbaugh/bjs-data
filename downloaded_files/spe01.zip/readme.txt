State Prison Expenditures, 2001 NCJ-202949

-------------------------------------------------------------
This zip archive contains tables in individual .wk1 spreadsheets
from State Prison Expenditures, 2001 NCJ-202949
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/spe01.htm

This report is one in a series.  More recent editions may 
be available. To view a list of all in the series go to 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#spe
-------------------------------------------------------------

File name       Table title
spe0101.wk1	Table 1: Annual per capita costs, in 2001 constant dollars, for selected State expenditures, 1986-2001
spe0102.wk1	Table 2: Total, operating, and capital expenditures, and operating costs per State inmate and per U.S. resident, fiscal year 2001
spe0103.wk1	Table 3: Components of State prison operating expenditures,fiscal year 2001
spe0104.wk1	Table 4: Components of State prison capital expendtures, fiscal year 2001
spe0105.wk1 	Table 5: State prison expenditures for medical care, food service, and utilities,  fiscal year 2001



File name	Text table title
texttable1	Table 1: State prison expenditures,2001
texttable2	Table 2: States with the largest and smallest expenditures
texttable3	Table 3: States with the highest and lowest average annual operating costs per inmate
texttable4	Table 4: Operating costs per resident among States with integrated systems
texttable5	Table 5: Components of State prison capital expenditures 
texttable6	Table 6: Contract housing as a percentage of total expenditure
					