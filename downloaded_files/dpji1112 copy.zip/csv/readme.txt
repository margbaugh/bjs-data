"Disabilities Among Prison and Jail Inmates, 2011-12 NCJ 249151"	
	
"This zip archive contains tables in individual .csv spreadsheets from Disabilities Among Prison and Jail Inmates, 2011-12 NCJ 249151"
 The full report including text and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=5500	
				
	
	
Tables	
dpji1112at01.csv	"Appendix table 1. Estimated percentages and standard errors for figure 1: Prevalence of disabilities among state and federal prisoners and jail inmates, by sex 2011?12"
dpji1112at02.csv	"Appendix table 2. Prevalence of disabilities among the general population, by demographic characteristics, 2011?12"
dpji1112at03.csv	"Appendix table 3. Standard errors for appendix table 2: Prevalence of disabilities among the general population, by demographic characteristics, 2011?12"
dpji1112at04.csv	"Appendix table 4. State and federal prisoners and jail inmates, by demographic characteristics, 2011?12"
dpji1112at05.csv	"Appendix table 5. Standard errors for table 4: Prevalence of disabilities among state and federal prisoners, by demographic characteristics, 2011?12"
dpji1112at06.csv	"Appendix table 6. Standard errors for table 5:  Prevalence of disabilities among jail inmates, by demographic characteristics, 2011?12"
dpji1112at07.csv	"Appendix table 7. Estimated percentages and standard errors for figure 2: Prevalence of past 30-day serious psychological distress among state and federal prisoners and jail inmates, by type disability, 2011?12"
dpji1112at08.csv	"Appendix table 8. Prevalence of those in the general population with past 30-day serious psychological distress, standardized to the prison and the jail population, 2009?12"
dpji1112t01.csv	"Table 1. Prevalence of disabilities among state and federal prisoners and the general population, standardized, 2011?12"
dpji1112t02.csv	"Table 2. Prevalence of disabilities among jail inmates and the general population, standardized, 2011?12"
dpji1112t03.csv	"Table 3. Number of disabilities reported by state and federal prisoners and jail inmates, 2011?12"
dpji1112t04.csv	"Table 4. Prevalence of disabilities among state and federal prisoners, by demographic characteristics, 2011?12"
dpji1112t05.csv	"Table 5. Prevalence of disabilities among jail inmates, by demographic characteristics, 2011?12"
dpji1112t06.csv	"Table 6. Prevalence of disabilities and other health conditions among state and federal prisoners and jail inmates, 2011?12"
	
Figures	
dpji1112f01.csv	"Figure 1. Prevalence of disabilities among state and federal prisoners and jail inmates, by sex, 2011?12"
dpji1112f02.csv	"Figure 2. Prevalence of past-30-day serious psychological distress among state and federal prisoners and jail inmates, by type of disability, 2011?12"
