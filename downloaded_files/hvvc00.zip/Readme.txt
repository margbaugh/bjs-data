Hispanic Victims of Violent Crime NCJ 191208
 
This zip archive contains tables in individual .wk1 spreadsheet format
from Hispanic Victims of Violent Crime NCJ 191208.    The full report
including text and graphics in pdf format are available at:
http://www.ojp.usdoj.gov/bjs/abstract/hvvc00.htm
 
Also available in Spanish http://www.ojp.usdoj.gov/bjs/abstract/vhcv00.htm
 
 
 
 
File Name         Table Titles
hvvc0001.wk1      Table 1. Number and rate of violent victimization, by type of crime, race, and
Hispanic origin, 2000
hvvc0002.wk1      Table 2. Rates of violent crime, by Hispanic origin, race, gender, age, marital
status, annual household income, and residence, 1993-2000
hvvc0003.wk1      Table 3. Relationship of victim to violent offender, by race and Hispanic
origin of the victim, 1993-2000
hvvc0004.wk1      Table 4. Presence and type of weapons, by race and Hispanic origin of the
victim, 1993-2000
hvvc0005.wk1      Table 5. Injury from crime and treatment of that injury, by race and Hispanic
origin of the victim, 1993-2000
hvvc0006.wk1      Table 6. Victim's perception of the violent offender's use of drugs or alcohol,
by race and Hispanic origin of the victim, 1993-2000
hvvc0007.wk1      Table 7. Reporting of violence to the police, by race and Hispanic origin of the
victim, 1993-2000
hvvc0008.wk1       Table 8.  Percent of violence against Hispanic victims reported to police, by
victim characteristics, 1993-2000
hvvc0009.wk1       Table 9.  Reasons for not reporting violence to police, by race or Hispanic
origin, 1993-2000
hvvc00app.wk1     Appendix table. Populations and rates per 1,000 Hispanic victims of violent
crime, by gender, age, marital status, annual household income, and residence, 1993-2000
hvvc00hlfig.wk1   Highlight The rate of violent crime against Hispanics fell 56% from 1993-
2000.  The rate for whites declined 50%, and for blacks, 51%
hvvc00fig1.wk1    Figure 1.Rate of violent victimization per 1,000 Hispanics in urban, suburban
and rural areas
hvvc00fig2.wk1    Figure 2.Rate of violent victimization per 1,000 Hispanics who were married,
never married and divorced/separated
hvvc00fig3.wk1    Figure 3.Rate of violent victimization per 1,000 Hispanics in different age
categories
