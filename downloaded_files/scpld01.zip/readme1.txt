State Court Prosecutors in Large Districts, 2001, NCJ 191206


This zip archive contains tables in individual .wk1 spreadsheets
from State Court Prosecutors in Large Districts, 2001, NCJ 191206.
 The full report including text and graphics in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/scpld01.htm 


 
File Name         Table Name
scpld1.wk1        Table 1.  Personnel categories for prosecutors' offices in large districts, 2001
scpld2.wk1        Table 2:   Median staff size in prosecutors' offices in large districts, by personnel categories, 2001
scpld3.wk1        Table 3.  Problems of recruiting and retaining staff attorneys in prosecutors' offices in large districts, 2001
scpld4.wk1        Table 4.  Annual salary for assistant prosecutors and supervisory attorneys in prosecutors' offices in large districts, 2001
scpld5.wk1        Table 5.  Budget for prosecutorial functions in prosecutors' offices in large districts, 2001
scpld6.wk1        Table 6.  Types of cases other than felonies handled in prosecutors' offices in large districts, 2001
scpld7.wk1        Table 7.  Special categories of felony offenses prosecuted in prosecutors' offices in large districts, 2001
scpld8.wk1        Table 8.  Types of computer crimes prosecuted in prosecutors' offices in large districts, 2001
scpld9.wk1        Table 9.  Criminal cases closed and convicted during an annual period in prosecutors' offices in large districts, 2001
scpld10.wk1       Table 10.  Juveniles proceeded against in criminal court, by prosecutors' offices in large districts, 2001
scpld11.wk1       Table 11.  Work-related threats and assaults received by staff members in prosecutors' offices in large districts, 2001
scpld12.wk1       Table 12.  Security measures used for protection by prosecutors' offices in large districts, 2001
scpld13.wk1       Table 13.  DNA evidence used by prosecutors' offices in large districts, 2001
scpld14.wk1       Table 14.  Community-related activities engaged in by prosecutors' offices in large districts, 2001
scpld15.wk1       Table 15.  Location, types of offenses handled, and caseload for prosecutors assigned to community-related activities in prosecutors' o
scpldbox.wk1      Box.  Prosecutors' offices serving districts with a population of 1 million or more, 1994, 1996, and 2001
scpldapp.wk1      Appendix.   Prosecutorial districts with 1999 population of 500,000 or more
 
 
