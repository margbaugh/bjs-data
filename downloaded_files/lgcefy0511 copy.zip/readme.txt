Local Government Corrections Expenditures, FY 2005-2011 243527	
	
This zip archive contains tables in individual .csv spreadsheets from	
Local Government Corrections Expenditures, FY 2005-2011 243527		
	
Tables	
lgce0511t01.csv		Table 1. Components of local government expenditures, FY 2005�2011 (real dollars)
lgce0511t02.csv		Table 2. Components of local corrections expenditures, FY 2005�2011
lgce0511t03.csv		Table 3. Capital outlay and current operations expenditures by local governments for correctional institutions, FY 2005�2011
	
Figures	
lgce0511f01.csv		Figure 1. Local corrections expenditures, FY 2005-2011
lgce0511f02.csv		Figure 2. State and local expenditures for correctional institutions, FY 2005�2011 (real dollars)
lgce0511f03.csv		Figure 3. State and local expenditures for current operations of correctional institutions, FY 2005�2011 (real dollars)
lgce0511f04.csv		Figure 4. State and local expenditures for capital outlay of correctional institutions, FY 2005�2011 (real dollars)
	
Appendix Tables	
lgce0511at01.csv	Appendix table 1. Standard errors for table 1: Components of local government expenditures, FY 2005�2011 (real dollars)
lgce0511at02.csv	Appendix table 2. Standard errors for table 2: Components of local corrections expenditures, FY 2005�2011 
lgce0511at03.csv	Appendix table 3. Standard error tables for table 3: Capital outlay and current operations expenditures by local governments for correctional institutions, FY 2005�2011 

