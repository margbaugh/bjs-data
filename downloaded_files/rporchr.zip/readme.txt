Reporting by Prosecutors' Offices to Repositories of Criminal History Records   NCJ  205334		

This zip archive contains tables in individual .csv spreadsheets from Reporting by Prosecutors' 		
Offices to Repositories of Criminal History Records   NCJ  205334. The full report including 		
text and graphics in pdf format are available from:  http://www.ojp.usdoj.gov/bjs/abstract/rporchr.htm		


rpochrrf01.csv		Figure 1. Reasons that offices of chief prosecutors provide for not regularly reporting final case dispositions to State criminal history repositories, 2003
rpochrrf02.csv		Figure 2:  Types of final case dispositions that offices of chief prosecutors provide to State criminal history repositories, 2003
