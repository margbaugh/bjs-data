Veterans in Prison and Jail, 2011-12 NCJ 249144	
	
This zip archive contains tables in individual .csv spreadsheets from Veterans in Prison and Jail, 2011-12 NCJ 249144	The full report including text"			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5479" 
	
This report is one in a series. More recent editions may be available. 	
To view a list of all in the series, go to: http://www.bjs.gov/index.cfm-ty=pbse&sid=55	
	
Tables	
vjp1112at01	Appendix table 1. Demographic and offense characteristics of male veterans in prison and jail, by discharge era, 2011-12
vjp1112at02	Appendix table 2. Standard errors for appendix table 1: Demographic and offense characteristics of male veterans in prison and jail, by discharge era, 2011-12
vjp1112at03	Appendix table 3. Standard errors for table 1: Veterans in prison and jail populations, 1978, 1985, 1998, 2004, and 2011-12
vjp1112at04	Appendix table 4. Standard errors for table 3: Demographic characteristics of inmates in prison and jail, by veteran status, 2011-12
vjp1112at05	Appendix table 5. Standard errors for table 4: Current offense, sentencing, and criminal history characteristics of male inmates in prison, by veteran status, 2011-12
vjp1112at06	Appendix table 6. Standard errors for table 5: Current offense, sentencing, and criminal history characteristics of male inmates in jail, by veteran status, 2011-12
vjp1112at07	Appendix table 7. Standard errors for table 6: Military characteristics of male veterans in prison and jail, 2011-12
vjp1112at08	Appendix table 8. Standard errors for table 7: Mental health characteristics reported by male inmates, by veteran status, 2011-12
vjp1112at09	Appendix table 9. Standard errors for table 8: Characteristics of veterans in prison and jail, by combat status, 2011-12
vjp1112at10	Appendix table 10. Standard errors for table 9: Estimated number of veterans in prison and jail reporting a disability, by veteran status, 2011-12
vjp1112t01	Table 1. Veterans in the U.S. adult resident, prison, and jail populations, 1978, 1985, 1998, 2004, and 2011-12
vjp1112t02	Table 2. Incarceration rate per 100,000 U.S. adult residents age 18 or older, by veteran status, 1978, 1985, 1998, 2004, and 2011-12
vjp1112t03	Table 3. Demographic characteristics of inmates in prison and jail, by veteran status, 2011-12
vjp1112t04	Table 4. Current offense, sentencing, and criminal history characteristics of male inmates in prison, by veteran status, 2011-12
vjp1112t05	Table 5. Current offense, sentencing, and criminal history characteristics of male inmates in jail, by veteran status, 2011-12
vjp1112t06	Table 6. Military characteristics of male veterans in prison and jail, 2011-12
vjp1112t07	Table 7. Mental health characteristics reported by male inmates, by veteran status, 2011-12
vjp1112t08	Table 8. Characteristics of male veterans in prison and jail, by combat status, 2011-12
vjp1112t09	Table 9. Estimated number of male veterans in prison and jail reporting a disability, by veteran status, 2011-12
	
	
figures 	
vjp1112f01	Figure 1. Estimated percent of veterans in the U.S. resident population in prison and jail, 1978, 1985, 1998, 2004, and 2011-12
vjp1112f02	Figure 2. Incarceration rate of veterans in prison and jail, 1978, 1985, 1998, 2004, and 2011-12
