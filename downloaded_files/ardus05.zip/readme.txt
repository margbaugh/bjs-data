Arrest-Related Deaths in the United States, 2003-2005
 
This zip archive contains tables in individual .csv spreadsheets
from Arrest-Related Deaths in the United States, 2003-2005, NCJ 219534.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/ardus05.htm

		
Filename		Appendix tables	
ardus05at01.csv	Appendix table 1. Number of arrest-related deaths and data reporting sources, by State, 2003-2005
ardus05at02.csv	Appendix table 2. Number of arrest-related deaths, by State and cause of death, 2003-2005
ardus05at03.csv	Appendix table 3. Comparative counts of law enforcement homicides in Supplemental Homicide Reports (SHR) and Deaths in Custody Reporting Program (DCRP) data collections, by State, 2003-2005
ardus05at04.csv	Appendix Table 4. Percent of arrest-related deaths, by cause of death and selected characteristics, 2003-2005
ardus05at05.csv	Appendix table 5. Arrest-related deaths, by most serious offense, 2003-2005
ardus05at06.csv	Appendix table 6. Most serious offense by cause of death among arrest-related deaths, 2003-2005
ardus05at07.csv	Appendix table 7. Profile of circumstances surrounding arrest-related homicides by law enforcement, 2003-2005
ardus05at08.csv	Appendix table 8. Profile of circumstances surrounding arrest-related intoxication deaths, 2003-2005
ardus05at09.csv	Appendix table 9. Profile of circumstances surrounding arrest-related suicides prior to booking, 2003-2005
ardus05at10.csv	Appendix table 10. Profile of circumstances surrounding arrest-related suicides at police stations and booking facilities, 2003-2005 
ardus05at11.csv	Appendix table 11. Law enforcement officers killed and assaulted, and arrestees killed in the process of arrest, by State, 2003-2005
ardus05at12.csv	Appendix table 12. Selected characteristics of deaths involving the use of conducted-energy devices, 2003-2005


			Exhibit table number
ardus05ext01.csv Exhibit table 1. Arrest-related deaths, by cause of death, 2003-2005
ardus05ext02.csv Exhibit table 2. Law enforcement officers killed and assaulted, and arrestees killed in the process of arrest, 2003-2005 ardus05ext03.csv	
ardus05ext03.csv Exhibit table 3. Arrest-related deaths involving the use of tasers or other conducted-energy devices, by cause of death and selected characteristics, 2003-2005

			Figure
ardus05f01.csv	Figure 1. Percent of deaths involving arrests for violent crimes

			Text tables
ardus05tt01.csv	Text table 1. Data sources on arrest-related deaths, 2003-2005
ardus05tt02.csv	Text table 2. Number of law enforcement homicides, 2003-2005
ardus05tt03.csv	Text table 3. Characteristics of law enforcement homicides, 2003-2005
ardus05tt04.csv	Text table 4. Homicides by law enforcement officers, by number of sworn officers employed by the arresting agency, 2003-2005
ardus05tt05.csv	Text table 5. Percent of arrest-related deaths by selected arrestee characteristics, 2003-2005 	
ardus05tt06.csv	Text table 6. Percent of arrest-related suicides by selected arrestee characteristics, 2003-2005
ardus05tt07.csv	Text table 7. Percent of arrest-related suicides by selected circumstances, 2003-2005	
ardus05tt08.csv	Text table 8. Agencies reporting DCRP arrest-related death records
