LOCAL POLICE DEPARTMENTS 2003 NCJ 210118																	
																	
This zip archive contains tables and figures in individual .csv spreadsheets from the 2003 Law Enforcement and Administrative
Statistics (LEMAS) report, "Local Police Departments 2003."  The full report including tables and graphics in .pdf format 
are available from: http://www.ojp.usdoj.gov/bjs/abstract/lpd03.htm

This report is one in a series.  More recent editions may be available. To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#lpd


Tables:
																	
lpd0301.csv	Table 1. Employment by general purpose State and local law enforcement agencies in the United States, 2003																
lpd0302.csv 	Table 2. Local police departments and full-time personnel, by number of sworn personnel, 2003
lpd0303.csv	Table 3. Local police departments and full-time personnel, by size of population served, 2003
lpd0304.csv	Table 4. Average number of employees in local police departments, by size of population served, 2003
lpd0305.csv	Table 5. Officers assigned to respond to citizen calls for service in local police departments, by size of population served, 2003
lpd0306.csv	Table 6. Authorized full-time strength of local police departments and percent of authorized strength employed, by size of population served, 2003
lpd0307.csv	Table 7. Officer separations and new officer hires in local police departments, by populations served, 2003
lpd0308.csv	Table 8. Types of officer separations in local police departments, by size of population served, 2003
lpd0309.csv	Table 9. Types of new officer hires in local police departments, by size of population served, 2003
lpd0310.csv	Table 10. Full-time sworn personnel in local police departments called-up as full-time military reservists, by size of population served, 2003
lpd0311.csv	Table 11. Use of sworn reserve or auxiliary officers in local police departments, by size of population served, 2003
lpd0312.csv	Table 12. Use of nonsworn reserve or auxiliary officers in local police departments, by size of population served, 2003
lpd0313.csv	Table 13. Gender and race of full-time sworn personnel in local police departments, by size of population served, 2003
lpd0314.csv	Table 14. Interviews, tests, and examinations used in selection of new officer recruits in local police departments, by size of population served, 2003
lpd0315.csv	Table 15. Background checks used in selection of new officer recruits in local police departments, by size of population served, 2003
lpd0316.csv	Table 16. Minimum educational requirement for new officers in local police departments, by size of population served, 2003
lpd0317.csv	Table 17. Training requirements for new officer recruits in local police departments, by size of population served, 2003
lpd0318.csv	Table 18. Annual inservice training requirements for non-probationary officers in local police departments, by size of population served, 2003
lpd0319.csv	Table 19. Operating budget of local police departments, by size of population served, 2003
lpd0320.csv	Table 20. Average base annual salary for selected positions in local police departments, by size of population served, 2003
lpd0321.csv	Table 21. Local police departments authorizing special pay for full-time sworn personnel, by size of population served, 2003
lpd0322.csv	Table 22. Collective bargaining authorized by local police departments, by size of population served, 2003
lpd0323.csv	Table 23. Average number of district/precinct stations, and neighborhood/community substations operated by local police departments, by size of population served, 2003
lpd0324.csv	Table 24. Types of routine patrol other than automobile used by local police departments, by size of population served, 2003
lpd0325.csv	Table 25. Dispatch functions of local police departments, by size of population served, 2003
lpd0326.csv	Table 26. Full-time sworn personnel in local police departments serving as communications technicians, by size of population served, 2003
lpd0327.csv	Table 27. Participation in a 9-1-1 emergency telephone system by local police departments, by size of population served, 2003
lpd0328.csv	Table 28. Local police departments with primary investigative responsibility for selected crimes, by size of population served, 2003
lpd0329.csv	Table 29. Drug enforcement in local police departments, by size of population served, 2003
lpd0330.csv	Table 30. Special units for drug enforcement in local police departments, by size of population served, 2003
lpd0331.csv	Table 31. Participation by local police departments in multi-agency drug enforcement task forces, by size of population served, 2003
lpd0332.csv	Table 32. Drug asset forfeiture program receipts of local police departments, by size of population served, 2003
lpd0333.csv	Table 33. Court-related functions of local police departments, by size of population served, 2003
lpd0334.csv	Table 34. Detention functions of local police departments, by size of population served, 2003
lpd0335.csv	Table 35. Temporary holding (lockup) facilities operated by local police departments, by size of population served, 2003
lpd0336.csv	Table 36. Special public safety functions of local police departments, by size of population served, 2003
lpd0337.csv	Table 37. Traffic and vehicle-related functions of local police departments, by size of population served, 2003
lpd0338.csv	Table 38. Special operations functions of local police departments, by size of population served, 2003
lpd0339.csv	Table 39. Local police departments with a formal, written community policing plan, by size of population served, 2003
lpd0340.csv	Table 40. Local police departments with a mission statement that includes community policing, by size of population served, 2003
lpd0341.csv	Table 41. Community policing training in local police departments, by size of population served, 2003
lpd0342.csv	Table 42. Full-time community policing officers in local police departments, by size of population served, 2003
lpd0343.csv	Table 43. Full-time school resource officers in local police departments, by size of population served, 2003
lpd0344.csv	Table 44. Ability assessments related to community policing used by local police departments for selecting new officers, by size of population served, 2003
lpd0345.csv	Table 45. Community policing policies for sworn personnel in local police departments, by size of population served, 2003
lpd0346.csv	Table 46. Community policing activities of local police departments, by size of population served, 2003
lpd0347.csv	Table 47. Surveying of citizens by local police departments, by size of population served, 2003
lpd0348.csv	Table 48. Policies on handling special populations in local police departments, by size of population served, 2003
lpd0349.csv	Table 49. Work-related policies in local police departments, by size of population served, 2003
lpd0350.csv	Table 50. Policies on officer use of force in local police departments, by size of population served, 2003
lpd0351.csv	Table 51. Written policy directives pertaining to officer conduct and appearance in local police departments, by size of population served, 2003
lpd0352.csv	Table 52. Vehicle use policies in local police departments, by size of population served, 2003
lpd0353.csv	Table 53. Pursuit driving policies of local police departments, by size of population served, 2003
lpd0354.csv	Table 54. Additional written policy directives of local police departments by size of population served, 2003
lpd0355.csv	Table 55. Semiautomatic sidearms authorized for use by sworn personnel in local police departments, by size of population served, 2003
lpd0356.csv	Table 56. Body armor requirements for field officers in local police departments, by size of population served, 2003
lpd0357.csv	Table 57. Types of nonlethal weapons authorized for personal use by sworn personnel in local police departments, by size of population served, 2003
lpd0358.csv	Table 58. Number of cars operated by local police departments, by size of population served, 2003
lpd0359.csv	Table 59. Number of motorcycles and 4-wheel motorized vehicles other than cars operated by local police departments, by size of population served, 2003
lpd0360.csv	Table 60. Number of bicycles operated by local police departments, by size of population served, 2003
lpd0361.csv	Table 61. Off-land vehicles operated by local police departments, by size of population served, 2003
lpd0362.csv	Table 62. Animals maintained by local police departments, by size of population served, 2003
lpd0363.csv	Table 63. Use of video cameras by local police departments, by size of population served, 2003
lpd0364.csv	Table 64. Special technologies used by local police departments, by size of population served, 2003
lpd0365.csv	Table 65. General functions of computers in local police departments, by size of population served, 2003
lpd0366.csv	Table 66. Analytic functions of computers in local police departments, by size of population served, 2003
lpd0367.csv	Table 67. Types of computerized information files maintained by more than half of local police departments, by size of population served, 2003
lpd0368.csv	Table 68. Types of computerized information files maintained by less than half of local police departments, by size of population served, 2003
lpd0369.csv	Table 69. Types of infield computers or terminals used by local police departments, by size of population served, 2003
lpd0370.csv	Table 70. Use of infield computers for reports and communications by local police departments, by size of population served, 2003
lpd0371.csv	Table 71. Computerized information accessible to infield officers of local police departments, by size of population served, 2003
lpd0372.csv	Table 72. Use of Automated Fingerprint Identification Systems (AFIS) in local police departments, by size of population served, 2003
lpd0373.csv	Table 73. Methods for transmitting criminal incident reports to the central information system in local police departments, by size of population served, 2003

Figures:

lpd03f01.csv	Figure 1. Full-time employment by local police departments, 1987-2003
lpd03f02.csv	Figure 2. Net change in number of full-time local police officers for 12-month period ending June 30, 2003
lpd03f03.csv	Figure 3. Female and minority local police officers, 1987-2003
lpd03f04.csv	Figure 4. Local police officers employed by departments using various recruit screening methods, 2003
lpd03f05.csv	Figure 5. Training requirements for new officer recruits in local police departments, 2000 and 2003
lpd03f06.csv	Figure 6. Annual per officer operating costs of local police departments, 2000 and 2003
lpd03f07.csv	Figure 7. Average base starting salary for entry-level officers in local police departments, 2000 and 2003
lpd03f08.csv	Figure 8. Starting salaries for entry-level officers in local police departments authorizing and not authorizing collective bargaining, 2003
lpd03f09.csv	Figure 9. Percent of local police departments using foot or bike patrol, by size of population served, 1997-2003
lpd03f10.csv	Figure 10. Local police department participation in a 9-1-1 emergency telephone system, 1987-2003
lpd03f11.csv	Figure 11. Drug asset forfeiture receipts of local police departments, by size of agency, 2002
lpd03f12.csv	Figure 12. Percent of local police departments using full-time community policing officers, 1997, 2000 and 2003
lpd03f13.csv	Figure 13. Groups with which local police departments had problem-solving partnerships or written agreements during the year ending June 30, 2003
lpd03f14.csv	Figure 14. Uses of citizen survey information by local police departments, 2003
lpd03f15.csv	Figure 15. Body armor requirements in local police departments, 1990-2003
lpd03f16.csv	Figure 16. Local police departments authorizing officers to use chemical agents, 1990 and 2003
lpd03f17.csv	Figure 17. Local police departments using video cameras in patrol cars, 2000 and 2003
lpd03f18.csv	Figure 18. Local police departments using infield computers or terminals, 1990 and 2003
lpd03f19.csv	Figure 19. Local police officers with infield computer access to information, 1997-2003
lpd03f20.csv	Figure 20. Local police departments using electronic methods for transmitting criminal incident reports to a central information system, 1997-2003
