Survey of DNA Crime Laboratories, 2001  NCJ 191191

This zip archive contains tables in individual .wk1 spreadsheets
from Survey of DNA Crime Laboratories, 2001  NCJ 191191.
 The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/sdnacl01.htm 
 
Filenames         Table    Titles
sdna0101.wk1      Table 1. Status of workloads in DNA crime laboratories,  by type of case, 1997-2000.
sdna0102.wk1      Table 2. Analytical responsibilities of crime laboratories which perform DNA analysis, 2001.
sdna0103.wk1      Table 3. Status of DNA crime  laboratory accreditation, 2001.
sdna0104.wk1      Table 4. DNA crime laboratory  accrediting organizations, 2001.
sdna0105.wk1      Table 5. Standard guidelines DNA crime laboratories follow, 2001.
sdna0106.wk1      Table 6. Crime laboratories with full-time DNA staff, 2001.
sdna0107.wk1      Table 7. Type of agencies submitting DNA samples to laboratories for analyses, 2001.
sdna0108.wk1      Table 8. Status of case workloads in DNA crime laboratories,  by type of case, 1999-2000.

sdna01p4.wk1      Text table p.4.  Labs performing DNA analyses, 2001
