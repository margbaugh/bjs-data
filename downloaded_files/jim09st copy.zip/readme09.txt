Jail Inmates at Midyear 2009 - Statistical Tables  NCJ 230122	
	
This zip archive contains tables in individual .csv spreadsheets	
for Jail Inmates at Midyear 2009 - Statistical Tables.  NCJ 230122	
The full report including text and graphics in .pdf format is available from:	
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2195.	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=38.	
 	
Tables	
jim09stt01.csv	Table 1: Inmates confined in local jails at midyear, average daily population, and incarceration rates, 2000-2009
jim09stt02.csv	Table 2: Rated capacity of local jails and percent of capacity occupied, 2000�2009
jim09stt03.csv	Table 3: Inmates confined in local jails at midyear, by size of jurisdiction, 2008 and 2009
jim09stt04.csv	Table 4: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2008 and 2009
jim09stt05.csv	Table 5: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2000, 2008, and 2009
jim09stt06.csv	Table 6: Number of inmates in local jails, by characteristics, midyear 2000 and 2005�2009
jim09stt07.csv	Table 7: Percent of inmates in local jails, by characteristics, midyear 2000 and 2005�2009
jim09stt08.csv	Table 8: Jurisdictions reporting on holdings for ICE, midyear 2002�2009
jim09stt09.csv	Table 9: The 50 largest local jail jurisdictions: Number of inmates held, average daily population and rated capacity, midyear 2007�2009
jim09stt09a.csv	Table 9a (cont.): The 50 largest local jail jurisdictions: Number of inmates held, average daily population, and rated capacity, midyear 2007�2009
jim09stt10.csv	Table 10: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2009
jim09stt11.csv	Table 11: Estimated standard errors by confinement status, Annual Survey of Jails, 2009
jim09stt12.csv	Table 12: Estimated standard errors by selected characteristics, Annual Survey of Jails, 2009
jim09stt13.csv	Table 13: Estimated percentages of local jail inmates, by selected characteristics and ratio estimates, 2009
	
Figures	
jim09stf01.csv	Figure 1: Inmates confined in local jails at midyear and annual percent change in the jail population, 2000-2009



 
 
