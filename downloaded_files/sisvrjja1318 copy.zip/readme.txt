Substantiated Incidents of Sexual Victimization Reported by Juvenile Justice Authorities, 2013–2018   NCJ 305192											
This zip archive contains tables in individual .csv spreadsheets
from Substantiated Incidents of Sexual Victimization Reported by Juvenile Justice Authorities, 2013–2018   NCJ 305192	
The full report including text and graphics in pdf format is available from 
https://bjs.ojp.gov/library/publications/substantiated-incidents-sexual-victimization-reported-juvenile-justice											
This report is one in a series.  More recent editions
may be available. To view a list of all in the series go to
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Publications																
Filenames		Table titles
sisvrjja1318t01.csv	Table 1. Incidents involving single or multiple victims or perpetrators, by type of victimization, 2013–18 
sisvrjja1318t02.csv	Table 2. Selected characteristics of substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t03.csv	Table 3. Selected characteristics of substantiated incidents of youth-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318t04.csv	Table 4. Demographic characteristics of victims in substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t05.csv	Table 5. Demographic characteristics of perpetrators in substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t06.csv	Table 6. Outcomes for victims and perpetrators in substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18 
sisvrjja1318t07.csv	Table 7. Outcomes for victims and perpetrators in substantiated incidents of youth-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318t08.csv	Table 8. Selected characteristics of substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t09.csv	Table 9. Selected characteristics of substantiated incidents of staff-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318t10.csv	Table 10. Demographic characteristics of victims in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t11.csv	Table 11. Demographic characteristics of perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t12.csv	Table 12. Employment characteristics of perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t13.csv	Table 13. Outcomes for victims and perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318t14.csv	Table 14. Outcomes for victims and perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318t15.csv	Table 15. Selected characteristics of substantiated incidents of youth-on-youth sexual harassment, by type of facility, 2013–18
sisvrjja1318t16.csv	Table 16. Demographic characteristics of victims and perpetrators in substantiated incidents of youth-on-youth sexual harassment, 2013–18
sisvrjja1318t17.csv	Table 17. Outcomes for victims and perpetrators in substantiated incidents of youth-on-youth sexual harassment, by type of facility, 2013–18																						
			Figures		
sisvrjja1318f01.csv	Figure 1. Number of substantiated incidents of sexual victimization, by type of victimization, 2013–18									
			Appendix tables	
sisvrjja1318at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Number of substantiated incidents of sexual victimization, by type of victimization, 2013–18
sisvrjja1318at02.csv	Appendix table 2. Standard errors for table 1: Incidents involving single or multiple victims or perpetrators, by type of victimization, 2013–18
sisvrjja1318at03.csv	Appendix table 3. Standard errors for table 2: Selected characteristics of substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at04.csv	Appendix table 4. Standard errors for table 3: Selected characteristics of substantiated incidents of youth-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318at05.csv	Appendix table 5. Standard errors for table 4: Demographic characteristics of victims in substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at06.csv	Appendix table 6. Standard errors for table 5: Demographic characteristics of perpetrators in substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at07.csv	Appendix table 7. Standard errors for table 6: Outcomes for victims and perpetrators in substantiated incidents of youth-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at08.csv	Appendix table 8. Standard errors for table 7: Outcomes for victims and perpetrators in substantiated incidents of youth-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318at09.csv	Appendix table 9. Standard errors for table 8: Selected characteristics of substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at10.csv	Appendix table 10. Standard errors for table 9: Selected characteristics of substantiated incidents of staff-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318at11.csv	Appendix table 11. Standard errors for table 10: Demographic characteristics of victims in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at12.csv	Appendix table 12. Standard errors for table 11: Demographic characteristics of perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at13.csv	Appendix table 13. Standard errors for table 12: Employment characteristics of perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at14.csv	Appendix table 14. Standard errors for table 13: Outcomes for victims and perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization, 2013–18
sisvrjja1318at15.csv	Appendix table 15. Standard errors for table 14: Outcomes for victims and perpetrators in substantiated incidents of staff-on-youth sexual victimization, by type of victimization and facility, 2013–18
sisvrjja1318at16.csv	Appendix table 16. Standard errors for table 15: Selected characteristics of substantiated incidents of youth-on-youth sexual harassment, by type of facility, 2013–18
sisvrjja1318at17.csv	Appendix table 17. Standard errors for table 16: Demographic characteristics of victims and perpetrators in substantiated incidents of youth-on-youth sexual harassment, 2013–18
sisvrjja1318at18.csv	Appendix table 18. Standard errors for table 17: Outcomes for victims and perpetrators in substantiated incidents of youth-on-youth sexual harassment, by type of facility, 2013–18