Capital Punishment, 2014 - Statistical Tables  NCJ 248448

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2013 - Statistical Tables  NCJ 248448, electronic only. 
The full electronic report is available at:


These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to:



Tables:
cp13stat01.csv		Appendix Table 1. Inmates under sentence of death, by demographic characteristics, 2013
cp13stf01.csv		Figure 1. Status of the death penalty, December 31, 2013
cp13stf02.csv		Figure 2. Number of persons under sentence of death, 1953�2013
cp13stf03.csv		Figure 3. Admissions to and removals from under sentence of death, 1973�2013
cp13stf04.csv		Figure 4. Persons executed in the United States, 1930-2013
cp13stf05.csv		Figure 5. Advance count of executions, January 1, 2014 - November 30, 2014
cp13stt01.csv		Table 1. Capital offenses, by state, 2013
cp13stt02.csv		Table 2. Method of execution, by state, 2013
cp13stt03.csv		Table 3. Federal capital offenses, 2013
cp13stt04.csv		Table 4. Prisoners under sentence of death, by region, jurisdiction, and race, 2012 and 2013
cp13stt05.csv		Table 5. Demographic characteristics of prisoners under sentence of death, 2013
cp13stt06.csv		Table 6. Female prisonsers under sentence of death, by region, jurisdiction, and race, 2012 and 2013
cp13stt07.csv		Table 7. Hispanic or Latino prisoners under sentence of death, by region and jurisdiction, 2012 and 2013
cp13stt08.csv		Table 8. Criminal history of prisoners under sentence of death, by race and Hispanic origin, 2013
cp13stt09.csv		Table 9. Inmates removed from under sentence of death, by region, jurisdiction, and method of removal, 2013
cp13stt10.csv		Table 10. Average time between sentencing and execution, 1977-2014
cp13stt11.csv		Table 11. Number of inmates executed, by race and Hispanic origin, 1977-2013
cp13stt12.csv		Table 12. Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2013
cp13stt13.csv		Table 13. Executions, by jurisdiction and method, 1977-2013
cp13stt14.csv		Table 14. Executions, by jurisdiction, 1930-2013
cp13stt15.csv		Table 15. Prisoners under sentence of death on December 31, 2013, by jurisdiction and year of sentencing
cp13stt16.csv		Table 16. Prisoners sentenced to death and the outcome of the sentence, by year of sentencing, 1973-2013
cp13stt17.csv		Table 17. Prisoners sentenced to death and the outcome of the sentence, by jurisdiction, 1973-2013


