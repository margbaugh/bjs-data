Primary State Law Enforcement Agencies: Personnel, 2020   NCJ 307507	
	
This zip archive contains tables in individual .csv spreadsheets	
from Primary State Law Enforcement Agencies: Personnel, 2020   NCJ 307507.	
The full report including text and graphics in .pdf format is available at	
https://bjs.ojp.gov/library/publications/primary-state-law-enforcement-agencies-personnel-2020	
	
Filenames		Table titles
psleap20t01.csv		Table 1. Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2020
psleap20t02.csv		Table 2. Full-time personnel in primary state law enforcement agencies, by region and size of agency, 2020
psleap20t03.csv		Table 3. Sex of full-time sworn officers in primary state law enforcement agencies, by region and size of agency, 2020
psleap20t04.csv		Table 4. Race or Hispanic origin of full-time sworn officers in primary state law enforcement agencies, by region and size of agency, 2020
psleap20t05.csv		Table 5. Sex and race or Hispanic origin of full-time sworn officers in primary state law enforcement agencies, by region and size of agency, 2020
psleap20t06.csv		Table 6. Intermediate supervisors and first-line supervisors in primary state law enforcement agencies who were female, by region and size of agency, 2020
psleap20t07.csv		Table 7. Race or Hispanic origin of intermediate supervisors and first-line supervisors in primary state law enforcement agencies, by region and size of agency, 2020
psleap20t08.csv		Table 8. Primary job responsibility of full-time personnel in primary state law enforcement agencies, by region and size of agency, 2020
psleap20t09.csv		Table 9. Full-time personnel in primary state law enforcement agencies who were bilingual or multilingual, by region and size of agency, 2020
psleap20t10.csv		Table 10. Primary state law enforcement agencies with personnel designated to address specific crime-related issues, by size of agency, 2020
psleap20t11.csv		Table 11. Primary state law enforcement agencies with personnel designated to address specific functional areas, by size of agency, 2020
psleap20t12.csv		Table 12. Annual operating budgets of primary state law enforcement agencies, by region and size of agency, 2020
	
			Figures
psleap20f01.csv		Figure 1. Full-time personnel in primary state law enforcement agencies, 1997–2020
psleap20f02.csv		Figure 2. Percent of primary state law enforcement agencies that adopted selected policies and procedures to address COVID-19, 2020
psleap20f03.csv		Figure 3. Percent of primary state law enforcement agencies that reported a reduction in operations due to changes in policy or practice as a result of COVID-19, 2020
	
			Appendix tables
psleap20at01.csv	Appendix Table 1. Estimates and standard errors for figure 1: Full-time personnel in primary state law enforcement agencies, 1997–2020
psleap20at02.csv	Appendix Table 2. Standard errors for table 1: Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2020
psleap20at03.csv	Appendix Table 3. Estimates for map 1: Full-time-equivalent sworn officers in primary state law enforcement agencies per 100,000 residents, by state, 2020
psleap20at04.csv	Appendix Table 4. Standard errors for table 2: Full-time personnel in primary state law enforcement agencies, by region and size of agency, 2020
psleap20at05.csv	Appendix Table 5. Estimates for figure 2: Percent of primary state law enforcement agencies that adopted selected policies and procedures to address COVID-19, 2020
psleap20at06.csv	Appendix Table 6. Estimates for figure 3: Percent of primary state law enforcement agencies that reported a reduction in operations due to changes in policy or practice as a result of COVID-19, 2020
