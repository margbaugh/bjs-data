Contract Trials and Verdicts in Large Counties, 2001																																		

This zip archive contains tables in individual .csv spreadsheets 		
from Contract Trials and Verdicts in Large Counties, 2001, NCJ 207388		
the full report including text and graphics in .pdf format are available from:		
http://www.ojp.usdoj.gov/bjs/abstract/ctvlc01.htm		

This report is one in a series.  More recent editions 		
may be available.  To view a list of all in the series go to		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#ctvlc		
		
File name 		Table title
		
Tables

ctvlc0101.csv		Table 1. Contract cases disposed of by trial in State courts in the Nation's 75 largest counties, 2001																													
ctvlc0102.csv		Table 2. Types of plaintiffs or defendants, by types of contract trials, in State courts in the Nation's 75 largest counties, 2001
ctvlc0103.csv		Table 3. Pairings of primary litigants in selected types of contract trials in State courts in the Nation's 75 largest counties, 2001
ctvlc0106.csv		Table 6. Final award amounts for civil jury and bench contract trials with plaintiff winners in State courts in the Nation's 75 largest counties, 2001
ctvlc0107.csv		Table 7. Punitive damages awarded to plaintiff winners in contract jury and bench trials in the Nation's 75 largest counties, 2001
ctvlc0108.csv		Table 8. Pairings of primary types of litigants in contract trials in State courts in the Nation's 75 largest counties, 2001
ctvlc0109.csv		Table 9. Case processing time from filing of the complaint to final verdict or judgment in State courts in the Nation's 75 largest counties, 2001
ctvlc0110.csv		Table 10. Case processing time from filing of the complaint to final verdict or judgment for pairings of primary litigants in contract trials in State courts in the Nation's 75 largest counties, 2001
ctvlc0111.csv		Table 11. Type of post verdict relief sought by plaintiffs or defendants in contract trials in State courts in the Nation's 75 largest counties, 2001
ctvlc0112.csv		Table 12. Type of post verdict relief granted to plaintiffs or defendants in contract trials in State courts in the Nation's 75 largest counties, 2001
ctvlc0113.csv		Table 13. Contract trials in which plaintiff or defendant gave notice of appeal in State courts in the Nation's 75 largest counties, 2001
ctvlc0114.csv		Table 14. Comparing contract trials in State courts in the Nation's 75 largest counties, 1996 to 2001

Appendices

ctvlc01appa		Appendix A. Selected estimates, standard errors, and confidence intervals, civil trial 2001 survey
ctvlc01appb		Appendix B. Contract trial winners in State courts by sampled counties, 2001
ctvlc01appc		Appendix C. Final and punitive damage awards for plaintiff winners in contract trials, by sampled counties, 2001

