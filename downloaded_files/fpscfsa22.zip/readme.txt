Federal Prisoner Statistics Collected under the First Step Act, 2022  NCJ 304953											
																				
This zip archive contains tables in individual .csv spreadsheets for
Federal Prisoner Statistics Collected under the First Step Act, 2022  NCJ 304953
The full report including text and graphics in pdf format is available from:
https://bjs.ojp.gov/library/publications/federal-prisoner-statistics-collected-under-first-step-act-2022

This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Prisoner%20Statistics%20Collected%20under%20the%20First%20Step%20Act

																				
Filenames	Table titles
fpscfsa2201.csv	Table 1. Selected characteristics of federal prisoners, 2018–2021
fpscfsa2202.csv	Table 2. Medical conditions, testing, and treatment of federal prisoners, 2018–2021
fpscfsa2203.csv	Table 3. Selected characteristics of federal facilities, 2018–2021
fpscfsa2204.csv	Table 4. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by security level of facility, 2021
fpscfsa2205.csv	Table 5. Federal prisoners who were cited for prohibited acts that resulted in reductions in rewards, incentives, or time credits, by demographic characteristics, 2018–2021
fpscfsa2206.csv	Table 6. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by facility, 2021
fpscfsa2207.csv	Table 7. Prisoner assaults on Federal Bureau of Prisons staff, by type of assault and prosecution status, 2021
fpscfsa2208.csv	Table 8. Volunteer levels in Federal Bureau of Prisons facilities, by facility, December 27, 2021
fpscfsa2209.csv	Table 9. Recidivism reduction partnerships in Federal Bureau of Prisons facilities, by facility, 2021
fpscfsa2210.csv	Table 10. Recidivism risk classification of persons in federal prison, by demographic and sentence characteristics, 2021
fpscfsa2211.csv	Table 11. Approved evidence-based recidivism reduction programs and productive activities, by facility availability and prisoner needs met, 2021
																				
*Not included in report
fpscfsa2212.csv	Table 12. Enrollment and completion of evidence-based recidivism reduction programs and productive activities, by BOP facility, program or activity, and recidivism risk level, 2021																			
																				
