Background Checks for Firearm Transfers, 2000,  NCJ 187985

This zip archive contains tables in individual .wk1 spreadsheets
from Background Checks for Firearm Transfers 2000,  NCJ 187985
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/bcft00.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#bcft


bcft00hi.wk1	Highlights.  Background checks of applications for firearm transfers 
		since implementation of the Brady Act

bcft0001.wk1	Table 1.  Number of applications and rejections for firearm 
		transfer, 1994-2000

bcft0002.wk1	Table 2.  FIST estimates by type of agency and approval
		system and total FBI checks, 2000

bcft0003.wk1	Table 3.  Number of firearm purchase applications received and rejected by
		State agencies, and percent change, 1999-2000

bcft0004.wk1	Table 4.  Reasons for rejection of firearm transfer applications, 2000

bcft0005.wk1	Table 5.  Trends in applications, rejections, and reasons for rejection 
		since the beginning of the Brady Act, 1994-2000

bcft0006.wk1	Table 6.  Appeal of denied applications, 2000

bcft0007.wk1	Table 7.  Notification procedures of State agencies regarding denied 
		persons subject to arrest, 2000

bcft00a1.wk1	Appendix A.  National Instant Criminal Background Check System: Checking 
		agencies - FBI or State Point of Contact - for firearm transfers, 2000
 
bcft00a2.wk1	Appendix B.  State and local agencies conducting background checks for 
		firearm applications, 2000

