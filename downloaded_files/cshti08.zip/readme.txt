Readme.TXT		

Characteristics of Suspected Human Trafficking Incidents, 2007-08		

This zip archive contains tables in individual .csv spreadsheets from Characteristics of Suspected Human Trafficking Incidents, 2007-08 NCJ 224526.  This full report including text and graphics in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/cshti08.htm		

	Tables	
cshti08t01.csv		Table 1. Alleged human trafficking incidents reported by task forces, 2007-08
cshti08t02.csv		Table 2. Characteristics of alleged human trafficking incidents reported by task forces, by incident status, 2007-08
cshti08t03.csv		Table 3. Number of suspects, victims, and agencies in alleged human trafficking incidents reported by task forces, 2007-08
cshti08t04.csv		Table 4. Number of suspects, victims, and agencies in confirmed human trafficking incidents reported by task forces, 2007-08
cshti08t05.csv		Table 5. Characteristics of suspects in alleged human trafficking incidents reported by task forces, 2007-08
cshti08t06.csv		Table 6. Characteristics of suspects in confirmed human trafficking incidents reported by task forces, 2007-08
cshti08t07.csv		Table 7. Characteristics of victims in alleged human trafficking incidents reported by task forces, 2007-08
cshti08t08.csv		Table 8. Characteristics of victims in confirmed human trafficking incidents reported by task forces, 2007-08
cshti08t09.csv		Table 9. Comparison of suspect and victim characteristics in alleged human trafficking incidents, 2007-08
cshti08t10.csv		Table 10. Arrest and adjudication of suspects in alleged human trafficking incidents, 2007-08
cshti08t11.csv		Table 11. Reported data for key items in the human trafficking reporting system, September 2008
cshti08t12.csv		Table 12. Characteristics of alleged human trafficking incidents, by year of occurrence, 2007-08

	Text table	
cshti08tt01.csv		Text table 1. Number of alleged cases of by trafficking by number of task forces
