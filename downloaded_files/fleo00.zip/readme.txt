Federal Law Enforcement Officers, 2000 NCJ  187231

This zip archive contains tables in individual .wk1 spreadsheets
from Federal Law Enforcement Officers, 2000 NCJ  187231
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/fleo00.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the 
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#fleo

File Name         Table Titles

fleo00h1.wk1      Highlights Figure 1.  Percent change in the number of Federal officers with arrest and firearm authority, 1998-2000.
fleo00f1.wk1      Figure 1.  Primary function of Federal officers with arrest and firearm authority, June 2000
fleo00f2.wk1      Figure 2.  Gender and race or ethnicity of full-time Federal officers with arrest and firearm authority, June 2000
fleo00f3.wk1      Figure 3.  Major employers of Federal officers, midyears 2000, 1998 and 1996
fleo00f4.wk1      Figure 4.  Gender and race or ethnicity of full-time Federal officers with arrest and firearm authority, June 2000 and June 1996
fleo0001.wk1      Table 1.  Federal agencies employing 500 or more full-time officers with authority to carry firearms and make arrests, June 2000
fleo0002.wk1      Table 2.  Federal agencies employing at least 100 but fewer than 500
                  full-time personnel authorized to make arrests and carry firearms, June 2000
fleo0003.wk1      Table 3.  Employment by offices of inspector general of full-time personnel authorized to make arrests and carry firearms, June 2000
fleo0004.wk1      Table 4.  Female and minority representation among personnel with arrest and firearm authority in offices of inspector general, June 2000
fleo0005.wk1      Table 5.  Gender and race or ethnicity of Federal officers with arrest and firearm authority,
                  agencies employing 500 or more full-time officers, June 2000
fleo0006.wk1      Table 6.  Number of full-time Federal officers with arrest and firearm authority and number per 100,000
                  residents, by primary State of employment, June 2000
fleo0008.wk1      Table 8.  Federal officers with arrest and firearm authority in selected large agencies, by primary State of employment, June 2000.
 
 
 
 
 
