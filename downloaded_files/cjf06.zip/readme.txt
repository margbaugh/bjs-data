Census of Jail Facilities, 2006 NCJ 230188

This zip archive contains tables in individual .csv spreadsheets
from Census of Jail Facilities, 2006 NCJ 230188, electronic only. 
The full electronic report is available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2205

These statistical tables are in a series.  More recent editions
may be available.  To view a list of all in the series go to:
http://www.bjs.gov/index.cfm?ty=pbse&sid=66


Tables:
cjf06t01.csv		Table 1.  Profile of jails in the United States by characteristic, 1999 and 2006 
cjf06t02.csv		Table 2.  Number of jail jurisdictions and number of jail facilities in the United States, 1999 and 2006
cjf06t03.csv		Table 3.  Selected  functions provided by local jail facilities, 2006
cjf06t04.csv		Table 4.  Number of  local jail facilities by function, 2006
cjf06t05.csv		Table 5.  Number of jail facilities by gender of inmates authorized to house, 2006
cjf06t06.csv		Table 6.  Number of contract jail facilities, 1999 and 2006
cjf06t07.csv		Table 7.  Number of Jail jurisdictions under court order or consent decree to limit 
cjf06t08.csv		Table 8.  Number of local jail jurisdictions by size ,  2006
cjf06t09.csv		Table 9.  Number of jail inmates confined in facilities directly by jail jurisdictions or by contractors, 1999 and 2006
cjf06t10.csv		Table 10. Number of confined  inmates  by size of local  jurisdiction, 2006
cjf06t11.csv		Table 11. Number of confined jail inmates per 100,000 U.S. residents, 1999  2006 
cjf06t12.csv		Table 12. Total estimated  and reported jail staff, 2006
cjf06t13.csv		Table 13. Number of confined jail inmates per employee, 1999 and 2006
cjf06t14.csv		Table 14. Prisoners in states with combined jail/prison systems, 2006



