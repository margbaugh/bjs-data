						readme.txt

Contents of zip archive scs9604.zip
Tables from Section 4 of State Court Sentencing of Convicted Felons, 1996, NCJ 175708

scs9641.wk1		Table 4.1 Number of felony convictions in State courts, by offense and type of
                    	conviction, 1996
scs9642.wk1		Table 4.2 Percent of felons convicted in State courts, by offense and type of
                    	conviction, 1996
scs9643.wk1		Table 4.3 Type of conviction of felons convicted in State courts, by offense, 1996
scs9644.wk1		Table 4.4 Offense of felons convicted in State courts, by the type of conviction and
                    	type of sentence imposed, 1996
scs9645.wk1		Table 4.5 Average felony sentence length in State courts, by the type of conviction,
                    	type of sentence imposed, and offense, 1996
scs9646.wk1		Table 4.6 Type of conviction in State courts, by the type of sentence imposed on
                    	felons convicted of murder or nonnegligent manslaughter, 1996
scs9647.wk1		Table 4.7 Type of conviction in State courts, by number of felony conviction
                    	offenses, 1996
scs9648.wk1		Table 4.8 Percent of conviction offenses of felons convicted in State courts, by
                    	type of conviction and type of sentence imposed, 1996
scs9649.wk1		Table 4.9 Average number of days between arrest and conviction for felony cases in
                    	State courts, by type of conviction, 1996
scs96410.wk1		Table 4.10 Average number of days between conviction and sentencing for felony cases
                    	in State courts, by type of conviction, 1996
scs96411.wk1      	Table 4.11 Mean and median number of days between arrest and sentencing for felony
                    	cases disposed by State courts, 1996
