Hate Crime Reported by Victims and Police, NCJ 209911

 
This zip archive contains tables in individual .csv spreadsheets
from Hate Crime Reported by Victims and Police, NCJ 209911. The full report
including 
text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/hcrvp.htm

Filename       Table number
hcrvp01.csv         Table 1.  Annual number, rate, and percent of hate crimes
reported to the National Crime Victimization Survey
hcrvp02.csv         Table 2.  Motivation and evidence in hate crime 
hcrvp03.csv         Table 3.  Hate and other crime victimizations, by type of
crime
hcrvp04.csv         Table 4.  Reporting crimes of hate and other violent crimes
to police 
hcrvp05.csv         Table 5.  Contacts with police for crimes of hate and other
violent victimizations
hcrvp06.csv         Table 6.  Reasons victim reported crime to police, by type
of crime
hcrvp07.csv         Table 7.  Reasons victim did not report crime to police, by
type of crime
hcrvp08.csv         Table 8.  Characteristics of victims of hate crime
hcrvp09.csv         Table 9.  Characteristics of offenders as reported by their
victims
hcrvp10.csv         Table 10. Hate crime and other types of crime, by time and
place of occurrence
hcrvp11.csv         Table 11. Hate crime motivation reported to the NCVS and the
UCR
hcrvp12.csv         Table 12. Type of hate crime reported to the NCVS and the
UCR
hcrvp13.csv         Table 13. Characteristics of victims of hate crime reported
to NCVS and NIBRS
hcrvp14.csv         Table 14. Characteristics of offenders reported by hate
crime victims to NCVS and NIBRS

hcrvpbt1.csv        Box table 1.  Almost all bias crime victims cited
offenders' remarks as evidence for classifying the offense as a hate crime
hcrvpbt2.csv        Box table 2.  Police confirmation 8% of hate
victimization
hcrvpbt3.csv        Box table 3.  1 in 10 victims of crime helped by an
agency other than the police
hcrvpbt4.csv        Box Table 4.  About 1 in every 265 vandalized
households considered the vandalism a hate crime

hcrvptt1.csv        Text table 1.  Motivation for hate crimes, by gender
hcrvptt2.csv        Text table 2:  Motivation for hate crimes, by race
hcrvptt3.csv        Text table 3:  Motivation for hate crimes, by age
hcrvptt4.csv        Text table 4:  Gender of offenders committing hate
crimes
hcrvptt5.csv        Text table 5:  Race of offenders committing hate
crimes
hcrvptt6.csv        Text table 6.  Age of offenders committing hate crimes
hcrvptt7.csv        Text table 7.  Hate crime victims and offenders, by
gender
hcrvptt8.csv        Text table 8.  Hate crime victims and offenders, by
race
hcrvptt9.csv        Text table 9.  Hate crime victims and offenders, by
age 
