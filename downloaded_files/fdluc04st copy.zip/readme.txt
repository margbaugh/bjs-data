Felony Defendants in Large Urban Counties, 2004 - Statistical Tables        		


This zip archive contains tables in individual  .csv spreadsheets               	
from Felony Defendants in Large Urban Counties, 2004 - Statistical Tables,  NCJ 221374
The full report including text and graphics in pdf format are available from:              		
http://www.ojp.usdoj.gov/bjs/pub/html/fdluc/2004/fdluc04st.htm          		


This report is one in a series.  More recent editions            		
may be available.  To view a list of all in the series go to               		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#fdluc    		

Tables

fdluc04st01.csv		Table 1. Felony defendants, by most serious arrest charge, 2004
fdluc04st02.csv		Table 2.  Race and Hispanic origin of felony defendants,  by most serious arrest charge, 2004
fdluc04st03.csv		Table 3.  Gender of felony defendants, by most serious arrest charge, 2004
fdluc04st04.csv		Table 4.  Age at arrest of felony defendants, by most serious arrest charge, 2004
fdluc04st05.csv		Table 5.  Criminal justice status of felony defendants at time of arrest, by most serious current arrest charge, 2004
fdluc04st06.csv		Table 6.  Number of prior arrest charges of felony defendants, by most serious current arrest charge, 2004
fdluc04st07.csv		Table 7.  Number of prior convictions of felony defendants, by most serious current arrest charge, 2004
fdluc04st08.csv		Table 8.  Most serious prior conviction of felony defendants, by most serious current arrest charge, 2004
fdluc04st09.csv		Table 9.  Felony defendants released before or detained until case disposition, by most serious arrest charge, 2004
fdluc04st10.csv		Table 10.  Type of pretrial release or detention of felony defendants, by most serious arrest charge, 2004  
fdluc04st11.csv		Table 11.  Bail amount set for felony defendants, by most serious arrest charge, 2004
fdluc04st12.csv		Table 12.  Median and mean bail amounts set for felony defendants, by pretrial release/detention outcome and most serious arrest charge, 2004
fdluc04st13.csv		Table 13.  Time from arrest to release for felony defendants released before case disposition, by most serious arrest charge, 2004
fdluc04st14.csv		Table 14.  Percent of felony defendants who were released prior to case disposition, by criminal history, 2004
fdluc04st15.csv		Table 15.  Released felony defendants committing misconduct, by most serious arrest charge, 2004
fdluc04st16.csv		Table 16.  Released felony defendants who failed to make a scheduled court appearance, by most serious arrest charge, 2004
fdluc04st17.csv		Table 17.  Released felony defendants who were rearrested prior to case disposition, by most serious arrest charge, 2004
fdluc04st18.csv		Table 18.  Time from arrest to adjudication for felony defendants, by most serious arrest charge, 2004
fdluc04st19.csv		Table 19.  Adjudication outcome for felony defendants, by most serious arrest charge, 2004  
fdluc04st20.csv		Table 20.  Adjudication outcome for felony defendants, by detention-release outcome and most serious arrest charge, 2004
fdluc04st21.csv		Table 21.  Conviction offense of defendants arrested for a violent offense and subsequently convicted, by most serious arrest charge, 2004
fdluc04st22.csv		Table 22.  Conviction offense of defendants arrested for a nonviolent offense and subsequently convicted, by most serious arrest charge, 2004
fdluc04st23.csv		Table 23.  Felony defendants, by conviction offense, 2004
fdluc04st24.csv		Table 24.  Time from conviction to sentencing for convicted defendants, by most serious conviction offense, 2004
fdluc04st25.csv		Table 25.  Most severe type of sentence received by convicted defendants, by most serious conviction offense, 2004
fdluc04st26.csv		Table 26.  Length of prison sentence received by defendants convicted of a felony, by most serious conviction offense, 2004
fdluc04st27.csv		Table 27.  Length of jail sentence received by convicted defendants, by most serious conviction offense, 2004
fdluc04st28.csv		Table 28.  Length of probation sentence received by convicted defendants,  by most serious conviction offense, 2004
fdluc04st29.csv		Table 29.  Conditions of probation sentence received most often by convicted defendants, by most serious conviction offense, 2004
fdluc04st30.csv		Table 30.  Most severe type of sentence received by defendants convicted of a felony, by prior conviction record, 2004

Appendix tables

fdluc04stata.csv	Appendix table A.  Population, sampling weights, and number of cases, by SCPS jurisdiction, 2004
fdluc04statb.csv	Appendix table B.  Most serious arrest charge of felony defendants, by SCPS jurisdiction, 2004
fdluc04statc.csv	Appendix table C.  Gender and age of felony defendants, by SCPS jurisdiction, 2004
fdluc04statd.csv	Appendix table D.  Race and Hispanic/Latino origin, by SCPS jurisdiction, 2004
fdluc04state.csv	Appendix table E.  Felony defendants released before or detained until case disposition, by SCPS jurisdiction, 2004
fdluc04statf.csv	Appendix table F.  Failure-to-appear and rearrest rates of defendants released prior to case disposition, by SCPS jurisdiction, 2004
fdluc04statg.csv	Appendix table G.  Adjudication outcome for felony defendants, by SCPS jurisdiction, 2004
fdluc04stath.csv	Appendix table H.  Most severe type of sentence received  by defendants convicted of a felony, by SCPS jurisdiction, 2004


