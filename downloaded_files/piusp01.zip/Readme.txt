Prevalence of Imprisonment in the U.S Population, 1974-2001, NCJ 197976
 
This zip archive contains tables in individual .wk1 spreadsheets
from Prevalence of Imprisonment in the U.S Population, 1974-2001,
NCJ 197976. The full report including text and graphics in
pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/piusp01.htm 

pius01t1.wk1         Table 1.  Prevalence of incarceration in a State or Federal prison, by current and former prisoners, 1974-2001
pius01t2.wk1         Table 2.  Prevalence of incarceration in a State or Federal prison, by age, 1974-2001
pius01t3.wk1         Table 3.  Percent of adult population ever incarcerated in a State or Federal prison, by age, 1974-2001
pius01t4.wk1         Table 4.  Number of adults ever incarcerated in a State or Federal prison, by gender, race, and Hispanic origin, 1974-2001
pius01t5.wk1         Table 5.  Percent of adult population ever incarcerated in a State or Federal prison, by gender, race, and Hispanic origin, 1974-2001
pius01t6.wk1         Table 6 . Number ever incarcerated in State or Federal prison, by gender, race, Hispanic origin, and age, 2001
pius01t7.wk1         Table 7.  Percent of adult population ever incarcerated in a State or Federal prison, by gender, race, Hispanic origin, and age, 2001
pius01t8.wk1         Table 8.  Percent of adults ever incarcerated in State or Federal prison, by year of birth and age
pius01t9.wk1         Table 9.  Lifetime chances of going to State or Federal prison for the first time, by gender, race and Hispanic origin, 1974-2001

        Highlight tables
pius01h1.wk1         Highlight Table 1.  At yearend 2001 over 5.6 million U.S. adults had ever served time in State or Federal prison
pius01h2.wk1         Highlight Table 2.  If incarceration rates remain unchanged, 6.6% of U.S. residents born in 2001 will go to prison at some time during their lifetime
 
        Text tables
pius01x1.wk1	     Text Table 1.  Number of adults with prison experience, 2001, by former inmates and current inmates
pius01x2.wk1         Text Table 2.  Former State and Federal prisoners, 2001, by type of supervision
pius01x3.wk1         Text Table 3.  Projected prevalence of having gone to State or Federal prison
         
	Figures
pius01f1.wk1         Figure 1.  First incarceration rates rose sharply among persons under age 45
pius01f2.wk1         Figure 2.  Younger age groups experience rising rates of imprisonment
pius01f3.wk1         Figure 3.  The lifetime chances of going to prison reached 6.6% in 2001, up from 1.9% in 1974
pius01f4.wk1         Figure 4.  Nearly 1 in 3 black males likely to go to prison based on constant 2001 incarceration rates
pius01f5.wk1         Figure 5.  1 in 19 black females compared with 1 in 118 white females likely to go to prison

	Appendix tables
pius01a1.wk1         Figure 1.  Calculating the number of persons ever incarcerated in State or Federal prison, 2001
pius01a2.wk1         Figure 2.  Estimating the prevalence of imprisonment in the U.S. population for persons born in 1980
pius01a3.wk1         Figure 3.  Estimating the prevalence of imprisonment in the U.S. population for persons born in 1970
