Indicators of School Crime and Safety:  2008  NCJ  226343		

This Zip archive contains tables in individual .csv spreadsheets		
from Indicators of School Crime and Safety:  2008  NCJ 226343.
The full report, including text and graphics in .pdf format are available from:		
http://www.ojp.usdoj.gov/bjs/abstract/iscs08.htm.		

This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#indicators.

NOTE: ADDITIONAL CSV FILES ARE FORTHCOMING.


Tables		

iscs08t01_1.csv		Table 1.1. Number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location and year: 1992�2007
icsc08t01_2.csv		Table 1.2. Number of school-associated violent deaths of students, staff, and nonstudents, by type: 1992�2007
iscs08t02_1.csv		Table 2.1. Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students, by location, type of crime and year: 1992�2006
iscs08t02_2.csv		Table 2.2. Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students at school, by type of crime and selected student and school characteristics: 2006
iscs08t02_3.csv		Table 2.3. Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students away from school, by type of crime and selected student and school characteristics: 2006
iscs08t03_1.csv		Table 3.1. Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student and school characteristics: Various years, 1995�2007.
iscs08t04_1.csv		Table 4.1. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by selected student and school characteristics: Various years, 1993�2007
iscs08t04_2.csv		Table 4.2. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by state: 2003, 2005, and 2007
iscs08t05_1.csv		Table 5.1. Percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs08t05_2.csv		Table 5.2. Percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs08t05_3.csv		Table 5.3. Percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: 1993�94, 1999�2000, and 2003�04
iscs08t05_4.csv		Table 5.4. Percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: 1993�94, 1999�2000, and 2003�04
iscs08t06_1.csv		Table 6.1. Percentage of public schools experiencing and reporting incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime: Various school years, 1999�2000, 2003�04, and 2005�06
iscs08t06_2.csv		Table 6.2. Percentage of public schools experiencing incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2005�06
iscs08t06_3.csv		Table 6.3. Percentage of public schools reporting incidents of crime to the police, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2005�06
iscs08t06_4.csv		Table 6.4. Percentage of public schools experiencing and reporting to the police violent incidents of crime, by the number of incidents and selected school characteristics: School year 2005�06
iscs08t06_5.csv		Table 6.5. Percentage of public schools experiencing and reporting to the police serious violent incidents of crime, by the number of incidents and selected school characteristics: School year 2005�06
iscs08t07_1.csv		Table 7.1. Percentage of public schools reporting selected discipline problems that occurred at school, by frequency: Various school years, 1999-2000,  2003-04, and 2005-06
iscs08t07_2.csv		Table 7.2. Percentage of public schools reporting selected discipline problems that occurred at school, by frequency and school characteristics: School year 2005-06
iscs08t08_1.csv		Table 8.1. Percentage of students ages 12�18 who reported that gangs were present at school, by urbanicity and selected student and school characteristics: Various years, 2001�2007
iscs08t09_1.csv		Table 9.1. Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by selected student and school characteristics: Various years, 1993�2007
iscs08t09_2.csv		Table 9.2. Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by state: 2003, 2005, and 2007
iscs08t10_1.csv		Table 10.1. Percentage of students ages 12�18 who reported being targets of hate-related words and seeing hate-related graffiti at school, by selected student and school characteristics: Various years, 1999�2007
iscs08t10_2.csv		Table 10.2. Percentage of students ages 12�18 who reported being targets of hate-related words at school during the school year, by selected student and school characteristics: 2007
iscs08t11_1.csv		Table 11.1. Percentage of students ages 12�18 who reported being bullied at school and cyber-bullied anywhere during the school year, by selected bullying problems and selected student and school characteristics: 2007
iscs08t11_2.csv		Table 11.2. Percentage of students ages 12�18 who reported being bullied at school during the school year, by location of bullying, injury, and selected student and school characteristics: 2007
iscs08t11_3.csv		Table 11.3. Percentage distribution of students ages 12�18 who reported being bullied at school and cyber-bullied anywhere by the frequency of bullying at school during the school year and percentage of students who notified an adult, by selected student and school characteristics: 2007
iscs08t12_1.csv		Table 12.1. Percentage of public and private school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class-cutting interfered with their teaching, by selected teacher and school characteristics: Various school years, 1987-88 through 2003-04
iscs08t12_2.csv		Table 12.2. Percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by selected teacher and school characteristics: Various school years, 1987-88 through 2003-04
iscs08t13_1.csv		Table 13.1. Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and selected student and school characteristics: Various years, 1993�2007
iscs08t13_2.csv		Table 13.2. Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location and state: 2003, 2005, and 2007
iscs08t14_1.csv		Table 14.1. Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2007
iscs08t14_2.csv		Table 14.2. Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and state: 2003, 2005, and 2007
iscs08t15_1.csv		Table 15.1. Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2007
iscs08t15_2.csv		Table 15.2. Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location and state: 2003, 2005, and 2007
iscs08t16_1.csv		Table 16.1. Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and selected student and school characteristics: Various years, 1993�2007
iscs08t16_2.csv		Table 16.2. Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location and state: 2003, 2005, and 2007
iscs08t17_1.csv		Table 17.1. Percentage of students ages 12�18 who reported being afraid of attack or harm, by location and selected student and school characteristics: Various years, 1995�2007
iscs08t18_1.csv		Table 18.1. Percentage of students ages 12�18 who reported avoiding school activities or one or more places in school because of fear of attack or harm: Various years, 1995�2007
iscs08t18_2.csv		Table 18.2. Percentage of students ages 12�18 who reported avoiding one or more places in school because of fear of attack or harm, by selected student and school characteristics: Various years, 1995�2007
iscs08t19_1.csv		Table 19.1. Number and percentage of public schools that took a serious disciplinary action, number of serious actions taken, and percentage distribution of serious actions, by type of action and type of offense: School year 2005-06
iscs08t19_2.csv		Table 19.2. Percentage of public schools that took a serious disciplinary action and number of serious actions taken, by type of offense: Various school years, 1999-2000, 2003-04, and 2005-06
iscs08t20_1.csv		Table 20.1. Percentage of public schools that used selected safety and security measures, by school characteristics: School year 2005-06
iscs08t20_2.csv		Table 20.2. Percentage of public schools that used safety and security measures: Various school years, 1999-2000, 2003-04, and 2005-06
iscs08t21_1.csv		Table 21.1. Percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999�2007