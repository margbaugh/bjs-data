Opioid Use Disorder Screening and Treatment in Local Jails, 2019   NCJ 305179
															
This zip archive contains tables in individual  .csv spreadsheets
from Opioid Use Disorder Screening and Treatment in Local Jails, 2019   NCJ 305179. The full report including text
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/opioid-use-disorder-screening-and-treatment-local-jails-2019
															
Filenames		Table titles														
oudstlj19t01.csv	Table 1. Percent of local jail inmates screened or treated for opioid use disorder, 2019
oudstlj19t02.csv	Table 2. Percent of local jail jurisdictions that screened for opioid use disorder at intake, by screening practice and jurisdiction characteristics, midyear 2019
oudstlj19t03.csv	Table 3. Percent of local jail admissions in June 2019 screened for opioid use disorder and positive screenings, by jurisdiction characteristics
oudstlj19t04.csv	Table 4. Percent of local jail admissions in June 2019 screened for opioid use disorder and positive screenings, by region and state
oudstlj19t05.csv	Table 5. Percent of local jail jurisdictions that treated for opioid use disorder in custody, by treatment practice and jurisdiction characteristics, midyear 2019
oudstlj19t06.csv	Table 6. Percent of local jail admissions in June 2019 treated for opioid withdrawal, by jurisdiction characteristics
oudstlj19t07.csv	Table 7. Percent of confined inmates at midyear 2019 receiving medication-assisted treatment for opioid use disorder, by jurisdiction characteristics
oudstlj19t08.csv	Table 8. Percent of local jail jurisdictions that treated for opioid use disorder upon release, by treatment practice and jurisdiction characteristics, midyear 2019
															
			Figures														
oudstlj19f01.csv	Figure 1. Percent of local jail jurisdictions that screened or treated inmates for opioid use disorder, midyear 2019
															
			Appendix tables														
oudstlj19at01.csv	Appendix table 1. Rate of response to survey items on screening and treatment for opioid use disorder, midyear 2019
oudstlj19at02.csv	Appendix table 2. Rates for map 1: Rates of opioid overdose deaths per 100,000 U.S. residents ages 15 to 74, by state, 2019
oudstlj19at03.csv	Appendix table 3. Percent of admissions, confined inmates, and releases in local jail jurisdictions that screened or treated for opioid use disorder, by screening or treatment practice, region, and state, 2019
oudstlj19at04.csv	Appendix table 4. Percent of local jail jurisdictions that screened or treated for opioid use disorder, by screening or treatment practice, region, and state, midyear 2019
oudstlj19at05.csv	Appendix table 5. Percentages for maps 5 and 6: Percent of local jail admissions in June 2019 treated for opioid withdrawal and confined inmates at midyear 2019 receiving medication-assisted treatment for opioid use disorder, by state