Federal Criminal Case Processing, 2000: With trends 1982-2000   NCJ  190737

 
This zip archive contains tables in individual .wk1 spreadsheets
from Federal Criminal Case Processing, 2000: With trends 1982-2000, NCJ  190737.
The full report including text and graphics in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/fccp00.htm
 
 
Filename          Table
fccp00cv.wk1          Cover figure on trends of Federal criminal case processing, 1994-2000
fccp001.wk1           Table 1. Arrests for Federal offenses, by offense, October 1, 1999 - September 30, 2000
fccp002.wk1           Table 2. Suspects in criminal matters investigated by U.S. attorneys, by offense, October 1, 1999 - September 30, 2000
fccp003.wk1           Table 3. Disposition of suspects in matters concluded by U.S. attorneys, by offense, October 1, 1999 - September 30, 2000
fccp004.wk1           Table 4. Defendants in cases proceeded against in U.S. district courts, by offense, October 1, 1999 - September 30, 2000
fccp005.wk1           Table 5. Disposition of defendants in cases terminating in U.S. district court, by offense, October 1, 1999 - September 30, 2000
fccp006.wk1           Table 6. Sanctions imposed on offenders convicted and sentenced in U.S. district courts, by offense, October 1, 1999 - September 30, 2000
fccp007.wk1           Table 7. Criminal appeals filed, by type of criminal case and offense, October 1, 1999 - September 30, 2000
fccp008.wk1           Table 8. Offenders under Federal supervision, by offense, October 1, 1999 - September 30, 2000
fccp009.wk1           Table 9. Federal prison admissions and releases,  by offense, October 1, 1999 - September 30, 2000
 
Appendix
fcp00a01.wk1          Table A.1.   Arrests for Federal offenses, by offense, 1994-2000
fcp00a02.wk1          Table A.2.   Suspects in criminal matters investigated by U.S. attorneys, by offense, 1994-2000
fcp00a03.wk1          Table A.3.   Suspects in criminal matters concluded by U.S. attorneys, by offense, 1994-2000
fcp00a04.wk1          Table A.4.   Suspects in criminal matters concluded by U.S. attorneys:  Number prosecuted before U.S. district court judge, by offense, 1994-2000
fcp00a05.wk1          Table A.5.   Suspects in criminal matters concluded by U.S. magistrates,  by offense, 1994-2000
fcp00a06.wk1          Table A.6.   Suspects in criminal matters concluded by U.S. attorneys:  Number declined prosecution, by offense, 1994-2000
fcp00a07.wk1          Table A.7.   Defendants in cases proceeded against in U.S. district courts, by offense, 1994-2000
fcp00a08.wk1          Table A.8.   Defendants in cases terminating in U.S. district courts, by offense, 1994-2000
fcp00a09.wk1          Table A.9.   Defendants in cases terminating in U.S. district courts:  Percent convicted, by offense, 1994-2000
fcp00a10.wk1          Table A.10.  Offenders convicted and sentenced in U.S. district courts, by offense, 1994-2000
fcp00a11.wk1          Table A.11.  Offenders convicted and sentenced in U.S. district courts:  Number sentenced to prison, by offense, 1994-2000
fcp00a12.wk1          Table A.12.  Criminal appeals filed, by offense, 1994-2000
fcp00a13.wk1          Table A.13.  Offenders convicted and sentenced in U.S. district courts:  Number sentenced to probation only, by offense, 1994-2000
fcp00a14.wk1          Table A.14.  Offenders convicted and sentenced in U.S. district courts:  Mean number of months of imprisonment imposed, by offense, 1994-2000
fcp00a15.wk1          Table A.15.  Offenders under Federal supervision, by offense, 1994-2000
fcp00a16.wk1          Table A.16.  Population at the end of the year in Federal prisons, by offense, 1994-2000
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
