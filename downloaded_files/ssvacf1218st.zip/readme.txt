Survey of Sexual Victimization in Adult Correctional Facilities, 2012-2018 – Statistical Tables  NCJ 252836	
	
This zip archive contains tables in individual .csv spreadsheets	
from Survey of Sexual Victimization in Adult Correctional Facilities, 2012-2018 – Statistical Tables  NCJ 252836	
The full report including text and graphics in pdf format is available from 	
https://bjs.ojp.gov/library/publications/survey-sexual-victimization-adult-correctional-facilities-2012-2018	
	
This report is one in a series.  More recent editions	
may be available. To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Publications	
	
Filenames		Table titles
ssvacf1218stt01.csv	Table 1. Allegations and substantiated incidents of sexual victimization, by type of adult correctional facility, 2012-2018
ssvacf1218stt02.csv	Table 2. Allegations and substantiated incidents of inmate-on-inmate sexual harassment, by type of adult correctional facility, 2016-18
ssvacf1218stt03.csv	Table 3. Allegations and substantiated incidents of inmate-on-inmate sexual harassment, by type of adult correctional facility, 2013-15
ssvacf1218stt04.csv	Table 4. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2018
ssvacf1218stt05.csv	Table 5. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2017
ssvacf1218stt06.csv	Table 6. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2016
ssvacf1218stt07.csv	Table 7. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2015
ssvacf1218stt08.csv	Table 8. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2014
ssvacf1218stt09.csv	Table 9. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2013
ssvacf1218stt10.csv	Table 10. Sexual victimization reported by federal and state prison authorities, by type of victimization, 2012
ssvacf1218stt11.csv	Table 11. Inmate-on-inmate sexual harassment reported by federal and state prison authorities, 2016-2018
ssvacf1218stt12.csv	Table 12. Inmate-on-inmate sexual harassment reported by federal and state prison authorities, 2013-2015
ssvacf1218stt13.csv	Table 13. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2018
ssvacf1218stt14.csv	Table 14. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2017
ssvacf1218stt15.csv	Table 15. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2016
ssvacf1218stt16.csv	Table 16. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2015
ssvacf1218stt17.csv	Table 17. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2014
ssvacf1218stt18.csv	Table 18. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2013
ssvacf1218stt19.csv	Table 19. Sexual victimization reported by authorities in large local jail jurisdictions, by type of victimization, 2012
ssvacf1218stt20.csv	Table 20. Inmate-on-inmate sexual harassment reported by authorities in large local jail jurisdictions, 2016-2018
ssvacf1218stt21.csv	Table 21. Inmate-on-inmate sexual harassment reported by authorities in large local jail jurisdictions, 2013-2015
	
			Figure
ssvacf1218stf01.csv	Figure 1. Allegations of sexual victimization, by type of adult correctional facility, 2018
	
			Appendix tables
ssvacat1218stat01.csv	Appendix table 1. Standard errors for table 1: Allegations and substantiated incidents of sexual victimization, by type of adult correctional facility, 2012-2018
ssvacat1218stat02.csv	Appendix table 2. Standard errors for table 2: Allegations and substantiated incidents of inmate-on-inmate sexual harassment, by type of adult correctional facility, 2016-18
ssvacat1218stat03.csv	Appendix table 3. Standard errors for table 3: Allegations and substantiated incidents of inmate-on-inmate sexual harassment, by type of adult correctional facility, 2013-15
