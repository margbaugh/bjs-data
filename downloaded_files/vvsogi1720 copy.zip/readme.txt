Violent Victimization by Sexual Orientation and Gender Identity, 2017–2020   NCJ 304277		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Violent Victimization by Sexual Orientation and Gender Identity, 2017–2020   NCJ 304277.  The full report including text		
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/violent-victimization-sexual-orientation-and-gender-identity-2017-2020
		
Filenames		Table titles	
vvsogi1720t01.csv	Table 1. Rate of violent victimization, by sexual orientation and type of crime, 2017–20	
vvsogi1720t02.csv	Table 2. Rate of violent victimization, by gender identity and type of crime, 2017–20	
vvsogi1720t03.csv	Table 3. Rate of violent victimization, by sexual orientation and demographic characteristics, 2017–20	
vvsogi1720t04.csv	Table 4. Unweighted number and percent response to gender identity confirmation item, 2017–20	
vvsogi1720t05.csv	Table 5. Percent of nonresponse to sexual orientation and gender identity items, 2017–20	
		
			Figures	
vvsogi1720f01.csv	Figure 1. Rate of violent victimization, by sexual orientation and gender identity, 2017–20	
vvsogi1720f02.csv	Figure 2. Percent of violent victimizations reported to police, by sexual orientation, 2017–20	
		
			Appendix tables	
vvsogi1720at01.csv	Appendix table 1. Rates and standard errors for figure 1: Rate of violent victimization, by sexual orientation and gender identity, 2017–20	
vvsogi1720at02.csv	Appendix table 2. Confidence intervals for table 1: Rate of violent victimization, by sexual orientation and type of crime, 2017–20	
vvsogi1720at03.csv	Appendix table 3. Number of violent victimizations for table 1, by sexual orientation and type of crime, 2017–20	
vvsogi1720at04.csv	Appendix table 4. Confidence intervals for table 2: Rate of violent victimization, by gender identity and type of crime, 2017–20	
vvsogi1720at05.csv	Appendix table 5. Number of violent victimizations for table 2, by gender identity and type of crime, 2017–20	
vvsogi1720at06.csv	Appendix table 6. Violent victimizations, by population, sexual orientation, and gender identity, 2017–20	
vvsogi1720at07.csv	Appendix table 7. Confidence intervals for table 3: Rate of violent victimization, by sexual orientation and demographic characteristics, 2017–20	
vvsogi1720at08.csv	Appendix table 8. Estimates and standard errors for figure 2: Percent of violent victimizations reported to police, by sexual orientation, 2017–20	
vvsogi1720at09.csv	Appendix table 9. Population of persons age 16 or older, by sexual orientation and gender identity, 2017–20	
vvsogi1720at10.csv	Appendix table 10. Population of persons age 16 or older, by sexual orientation and demographic characteristics, 2017–20	
vvsogi1720at11.csv	Appendix table 11. Population of persons age 16 or older, by gender identity and demographic characteristics, 2017–20	
		
		
		
		
		
		
		
