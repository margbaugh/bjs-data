Prosecutors in State Courts, 2007 - Statistical Tables -  NCJ 234211
											
This zip archive contains tables in individual .csv spreadsheets from 
Prosecutors in State Courts, 2007 - Statistical Tables, NCJ 234211
The full report including text and graphics in pdf format are available 
from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=1749
 
This report is one in a series.  More recent editions may be available. 
 To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=9
										
Tables											
psc07st_t01.csv		Table 1. State prosecutors' offices by office size, 2007									
psc07st_t02.csv		Table 2: State prosecutors offices budget and staffing, by office size, 2007
psc07st_t03.csv		Table 3: Personnel employed in State prosecutors offices, 2007
psc07st_t04.csv		Table 4: Felony cases closed by state prosecutor's offices, by office size, 2007
psc07st_t05.csv		Table 5: Tenure and salary of Chief Prosecutors in state prosecutors' offices, by office size, 2007
psc07st_t06.csv		Table 6: Assistant Prosecutors average mimimum and maximum salary in State prosecutors' offices by office classification, 2007
psc07st_t07.csv		Table 7: State prosecutors' offices receiving threats and percent with staff who carry firearms, by office size, 2007
psc07st_t08.csv		Table 8: Prosecution of specific felony offenses, by office size, 2007
psc07st_t09.csv		Table 9: State court prosecutors' office use of DNA evidence, 2007
psc07st_t10.csv		Table 10: Type of disposition information reported to data repositories by state court prosecutors' offices, 2007
psc07st_t11.csv		Table 11: Standard errors of critical variables, by data source, 2007

Figures
psc07st_f01.csv		Figure 1: Salary of Chief and Assistant Prosecutors in state prosecutors' offices by office classification, 2007
psc07st_f02.csv		Figure 2: Prosecution of specific felony offenses, by office size, 2007
psc07st_f03.csv		Figure 3: Type of disposition information reported to data repositories by state court prosecutors' offices, 2007