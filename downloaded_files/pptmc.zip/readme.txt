Parents in Prison and Their Minor Children 
This zip archive contains tables in individual .csv spreadsheets
from Parents in Prison and Their Minor Children, NCJ 222984.
The full report including text and graphics in .pdf format is available at		
http://www.ojp.usdoj.gov/bjs/abstract/pptmc.htm

Filename        Table number	
pptmct01.csv	Table 1. Estimated number of parents in state and federal prisons and their minor children
pptmct02.csv	Table 2. Minor children in the U.S. resident population with a parent in state or federal prison, by race and Hispanic origin, 2007
pptmct03.csv	Table 3. Percent of minor children of parents in state and federal prisons at time of interview, by gender, 2004
pptmct04.csv	Table 4. Estimated number of minor children of state and federal inmates at time of admission, at interview, and at expected release, by gender, 2004
pptmct05.csv	Table 5. Percent of state and federal inmates who were parents of minor children, by age and gender, 2004
pptmct06.csv	Table 6. Percent of state inmates who were parents of minor children, by current offense and gender, 2004
pptmct07.csv	Table 7. Parents in state prison who reported living with their children in the month before arrest or just prior to incarceration, by gender, 2004
pptmct08.csv	Table 8. Current caregiver of minor children of parents in state prison, by gender, 2004
pptmct9.csv	Table 9. Financial support of minor children provided by parents in state prison prior to their incarceration, by gender, 2004
pptmct10.csv	Table 10. Frequency of contact with adult or minor children among state inmates who were parents of minor children, by gender, 2004
pptmct11.csv	Table 11. Family incarceration of state inmates who were parents of minor children, by gender, 2004
pptmct12.csv	Table 12. Homelessness, physical/sexual abuse, medical/mental health problems, or substance dependence/abuse problems among state inmates who were parents of minor children, by living arrangement and gender, 2004
pptmct13.csv	Table 13. Alcohol or drug and mental health treatment history of inmates in state prison who were parents of minor children who had an alcohol or drug or mental health problem, by living arrangement and gender, 2004
pptmct14.csv	Table 14. Work assignments, program participation, and education among state inmates who were parents of minor children, by living arrangement and gender, 2004
pptmct15.csv	Table 15. Time served since admission and time to be served until expected release among state inmates who were parents of minor children, by gender, 2004

		Figure number	
pptmcf01.csv	Figure 1. Estimated number of parents in state and federal prisons and their minor children

		Appendix table number	
pptmcat01.csv	Appendix table 1. Estimated number of parents in state and federal prisons and their minor children, by inmate's gender 
pptmcat02.csv	Appendix table 2. Estimated number of parents in state and federal prisons and their minor children, by inmate's gender, race, and Hispanic origin, 2004 and 2007
pptmcat03.csv	Appendix table 3. State and federal inmates who reported having minor children, by gender, race, and Hispanic origin, 2004
pptmcat04.csv	Appendix table 4. Percent of state and federal inmates who were parents of minor children, by selected characteristics and gender, 2004
pptmcat05.csv	Appendix table 5. Percent of state and federal inmates who were parents of minor children, by current offense and gender, 2004
pptmcat06.csv	Appendix table 6. Percent of state and federal inmates who were parents of minor children, by criminal history and gender, 2004
pptmcat07.csv	Appendix table 7. Parents in federal prison who reported living with their minor children in the month before arrest or just prior to incarceration, by gender, 2004
pptmcat08.csv	Appendix table 8. Daily care and living status of minor children of parents in state and federal prisons, by gender, 2004
pptmcat09.csv	Appendix table 9. Financial support of minor children, employment, and income among parents in state and federal prisons, by gender, 2004
pptmcat10.csv	Appendix table 10. Frequency of telephone, mail, and personal contacts with adult or minor children among state and federal inmates who were parents of minor children, by gender, 2004
pptmcat11.csv	Appendix table 11. Family background of state and federal inmates who were parents of minor children, by gender, 2004
pptmcat12.csv	Appendix table 12. Homelessness, physical/sexual abuse, medical/mental health problems, or substance dependence/abuse problems among state and federal inmates who were parents of minor children, by gender, 2004
pptmcat13.csv	Appendix table 13. Alcohol or drug and mental health treatment history of inmates in state and federal prisons who were parents of minor children and who had an alcohol or drug or mental health problem, by gender, 2004
pptmcat14.csv	Appendix table 14. Work assignments, program participation, and education among state and federal inmates who were parents of minor children, by gender, 2004
pptmcat15.csv	Appendix table 15. Time served since admission and time to be served until expected release among state and federal inmates who were parents of minor children, by gender, 2004
pptmcat16.csv	Appendix table 16. Estimated number of inmates, by selected characteristics and gender, 2004
pptmcat17.csv	Appendix table 17. Estimated number of inmates, by offense, criminal history, and gender, 2004
pptmcat18.csv	Appendix table 18. Estimated number of parents in state prison, by selected characteristics and gender, 2004
pptmcat19.csv	Appendix table 19.  Standard errors of the estimated percentages, state inmates, by gender, 2004
pptmcat20.csv	Appendix table 20.  Standard errors of the estimated percentages, federal inmates, by gender, 2004
