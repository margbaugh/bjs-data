Felony Defendants in Large Urban Counties, 2009 - Statistical Tables NCJ 243777			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Felony Defendants in Large Urban Counties, 2009 - Statistical Tables NCJ 243777.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4845			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=27			
			
Filename			Table title
fdluc09t01.csv			Table 1. Felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t02.csv			Table 2. Level of second most serious charge for felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t03.csv			Table 3. Age at arrest of felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t04.csv			Table 4. Sex of felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t05.csv			Table 5. Race and Hispanic or Latino origin of felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t06.csv			Table 6. Felony defendants on probation or parole at time of arrest in the 75 largest counties, by most serious current arrest charge, 2009
fdluc09t07.csv			Table 7. Number of prior arrest charges for felony defendants in the 75 largest counties, by most serious current arrest charge, 2009
fdluc09t08.csv			Table 8. Number of prior felony arrest charges for felony defendants in the 75 largest counties, by most serious current arrest charge, 2009
fdluc09t09.csv			Table 9. Number of prior convictions for felony defendants in the 75 largest counties, by most serious current arrest charge, 2009
fdluc09t10.csv			Table 10. Number of prior felony convictions for felony defendants in the 75 largest counties, by most serious current arrest charge, 2009
fdluc09t11.csv			Table 11. Most serious prior conviction for felony defendants in the 75 largest counties, by most serious current arrest charge, 2009
fdluc09t12.csv			Table 12. Felony defendants released before or detained until case disposition in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t13.csv			Table 13. Felony defendants released prior to case disposition in the 75 largest counties, by criminal history, 2009
fdluc09t14.csv			Table 14. Time from arrest to release for felony defendants released before case disposition in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t15.csv			Table 15. Bail amount for felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t16.csv			Table 16. Median and mean bail amounts for felony defendants in the 75 largest counties, by pretrial release/detention outcome and most serious arrest charge, 2009
fdluc09t17.csv			Table 17. Released felony defendants committing misconduct in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t18.csv			Table 18. Released felony defendants who failed to make a scheduled court appearance in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t19.csv			Table 19. Released felony defendants rearrested prior to case disposition in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t20.csv			Table 20. Time from arrest to adjudication for felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t21.csv			Table 21. Adjudication outcome for felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t22.csv			Table 22. Felony defendants in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t23.csv			Table 23. Time from conviction to sentencing for convicted defendants in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t24.csv			Table 24. Most severe type of sentence received by convicted defendants in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t25.csv			Table 25. Length of prison sentence received by defendants convicted of a felony in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t26.csv			Table 26. Length of jail sentence received by convicted defendants in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t27.csv			Table 27. Length of probation sentence received by convicted defendants in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t28.csv			Table 28. Conditions of probation sentence received most often by convicted defendants in the 75 largest counties, by most serious conviction offense, 2009
fdluc09t29.csv			Table 29. Population, sampling weights, and number of cases, by SCPS jurisdiction, 2009
fdluc09t30.csv			Table 30. Standard errors and confidence intervals for felony in defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09t31.csv			Table 31. Standard errors and confidence intervals for felony in defendants in the 75 largest counties, by selected characteristics, 2009
			
Figures			
fdluc09f01.csv			Figure 1. Age of defendants convicted of a felony in the 75 largest counties, 1990, 2000, and 2009
fdluc09f02.csv			Figure 2. Defendants convicted of a felony in the 75 largest counties who had at least 1 prior felony conviction, by age at arrest, 1990, 2000, and 2009
fdluc09f03.csv			Figure 3. Age of defendants convicted of a felony and sentenced to prison in the 75 largest counties, 1990, 2000, and 2009
fdluc09f04.csv			Figure 4. Most frequently charged offenses of felony defendants in the 75 largest counties, 2009
fdluc09f05.csv			Figure 5. Most serious arrest charge category for felony defendants in the 75 largest counties, 1990�2009
fdluc09f06.csv			Figure 6. Age at arrest of felony defendants in the 75 largest counties, 1990�2009
fdluc09f07.csv			Figure 7. Race and Hispanic or Latino origin and sex of felony defendants in the 75 largest counties, by age at arrest, 2009
fdluc09f08.csv			Figure 8. Number of prior arrest charges for felony defendants in the 75 largest counties, by age at arrest, 2009
fdluc09f09.csv			Figure 9. Prior arrest record for felony defendants in the 75 largest counties, 1990�2009
fdluc09f10.csv			Figure 10. Most serious prior conviction for felony defendants in the 75 largest counties, by age at arrest, 2009
fdluc09f11.csv			Figure 11. Prior conviction record for felony defendants in the 75 largest counties, 1990�2009
fdluc09f12.csv			Figure 12. Type of pretrial release for felony defendants in the 75 largest counties, 2009 
fdluc09f13.csv			Figure 13. Pretrial release of felony defendants in the 75 largest counties, by bail amount, 2009 
fdluc09f14.csv			Figure 14. Use of financial conditions for pretrial release of felony defendants in the 75 largest counties, 1990�2009
fdluc09f15.csv			Figure 15. Median number of days from arrest to adjudication in the 75 largest counties, by detention-release outcome, 2009
fdluc09f16.csv			Figure 16. Conviction percents for felony defendants in the 75 largest counties, by most serious arrest charge, 2009
fdluc09f17.csv			Figure 17. Adjudication outcome for felony defendants in the 75 largest counties, by detention-release outcome and most serious arrest charge category, 2009
fdluc09f18.csv			Figure 18. Conviction rates for felony defendants in the 75 largest counties, 1990�2009
fdluc09f19.csv			Figure 19. Felony defendants convicted and sentenced to incarceration in the 75 largest counties, by most serious arrest charge, 2009
fdluc09f20.csv			Figure 20. Type of sentence received for a felony conviction in the 75 largest counties, by prior conviction record, 2009
fdluc09f21.csv			Figure 21. Most severe type of sentence received by defendants convicted of a felony in the 75 largest counties, 1990�2009
fdluc09f22.csv			Figure 22. Defendants convicted of a felony who were sentenced to incarceration in the 75 largest counties, by age at arrest, 1990, 2000, and 2009
