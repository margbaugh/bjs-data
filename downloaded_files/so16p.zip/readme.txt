Sheriffs� Offices, 2016: Personnel  NCJ 252834		
		
This zip archive contains tables in individual  .csv spreadsheets		
Sheriffs� Offices, 2016: Personnel  NCJ 252834  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6707 		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=45		
		
		
Filename		Tables
so16pt01.csv		Table 1. Full-time employees in sheriffs� offices, 1997-2016
so16pt02.csv		Table 2. Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2016
so16pt03.csv		Table 3. Sheriffs� offices and full-time employees, by size of office, 2016
so16pt04.csv		Table 4. Sex of full-time sworn personnel in sheriffs� offices, by size of office, 2016
so16pt05.csv		Table 5. Race or ethnicity of full-time sworn personnel in sheriffs� offices, by size of office, 2016
so16pt06.csv		Table 6. Race or ethnicity among full-time sworn personnel in sheriffs� offices, 1997-2016
so16pt07.csv		Table 7. Sex and race or ethnicity of full-time sworn personnel in sheriffs� offices, by size of office, 2016
so16pt08.csv		Table 8. Percent of sheriffs, intermediate supervisors, and first-line supervisors in sheriffs� offices who were female, by size of office, 2016
so16pt09.csv		Table 9. Race or ethnicity among sheriffs, intermediate supervisors, and first-line supervisors in sheriffs� offices, by size of office, 2016
so16pt10.csv		Table 10. Full-time personnel in sheriffs� offices who were bilingual or multilingual, by size of office, 2016
so16pt11.csv		Table 11. Percent of sheriffs� offices with personnel designated to address specific crime-related issues, by size of office, 2016
so16pt12.csv		Table 12. Percent of sheriffs� offices with personnel designated to functional areas, by size of office, 2016
so16pt13.csv		Table 13. Full-time school resource officers in sheriffs� offices, by size of office, 2016
so16pt14.csv		Table 14. Base weights, non-response adjustments, and final weights for sheriffs� offices, by strata, 2016
so16pt15.csv		Table 15. Law Enforcement Management and Administrative Statistics survey response rates for sheriffs� offices, by size of agency, 2016
		
			Figures
so16pf01.csv		Figure 1. Full-time employees in sheriffs� offices, 1997-2016
so16pf02.csv		Figure 2. Percent of full-time sworn personnel in sheriffs� offices who were female, 1997-2016
		
			Appendix tables
so16pat01.csv		Appendix table 1. Fifty largest sheriffs� offices in the U.S., by number of full-time sworn personnel, 2016
so16pat02.csv		Appendix table 2. Standard errors for figure 1 and table 1: Full-time employees in sheriffs� offices, 1997-2016
so16pat03.csv		Appendix table 3. Standard errors for table 2: Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2016
so16pat04.csv		Appendix table 4. Standard errors for table 3: Sheriffs� offices and full-time employees, by size of office, 2016
so16pat05.csv		Appendix table 5. Standard errors for table 4: Sex of full-time sworn personnel in sheriffs� offices, by size of office, 2016
so16pat06.csv		Appendix table 6. Estimates and standard errors for figure 2: Percent of full-time sworn personnel in sheriffs� offices who were female, 1997-2016
so16pat07.csv		Appendix table 7. Standard errors for table 5: Race or ethnicity of full-time sworn personnel in sheriffs� offices, by size of office, 2016
so16pat08.csv		Appendix table 8. Standard errors for table 6: Race or ethnicity among full-time sworn personnel in sheriffs� offices, 1997-2016
so16pat09.csv		Appendix table 9. Standard errors for table 7: Sex and race or ethnicity of full-time sworn personnel in sheriffs� offices, by size of office, 2016
so16pat10.csv		Appendix table 10. Standard errors for table 8: Percent of sheriffs, intermediate supervisors, and first-line supervisors in sheriffs� offices who were female, by size of office, 2016
so16pat11.csv		Appendix table 11. Standard errors for table 9: Race or ethnicity among sheriffs, intermediate supervisors, and first-line supervisors in sheriffs� offices, by size of office, 2016
so16pat12.csv		Appendix table 12. Standard errors for table 10: Full-time personnel in sheriffs� offices who were bilingual or multilingual, by size of office, 2016
so16pat13.csv		Appendix table 13. Standard errors for table 11: Percent of sheriffs� offices with personnel designated to address specific crime-related issues, by size of office, 2016
so16pat14.csv		Appendix table 14. Standard errors for table 12: Percent of sheriffs� offices with personnel designated to functional areas, by size of office, 2016
so16pat15.csv		Appendix table 15. Standard errors for table 13: Full-time school resource officers in sheriffs� offices, by size of office, 2016
