Federal Prisoner Statistics Collected under the First Step Act, 2021  NCJ 301582	
	
This zip archive contains tables in individual .csv spreadsheets for	
Federal Prisoner Statistics Collected under the First Step Act, 2021  NCJ 301582	
The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/federal-prisoner-statistics-collected-under-first-step-act-2021	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Prisoner%20Statistics%20Collected%20under%20the%20First%20Step%20Act	
	
Filename		Table names
fpscfsa21t01.csv	Table 1. Selected characteristics of federal prisoners, 2018–2020
fpscfsa21t02.csv	Table 2. Medical conditions, testing, and treatment of federal prisoners, 2018–2020
fpscfsa21t03.csv	Table 3. Selected characteristics of federal facilities, 2018–2020
fpscfsa21t04.csv	Table 4. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by security level of facility, 2020
fpscfsa21t05.csv	Table 5. Federal prisoners who were cited for prohibited acts that resulted in reductions in rewards, incentives, or time credits, by demographic characteristics, 2018–2020
fpscfsa21t06.csv	Table 6. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by facility, 2020
fpscfsa21t07.csv	Table 7. Prisoner assaults on Federal Bureau of Prisons staff, by type of assault and prosecution status, 2020
fpscfsa21t08.csv	Table 8. Volunteer levels in Federal Bureau of Prisons facilities, by facility, December 30, 2020
fpscfsa21t09.csv	Table 9. Recidivism reduction partnerships in Federal Bureau of Prisons facilities, by facility, 2020
fpscfsa21t10.csv	Table 10. Recidivism risk classification of persons in federal prison, by demographic and sentence characteristics, 2020
fpscfsa21t11.csv	Table 11. Approved evidence-based recidivism reduction programs and productive activities, by facility availability and prisoner needs met, 2020

*Not included in report
fpscfsa21t12.csv	Table 12. Enrollment and completion of evidence-based recidivism reduction programs and productive activities, by BOP facility, program or activity, and recidivism risk level, 2020
