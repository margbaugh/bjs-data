					
Tort Bench and Jury Trials in State Courts, 2005					
					
This zip archive contains tables in individual .csv spreadsheets from Tort Bench and Jury Trials in State Courts, 2005, NCJ 228129.					
The full report including text and graphics in pdf format is available at http://www.ojp.usdoj.gov/bjs/abstract/tbjtsc05.htm					
					
This report is an expansion of a series. See also Civil Jury and Bench Trials in State Courts, 2005					
at http://www.ojp.usdoj.gov/bjs/abstract/cbjtsc05.htm					
					
Filename		Table title				
tbjtsc05t01.csv		Table 1. Tort cases disposed of by bench or jury trial in state courts, by case type, 2005				
tbjtsc05t02.csv		Table 2. Pairings of primary litigants in tort trials in state courts, by case type, 2005				
tbjtsc05t03.csv		Table 3. Defective products in product liability trials in state courts, 2005				
tbjtsc05t04.csv		Table 4. Percent of tort trials with plaintiff winners in state courts, by case and trial type, 2005				
tbjtsc05t05.csv		Table 5. Plaintiff award winners in tort trials in state courts, by case and trial type, 2005				
tbjtsc05t06.csv		Table 6. Punitive damages sought and awarded in tort trials with plaintiff winners in state courts, by case and trial type, 2005				
tbjtsc05t07.csv		Table 7. Plaintiff winners with awards reduced due to contributory or comparative negligence in tort trials in state courts, by case type, 2005				
tbjtsc05t08.csv		Table 8. Case processing time in months from filing to verdict or judgment in tort trials in state courts, by case and trial type, 2005				
tbjtsc05t09.csv		Table 9. Post-trial relief sought by plaintiffs or defendants in tort trials in state courts, 2005				
tbjtsc05t10.csv		Table 10. Post-trial relief granted to plaintiffs or defendants in tort trials in state courts, 2005				
tbjtsc05t11.csv		Table 11. Notices of appeal filed by plaintiffs or defendants in tort trials in state courts, by case type and trial outcome, 2005				
tbjtsc05t12.csv		Table 12. Comparing tort trials in state courts in the nation's 75 most populous counties, by selected case types, 1996, 2001, 2005				
tbjtsc05t13.csv		Table 13. Percent of all tort cases disposed of by trial, by selected case types and jurisdictions, 2005				
					
Filename		Figure title				
tbjtsc05f01.csv		Figure 1. Types of tort cases concluded by trial, 2005				
tbjtsc05f02.csv		Figure 2. Punitive damages accounted for nearly 10% of the total awards to plaintiff winners in tort trials				
tbjtsc05f03.csv		Figure 3. Average duration of tort bench and jury trials in state courts, 2005				
					
Filename		Appendix table title				
tbjtsc05at01.csv	Appendix table 1. Standard errors and confidence intervals for tort trials, by selected characteristics, 2005 Civil Justice Survey of State Courts				
tbjtsc05at02.csv	Appendix table 2.  Pairings of primary litigants in tort trials in state courts, by case type, 2005				
tbjtsc05at03.csv	Appendix table 3.  Types of tort trials in state courts in 46 of the nation's 75 most populous counties, by jurisdiction, 2005				
tbjtsc05at04.csv	Appendix table 4.  Percentage of plaintiff winners in tort trials in state courts in 46 of the nation's 75 most populous counties, by jurisdiction, 2005				
tbjtsc05at05.csv	Appendix table 5.  Final damage awards for plaintiff winners in tort trials in state courts in 46 of the nation's 75 most populous counties, by jurisdiction, 2005				
