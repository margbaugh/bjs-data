LAW ENFORCEMENT TRAINING ACADEMIES, 2002 NCJ 204030																	

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .csv spreadsheets from the
BJS report, "State and Local Law Enforcement Training Academies, 2002" NCJ 204030. 
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/slleta02.htm 
----------------------------------------------------------------------------
																	
Filename		Table																
																	
slleta02h1.csv	Highlights Figure 1. Female and minority academy graduates, 2002
slleta02h2.csv	Highlights Figure 2. Basic instruction related to terrorism and responding to terrorist incidents, 2002

slleta0201.csv	Table 1. Law enforcement training academies and personnel, by number of full-time equivalent training personnel, 2002	
slleta0202.csv	Table 2. Employment by law enforcement training academies in the United States, by type of academy, 2002
slleta0203.csv	Table 3. Minimum education requirement for instructors, by number of full-time equivalent training personnel, 2002
slleta0204.csv	Table 4. Minimum years of law enforcement experience required for instructors, by number of full-time equivalent training personnel, 2002
slleta0205.csv	Table 5. Academies providing refresher training for instructors, by number of full-time equivalent training personnel, 2002
slleta0206.csv	Table 6. Methods used for evaluating performance of instructos, by number of full-time equivalent training personnel, 2002
slleta0207.csv	Table 7. Training academy expenditures, by number of full-time equivalent training personnel, FY 2002
slleta0208.csv	Table 8. Training academy facilities, 2002
slleta0209.csv	Table 9. Average number of basic recruit classes and class size, by number of FTE training personnel, 2002
slleta0210.csv	Table 10. Number of basic recruits starting and completing training, by number of FTE training personnel, among academy classes that completed training during 2002
slleta0211.csv	Table 11. Number of basic recruits starting and completing training, by type of academy, among all academy classes that completed training during 2002
slleta0212.csv	Table 12. Race and gender distributions for recruits who started and completed training, among academy classes that completed training during 2002
slleta0213.csv	Table 13. Average number of in-service trainees, by number of FTE training personnel, 2002
slleta0214.csv	Table 14. Duration of basic recruit training, by number of full-time equivalent training personnel, 2002
slleta0215.csv	Table 15. Field training programs and duration, by number of full-time equivalent training personnel, 2002
slleta0216.csv	Table 16. Academies providing basic instruction on various topics, and number of hours of instruction required, 2002
slleta0217.csv	Table 17. College credit for basic and in-service training, by type of academy, 2002
slleta0218.csv	Table 18. Training evnvironment in law enforcement academies, by type of academy, 2002
slleta0219.csv	Table 19. Basic firearms training, by type of academy, 2002
slleta0220.csv	Table 20. Basic firearms training conditions, by number of full-time equivalent training personnel, 2002
slleta0221.csv	Table 21. Types of community policing training for basic recruits provided by a majority of training academies, by number of full-time equivalent training personnel, 2002
slleta0222.csv	Table 22. Types of community policing training for basic recruits provided by less than one-half of training academies, by number of full-time equivalent training personnel, 2002
slleta0223.csv	Table 23. Changes to basic curriculum since January 2000 related to community policing, by number of full-time equivalent training personnel, 2002
slleta0224.csv	Table 24. Terrorism realted training (other than in basic training), by number of full-time equivalent training personnel, 2002 
slleta0225.csv	Table 25. Training or orientation for families of recruits, by number of full-time equivalent training personnel, 2002
slleta0226.csv	Table 26. Special patrol operations training, by number of full-time equivalent training personnel, 2002
slleta0227.csv	Table 27. Other special training, by number of full-time equivalent training personnel, 2002
slleta0228.csv	Table 28. Training on court security and airport security, by number of FTE training personnel, 2002

slleta02f1.csv	Figure 1. Types of training provided by academies, in addition to basic recruit training, 2002
slleta02f2.csv	Figure 2. Positions for which academies provided training and/or certification, 2002
slleta02f3.csv	Figure 3. Certifications required of full-time trainers or instructors, 2002
slleta02f4.csv	Figure 4. Methods used to develop content of refresher training for academy training personnel, 2002
slleta02f5.csv	Figure 5. Sources of training funds or equipment, 2002
slleta02f6.csv	Figure 6. Percent of recruits completing training, by race and gender, 2002
slleta02f7.csv	Figure 7. Methods used to develop content of basic recruit training curriculum, 2002
slleta02f8.csv	Figure 8. Tests used to evaluate recruits in basic training program, 2002
slleta02f9.csv	Figure 9. Training environment in law enforcement academies, 2002
slleta02f10.csv	Figure 10. Disciplinary actions that may be taken in response to violations of academy disciplinary code or code of conduct, 2002
slleta02f11.csv	Figure 11. Basic defensive weapons training, 2002
slleta02f12.csv	Figure 12. Basic control/defensive tactics training, 2002
slleta02f13.csv	Figure 13. Percent of academies using reality-based (mock) scenario training instruction
slleta02f14.csv	Figure 14. Percent of academies providing in-service training on community policing topics, 2002
slleta02f15.csv	Figure 15. Training methods related to community policing, 2002
slleta02f16.csv	Figure 16. Community involvement in academy training, 2002
slleta02f17.csv	Figure 17. Basic instruction related to terrorism and responding to terrorist incidents, 2002
slleta02f18.csv	Figure 18. Training related to 'racially-biased policing', by methods of instruction, 2002
slleta02f19.csv	Figure 19. Training related to disengagement techniques, by methods of instruction, 2002

slleta02t1.csv	Text Table 1. Number of academies, by type of academy, 2002
slleta02t2.csv	Text Table 2. Type of academy, by number of FTE training personnel, 2002
slleta02t3.csv	Text Table 3. Academy expenditures, by type of academy, FY 2002
slleta02t4.csv	Text Table 4. Percent of academies using field-training evaluation methods, 2002
slleta02t5.csv	Text Table 5. Percent of academies using a mock use of force review board, by number of FTE training personnel, 2002
slleta02t6.csv	Text Table 6. Academies providing training on response to excessive force, by number of FTE training personnel, 2002
slleta02t7.csv	Text Table 7. Academies providing training on response to mnisconduct, by number of FTE training personnel, 2002