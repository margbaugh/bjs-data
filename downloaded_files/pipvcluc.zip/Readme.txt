Profile of Intimate Partner Violence Cases in Large Urban Counties,  NCJ 228193


This zip archive contains tables in individual .csv spreadsheets from Profile of Intimate Partner Violence Cases in Large Urban Counties,  NCJ 228193.  
This full report including text and graphics in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/pipvcluc.htm.



Tables

pipvcluct01.csv   Table 1. Demographic characteristics of intimate partner violence victims and defendants in 16 large counties, May 2002
pipvcluct02.csv	  Table 2. Most serious charges filed against intimate partner violence defendants in 16 large counties, by charge type, May 2002
pipvcluct03.csv	  Table 3. Location of incident in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct04.csv	  Table 4. Alcohol and drug use among defendants in intimate partner violence  cases in 16 large counties, by charge type, May 2002
pipvcluct05.csv	  Table 5. Weapon use among defendants in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct06.csv	  Table 6. Most severe injury to victim in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct07.csv	  Table 7. Witness to the incident in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct08.csv	  Table 8. Children present during the incident in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct09.csv	  Table 9. Evidence obtained in intimate partner violence cases in 16 large counties by charge type, May 2002
pipvcluct10.csv	  Table 10. History and reporting of prior violence between victim and defendant in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct11.csv	  Table 11. Adjudication outcome in intimate partner violence cases in 16 large counties, by charge type, May 2002
pipvcluct12.csv	  Table 12. Most severe sentence imposed on convicted defendants in 16 large counties, by conviction charge, May 2002
pipvcluct13.csv	  Table 13. Characteristics of intimate partner violence cases in 16 large counties, by adjudication outcome, May 2002
pipvcluct14.csv	  Table 14. Logistic regression analysis of the effect of case characteristics on the probability of conviction in intimate partner violence cases in 16 large counties, May 2002
pipvcluct15.csv	  Table 15. Incident characteristics of intimate partner violence cases in 16 large counties, by defendant and victim gender, May 2002
pipvcluct16.csv	  Table 16. Case processing characteristics of intimate partner violence cases in 16 large counties, by defendant and victim gender, May 2002
pipvcluct17.csv	  Table 17. Adjudication outcome in intimate partner violence cases in 16 large counties, by prosecutor screening practice, May 2002


Appendix tables

pipvclucat01.csv  Appendix Table 1. Relationship of victim to defendant in domestic violence cases in 16 large counties, by charge type, May 2002
pipvclucat02.csv  Appendix Table 2. Number of defendants in intimate partner violence cases in 16 large counties, by county, state, and charge type, May 2002

