Arrest in the United States, 1980-2009  NCJ 234319		
		
This zip archive contains tables in individual  .csv spreadsheets		
from CArrest in the United States, 1980-2009  NCJ 234319.  The full report including text		
and graphics in pdf format is available at: /index.cfm?ty=pbdetail&iid=2203		
		
Filename		Table titles
aus8009t01.csv		Table 1. Arrest in the Unites States, by sex, age group, and race, 2009
aus8009t02.csv		Table 2. Characteristics of annual reporting samples, 1980�2009
aus8009t03.csv		Table 3. Estimated arrests, by age, 2009
aus8009t04.csv		Table 4. Estimated male arrests, by age, 2009
aus8009t05.csv		Table 5. Estimated female arrests, by age, 2009
aus8009t06.csv		Table 6. Estimated arrests, by race and age, 2009
		
		
			Figures	Title
aus8009f01.csv		Figure 1. Murder arrest rates
aus8009f02.csv		Figure 2. Murder arrest rates, by sex
aus8009f03.csv		Figure 3. Murder arrest rates, by age group
aus8009f04.csv		Figure 4. Murder arrest rates, by race
aus8009f05.csv		Figure 5. Forcible rape arrest rates
aus8009f06.csv		Figure 6. Forcible rape arrest rates, by age group
aus8009f07.csv		Figure 7. Forcible rape arrest rates, by race
aus8009f08.csv		Figure 8. Forcible rape arrest rates, by race and age group
aus8009f09.csv		Figure 9. Robbery arrest rates
aus8009f10.csv		Figure 10. Robbery arrest rates, by sex
aus8009f11.csv		Figure 11. Robbery arrest rates, by age group
aus8009f12.csv		Figure 12. Robbery arrest rates, by race
aus8009f13.csv		Figure 13. Aggravated assault arrest rates
aus8009f14.csv		Figure 14. Aggravated assault arrest rates, by sex
aus8009f15.csv		Figure 15. Aggravated assault arrest rates, by age group
aus8009f16.csv		Figure 16. Aggravated assault arrest rates, by race
aus8009f17.csv		Figure 17. Simple assault arrest rates
aus8009f18.csv		Figure 18. Simple assault arrest rates, by sex
aus8009f19.csv		Figure 19. Simple assault arrest rates, by age group
aus8009f20.csv		Figure 20. Simple assault arrest rates, by race
aus8009f21.csv		Figure 21. Burglary arrest rates
aus8009f22.csv		Figure 22. Burglary arrest rates, by sex
aus8009f23.csv		Figure 23. Burglary arrest rates, by age group
aus8009f24.csv		Figure 24. Burglary arrest rates, by race
aus8009f25.csv		Figure 25. Larceny-theft arrest rates
aus8009f26.csv		Figure 26. Larceny-theft arrest rates, by sex
aus8009f27.csv		Figure 27. Larceny-theft arrest rates, by age group
aus8009f28.csv		Figure 28. Larceny-theft arrest rates, by race
aus8009f29.csv		Figure 29. Motor vehicle theft arrest rates
aus8009f30.csv		Figure 30. Motor vehicle theft arrest rates, by sex
aus8009f31.csv		Figure 31. Motor vehicle theft arrest rates, by age group
aus8009f32.csv		Figure 32. Motor vehicle theft arrest rates, by race
aus8009f33.csv		Figure 33. Weapon law violations arrest rates
aus8009f34.csv		Figure 34. Weapon law violations arrest rates, by sex
aus8009f35.csv		Figure 35. Weapon law violations arrest rates, by age group
aus8009f36.csv		Figure 36. Weapon law violations arrest rates, by race
aus8009f37.csv		Figure 37. Drug possession/use arrest rates
aus8009f38.csv		Figure 38. Drug possession/use arrest rates, by sex
aus8009f39.csv		Figure 39. Drug possession/use arrest rates, by age group
aus8009f40.csv		Figure 40. Drug possession/use arrest rates, by race
aus8009f41.csv		Figure 41. Drug sale/manufacture arrest rates
aus8009f42.csv		Figure 42. Drug sale/manufacture arrest rates, by sex
aus8009f43.csv		Figure 43. Drug sale/manufacture arrest rates, by age group
aus8009f44.csv		Figure 44. Drug sale/manufacture arrest rates, by race
