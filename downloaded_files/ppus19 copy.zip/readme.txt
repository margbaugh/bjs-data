Probation and Parole in the United States, 2019 NCJ 256092									
									
This zip archive contains tables in individual .csv spreadsheets from									
Probation and Parole in the United States, 2019 NCJ 256092.  The full report including text									
and graphics in pdf format is available from https://bjs.ojp.gov/library/publications/probation-and-parole-united-states-2019
									
This report is one in a series.  More recent editions may be available.				
To view a list of all in the series go to 								
https://bjs.ojp.gov/library/publications/list?series_filter=Probation%20and%20Parole%20Populations									
									
Filename	Table titles								
ppus19t01.csv	Table 1. Adults under community supervision, 2000-2019								
ppus19t02.csv	Table 2. Changes in probation populations, by jurisdiction, 2019								
ppus19t03.csv	Table 3. Changes in parole populations, by jurisdiction, 2019								
ppus19t04.csv	Table 4. Community supervision rates of adult U.S. residents, 2000, 2005, and 2010-2019								
ppus19t05.csv	Table 5. Exits from probation, by type of exit, 2000-2019								
ppus19t06.csv	Table 6. Exits from parole, by type of exit, 2000-2019								
ppus19t07.csv	Table 7. Parolees also on probation excluded from the January 1 and December 31 community supervision populations, 2007-2019				
ppus19t08.csv	Table 8. One-day difference based on reporting changes for probation and parole, 2008-2019								
									
		Figures								
ppus19f01.csv	Figure 1. Adults on probation or parole, 2000-2019								
ppus19f02.csv	Figure 2. Annual percent change of adults on probation, 2000-2019								
ppus19f03.csv	Figure 3. Annual percent change of adults on parole, 2000-2019								
ppus19f04.csv	Figure 4. Estimated total probation movements, entries, and exits, 2000-2019								
ppus19f05.csv	Figure 5. Estimated total parole movements, entries, and exits, 2000-2019								
ppus19f06.csv	Figure 6. Response rate for Annual Probation Survey, by month, 2018-2019								
									
		Appendix tables								
ppus19at01.csv	Appendix Table 1. Estimates for figure 2: Annual percent change of adults on probation, 2000-2019
ppus19at02.csv	Appendix Table 2. Estimates for figure 3: Annual percent change of adults on parole, 2000-2019								
ppus19at03.csv	Appendix Tabe 3. Estimates for figure 4: Estimated total probation movements, entries, and exits, 2000-2019
ppus19at04.csv	Appendix Table 4. Estimates for figure 5: Estimated total parole movements, entries, and exits, 2000-2019
ppus19at05.csv	Appendix Table 5. Estimates for figure 6: Response rate for Annual Probation Survey, by month, 2018-2019
ppus19at06.csv	Appendix Table 6. Adults under community supervision, 2019								
ppus19at07.csv	Appendix Table 7. Adults on probation, 2019								
ppus19at08.csv	Appendix Table 8. Adults exiting probation, by type of exit, 2019								
ppus19at09.csv	Appendix Table 9. Characteristics of adults on probation, 2008 and 2019								
ppus19at10.csv	Appendix Table 10. Adults on parole, 2019								
ppus19at11.csv	Appendix Table 11. Adults entering parole, by type of entry, 2019								
ppus19at12.csv	Appendix Table 12. Adults exiting parole, by type of exit, 2019								
ppus19at10.csv	Appendix Table 13. Characteristics of adults on parole, 2008 and 2019	