Criminal Victimization, 2008     NCJ  227777			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization,  2008,   NCJ  227777.  The full report including text			
and graphics in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/cv08.htm			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#ncvs			
			
			
Filename			Table title
cv08t01.csv			Table 1. Criminal victimization, numbers, rates, and percent change, by type of crime, 2007 and 2008
cv08t02.csv			Table 2. Rates of criminal victimization and percent change, by type of crime, 1999 and 2008
cv08t03.csv			Table 3. National crime victimization rates and percent change in rates, by type of crime, 2005-2008
cv08t04.csv			Table 4. Rates of violent crime, by gender, race, Hispanic origin, and age of victim, 2008
cv08t05.csv			Table 5. Property crime rates, by household income and household size, 2008
cv08t06.csv			Table 6. Relationship between victim and offender, by gender of victim, 2008
cv08t07.csv			Table 7. Presence of weapons in violent incidents, by type, 2008
cv08t08.csv			Table 8. Crimes reported to the police, by gender, race, and Hispanic origin, 2008 
			
Figures			
cv08f01.csv			Figure 1. Violent crime rates overall fell by 41% from 1999 to 2008
cv08f02.csv			Figure 2. Property crime rates overall fell by 32% from 1998 to 2008
cv08f03.csv			Figure 3. Violent and property crime reported to the police
			
Text tables			
cv08tt01.csv			Text table 1. Percent changes in the numer of crimes reported in the UCR, 2007-2008
cv08tt02.csv			Text table 2. Number and rate of intimate partner violence, by victims' gender, 2007 and 2008
cv08tt03.csv			Text table 3. Firearm use in violent crime, 1999 and 2008
cv08tt04.csv			Text table 4. Percent of crimes reported to police, 2008
