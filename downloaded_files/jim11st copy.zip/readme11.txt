Jail Inmates at Midyear 2011-Statistical Tables  NCJ 237961	
	
This zip archive contains tables in individual .csv spreadsheets	
Jail Inmates at Midyear 2011-Statistical Tables  NCJ 237961	
The full report including text and graphics in .pdf format are available from:	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4235
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the 
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=38
 	
Tables	
jim11stt01.csv	Table 1: Inmates confined in local jails at midyear, average daily population, and incarceration rates, 2000�2011
jim11stt02.csv	Table 2: Rated capacity of local jails and percent of capacity occupied, 2000�2011
jim11stt03.csv	Table 3: Inmates confined in local jails at midyear, by size of jurisdiction, 2010 and 2011
jim11stt04.csv	Table 4: Average daily jail population, admissions, and turnover rate, by size of jurisdiction, week ending June 30, 2010 and 2011
jim11stt05.csv	Table 5: Percent of jail capacity occupied at midyear, by size of jurisdiction, 2010 and 2011
jim11stt06.csv	Table 6: Number of inmates in local jails, by characteristic, midyear 2000 and 2005�2011
jim11stt07.csv	Table 7: Percent of inmates in local jails, by characteristic, midyear 2000 and 2005�2011
jim11stt08.csv	Table 8: Inmate population in jail jurisdictions reporting on confined persons being held for U.S. Immigration and Customs Enforcement, midyear 2002�2011
jim11stt09.csv	Table 9: Persons under jail supervision, by confinement status and type of program, midyear 2000 and 2006�2011
jim11stt10.csv	Table 10: Estimated standard errors, by confinement status, 2011
jim11stt11.csv	Table 11: Estimated standard errors, by selected characteristic, 2011
jim11stt12.csv	Table 12: Estimated percentages of local jail inmates, by selected characteristic and ratio estimates, 2011
	
Figures	
jim11stf01.csv	Figure 1: Inmates confined in local jails at midyear and change in the jail population, 2000�2011
jim11stf02.csv	Figure 2: Annual counts of the midyear custody population, average daily population, and rated capacity in local jails, 2000�2011
jim11stf03.csv	Figure 3: Percent change in the midyear custody population and rated capacity between 2008 and 2011
