State Court Organization, 2004  NCJ 212351

This zip archive contains tables in individual .csv spreadsheets from State Court Organization, 2004, NCJ 212351. The full report including text and graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/sco04.htm

This report is one in a series. More recent editions may be available. To view a list of all in the series go to http://www.ojp.usdoj.gov/bjs/pubalp2.htm#sc

sco04t01.csv	Table: 1	Appellate Courts in the United States	
sco04t02.csv	Table: 2	Number of Appellate Court Judges
sco04t03.csv	Table: 3	Trial Courts and Trial Court Judges of the United States
sco04t04.csv	Table: 4	Selection of Appellate Court Judges
sco04t05.csv	Table: 5	Qualifications to Serve as an Appellate Court Judge
sco04t06.csv	Table: 6	Selection of Trial Court Judges
sco04t07.csv	Table: 7	Qualifications to Serve as a Trial Court Judge
sco04t08.csv	Table: 8	Judicial Nominating Commissions
sco04t09.csv	Table: 9	Provisions for Mandatory Judicial Education
sco04t10.csv	Table: 10	Judicial Performance Evaluation
sco04t11.csv	Table: 11	Judicial Discipline: Investigating and Adjudicating Bodies
sco04t12.csv	Table: 12	Governance of the Judicial Branch
sco04t13.csv	Table: 13	The Source of Rule Making Authority of Courts of Last Resort by Specific Areas
sco04t14.csv	Table: 14	Judicial Councils and Conferences
sco04t15.csv	Table: 15	Judicial Compensation Commissions
sco04t16.csv	Table: 16	Preparation and Submission of the Judicial Branch Budget for State Funding
sco04t17.csv	Table: 17	Trial Court Expenditures and Funding Sources for Selected Expenditure Items
sco04t18.csv	Table: 18	Appellate Court Clerks� Office: Staffing and Responsibilities by Function
sco04t19.csv	Table: 19	Clerks of Appellate Courts: Number and Method of Selection
sco04t20.csv	Table: 20	Provision of Law Clerks to Appellate Court Judges
sco04t21.csv	Table: 21	Administrative Office of the Courts: Staffing and Responsibilities for Trial Court Functions
sco04t22.csv	Table: 22	Mandatory and Discretionary Jurisdiction of Appellate Courts
sco04t23.csv	Table: 23	The Structure of Appellate Court Panels
sco04t24.csv	Table: 24	Reviewing Discretionary Petitions
sco04t25.csv	Table: 25	Expediting Procedures in Appellate Courts
sco04t26.csv	Table: 26	Limitations on Oral Arguments in Appellate Courts
sco04t27.csv	Table: 27	Type of Court Hearing Administrative Agency Appeals
sco04t28.csv	Table: 28	Presiding Judges: Authority and Responsibilities
sco04t29.csv	Table: 29	Selection and Number of Trial Court Clerks and Trial Court Administrators
sco04t30.csv	Table: 30	Clerk of Court and Trial Court Administrator Responsibilities by Selected Function
sco04t31.csv	Table: 31	Specialized Jurisdiction: Problem Solving Courts
sco04t32.csv	Table: 32	Specialized Court Jurisdiction: Family Courts
sco04t33.csv	Table: 33	Tribal Courts
sco04t34.csv	Table: 34	Cameras and Audio Coverage in the Courtroom
sco04t35.csv	Table: 35	The Defense of Insanity: Standards and Procedures
sco04t36.csv	Table: 36	DNA Evidence: Post-Conviction Analysis
sco04t37.csv	Table: 37	Making the Trial Record
sco04t38.csv	Table: 38	Grand Juries: Composition and Function
sco04t39.csv	Table: 39	Trial Juries: Qualifications and Source Lists for Juror Service
sco04t40.csv	Table: 40	Trial Juries: Exemptions, Excusals, and Fees
sco04t41.csv	Table: 41	Trial Juries: The Allocation of Peremptory Challenges
sco04t42.csv	Table: 42	Trial Juries: Size and Verdict Rules
sco04t43.csv	Table: 43	Sentencing Statutes: Key Definitions and Provisions for Sentence Enhancement
sco04t44.csv	Table: 44	Jurisdiction for Adjudication and Sentencing of Felony Cases
sco04t45.csv	Table: 45	Sentencing Procedures in Capital and Non-Capital Felony Cases
sco04t46.csv	Table: 46	Active Sentencing Commissions/Sentencing Guideline Systems
sco04t47.csv	Table: 47	Collateral Consequences of a Felony Conviction