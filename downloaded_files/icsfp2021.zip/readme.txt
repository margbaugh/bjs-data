Impact of COVID-19 on State and Federal Prisons, March 2020–February 2021 NCJ 304500						
						
This zip archive contains tables in individual .csv spreadsheets						
from Impact of COVID-19 on State and Federal Prisons, March 2020–February 2021 NCJ 304500. 						
The full report including text and graphics in pdf format is available from: 
https://bjs.ojp.gov/library/publications/impact-covid-19-state-and-federal-prisons-march-2020-february-2021
						
						
Filenames		Table titles
icsfp2021t01.csv	Table 1. Persons in the custody of state and federal prisons, by jurisdiction, February 29, 2020, August 31, 2020, and February 28, 2021
icsfp2021t02.csv	Table 2. Admissions to the custody of state and federal prisons, by jurisdiction, January 1, 2020–February 28, 2021
icsfp2021t03.csv	Table 3. Releases from the custody of state and federal prisons, by jurisdiction, January 1, 2020–February 28, 2021
icsfp2021t04.csv	Table 4. Number of jurisdictions that adopted criteria for expedited release due to the COVID-19 pandemic, January 2020–February 2021
icsfp2021t05.csv	Table 5. Number of COVID-19 tests and test positivity rate among persons in the custody of state and federal prisons, by jurisdiction, March 1, 2020–February 28, 2021					
icsfp2021t06.csv	Table 6. Number of jurisdictions that adopted tactics to mitigate COVID-19 transmission in state and federal prisons, by tactic, March 1, 2020–February 28, 2021					
icsfp2021t07.csv	Table 7. COVID-19 infection rate among persons in the custody of state and federal prisons, by jurisdiction, March 1, 2020–February 28, 2021					
icsfp2021t08.csv	Table 8. COVID-19 infections among persons in the custody of state and federal prisons, by demographic characteristics, March 1, 2020–February 28, 2021					
icsfp2021t09.csv	Table 9. Number of COVID-19-related deaths and crude mortality rate among persons in the custody of state and federal prisons, by sex and jurisdiction, March 1, 2020–February 28, 2021					
icsfp2021t10.csv	Table 10. COVID-19-related deaths of persons in the custody of state and federal prisons, by demographic characteristics, March 1, 2020–February 28, 2021					
icsfp2021t11.csv	Table 11. COVID-19 vaccine availability and administration to staff and persons in the custody of state and federal prisons, by jurisdiction, through February 28, 2021					
icsfp2021t12.csv	Table 12. Number of jurisdictions that adopted COVID-19 vaccine distribution policies, through February 28, 2021
icsfp2021t13.csv	Table 13. Number of COVID-19 infections, test positivity rate, number of COVID-19-related deaths, and crude mortality rate among correctional staff in state and federal prisons, by jurisdiction, March 1, 2020–February 28, 2021					
						
			Figures					
icsfp2021f01.csv	Figure 1. Percent of COVID-19 infections and deaths and 2020 yearend population of persons in the custody of state and federal prisons, by race or ethnicity, March 1, 2020–February 28, 2021					
icsfp2021f02.csv	Figure 2. Mean number of persons admitted to state prisons in 37 states, by offense type, January 2018–December 2020
icsfp2021f3a-e.csv	Figure 3a-e. Number of persons admitted to state prisons in five states, by offense type, January 2018–December 2020
icsfp2021f04.csv	Figure 4. Mean number of persons in the custody of state prisons in 37 states, by offense type, month-end January 2018–December 2020
icsfp2021f05.csv	Figure 5. Mean number of persons released from state prisons in 37 states, by offense type, January 2018–December 2020	
						
			Appendix tables					
icsfp2021at01.csv	Appendix table 1. Number of persons in the custody of and admissions to state and federal prisons, January 2020–February 2021 
icsfp2021at02.csv	Appendix table 2. Criteria for expedited release due to the COVID-19 pandemic, by jurisdiction, January 2020–February 2021
icsfp2021at03.csv	Appendix table 3. Estimates for figure 2: Mean number of persons admitted to state prisons in 37 states, by offense type, January 2018–December 2020					
icsfp2021at04.csv	Appendix table 4. Estimates for figures 3a–e: Number of persons admitted to state prisons in five states, by offense type, January 2018–December 2020					
icsfp2021at05.csv	Appendix table 5. Estimates for figure 4: Mean number of persons in the custody of state prisons in 37 states, by offense type, month-end January 2018–December 2020					
icsfp2021at06.csv	Appendix table 6. Estimates for figure 5: Mean number of persons released from state prisons in 37 states, by offense type, January 2018–December 2020					
icsfp2021at07.csv	Appendix table 7. Tactics adopted to mitigate COVID-19 transmission in state and federal prisons, by jurisdiction, March 1, 2020–February 28, 2021					
icsfp2021at08.csv	Appendix table 8. Activities completely suspended to mitigate COVID-19 transmission in state and federal prisons, by jurisdiction, March 1, 2020–February 28, 2021					
icsfp2021at09.csv	Appendix table 9. Denominators for calculation of COVID-19 infection rates in state and federal prisons, by jurisdiction, March 1, 2020–February 28, 2021					
icsfp2021at10.csv	Appendix table 10. COVID-19 vaccine distribution policies that were adopted, by jurisdiction, through February 28, 2021	