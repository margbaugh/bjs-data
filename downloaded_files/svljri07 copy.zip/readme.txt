Sexual Victimization in Local Jails Reported by Inmates, 2007  NCJ 221946

This zip archive contains tables in individual .csv spreadsheets from "Sexual Victimization in Local Jails Reported by Inmates, 2007," NCJ 221946.  The full report including text and graphics in pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/svljri07.htm. 



Tables
svljri07t01.csv			Table 1. Local jail inmates reporting sexual victimization, National Inmate Survey, 2007
svljri07t02.csv			Table 2. Local jails with high rates of inmate sexual victimization, National Inmate Survey, 2007
svljri07t03.csv			Table 3. Local jails with no reported incidents of sexual victimization, National Inmate Survey, 2007
svljri07t04.csv			Table 4. Local jails with the highest rates of inmate sexual victimization, by type, National Inmate Survey, 2007
svljri07t05.csv			Table 5. Local jails with the highest rates of injury, National Inmate Survey, 2007
svljri07t06.csv			Table 6. Prevalence of inmate sexual victimization, by selected characteristics of jail facilities, National Inmate Survey, 2007
svljri07t07.csv			Table 7. Prevalance of inmate sexual victimization, by selected characteristics of jail inmates, National Inmate Survey, 2007
svljri07t08.csv			Table 8. Circumstances surrounding incidents of inmate sexual victimization in local jails, National Inmate Survey, 2007
svljri07t09.csv			Table 9. Sampled jail facilities excluded from the survey, National Inmate Survey, 2007

Text tables		
svljri07tt01.csv		Text table 1. Injuries reported by victims of sexual violence in local jails, National Inmate Survey, 2007
svljri07tt02.csv		Text table 2. Gender of staff and victims of staff sexual misconduct in local jails, National Inmate Survey, 2007

Appendix tables		
svljri07at01.csv		Appendix table 1. Characteristics of local jails selected in the National Inmate Survey, 2007
svljri07at02.csv		Appendix table 2. Percent of local jail inmates reporting sexual victimization and estimated standard error, by facility, National Inmate Survey, 2007
svljri07at03.csv		Appendix table 3. Percent of local jail inmates reporting nonconsensual sexual acts and abusive sexual contacts, by facility, National Inmate Survey, 2007
svljri07at04.csv		Appendix table 4. Percent of local jail inmates reporting sexual victimization, by type of incident and facility, National Inmate Survey, 2007
svljri07at05.csv		Appendix table 5. Percent of local jail inmates reporting nonconsensual sexual acts, by type of incident and facility, National Inmate Survey, 2007
svljri07at06.csv		Appendix table 6. Percent of local jail inmates reporting sexual victimization, by type of incident, level of coercion, and facility, National Inmate Survey, 2007
svljri07at07.csv		Appendix table 7. Survey items related to inmate-on-inmate sexual victimization, National Inmate Survey, 2007
svljri07at08.csv		Appendix table 8. Survey items related to staff sexual misconduct, National Inmate Survey, 2007
svljri07at09.csv		Appendix table 9. Follow-up questions for inmates reporting no sexual activity, National Inmate Survey, 2007
