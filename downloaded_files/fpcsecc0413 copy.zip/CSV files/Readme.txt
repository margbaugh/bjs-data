Federal Prosecution of Commercial Sexual Exploitation of Children Cases, 2004-2013  NCJ 250746			
			
This zip archive contains tables in individual .csv spreadsheets from 			
Federal Prosecution of Commercial Sexual Exploitation of Children Cases, 2004-2013			
from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6086	
	
			
Tables			Title
fpcsecc0413t01.csv			Table 1. Suspects referred to U.S. attorneys with commercial sexual exploitation of children offense as lead charge, 2004-2013
fpcsecc0413t02.csv			Table 2. Suspects in commercial sexual exploitation of children (lead charge) matters referred, by investigative agency, 2004-2013
fpcsecc0413t03.csv			Table 3. Suspects in commercial sexual exploitation of children matters concluded, by disposition of matter, 2004-2013
fpcsecc0413t04.csv			Table 4. Suspects in commercial sexual exploitation of children matters declined, by reason for declination, 2004-2013
fpcsecc0413t05.csv			Table 5. Characteristics of commercial sexual exploitation of children suspects at initial hearing, 2006-2013
fpcsecc0413t06.csv			Table 6. Defendants in commercial sexual exploitation of children cases released pretrial, by type of offense, 2006-2013
fpcsecc0413t07.csv			Table 7. Defendants in commercial sexual exploitation of children cases filed, by offense, 2004-2013
fpcsecc0413t08.csv			Table 8. Adjudication outcomes of defendants in commercial sexual exploitation of children cases, 2004-2013
fpcsecc0413t09.csv			Table 9. Type of sentence imposed for convicted defendants in commercial sexual exploitation of children cases, 2004-2013
fpcsecc0413t10.csv			Table 10. Mean and median prison sentence length imposed for defendants convicted in commercial sexual exploitation of children cases, 2004 and 2013
			
Figures			
fpcsecc0413f01.csv			Figure 1. Suspects in commercial sexual exploitation of children matters referred, and defendants in cases filed and convicted, 2004 and 2013
fpcsecc0413f02.csv			Figure 2. Suspects in commercial sexual exploitation of children matters referred, by offense type, 2004 and 2013 
fpcsecc0413f03.csv			Figure 3. Prosecution rate of suspects in commercial sexual exploitation of children matters concluded, 2004-2013
fpcsecc0413f04.csv			Figure 4. Defendants in commercial sexual exploitation of children cases filed, by offense, 2004-2013 
