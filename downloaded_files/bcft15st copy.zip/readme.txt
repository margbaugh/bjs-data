"Background Checks for Firearm Transfers, 2015 - Statistical Tables  NCJ 250978"			
			
This zip archive contains tables in individual .csv spreadsheets from 			
"Background Checks for Firearm Transfers, 2015 - Statistical Tables"			
from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6126		
This report is one in a series.  More recent editions may be available. 			
To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=13		
			
Tables			Title
bcft15st_t01.csv			"Table 1. Estimated number of firearm applications received and denied since the effective date of the Brady Act, 1994?2015"
bcft15st_t02.csv			"Table 2. irearm applications received and denied, by type of agency and type of check, 2015"
bcft15st_t03.csv			"Table 3. Firearm applications received and denied by state agency reporters, by type of check, 2015"
bcft15st_t04.csv			"Table 4. Firearm applications received and denied by local agencies, by type of permit and size of population served, 2015"
bcft15st_t05.csv			"Table 5. Percent of reasons for denial of firearm transfer and permit applications, by checking agencies, 2015"
bcft15st_t06.csv			"Table 6. Percent change in the number of applications, denials, and reasons for denial, 1999?2015"
bcft15st_t07.csv			"Table 7. Bureau of Alcohol, Tobacco, Firearms, and Explosives investigation of National Instant Criminal Background Check System denials by the FBI, 2015"
bcft15st_t08.csv			Table 8. Number of checking agencies in the 2015 Firearm Inquiry Statistics surve
			
Appendix Tables			
bcft15st_at01.csv			"Appendix table 1. Estimated standard errors for table 2: Firearm applications received and denied by local agencies, by type of check, 2015"
bcft15st_at02.csv			"Appendix table 2. Standard errors for table 4: Firearm applications received and denied by local agencies, by type of permit and size of population served, 2015"
bcft15st_at03.csv			"Appendix table 3. Firearm applications received and denied, by jurisdiction, 2015"
bcft15st_at04.csv			"Appendix table 4. Number of reasons for denial of firearm transfer and permit applications, by checking agencies, 2015"
bcft15st_at05.csv			"Appendix table 5. Prohibited person records in the National Instant Criminal Background Check System Index, 2015"
bcft15st_at06.csv			"Appendix table 6. Reasons for denial of firearm transfer and permit applications, December 31, 2015"
bcft15st_at07.csv			"Appendix table 7. Agencies conducting firearm background checks, December 31, 2015"
bcft15st_at08.csv			"Appendix table 8. National Instant Criminal Background Check System checking agencies, FBI, or state Point of Contact for firearm transfers, 2015"
bcft15st_at09.csv			"Appendix table 9. Forums for appeals of firearm transfer and permit denials, 2015"
