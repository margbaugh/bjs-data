Law Enforcement Agencies that Employ School Resource Officers, 2019   NCJ 305181		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Law Enforcement Agencies that Employ School Resource Officers, 2019   NCJ 305181.  		
The full report including text and graphics in pdf format is available from: 		
https://bjs.ojp.gov/library/publications/law-enforcement-agencies-employ-school-resource-officers-2019
		
Filenames		Table titles	
leaesro19t01.csv	Table 1. Law enforcement agencies with sworn SROs, by type of agency and size of SRO program, 2019	
leaesro19t02.csv	Table 2. Law enforcement agencies with nonsworn employees primarily assigned to public K–12 schools, by type of agency, 2019	
leaesro19t03.csv	Table 3. Sex of sworn SROs, by type of agency and size of SRO program, 2019	
leaesro19t04.csv	Table 4. Race or Hispanic origin of SROs, by type of agency and size of SRO program, 2019	
leaesro19t05.csv	Table 5. Funding sources for SRO programs, by type of agency and size of SRO program, 2019	
leaesro19t06.csv	Table 6. Type of SRO assignment, by type of agency and size of SRO program, 2019	
leaesro19t07.csv	Table 7. Percent of agencies that required SROs to perform selected law enforcement activities, by type of agency and size of SRO program, 2019	
leaesro19t08.csv	Table 8. Percent of agencies that required SROs to perform selected mentoring activities, by type of agency and size of SRO program, 2019	
leaesro19t09.csv	Table 9. Percent of agencies that required SROs to perform selected teaching activities, by type of agency and size of SRO program, 2019	
leaesro19t10.csv	Table 10. Actions requiring SROs to inform school executive staff, by type of agency and size of SRO program, 2019	
leaesro19t11.csv	Table 11. Direct or physical contact requiring SROs to inform school executive staff, by type of agency and size of SRO program, 2019	
leaesro19t12.csv	Table 12. Percent of agencies with procedural SRO program characteristics specified in internal policy or formal agreement with schools, by type of agency and size of SRO program, 2019	
leaesro19t13.csv	Table 13. Percent of agencies with administrative SRO program characteristics specified in internal policy or formal agreement with schools, by type of agency and size of SRO program, 2019	
leaesro19t14.csv	Table 14. SRO selection methods, by type of agency and size of SRO program, 2019	
leaesro19t15.csv	Table 15. Percent of agencies that required training on de-escalation and use of force, by type of agency, 2019	
leaesro19t16.csv	Table 16. Frequency of SRO supervisor visits, by type of agency and size of SRO program, 2019	
leaesro19t17.csv	Table 17. Percent of agencies with SROs allowed to carry selected equipment on campus, by issuance and type of agency, 2019	
leaesro19t18.csv	Table 18. LEA sample allocation	
		
			Figures	
leaesro19f01.csv	Figure 1. Number of personnel primarily assigned to public K–12 schools, by type of agency and sworn status, 2019	
leaesro19f02.csv	Figure 2. Age of SRO programs, by type of agency and size of SRO program, 2019	
leaesro19f03.csv	Figure 3. Allowance of SRO interviews of students without a parent present without first obtaining parental permission, by type of agency and size of SRO program, 2019	
leaesro19f04.csv	Figure 4. Percent of agencies that required training on selected topics, 2019	
		
			Appendix tables	
leaesro19at01.csv	Appendix table 1. Standard errors for figure 1: Number of personnel primarily assigned to public K–12 schools, by type of agency and sworn status, 2019 and table 1: Law enforcement agencies with sworn SROs, by type of agency and size of SRO program, 2019	
leaesro19at02.csv	Appendix table 2. Standard errors for figure 1: Number of personnel primarily assigned to public K–12 schools, by type of agency and sworn status, 2019 and table 2: Law enforcement agencies with nonsworn employees primarily assigned to public K–12 schools, by type of agency, 2019	
leaesro19at03.csv	Appendix table 3. Standard errors for table 3: Sex of sworn SROs, by type of agency and size of SRO program, 2019	
leaesro19at04.csv	Appendix table 4. Standard errors for table 4: Race or Hispanic origin of SROs, by type of agency and size of SRO program, 2019	
leaesro19at05.csv	Appendix table 5. Estimates and standard errors for figure 2: Average age of SRO programs, by type of agency and size of SRO program, 2019	
leaesro19at06.csv	Appendix table 6. Standard errors for table 5: Funding sources for SRO programs, by type of agency and size of SRO program, 2019	
leaesro19at07.csv	Appendix table 7. Standard errors for table 6: Type of SRO assignment, by type of agency and size of SRO program, 2019	
leaesro19at08.csv	Appendix table 8. Standard errors for table 7: Percent of agencies that required SROs to perform selected law enforcement activities, by type of agency and size of SRO program, 2019	
leaesro19at09.csv	Appendix table 9. Standard errors for table 8: Percent of agencies that required SROs to perform selected mentoring activities, by type of agency and size of SRO program, 2019	
leaesro19at10.csv	Appendix table 10. Standard errors for table 9: Percent of agencies that required SROs to perform selected teaching activities, by type of agency and size of SRO program, 2019	
leaesro19at11.csv	Appendix table 11. Standard errors for table 10: Actions requiring SROs to inform school executive staff, by type of agency and size of SRO program, 2019	
leaesro19at12.csv	Appendix table 12. Standard errors for table 11: Direct or physical contact requiring SROs to inform school executive staff, by type of agency and size of SRO program, 2019	
leaesro19at13.csv	Appendix table 13. Estimates and standard errors for figure 3: Allowance of SRO interviews of students without a parent present without first obtaining parental permission, by type of agency and size of SRO program, 2019	
leaesro19at14.csv	Appendix table 14. Standard errors for table 12: Percent of agencies with procedural SRO program characteristics specified in internal policy or formal agreement with schools, by type of agency and size of SRO program, 2019	
leaesro19at15.csv	Appendix table 15. Standard errors for table 13: Percent of agencies with administrative SRO program characteristics specified in internal policy or formal agreement with schools, by type of agency and size of SRO program, 2019	
leaesro19at16.csv	Appendix table 16. Standard errors for table 14: SRO selection methods, by type of agency and size of SRO program, 2019	
leaesro19at17.csv	Appendix table 17. Standard errors for table 15: Percent of agencies that required training on de-escalation and use of force, by type of agency, 2019	
leaesro19at18.csv	Appendix table 18. Estimates and standard errors for figure 4: Percent of agencies that required training on selected topics, 2019	
leaesro19at19.csv	Appendix table 19. Standard errors for table 16: Frequency of SRO supervisor visits, by type of agency and size of SRO program, 2019	
leaesro19at20.csv	Appendix table 20. Standard errors for table 17: Percent of agencies with SROs allowed to carry selected equipment on campus, by issuance and type of agency, 2019	
		
		
		
