2002 National Corrections Reporting Program


It is one of a series of files from the National Corrections Reporting Program since 1993.  
All of the files may be obtained from http://www.ojp.usdoj.gov/bjs/dtdata.htm#ncrp. 

Three groups of tables -- sentence length, time served and most serious offense of State prisoners-- are archived for each year.  
In addition to the list of tables in this file, the tables in the related archives are listed below.*

This Zip archive, Most serious offense of State prisoners, 2002,
NCJ 211359 contains the following tables:

   File name        Contents

ncrp0201.csv        State prison admissions: offense, by admission type
ncrp0202.csv        New court commitments to State prisons: offense, by age at admission
ncrp0203.csv        Parole violators returned to State prison: offense, by age at admission
ncrp0204.csv        New court commitments to State prisons: offense, by gender, race, and Hispanic origin
ncrp0205.csv        Parole violators returned to State prison: offense, by gender, race, and Hispanic origin
ncrp0212.csv        First entries to parole supervision from State prison: method of prison release, by offense
ncrp0213.csv        First entries to parole supervision from State prison: offense, by gender, race, and  Hispanic origin
ncrp0214.csv        State parole discharges: method of parole discharge, by offense 

*Note:  Beginning in 1999, Table 7 (New court commitments to State prison:  
sentence length and minimum time to be served, by offense) 
was discontinued.  

Two related archives are also available.  The tables in these
archives are listed below.

Time Served in State Prison (NCJ 211358)

ncrp0208.csv        State prison releases: time served in prison, by offense and release type
ncrp0209.csv        First releases from State prison: sentence length, time served, and percent of sentence served, by offense
ncrp0210.csv        First releases from State prison: sentence length and time served in prison, by offense and gender
ncrp0211.csv        First releases from State prison: sentence length and time served in prison, by offense and race
ncrp0215.csv        Successful first State parole discharges: sentence length and time served, by offense
ncrp0216.csv        Unsuccessful first State parole discharges: sentence length and time served, by offense

Sentence length of State prisoners (NCJ 211360)

ncrp0206.csv   State prison admissions: sentence length by offense and admission type 
ncrp0209.csv   First releases from State prison: sentence length, time served, and percent of sentence served in prison, by offense
ncrp0210.csv   First releases from State prison: sentence length and time served in prison, by offense, and gender
ncrp0211.csv   First releases from State prison: sentence length and time served in prison, by offense, and race 
ncrp0215.csv   Successful first State parole discharges: sentence length and time served, by offense
ncrp0216.csv   Unsuccessful first State parole discharges: sentence length and time served, by offense
