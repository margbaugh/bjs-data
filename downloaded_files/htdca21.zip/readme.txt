Human Trafficking Data Collection Activities, 2021   NCJ 302732								
								
This zip archive contains tables in individual  .csv spreadsheets								
from Human Trafficking Data Collection Activities, 2021   NCJ 302732.  The full report including text								
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/human-trafficking-data-collection-activities-2021								
								
This report is one in a series.  More recent editions								
may be available.  To view a list of all in the series go to:								
https://bjs.ojp.gov/library/publications/list?series_filter=Human%20Trafficking%20Data%20Collection%20Activities								
								
Filenames	Table title							
htdca21t01.csv	Table 1. Human-trafficking suspects referred to and prosecuted by U.S. attorneys and human-trafficking defendants convicted and sentenced to prison, 2011–2019							
								
		Figures							
htdca21f01.csv	Figure 1. Number of states reporting to Uniform Crime Reporting-Human Trafficking (UCR-HT), by offense type, 2015-2020					
htdca21f02.csv	Figure 2. Arrests for human trafficking, by offense type, 2015-2020							
htdca21f03.csv	Figure 3. Human-trafficking suspects referred to and prosecuted by U.S. attorneys and human-trafficking defendants convicted, 2011–2019							
