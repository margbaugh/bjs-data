Capital Punishment, 2018 - Statistical Tables    NCJ 254786		
		
This zip archive contains tables in individual .csv spreadsheets		
from Capital Punishment, 2018 - Statistical Tables    NCJ 254786		
The full electronic report is available at: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7066		
		
These statistical tables are in a series.  More recent editions		
may be available.  To view a list of all reports in the series go to:		
https://www.bjs.gov/index.cfm?ty=pbse&sid=1		
		
		
File name		Table names
cp18stt01.csv		Table 1. Status of the death penalty, December 31, 2018
cp18stt02.csv		Table 2. Capital offenses, by state, 2018
cp18stt03.csv		Table 3. Federal capital offenses, 2018
cp18stt04.csv		Table 4. Authorized methods of execution, by state, 2018
cp18stt05.csv		Table 5. Movement of prisoners under sentence of death, by region, jurisdiction, and race, 2017 and 2018
cp18stt06.csv		Table 6. Demographic characteristics of prisoners under sentence of death, 2018
cp18stt07.csv		Table 7. Female prisoners under sentence of death, by region, jurisdiction, and race, 2017 and 2018
cp18stt08.csv		Table 8. Hispanic prisoners under sentence of death, by region and jurisdiction, 2017 and 2018
cp18stt09.csv		Table 9. Criminal history of prisoners under sentence of death, by race or ethnicity, 2018
cp18stt10.csv		Table 10. Prisoners removed from being under sentence of death, by region, jurisdiction, and method of removal, 2018
cp18stt11.csv		Table 11. Average elapsed time between sentencing and execution, 1977-2018
cp18stt12.csv		Table 12. Number of prisoners executed, by race or ethnicity, 1977-2018
cp18stt13.csv		Table 13. Number of executions, by method and jurisdiction, 1977-2018
cp18stt14.csv		Table 14. Cumulative number of executions at year-end 2018, by jurisdiction, since 1930 and since 1977
		
			Figures
cp18stf01.csv		Figure 1. Number of prisoners under sentence of death, 1953-2018
cp18stf02.csv		Figure 2. Admissions to and removals from a sentence of death, 1973-2018
cp18stf03.csv		Figure 3. Number of prisoners executed under civil authority in the United States, 1930-2018
cp18stf04.csv		Figure 4. Number of prisoners under sentence of death, by race, 1968-2018
cp18stf05.csv		Figure 5. Advance count of executions, January 1, 2019-December 31, 2019
		
			Appendix tables
cp18stat01.csv		Appendix table 1. Demographic characteristics for prisoners under sentence of death, 2018
cp18stat02.csv		Appendix table 2. Number of prisoners under sentence of death, 1953-2018
cp18stat03.csv		Appendix table 3. Admissions to and removals from a sentence of death, 1973-2018
cp18stat04.csv		Appendix table 4. Number of prisoners executed under civil authority in the United States, 1930-2018
cp18stat05.csv		Appendix table 5. Number of prisoners under sentence of death, by race, 1968-2018
