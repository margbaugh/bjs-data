Mental Health Treatment in State Prisons, 2000   NCJ  188215

This zip archive contains tables in individual .wk1 spreadsheets
from Mental Health Treatment in State Prisons, 2000   NCJ  188215
the full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/mhtsp00.htm


mhts0001.wk1     Table 1.  Mental health screening and treatment in Sta
                 correctional  facilities, by type of facility, June 30
mhts0002.wk1     Table 2.  Mental health screening and treatment in Sta
                 facilities, by facility security level, June 30, 2000
mhts0003.wk1     Table 3.  Inmates receiving mental health treatment in
                 correctional  facilities, by facility characteristic,
mhts0004.wk1     Table 4.  Inmates receiving mental health treatment in
                 confinement  facilities, by facility characteristic, J
mhts0005.wk1     Table 5.  Characteristics of State correctional facili
                 mental health services, June 30, 2000
mhts00a1.wk1     Appendix table A.  Mental health screening and treatme
                 correctional facilities, June 30, 2000
mhts00a2.wk1     Appendix table B.  Inmates receiving mental health tre
                 in State correctional facilities, June 30, 2000
mhts00a3.wk1     Appendix table C.  The 35 largest State correctional f
                 mental health therapy/treatment, June 30, 2000
 
