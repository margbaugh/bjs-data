Contacts between Police and the Public, 2005
 
This zip archive contains tables in individual .csv spreadsheets
from Contacts between Police and the Public, 2005, NCJ 215243.
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cpp05.htm

		
Filename		Table number	
cpp05t01.csv		Table 1. Percent of U.S. population who had contact with police in 2002 and 2005, by demographic characteristics
cpp05t02.csv		Table 2. Number of contacts between police and the public in 2005, by demographic characteristics
cpp05t03.csv		Table 3. Reasons for face-to-face contact with police in 2002 and 2005
cpp05t04.csv		Table 4. Among persons who had face-to face contact, percent who felt police acted properly, by race/Hispanic origin, 2005 
cpp05t05.csv		Table 5. Number and percent of drivers stopped by police in 2002 and 2005, by demographic characteristics
cpp05t06.csv		Table 6. Reasons police gave drivers for pulling them over in 2005  
cpp05t07.csv		Table 7. Enforcement actions taken by police during traffic stops in 2005, by the reason for being stopped
cpp05t08.csv		Table 8. Enforcement actions taken by police during traffic stops in 2005, by demographic characteristics   
cpp05t09.csv		Table 9. Number and percent of contacts with police in which force was used in 2002 and 2005, by demographic characteristics  
cpp05t10.csv		Table 10. Demographic characteristics of persons who had a police contact in which force was used in 2005 
cpp05t11.csv		Table 11. Type of and reason for contact with police in which force was used in 2005 
cpp05t12.csv		Table 12. Type of force used or threatened by police in 2005   
cpp05t13.csv		Table 13. Characteristics of contacts with police in which force was used in 2005, by race/Hispanic origin   
	
			Text tables
cpp05tt01.csv		Text table 1. Characteristics of searches conducted during traffic stops in 2005 
cpp05tt02.csv		Text table 2. Among persons who experienced force in 2005, number and percent who felt it was excessive

			Box tables
cpp05bx01.csv		Box 1. Most stopped drivers felt they had been stopped for a legitimate reason
cpp05bx02.csv		Box 2. The likelihood of being searched during a traffic stop was unchanged between 2002 and 2005

			Methodology tables
cpp05meth01.csv		Methodology table 1. Number of drivers, persons with face-to-face police contact, and total residents age 16 or older in the United States in 2002 and 2005, by demographic characteristics   
cpp05meth02.csv		Methodology table 2. Estimate of 1 standard error for percentages in tables 5 and 9

			Appendix tables
cpp05at01.csv		Appendix table 1. Number of survey respondents in the 2005 Police-Public Contact Survey, by demographic characteristics
cpp05at02.csv		Appendix table 2. Estimate of 1 standard error for percentages in table 1 
cpp05at03.csv		Appendix table 3. Estimate of 1 standard error for percentages in table on page 7 

			Summary tables
cpp05st01.csv		Summary table 1. Reasons for contact with police in 2002 and 2005
cpp05st02.csv		Summary table 2. White, black, and Hispanic drivers were stopped by police at similar rates; blacks and Hispanics were searched by police at higher rates than whites
	


		
	
			
 
 
 
 
 
