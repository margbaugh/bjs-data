Selected Findings from the FBI�s Uniform Crime Reporting Program  NCJ 254862											
											
This zip archive contains tables in individual  .csv spreadsheets											
from Selected Findings from the FBI�s Uniform Crime Reporting Program  NCJ 254862.											
The full report including text and graphics in pdf format is available from:											
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6929											
											
Filename		Table name									
sffucrpt01.csv		Table 1. Crime in the United States, by number of crimes and rates per 100,000 population, 2014-2018									
sffucrpt02.csv		Table 2. Percent change in the crime rate per 100,000 population, for selected years between 2014 and 2018									
sffucrpt03.csv		Table 3. Percent change in the total number of crimes, for selected years between 2014 and 2019									
sffucrpt04.csv		Table 4. Percent change in number of crimes, by offense and population group, from January-June 2018 to January-June 2019									
sffucrpt05.csv		Table 5. Homicide victimization rate per 100,000 persons of a given race and sex, 2009-2018									
sffucrpt05a.csv		Table 5a. Number of homicides, by victim sex and race, 2009-2018									
sffucrpt06.csv		Table 6. Male homicide victimization rate per 100,000 males of a given race, 2014-2018									
sffucrpt07.csv		Table 7. Female homicide victimization rate per 100,000 females of a given race, 2014-2018									
sffucrpt08.csv		Table 8. Homicide victimization rate per 100,000 persons of a given race, 2014-2018									
											
			Figure name									
sffucrpf01.csv		Figure 1. Male homicide victimization rate per 100,000 males of a given race, 2014-2018									
sffucrpf02.csv		Figure 2. Female homicide victimization rate per 100,000 females of a given race, 2014-2018									
sffucrpf03.csv		Figure 3. Homicide victimization rate per 100,000 persons of a given race, 2014-2018									
