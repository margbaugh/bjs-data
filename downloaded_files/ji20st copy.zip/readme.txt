Jail Inmates in 2020 – Statistical Tables   NCJ 303308	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Jail Inmates in 2020 – Statistical Tables   NCJ 303308.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/jail-inmates-2020-statistical-tables	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to 	
https://bjs.ojp.gov/library/publications/list?series_filter=Prison%20and%20Jail%20Inmates%20at%20Midyear	
	
Filenames	Table names
ji20stt01.csv	Table 1. Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2010–2020
ji20stt02.csv	Table 2. Number of confined inmates in local jails, by demographic characteristics, 2010 and 2015–2020
ji20stt03.csv	Table 3. Percent of confined inmates in local jails, by demographic characteristics, 2010 and 2015–2020
ji20stt04.csv	Table 4. Jail incarceration rates, by demographic characteristics, 2010 and 2015–2020
ji20stt05.csv	Table 5. Number of confined inmates in local jails, by conviction status and offense severity, 2010 and 2015–2020
ji20stt06.csv	Table 6. Percent of confined inmates in local jails, by conviction status and offense severity, 2010 and 2015–2020
ji20stt07.csv	Table 7. Confined inmates in local jails, by probation or parole violation status, midyears 2019 and 2020
ji20stt08.csv	Table 8. Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, midyears 2015 and 2019–2020
ji20stt09.csv	Table 9. Average daily jail population, by size of jurisdiction, 2020
ji20stt10.csv	Table 10. Midyear population, jail capacity, and percent of capacity occupied in local jails, 2010–2020
ji20stt11.csv	Table 11. Percent of jail capacity occupied at midyear, by size of jail jurisdiction, 2020
ji20stt12.csv	Table 12. Inmate turnover rate and estimated average time in jail, 2010–2020
ji20stt13.csv	Table 13. Inmate turnover rate and estimated average time in jail, by size of jurisdiction, 2020
ji20stt14.csv	Table 14. Persons under jail supervision, by confinement status, midyears 2010–2020
ji20stt15.csv	Table 15. Number of persons serving weekend-only sentences on the weekend before the last weekday in June, 2010–2020
ji20stt16.csv	Table 16. Number of staff employed in local jails, by job function and sex, 2013 and 2015–2020
ji20stt17.csv	Table 17. Percent of staff employed in local jails, by job function and sex, 2013 and 2015–2020
	
		Figures
ji20stf01.csv	Figure 1. Number of inmates confined in local jails at midyear, 2010–2020
	
		Appendix tables
ji20stat01.csv	Appendix Table 1. Standard errors for table 1: Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2010–2020
ji20stat02.csv	Appendix Table 2. Standard errors for table 2: Number of confined inmates in local jails, by demographic characteristics, 2010 and 2015–2020
ji20stat03.csv	Appendix Table 3. Standard errors for table 3: Percent of confined inmates in local jails, by demographic characteristics, 2010 and 2015–2020
ji20stat04.csv	Appendix Table 4. Standard errors for table 4: Jail incarceration rates, by demographic characteristics, 2010 and 2015–2020
ji20stat05.csv	Appendix Table 5. Standard errors for table 5: Number of confined inmates in local jails, by conviction status and offense severity, 2010 and 2015–2020
ji20stat06.csv	Appendix Table 6. Standard errors for table 6: Percent of confined inmates in local jails, by conviction status and offense severity, 2010 and 2015–2020
ji20stat07.csv	Appendix Table 7. Standard errors for table 7: Confined inmates in local jails, by probation or parole violation status, midyears 2019 and 2020
ji20stat08.csv	Appendix Table 8. Standard errors for table 8: Confined inmates held in local jails for federal correctional authorities, state prison authorities, and American Indian and Alaska Native tribal governments, midyears 2015 and 2019–2020
ji20stat09.csv	Appendix Table 9. Standard errors for table 9: Average daily jail population, by size of jurisdiction, 2020
ji20stat10.csv	Appendix Table 10. Standard errors for table 10: Midyear population, jail capacity, and percent of capacity occupied in local jails, 2010–2020
ji20stat11.csv	Appendix Table 11. Standard errors for table 11: Percent of jail capacity occupied at midyear, by size of jail jurisdiction, 2020
ji20stat12.csv	Appendix Table 12. Standard errors for table 12: Inmate turnover rate and estimated average time in jail, 2010–2020
ji20stat13.csv	Appendix Table 13. Standard errors for table 13: Inmate turnover rate and estimated average time in jail, by size of jurisdiction, 2020
ji20stat14.csv	Appendix Table 14. Standard errors for table 14: Persons under jail supervision, by confinement status, midyears 2010–2020
ji20stat15.csv	Appendix Table 15. Standard errors for table 15: Number of persons serving weekend-only sentences on the weekend before the last weekday in June, 2010–2020
ji20stat16.csv	Appendix Table 16. Standard errors for table 16: Number of staff employed in local jails, by job function and sex, 2013 and 2015–2020
ji20stat17.csv	Appendix Table 17. Standard errors for table 17: Percent of staff employed in local jails, by job function and sex, 2013 and 2015–2020
