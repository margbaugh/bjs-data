Jails in Indian Country, 2004, NCJ 214257

This zip archive contains tables in individual .csv spreadsheets
from Jails in Indian Country, 2004, NCJ 214257
The full report including text and graphics in .pdf format are 
available from: http://www.ojp.usdoj.gov/bjs/abstract/jic04.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#jic
 
Tables	
jic04t01.csv	Table 1. Indian country jail inmate characteristics, midyear 2003-04
jic04t02.csv	Table 2. Ten largest jails in Indian country, June 30, 2004
jic04t03.csv	Table 3. Jails in Indian country operating above 150% of capacity on the peak day during June 2004
jic04t04.csv	Table 4. Staff characteristics of jails in Indian country, June 30, 2004
jic04t05.csv	Table 5. Jails in Indian country with testing policies for HIV, Hepatitis, and Tuberculosis among inmates, June 30, 2004
jic04t06.csv	Table 6. Jails in Indian country with inmate mental health policies and suicide prevention procedures
jic04t07.csv	Table 7. Jails in Indian country providing inmate treatment, counseling, and programs
	
Highlights tables	
jic04ht01.csv	Highlights table 1. Inmates, admissions, rated capacity, seriousness of offense, and percent of capacity occupied in Indian country jails, 2002-04
jic04ht02.csv	Highlights table 2. Facility policies or programs, June 2004
	
Text tables	
jic04tt01.csv	Text table 1. Number of adult and juvenile inmates, midyear 2003-04
jic04tt02.csv	Text table 2. American Indians and Alaska Natives under correctional supervision in the United States 
jic04tt03.csv	Text table 3. Indian country jail inmates, by type of offense, June 30, 2004
jic04tt04.csv	Text table 4. Indian country jail inmate admissions and reported suicides, 2002-04
jic04tt05.csv	Text table 5: Size of facilities by the custody population at midyear 2002-04
jic04tt06.csv	Text table 6. Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, 2002-04
jic04tt07.csv	Text table 7. Percent of capacity occupied on peak day in June 2004 by rated capacity of facility 
jic04tt08.csv 	Text table 8. Jails in Indian country that provide medical services to inmates, June 30, 2004
jic04tt09.csv	Text table 9. Jails in Indian country that offer work assignments to inmates, June 30, 2004
	
Appendix tables	
jic04at01.csv	Appendix table 1. Inmates, rated capacity, and percent of capacity occupied in jails in Indian country, June 2004
jic04at02.csv	Appendix table 2. Number of inmates in jails in Indian country, by type of offense, June 30, 2004
jic04at03.csv	Appendix table 3. Number of inmates in jails in Indian country, by conviction status and seriousness of offense, June 30, 2004 
jic04at04.csv	Appendix table 4. Adults and juveniles in the custody of jails in Indian country, by gender, June 30, 2004 
jic04at05.csv	Appendix table 5. Jails in Indian country that provide medical services to inmates, June 30, 2004
jic04at06.csv	Appendix table 6. Jails in Indian country with screening policies among inmates for the antibody to the human immunodeficiency virus (HIV) that causes 			AIDS, June 30, 2004
jic04at07.csv	Appendix table 7. Jails in Indian country with testing policies for hepatitis B infection among inmates, June 30, 2004
jic04at08.csv	Appendix table 8. Jails in Indian country with testing policies for hepatitis C infection among inmates, June 30, 2004
jic04at09.csv	Appendix table 9. Jails in Indian country with testing policies for tuberculosis among inmates, June 30, 2004
jic04at10.csv	Appendix table 10. Jails in Indian country with policies relating to mental health among inmates, June 30, 2004 
jic04at11.csv	Appendix table 11. Jails in Indian country with procedures for suicide prevention, June 30, 2004 
jic04at12.csv	Appendix table 12. Jails in Indian country providing treatment, counseling, and special programs for inmates on or off facility grounds, June 30, 2004 
jic04at13.csv	Appendix table 13. Jails in Indian country providing education programs for inmates on or off facility grounds, June 30, 2004 
jic04at14.csv	Appendix table 14. Jails in Indian country with work assignments available to inmates, June 30, 2004 
	
Figure	
jic04f01.csv	Figure 1. Indian county jail inmate population, 2003-2004

	



