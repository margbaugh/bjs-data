Financial Fraud in the United States, 2017  NCJ 255817	
	
This zip archive contains tables in individual  .csv spreadsheets	
Financial Fraud in the United States, 2017  NCJ 255817  The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7366	
	
Filenames	Table names
ffus17t01.csv	Table 1. Victims age 18 or older who experienced at least one incident of personal financial fraud in the past 12 months, by type of fraud, 2017
ffus17t02.csv	Table 2. Victims age 18 or older who experienced personal financial fraud, by number of fraud types experienced, 2017
ffus17t03.csv	Table 3. Victims age 18 or older who reported personal financial fraud in the Supplemental Fraud Survey screener, by fraud definition and type of fraud, 2017
ffus17t04.csv	Table 4. Victims age 18 or older who experienced personal financial fraud, by demographic characteristics, 2017
ffus17t05.csv	Table 5. Victims age 18 or older who reported personal financial fraud to police, by type of fraud, 2017
ffus17t06.csv	Table 6. Victims age 18 or older who reported personal financial fraud to select persons or groups, by type of person or group, 2017
ffus17t07.csv	Table 7. Financial losses among victims age 18 or older who experienced at least one financial fraud incident in the past 12 months, by type of fraud, 2017
ffus17t08.csv	Table 8. Financial losses among victims age 18 or older who experienced at least one incident of personal financial fraud in the past 12 months, by type of fraud and reporting to police, 2017
	
		Figures
ffus17f01.csv	Figure 1. Percent of persons age 18 or older who experienced at least one incident of personal financial fraud in the past 12 months, by type of fraud, 2017
ffus17f02.csv	Figure 2. Percent of victims age 18 or older who experienced socioemotional problems as a result of personal financial fraud, by type of fraud, 2017
	
		Appendix tables
ffus17at01.csv	Appendix table 1. Prevalence of consumer products and services fraud, by type of product or service purchased, 2017
ffus17at02.csv	Appendix table 2. Prevalence of charity fraud, by type of fraud scheme, 2017
ffus17at03.csv	Appendix table 3. Prevalence of phantom debt fraud, by type of fraud scheme, 2017
ffus17at04.csv	Appendix table 4. Prevalence of prize and grant fraud, by type of fraud scheme, 2017
ffus17at05.csv	Appendix table 5. Prevalence of relationship and trust fraud, by type of falsified relationship and mode of contact, 2017
ffus17at06.csv	Appendix table 6. Prevalence of employment fraud, by type of fraud scheme, 2017
ffus17at07.csv	Appendix table 7. Prevalence of consumer investment fraud, by type of fraud scheme, 2017
ffus17at08.csv	Appendix table 8. Estimates and standard errors for figure 1: Percent of persons age 18 or older who experienced at least one incident of personal financial fraud in the past 12 months, by type of fraud, 2017
ffus17at09.csv	Appendix table 9. Standard errors for table 3: Victims age 18 or older who reported personal financial fraud in the Supplemental Fraud Survey screener, by fraud definition and type of fraud, 2017
ffus17at10.csv	Appendix table 10. Population totals and standard errors for table 4: Victims age 18 or older who experienced personal financial fraud, by demographic characteristics, 2017
ffus17at11.csv	Appendix table 11. Standard errors for table 5: Victims age 18 or older who reported personal financial fraud to police, by type of fraud, 2017
ffus17at12.csv	Appendix table 12. Standard errors for table 7: Financial losses among victims age 18 or older who experienced at least one financial fraud incident in the past 12 months, by type of fraud, 2017
ffus17at13.csv	Appendix table 13. Standard errors for table 8: Financial losses among victims age 18 or older who experienced at least one incident of personal financial fraud in the past 12 months, by type of fraud and reporting to police, 2017
ffus17at14.csv	Appendix table 14. Estimates and standard errors for figure 2: Percent of victims age 18 or older who experienced socioemotional problems as a result of personal financial fraud, by type of fraud, 2017
ffus17at15.csv	Appendix table 15. Standard errors for appendix table 1: Prevalence of consumer products and services fraud, by type of product or service purchased, 2017
ffus17at16.csv	Appendix table 16. Standard errors for appendix table 2: Prevalence of charity fraud, by type of fraud scheme, 2017
ffus17at17.csv	Appendix table 17. Standard errors for appendix table 3: Prevalence of phantom debt fraud, by type of fraud scheme, 2017
ffus17at18.csv	Appendix table 18. Standard errors for appendix table 4: Prevalence of prize and grant fraud, by type of fraud scheme, 2017
ffus17at19.csv	Appendix table 19. Standard errors for appendix table 5: Prevalence of relationship and trust fraud, by type of falsified relationship and mode of contact, 2017
ffus17at20.csv	Appendix table 20. Standard errors for appendix table 6: Prevalence of employment fraud, by type of fraud scheme, 2017
ffus17at21.csv	Appendix table 21. Standard errors for appendix table 7: Prevalence of consumer investment fraud, by type of fraud scheme, 2017
	
	
	
	
	
