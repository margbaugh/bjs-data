Contacts Between Police and the Public, 2020 NCJ 304527	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Contacts Between Police and the Public, 2020 NCJ 304527.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/contacts-between-police-and-public-2020	
	
This report is one in a series.  More recent editions may be available.	
To view a list of all in the series go to https://bjs.ojp.gov/library/publications/list?series_filter=Contacts%20between%20Police%20and%20the%20Public	
	
Filenames	Table titles
cbpp20t01.csv	Table 1. U.S. residents age 16 or older who had police contact, by type of contact and demographic characteristics, 2020
cbpp20t02.csv	Table 2. U.S. residents age 16 or older who had police contact, by type of contact and reason, 2015, 2018, and 2020
cbpp20t03.csv	Table 3. U.S. residents age 16 or older whose police contact involved the threat or nonfatal use of force, by demographic characteristics, 2018 and 2020
cbpp20t04.csv	Table 4. U.S. residents age 16 or older whose most recent police contact was police-initiated, by reason and demographic characteristics, 2020
cbpp20t05.csv	Table 5. Percent of U.S. residents age 16 or older whose most recent police contact was as a driver in a traffic stop, by enforcement action and demographic characteristics, 2018 and 2020
cbpp20t06.csv	Table 6. Percent of U.S. residents age 16 or older whose most recent police contact was a street stop, by enforcement action and demographic characteristics, 2018 and 2020
cbpp20t07.csv	Table 7. Percent of U.S. residents age 16 or older whose most recent police contact involved misconduct, by demographic characteristics, 2018 and 2020
cbpp20t08.csv	Table 8. Percent of U.S. residents age 16 or older whose most recent police contact was police-initiated or related to a traffic accident, by race or Hispanic origin and police action, 2018 and 2020
cbpp20t09.csv	Table 9. U.S. residents age 16 or older whose most recent police-initiated or traffic accident-related contact involved the threat or nonfatal use of force, by perceptions of force and demographic characteristics, 2018 and 2020
cbpp20t10.csv	Table 10. Percent of U.S. residents age 16 or older who engaged in action toward police during their most recent police-initiated or traffic accident-related contact, by demographic characteristics, 2020
cbpp20t11.csv	Table 11. U.S. residents age 16 or older whose most recent police contact was resident-initiated, by reason and demographic characteristics, 2020
cbpp20t12.csv	Table 12. Percent of U.S. residents age 16 or older whose most recent police contact was resident-initiated for any reason excluding block watch, by perceptions of response and demographic characteristics, 2020
	
		Figures
cbpp20f01.csv	Figure 1. U.S. residents age 16 or older who had police contact, by type of contact and reason, 2020 
cbpp20f02.csv	Figure 2. Police Public Contact Survey field operation procedures, 2020
	
		Appendix tables
cbpp20at01.csv	Appendix Table 1. Standard errors for figure 1 and table 2: U.S. residents age 16 or older who had police contact, by type of contact and reason, 2015, 2018, and 2020  
cbpp20at02.csv	Appendix Table 2. Standard errors for table 1: U.S. residents age 16 or older who had police contact, by type of contact and demographic characteristics, 2020
cbpp20at03.csv	Appendix Table 3. Standard errors for table 3: U.S. residents age 16 or older whose police contact involved the threat or nonfatal use of force, by demographic characteristics, 2018 and 2020
cbpp20at04.csv	Appendix Table 4. Standard errors for table 4: U.S. residents age 16 or older whose most recent police contact was police-initiated, by reason and demographic characteristics, 2020
cbpp20at05.csv	Appendix Table 5. Standard errors for table 5: Percent of U.S. residents age 16 or older whose most recent police contact was as a driver in a traffic stop, by enforcement action and demographic characteristics, 2018 and 2020
cbpp20at06.csv	Appendix Table 6. Standard errors for table 6: Percent of U.S. residents age 16 or older whose most recent police contact was a street stop, by enforcement action and demographic characteristics, 2018 and 2020
cbpp20at07.csv	Appendix Table 7. Standard errors for table 7: Percent of U.S. residents age 16 or older whose most recent police contact involved misconduct, by demographic characteristics, 2018 and 2020
cbpp20at08.csv	Appendix Table 8. Standard errors for table 8: Percent of U.S. residents age 16 or older whose most recent police contact was police-initiated or related to a traffic accident, by race or Hispanic origin and police action, 2018 and 2020
cbpp20at09.csv	Appendix Table 9. Standard errors for table 9: U.S. residents age 16 or older whose most recent police-initiated or traffic accident-related contact involved the threat or nonfatal use of force, by perceptions of force and demographic characteristics, 2018 and 2020
cbpp20at10.csv	Appendix Table 10. Standard errors for table 10: Percent of U.S. residents age 16 or older who engaged in action toward police during their most recent police-initiated or traffic accident-related contact, by demographic characteristics, 2020
cbpp20at11.csv	Appendix Table 11. Standard errors for table 11: U.S. residents age 16 or older whose most recent police contact was  resident-initiated, by reason and demographic characteristics, 2020
cbpp20at12.csv	Appendix Table 12. Standard errors for table 12: Percent of U.S. residents age 16 or older whose most recent police contact was resident-initiated for any reason excluding block watch, by perceptions of response and demographic characteristics, 2020
