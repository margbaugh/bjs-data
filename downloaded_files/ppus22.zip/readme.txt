Probation and Parole in the United States, 2022  NCJ 308575	
	
This zip archive contains tables in individual .csv spreadsheets from	
Probation and Parole in the United States, 2022  NCJ 308575.  The full report including text	
and graphics in pdf format is available from https://bjs.ojp.gov/library/publications/probation-and-parole-united-states-2022	
	
This report is one in a series.  More recent editions may be available.	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Probation%20and%20Parole%20Populations	
	
Filenames	Table titles
ppus22t01.csv	Table 1. Adults under community supervision, 2012–2022
ppus22t02.csv	Table 2. Change in probation population, by jurisdiction, 2022
ppus22t03.csv	Table 3. Change in parole population, by jurisdiction, 2022
ppus22t04.csv	Table 4. Community supervision rate of adult U.S. residents, 2012–2022
ppus22t05.csv	Table 5. Exits from probation, by type of exit, 2012–2022
ppus22t06.csv	Table 6. Exits from parole, by type of exit, 2012–2022
ppus22t07.csv	Table 7. Characteristics of adults on probation, 2012 and 2022
ppus22t08.csv	Table 8. Characteristics of adults on parole, 2012 and 2022
ppus22t09.csv	Table 9. Adults supervised on both parole and probation adjusted in the January 1 and December 31 community supervision population, 2012–2022
ppus22t10.csv	Table 10. One-day difference based on reporting changes for probation and parole, 2012–2022
	
		Figures
ppus22f01.csv	Figure 1. Adults on probation or parole, 2012–2022
ppus22f02.csv	Figure 2. Annual percent change in number of adults on probation, 2012–2022
ppus22f03.csv	Figure 3. Annual percent change in number of adults on parole, 2012–2022
ppus22f04.csv	Figure 4. Estimated total probation movements, entries, and exits, 2012–2022
ppus22f05.csv	Figure 5. Estimated total parole movements, entries, and exits, 2012–2022
	
		Appendix tables
ppus22at01.csv	Appendix table 1. Counts for figure 2: Annual percent change of adults on probation, 2012–2022
ppus22at02.csv	Appendix table 2. Estimates for figure 3: Annual percent change of adults on parole, 2012–2022
ppus22at03.csv	Appendix table 3. Estimates for figure 4: Estimated total probation movements, entries, and exits, 2012–2022
ppus22at04.csv	Appendix table 4. Estimates for figure 5: Estimated total parole movements, entries, and exits, 2012–2022
ppus22at05.csv	Appendix table 5. Adults under community supervision, 2022
ppus22at06.csv	Appendix table 6. Adults on probation, by jurisdiction, 2022
ppus22at07.csv	Appendix table 7. Adults exiting probation, by type of exit and jurisdiction, 2022
ppus22at08.csv	Appendix table 8. Adults on probation, by sex and race or ethnicity, 2012–2022
ppus22at09.csv	Appendix table 9. Select characteristics of adults on probation, by jurisdiction, 2022
ppus22at10.csv	Appendix table 10. Adults on parole, by jurisdiction, 2022
ppus22at11.csv	Appendix table 11. Adults exiting parole, by type of exit and jurisdiction, 2022
ppus22at12.csv	Appendix table 12. Adults on parole, by sex and race or ethnicity, 2012–2022
ppus22at13.csv	Appendix table 13. Selected characteristics of adults on parole, by jurisdiction, 2022
