Mortality in State and Federal Prisons, 2001–2019 – Statistical Tables  NCJ 300953	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Mortality in State and Federal Prisons, 2001–2019 – Statistical Tables  NCJ 300953.  The full report including text and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/mortality-state-and-federal-prisons-2001-2019-statistical-tables	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Mortality%20in%20Local%20Jails%20and%20State%20Prisons	
	
Filename		Table names
msfp0119stt01.csv	Table 1. Deaths of state and federal prisoners, by cause of death, 2001–19
msfp0119stt02.csv	Table 2. Number of deaths of state and federal prisoners, by cause of death, 2001–2019
msfp0119stt03.csv	Table 3. Percent of deaths of state prisoners, by cause of death, 2001–2019
msfp0119stt04.csv	Table 4. Mortality rate per 100,000 state prisoners, by cause of death, 2001–2019
msfp0119stt05.csv	Table 5. Crude and adjusted mortality rate per 100,000 U.S. residents, by cause of death, 2019
msfp0119stt06.csv	Table 6. Number of deaths of state prisoners, by decedent characteristics, 2001–2019
msfp0119stt07.csv	Table 7. Percent of deaths of state prisoners, by decedent characteristics, 2001–2019
msfp0119stt08.csv	Table 8. Mortality rate per 100,000 state prisoners, by decedent characteristics, 2001–2019
msfp0119stt09.csv	Table 9. Number of deaths of state prisoners, by cause of death and decedent characteristics, 2001–19
msfp0119stt10.csv	Table 10. Average annual mortality rate per 100,000 state prisoners within each demographic group, by cause of death and decedent characteristics, 2001–19
msfp0119stt11.csv	Table 11. Mortality rate per 100,000 federal prisoners, by cause of death, 2001–2019
msfp0119stt12.csv	Table 12. Deaths of federal prisoners in federally and privately operated prison facilities, by cause of death, 2015–2019
msfp0119stt13.csv	Table 13. Deaths of federal prisoners in federally and privately operated prison facilities, by decedent characteristics, 2015–2019
msfp0119stt14.csv	Table 14. Number of deaths of state and federal prisoners, by jurisdiction, 2001–2019
msfp0119stt15.csv	Table 15. Mortality rate per 100,000 state and federal prisoners, by jurisdiction, 2001–2019
msfp0119stt16.csv	Table 16. Number of deaths of state and federal prisoners, by cause of death and jurisdiction, 2001–19
msfp0119stt17.csv	Table 17. Average annual mortality rate per 100,000 state and federal prisoners, by cause of death and jurisdiction, 2001–19
	
			Figures
msfp0119stf01.csv	Figure 1. Number of unnatural deaths of state prisoners, by cause of death, 2001–2019
msfp0119stf02.csv	Figure 2. Mortality rate per 100,000 state and federal prisoners, 2001–2019
msfp0119stf03.csv	Figure 3. Adjusted illness mortality rate per 100,000 U.S. residents, by cause of death, 2019
msfp0119stf04.csv	Figure 4. Adjusted rate of unnatural deaths per 100,000 U.S. residents, by cause of death, 2019
msfp0119stf05.csv	Figure 5. Mortality rate per 100,000 state prisoners, by race or ethnicity, 2009 and 2019
	
			Appendix tables
msfp0119stat01.csv	Appendix Table 1. Estimated number of state and federal prisoners in custody, by prisoner characteristics, 2001–2019
msfp0119stat02.csv	Appendix Table 2. Illness mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
msfp0119stat03.csv	Appendix Table 3. Cancer mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
msfp0119stat04.csv	Appendix Table 4. Heart disease mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
msfp0119stat05.csv	Appendix Table 5. Liver disease mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
msfp0119stat06.csv	Appendix Table 6. Respiratory disease mortality rate per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
msfp0119stat07.csv	Appendix Table 7. Mortality rate due to all other illnesses per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
msfp0119stat08.csv	Appendix Table 8. Rate of unnatural deaths per 100,000 state prisoners within each demographic group, by decedent characteristics, 2003–2019 (3-year rolling averages)
