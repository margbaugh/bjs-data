Probation and Parole in the United States, 2002, NCJ 201135


This zip archive contains tables in individual .wk1 spreadsheets
from Probation and Parole in the United States, 2002, NCJ 201135.
The full report including text and graphics in pdf format 
are available from:http://www.ojp.usdoj.gov/bjs/abstract/ppus02.htm

This report is one in a series.  More recent editions 
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#Probation

ppus02highlights.wk1	Persons under adult correctional supervision, 1995-2002
ppus0201.wk1		Table 1. Community corrections among the States, yearend 2002
ppus0202.wk1		Table 2. Adults on probation, 2002
ppus0203.wk1		Table 3. Change in the number of adults on probation, 1995-2002
ppus0204.wk1		Table 4. Characteristics of adults on probation, 1995, 2000, and 2002
ppus0205.wk1		Table 5. Adults on parole, 2002
ppus0206.wk1		Table 6. Change in the number of adults on parole, 1995-2002
ppus0207.wk1		Table 7. Characteristics of adults on parole, 1995, 2000, and 2002
ppus0208.wk1		Table 8. Total under adults correctional supervision and number supervised per 100,000 adult residents, by jurisdiction, yearend 2002

	Text tables
ppus02tt01.wk1		Text Table 1. Lowest rates of community supervision among the States, 2002
ppus02tt02.wk1		Text Table 2. Entries to probation, 1995-2002
ppus02tt03.wk1		Text Table 3. Ten States with the highest correctional and probation supervision rates