Probation and Parole in the United States, 2016	

This zip archive contains tables in individual .csv spreadsheets from		
Probation and Parole in the United States, 2016 NCJ 251148.  The full report including text		
and graphics in pdf format is available from https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6188
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=42		
		
		
Filename		Table title
ppus16t01.csv		Table 1. Adults under community supervision on probation or parole, year-end, 2000-2016
ppus16t02.csv		Table 2. Rates of U.S. adult residents on community supervision, probation, and parole, 2000, 2005, and 2010-2016
ppus16t03.csv		Table 3. Parolees on probation excluded from the January 1 and December 31 community supervision populations, 2008-2016
ppus16t04.csv		Table 4. One-day difference based on reporting changes for probation and parole, 2000�2016
		
			Figure title		
ppus16f01.csv		Figure 1. Adults under community supervision, probation, and parole on December 31, 2000�2016
ppus16f02.csv		Figure 2. Annual percent change of adults on probation on December 31, 2000�2016
ppus16f03.csv		Figure 3. Annual percent change of adults on parole on December 31, 2000�2016
ppus16f04.csv		Figure 4. Estimated total probation movements, entries, and exits, 2000�2016
ppus16f05.csv		Figure 5. Estimated total parole movements, entries, and exits, 2000�2016
		
			Appendix table title 		
ppus16at01.csv		Appendix table 1. Adults under community supervision, 2016
ppus16at02.csv		Appendix table 2. Adults on probation, 2016
ppus16at03.csv		Appendix table 3. Adults exiting probation, by type of exit, 2016
ppus16at04.csv		Appendix table 4. Characteristics of adults on probation, 2000, 2015, and 2016
ppus16at05.csv		Appendix table 5. Adults on parole, 2016
ppus16at06.csv		Appendix table 6. Adults entering parole, by type of entry, 2016
ppus16at07.csv		Appendix table 7. Adults exiting parole, by type of exit, 2016 
ppus16at08.csv		Appendix table 8. Characteristics of adults on parole, 2000, 2015, and 2016

