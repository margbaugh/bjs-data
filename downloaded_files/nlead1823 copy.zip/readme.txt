National Law Enforcement Accountability Database, 2018–2023   NCJ 309614	
	
This zip archive contains tables in individual .csv spreadsheets for	
National Law Enforcement Accountability Database, 2018–2023   NCJ 309614	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/national-law-enforcement-accountability-database-2018-2023	
	
Filename		Table names
nlead1823t01.csv	Table 1. Number and percent of federal law enforcement agencies that submitted records to the National Law Enforcement Accountability Database for all officers or had zero qualifying incidents, by department, 2018–2023
nlead1823t02.csv	Table 2. Number and percent of federal law enforcement agencies that provided records to the National Law Enforcement Accountability Database for all officers or had zero qualifying incidents, by number of law enforcement officers, 2018–2023
nlead1823t03.csv	Table 3. Number of law enforcement officers and incidents in the National Law Enforcement Accountability Database, by department, 2018–2023
nlead1823t04.csv	Table 4. Number of Offices of Inspectors General reporting to the National Law Enforcement Accountability Database, 2018–2023
nlead1823t05.csv	Table 5. Number and percent of incidents reported to the National Law Enforcement Accountability Database by type, 2018–2023 
	
			Figures
nlead1823f01.csv	Figure 1. Number of officer misconduct records in the National Law Enforcement Accountability Database by year, 2018–2023
nlead1823f02.csv	Figure 2. Number of National Law Enforcement Accountability Database searches by month, January 1–August 31, 2024
	
			Appendix tables
nlead1823at01.csv	Appendix table 1. Number of officers for federal law enforcement agencies reporting to the National Law Enforcement Accountability Database, 2018–2023 
nlead1823at02.csv	Appendix table 2. Counts for figure 1: Number of officer misconduct records in the National Law Enforcement Accountability Database by year, 2018–2023
nlead1823at03.csv	Appendix table 3. Counts for figure 2: Number of National Law Enforcement Accountability Database searches by month, January 1–August 31, 2024