Asian, Native Hawaiian, and, Pacific Islander Victims of Crime NCJ 225037	

This zip archive contains tables in individual .csv spreadsheets from Asian, Native Hawaiian, and Pacific Islander Victims of Crime, NCJ 225037. The full report including text and graphics in pdf format is available at: http://www.ojp.usdoj.gov/bjs/abstract/anhpivc.htm.          	

                        Figures		
anhpivcf01.csv		Figure 1. Violent victimization of Asians and non-Asians, 1993-2006
anhpivcf02.csv		Figure 2. Violent Victimization of Asians, by victim gender, 1993-2006
anhpivcf03.csv		Figure 3. Asian homicide victims, by gender, 1993-2006
anhpivcf04.csv		Figure 4. Property victimzation for Asian and non-Asian households, 1993-2006

                        Tables		
anhpivct01.csv		Table 1. Average annual numbers and rates of violent and household property victimization for Asian/Native Hawaiian/other Pacific Islanders and non-Asians, by type of crime, 2002-2006
anhpivct02.csv		Table 2. Average annual violent victimization rate by race/Hispanic origin and type of crime, 2002-2006
anhpivct03.csv		Table 3. Violent victimization rate for Asians and non-Asians, by gender, age, and marital status, 2002-2006
anhpivct04.csv		Table 4. Violent victimization rate of Asians and non-Asians, by annual household income and region, 2002-2006
anhpivct05.csv		Table 5. Victim/offender relationships in violent crime, Asians and non-Asians, 2002-2006
anhpivct06.csv		Table 6. Percent of violent victimizations reported to police, by race/Hispanic origin of victim and type of crime, 2002-2006
anhpivct07.csv		Table 7. Average annual rate of property victimization, by race/Hispanic origin of head of household and type of crime, 2002-2006
anhpivct08.csv		Table 8. Rate of property victimization for Asian and non-Asian households, annual household income, and region, 2002-2006
anhpivct09.csv		Table 9. Percent of property victimizations reported to the police, by race/Hispanic origin of head of household and type of crime, 2002-2006

                        Text tables		
anhpivctt01.csv		Text table 1. Percent of violent crime that is serious, by race/Hispanic origin of the victim, 2002-2006
anhpivctt02.csv		Text table 2. Percent of violent crime in which victim perceived offender to be under influence of alcohol or drugs, by race/Hispanic origin of the victim, 2002-2006
anhpivctt03.csv		Text table 3. Percent of violent crime in which a weapon was present and percent of violent crime in which a firearm was present, by race/Hispanic origin of the victim, 2002-2006
anhpivctt04.csv		Text table 4. Percent of violent crime in which a victim was injured and percent of injured victims that were treated, by race/Hispanic origin of the victim, 2002-2006
