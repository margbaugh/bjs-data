Crime Against Persons with Disabilities, 2009-2011-Statistical Tables, NCJ 240299

 
This zip archive contains tables in individual .csv spreadsheets from
Crime Against Persons with Disabilities, 2009-2011-Statistical Tables, NCJ 240299

This report is one in a series. More recent editions may be
available. To view a list of all in the series go to: http://www.bjs.gov/index.cfm?ty=pbse&sid=65

The full electronic report is available at:
http://www.bjs.gov//index.cfm?ty=pbdetail&iid=4574

Filename		Table title
capd08t01.csv		Average annual number of violent crimes, by type of crime and victim's disability status, 2009-2011
capd08t02.csv		Unadjusted violent victimization rates, by victim's disability status and age, 2009-2011
capd08t03.csv		Age-adjusted and unadjusted rates of violent victimization for persons with disabilities, by type of crime, 2009-2011
capd08t04.csv		Age-adjusted and unadjusted rates of violent victimization for persons without disabilities, by type of crime, 2009-2011
capd08t05.csv		Age-adjusted rates of violent victimization, by victim's disability status, sex, race, and Hispanic origin, 2009-2011
capd08t06.csv		Percent of violence against persons with disabilities that involved victims with multiple disablity types, by type of crime, 2009-2011
capd08t07.csv		Age-adjusted rate of violent victimization, by type of crime and number of disability types, 2009-2011
capd08t08.csv		Unadjusted rate of violent victimization against persons with disabilities, by disability type, 2009-2011
capd08t09.csv		Unadjusted rate of serious violent victimization against persons with disabilities, by disability type, 2009-2011
capd08t10.csv		Unadjusted rate of simple assault of persons with disabilities, by disability type, 2009-2011
capd08t11.csv		Unadjusted violent victimization rate, by victim's sex and disability type, 2009-2011

Filename		Appendix table title
capd08at01.csv		Standard errors for average annual number of violent crimes, by type of crime and victim's disability status, 2009-2011
capd08at02.csv		Standard errors for unadjusted violent victimization rates, by victim's disability status and age, 2009-2011
capd08at03.csv		Standard errors for age-adjusted and unadjusted rates of violent victimization against persons with disabilities, by type of crime, 2009-2011
capd08at04.csv		Standard errors for age-adjusted and unadjusted rates of violent victimization against persons without disabilities, by type of crime, 2009-2011			
capd08at05.csv		Standard errors for age-adjusted rates of violent victimization, by victim's disability status, sex, race, and Hispanic origin, 2009-2011
capd08at06.csv		Standard errors for percent of violence against persons with disabilities that involved victims with multiple disability types, by type of crime, 2009-2011
capd08at07.csv		Standard errors for age-adjusted rate of violent victimization, by type of crime and number of disability types, 2009-2011
capd08at08.csv		Standard errors for unadjusted rate of violent victimization of persons with disabilities, by disability type, 2009-2011
capd08at09.csv		Standard errors for unadjusted rate of serious violent victimization of persons with disabilities, by disability type, 2009-2011
capd08at10.csv		Standard errors for unadjusted rate of simple assault of persons with disabilities, by disability type, 2009-2011
capd08at11.csv		Standard errors for unadjusted violent victimization rate, by victim's sex and disability type, 2009-2011
capd08at12.csv		Numbers and percentages of U.S. population, by the victim's disability status and demographic characteristics, 2008-2011
capd08at13.csv		U.S. residential population calculated and according to the Census Bureau's actual ACS estimates, by victim's disability status and demographic characteristics, 2010
capd08at14.csv		Standard errors for unadjusted rates of violent victimization, by type of crime and victim's disability status, 2009-2011
capd08at15.csv		Unadjusted rate of violent victimization, by victim's disability status and demographic characteristics, 2009-2011
capd08at16.csv		Standard errors for unadjusted rate of violent victimization, by victim's disability status and demographic characteristics, 2009-2011
capd08at17.csv		Unadjusted rates of violent victimization, by type of crime and victim's number of disability types, 2009-2011
capd08at18.csv		Standard errors for unadjusted rates of violent victimization, by type of crime and victim's number of disability types, 2009-2011