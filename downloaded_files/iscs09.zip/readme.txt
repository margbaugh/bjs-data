Indicators of School Crime and Safety:  2009  NCJ  228478

This Zip archive contains Figures in individual .csv spreadsheets		
from Indicators of School Crime and Safety:  2009  NCJ 228478.
The full report, including text and graphics in .pdf format are available from:		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=1762	

This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=8

Tables
iscs09t1_1.csv		Table 1.1.�Number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location and year: 1992�2008
iscs09t1_2.csv		Table 1.2.�Number of school-associated violent deaths of students, staff, and nonstudents, by type: 1992�2008
iscs09t2_.csv		Table 2.1.�Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students, by location, type of crime and year: 1992�2007
iscs09t2_2.csv		Table 2.2.�Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students at school, by type of crime and selected student and school characteristics: 2007
iscs09t2_3.csv		Table 2.3.�Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students away from school, by type of crime and selected student and school characteristics: 2007
iscs09t5_1.csv		Table 5.1.�Percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: Various school years, 1993�94 through 2007�08
iscs09t5_2.csv		Table 5.2.�Percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics:  Various school years, 1993�94 through 2007�08
iscs09t5_3.csv		Table 5.3.�Percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08  
iscs09t5_4.csv		Table 5.4.�Percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08 
iscs09t6_1.csv		Table 6.1.�Percentage of public schools recording and reporting incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime: Various school years, 1999�2000 through 2007�08
iscs09t6_2.csv		Table 6.2.�Percentage of public schools recording incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2007�08
iscs09t6_3.csv		Table 6.3.�Percentage of public schools reporting incidents of crime to the police, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2007�08
iscs09t6_5.csv		Table 6.5.�Percentage of public schools recording and reporting serious violent incidents of crime, by the number of incidents and selected school characteristics: School year 2007�08
iscs09t7_1.csv		Table 7.1.�Percentage of public schools reporting selected discipline problems that occurred at school, by frequency and school characteristics: School year 2007�08
iscs09t7_2.csv		Table 7.2.�Percentage of public schools reporting selected discipline problems that occurred at school, by frequency: Various school years, 1999�2000 through 2007�08
iscs09t12_1.csv		Table 12.1.�Percentage of public and private school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching, by selected teacher and school characteristics: Various school years, 1987�88 through 2007�08
iscs09t12_2.csv		Table 12.2.�Percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by selected teacher and school characteristics: Various school years, 1987�88 through 2007�08
iscs09t12_3.csv		Table 12.3.�Percentage of public school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching and that school rules are enforced by other teachers and by the principal, by state: School year 2007�08
iscs09t19_1.csv		Table 19.1.�Number and percentage of public schools that took a serious disciplinary action, number of serious actions taken, and percentage distribution of serious actions, by type of action and type of offense: School year 2007�08
iscs09t19_2.csv		Table 19.2.�Percentage of public schools that took a serious disciplinary action and number of serious actions taken, by type of offense: Various school years, 1999�2000 through 2007�08
iscs09t20_1.csv		Table 20.1.�Percentage of public schools that used safety and security measures: Various school years, 1999�2000 through 2007�08
iscs09t20_2.csv		Table 20.2.�Percentage of public schools that used selected safety and security measures, by school characteristics: School year 2007�08
iscs09st2_1.csv		Table S2.1.�Standard errors for the number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students, by location, type of crime and year: 1992�2007 
iscs09st2_2.csv		Table S2.2.�Standard errors for the number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students at school, by type of crime and selected student and school characteristics: 2007
iscs09st2_3.csv		Table S2.3.�Standard errors for the number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students away from school, by type of crime and selected student and school characteristics: 2007
iscs09st5_1.csv		Table S5.1.�Standard errors for the percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: Various school years, 1993�94 through 2007�08   
iscs09st5_2.csv		Table S5.2.�Standard errors for the percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: Various school years, 1993�94 through 2007�08
iscs09st5_3.csv		Table S5.3.�Standard errors for the percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08 
iscs09st5_4.csv		Table S5.4.�Standard errors for the percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08 
iscs09st6_1.csv		Table S6.1.�Standard errors for the percentage of public schools recording and reporting incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime: Various school years, 1999�2000 through 2007�08
iscs09st6_2.csv		Table S6.2.�Standard errors for the percentage of public schools recording incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2007�08
iscs09st6_3.csv		Table S6.3.�Standard errors for the percentage of public schools reporting incidents of crime to the police, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2007�08
iscs09st6_4.csv		Table 6.4.�Percentage of public schools recording and reporting violent incidents of crime, by the number of incidents and selected school characteristics: School year 2007�08
iscs09st6_5.csv		Table S6.5.�Standard errors for the percentage of public schools recording and reporting serious violent incidents of crime, by the number of incidents and selected school characteristics: School year 2007�08
iscs09st7_1.csv		Table S7.1.�Standard errors for the percentage of public schools reporting selected discipline problems that occurred at school, by frequency and school characteristics: School year 2007�08
iscs09st7_2.csv		Table S7.2.�Standard errors for the percentage of public schools reporting selected discipline problems that occurred at school, by frequency: Various school years, 1999�2000 through 2007�08
iscs09st12_1.csv	Table S12.1.�Standard errors for the percentage of public and private school teachers who agreed or strongly agreed that student misbehavior, student tardiness, class cutting interfered with their teaching, by selected teacher and school characteristics: Various school years, 1987�88 through 2007�08
iscs09st12_2.csv	Table S12.2.�Standard errors for the percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by selected teacher and school characteristics: Various school years, 1987�88 through 2007�08
iscs09st12_3.csv	Table S12.3.�Standard errors for the percentage of public school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching and that school rules are enforced by other teachers and by the principal, by state: School year 2007�08
iscs09st19_1.csv	Table S19.1.�Standard errors for the number and percentage of public schools that took a serious disciplinary action, number of serious actions taken, and percentage distribution of serious actions, by type of action and type of offense: School year 2007�08
iscs09st19_2.csv	Table S19.2.�Standard errors for the percentage of public schools that took a serious disciplinary action and number of serious actions taken, by type of offense: Various school years, 1999�2000 through 2007�08
iscs09st20_1.csv	Table S20.1.�Standard errors for the percentage of public schools that used safety and security measures: Various school years, 1999�2000 through 2007�08
iscs09st20_2.csv	Table S20.2.�Standard errors for the percentage of public schools that used selected safety and security measures, by school characteristics: School year 2007�08 


Figures		

iscs09f1_1.csv		Figure 1.1. Number of homicides and suicides of youth ages 5�18, by location: 2005�06
icsc09f1_2.csv		Figure 1.2. Number of homicides and suicides of youth ages 5�18 at school: 1992�2007
iscs09f2_1.csv		Figure 2.1. Rate of student-reported nonfatal crimes against students ages 12-18 per 1,000 students, by age and type of crime: 2006
iscs09f2_2.csv		Figure 2.2. Rate of student-reported nonfatal crimes against students ages 12-18 away from school per 1,000 students, by type of crime and selected student characteristics: 2006
iscs09f3_1.csv		Figure 3.1. Percentage of students ages 12-18 who reported criminal victimization at school during the previous 6 months, by type of victimization:  Various years, 1995-2007
iscs09f4_1.csv		Figure 4.1. Percentage of students in grades 9-12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by sex: Various years, 1993-2007
iscs09f4_2.csv		Figure 4.2. Percentage of students in grades 9-12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by grade: 2007
iscs09f5_1.csv		Figure 5.1. Percentage of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs09f5_2.csv		Figure 5.2. Percentage of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04
iscs09f6_1.csv		Figure 6.1. Percentage of public schools experiencing and reporting incidents of crime, number of incidents, and the rate of crimes per 1,000 students, by type of crime: Various school years, 1999�2000, 2003�04, and 2005�06
iscs09f6_2.csv		Figure 6.2. Percentage of public schools experiencing and reporting to the police violent and serious violent incidents of crime, by the number of incidents: School year 2005�06
iscs09f6_3.csv		Figure 6.3. Percentage of public schools experiencing and reporting to the police incidents of crime,by type of crime: Various school years, 1999�2000, 2003�04, and 2005�06	
iscs09f7_1.csv		Figure 7.1. Percentage of public schools reporting selected discipline problems that occurred at school, by frequency: Various school years, 1999-2000,  2003-04, and 2005-06
iscs09f8_1.csv		Figure 8.1. Percentage of students ages 12�18 who reported that gangs were present at school, by school sector and race/ethnicity: 2007
iscs09f8_2.csv		Figure 8.2. Percentage of students ages 12-18 who reported that gangs were present at school during the previous 6 months, by sex: Various years 2001-07
iscs09f9_1.csv		Figure 9.1. Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by sex: Various years, 1993�2007
iscs09f9_2.csv		Figure 9.2. Percentage of students in grades 9�12 who reported that drugs were made available to them on school property during the previous 12 months, by race/ethnicity: 2007
iscs09f10_1.csv		Figure 10.1. Percentage of students ages 12�18 who reported being targets of hate-related words and seeing hate-related graffiti at school, by selected student and school characteristics: 2007
iscs09f10_2.csv		Figure 10.2. Percentage of students ages 12-18 who reported being targets of hate-related words or seeing hate-related graffiti at school during the previous 6 months, by type of hate-related word: 2007
iscs09f11_1.csv		Figure 11.1. Percentage of students ages 12-18 who reported being bullied at school and being cyber-bullied anywhere during the previous school year, by sex: 2007
iscs09f11_2.csv		Figure 11.2. Percentage of students ages 12-18 who reported selected bullying problems at school and cyber-bullying problems anywhere during the previous 6 months, by type of bullying: 2007
iscs09f11_3.csv		Figure 11.3. Percentage of students ages 12-18 who reported being bullied at school during the previous 6 months, by location of bullying, injury, and sex: 2007
iscs09f11_4.csv		Figure 11.4. Percentage of students ages 12-18 who reported being bullied at school and being cyber-bullied anywhere by the frequency of bullying at school during the school year and percentage of students who notified an adult: 2007
iscs09f12_1.csv		Figure 12.1.  Percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by school level: 2003-04
iscs09f12_2.csv		Figure 12.2.  Percentage of public and private school teachers who agreed or strongly agreed that student misbehavior interfered with their teaching, by sector: Various school years, 1987-88 through 2003-04
iscs09f13_1.csv		Figure 13.1. Percentage of students in grades 9-12 who reported having been in a physical fight during the previous 12 months, by location and sex:  Various years 1993-2007
iscs09f13_2.csv		Figure 13.2. Percentage of students in grades 9-12 who reported having been in a physical fight during the previous 12 months, by location and grade: 2007
iscs09f14_1.csv		Figure 14.1. Percentage of students in grades 9-12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and sex:  Various years 1993-2007
iscs09f14_2.csv		Figure 14.2. Percentage of students in grades 9-12 who reported carrying a weapon at least 1 day during the previous 30 days, by location andgrade: 2007
iscs09f15_1.csv		Figure 15.1. Percentage of students in grades 9-12 who reported using alcohol during the previous 30 days, by location and sex: Various years 1993-2007
iscs09f15_2.csv		Figure 15.2. Percentage of students in grades 9-12 who reported using alcohol during the previous 30 days, by location and grade: 2007
iscs09f16_1.csv		Figure 16.1. Percentage of students in grades 9-12 who reported using marijuana during the previous 30 days, by location and sex: Various years 1993-2007
iscs09f16_2.csv		Figure 16.2. Percentage of students in grades 9-12 who reported using marijuana during the previous 30 days, by location and grade: 2007
iscs09f17_1.csv		Figure 17.1. Percentage of students ages 12�18 who reported being afraid of attack or harm during the previous 6 months, by location and race/ethnicity: 2007
iscs09f17_2.csv		Figure 17.2. Percentage of students ages 12-18 who reported being afraid of attack or harm during the previous 6 months, by location and school sector: Various years, 1995-2007 
iscs09f18_1.csv		Figure 18.1. Percentage of students ages 12�18 who reported avoiding school activities or one or more places in school during the previous 6 months because of fear of attack or harm during the school year: 2007
iscs09f18_2.csv		Figure 18.2. Percentage of students ages 12�18 who reported avoiding one or more places in school during the previous 6 months because of fear of attack or harm, by grade level and school sector: 2007
iscs09f19_1.csv		Figure 19.1. Percentage of public schools that took a serious disciplinary action for specific offenses, by type of offense:  2005-2006
iscs09f19_2.csv		Figure 19.2. Percentage of public schools that took a serious disciplinary action, by type of offense:  1999-2000, 2003-04, and 2005-06
iscs09f20_1.csv		Figure 20.1. Percentage of public schools that used selected safety and security measures: 2005-06
iscs09f20_2.csv		Figure 20.2. Percentage of public schools that used selected safety and security measures: 1999-2000, 2003-04, and 2005-06
iscs09f21_1.csv		Figure 21.1. Percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999-2007
iscs09t01_1.csv		Table 1.1. Number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location: 1992�2006
iscs09t1_2.csv		Table 1.2. Number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location: 1992�2006	
iscs09t2_1.csv		Table 2.1. Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students, by location, type of crime and year: 1992�2006	
iscs09t2_2.csv		Table 2.2. Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students at school, by type of crime and selected student and school characteristics: 2006
iscs09t2_3.csv		Table 2.3.Number of student-reported nonfatal crimes against students ages 12�18 and rate of crimes per 1,000 students away from school, by type of crime and selected student and school characteristics: 2006
iscs09t5_1.csv		Table 5.1. Percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher and school characteristics: 1993�94, 1999�2000, and 2003�04	

