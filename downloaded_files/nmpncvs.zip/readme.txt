A New Measure of Prevalence for the National Crime Victimization Survey   NCJ 307554																					
																					
This zip archive contains tables in individual  .csv spreadsheets																					
from A New Measure of Prevalence for the National Crime Victimization Survey   NCJ 307554.  The full report including text																					
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/new-measure-prevalence-national-crime-victimization-survey																					
																					
																					
Filenames	Table titles																				
nmpncvst01.csv	Table 1. Percent of persons who were victims of violent crime, by type of crime and prevalence estimation method, 2018–2022																				
nmpncvst02.csv	Table 2. Percent of persons who were victims of violent crime, by victim demographic characteristics and prevalence estimation method, 2021 and 2022																				
nmpncvst03.csv	Table 3. Percent of households victimized, by type of property crime and prevalence estimation method, 2018–2022																				
																					
		Figures																				
nmpncvsf01.csv	Figure 1. Percent of persons age 12 or older who were victims of violent crime, by prevalence estimation method, 1993–2022
																					
		Appendix tables																				
nmpncvsat01.csv	Appendix table 1. Estimates and standard errors for figure 1: Percent of persons age 12 or older who were victims of violent crime, by prevalence estimation method, 1993–2022																				
nmpncvsat02.csv	Appendix table 2. Standard errors for table 1: Percent of persons who were victims of violent crime, by type of crime and prevalence estimation method, 2018–2022																				
nmpncvsat03.csv	Appendix table 3. Standard errors for table 2: Percent of persons who were victims of violent crime, by victim demographic characteristics and prevalence estimation method, 2021 and 2022																				
nmpncvsat04.csv	Appendix table 4. Standard errors for table 3: Percent of households victimized, by type of property crime and prevalence estimation method, 2018–2022																				
																					
																					
																					
																					
