Federal Law Enforcement Officers, 2008  NCJ 238250										
										
This zip archive contains tables in individual .csv spreadsheets										
Federal Law Enforcement Officers, 2008  NCJ 238250										
The full report including text and graphics in .pdf format are available from:										
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4372										
										
This report is one in a series. More recent editions may be available. To 										
view a list of all in the series go to the 
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=25										
										
fleo08t01.csv		Table 1. Federal agencies employing 250 or more full-time personnel with arrest and firearm authority, September 2008								
fleo08t02.csv		Table 2. Federal agencies employing fewer than 250 full-time personnel with arrest and firearm authority, September 2008								
fleo08t03.csv		Table 3. Offices of inspectors general employing full-time personnel with arrest and firearm authority, September 2008								
fleo08t04.csv		Table 4. Female and minority federal officers in agencies employing 500 or more full-time officers, September 2008								
fleo08t05.csv		Table 5. Female and minority representation among personnel with arrest and firearm authority in offices of inspectors general with 50 or more full-time investigators, September 2008								
fleo08t06.csv		Table 6. Assaults on federal officers with arrest and firearm authority, 2008								
fleo08at01.csv		Appendix table 1. Number of full-time federal officers with arrest and firearm authority, by job function and primary state of employment, September 2008								
fleo08at02.csv		Appendix table 2. Number of full-time federal officers with arrest and firearm authority per 100,000 residents, by job function and primary state of employment, September 2008								
fleo08at03.csv		Appendix table 3. Full-time federal officers with arrest and firearm authority in the U.S. Territories and Commonwealths, by location, agency, and function, September 2008								
fleo08at04.csv		Appendix table 4. Department and branch of federal agencies employing full-time officers with authority to carry firearms and make arrests, by primary place of employment, September 2008								
fleo08at05.csv		Appendix table 5. Female and minority representation among federal officers with arrest and firearm authority in agencies employing 50 to 499 officers, September 2008 								
fleo08f01.csv		Figure 1. Primary function of full-time Federal officers with arrest and firearm authority, September 2008								
fleo08f02.csv		Figure 2. Percent of federal officers with arrest and firearm authority, by department or branch of government, September 2008								
fleo08f03.csv		Figure 3. Growth in U.S. Border Patrol employment of officers with arrest and firearm authority, 1996 - 2008								
fleo08f04.csv		Figure 4. Percent of female and minority federal officers with arrest and firearm authority, 1996 and 2008								
										
										
										
										
										
										
										
										
										
										
										
 										
