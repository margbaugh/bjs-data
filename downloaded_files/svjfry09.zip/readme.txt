Sexual Victimization in Juvenile Facilities Reported by Youth, 2008-09 NCJ 228416

This zip archive contains tables in individual .csv spreadsheets
from Sexual Victimization in Juvenile Facilities Reported by Youth, 2008-09. 
The full electronic report is available at:

https://ojprdcweb57/index.cfm?ty=pbdetail&iid=2113


Tables:
svjfry09t01.csv		Table 1.  Youth reporting sexual victimization, by type of incident, National Survey of Youth in Custody, 2008-09
svjfry09t02.csv		Table 2.  Juvenile facilities with high rates of sexual victimization, by type of consent, National Survey of Youth in Custody, 2008-09
svjfry09t03.csv		Table 3.  Juvenile facilities with low rates of sexual victimization, by type of consent, National Survey of Youth in Custody, 2008-09
svjfry09t04.csv		Table 4.  Juvenile facilities with the highest rates of sexual victimization, by type of consent and contact, National Survey of Youth in Custody, 2008-09
svjfry09t05.csv		Table 5.  Juvenile facilities with the highest rates of sexual victimization, by type of consent and incident, National Survey of Youth in Custody, 2008-09
svjfry09t06.csv		Table 6.  Juvenile facilities with the highest rates of staff sexual misconduct, by type of consent and use of force by facility staff, National Survey of Youth in Custody, 2008-09
svjfry09t07.csv		Table 7.  Prevalence of sexual victimization, by type of incident and selected facility characteristics, National Survey of Youth in Custody, 2008-09
svjfry09t08.csv		Table 8.  Prevalence of sexual victimization, by type of incident and selected youth victim characteristics, National Survey of Youth in Custody, 2008-09
svjfry09t09.csv		Table 9.  Experiences of youth-on-youth victims of sexual victimization, National Survey of Youth in Custody, 2008-09
svjfry09t10.csv		Table 10. Circumstances surrounding youth-on-youth sexual victimization, National Survey of Youth in Custody, 2008-09
svjfry09t11.csv		Table 11. Victims of staff sexual misconduct, by gender of youth and staff and use of force, National Survey of Youth in Custody, 2008-09
svjfry09t12.csv		Table 12. Circumstances surrounding incidents of staff sexual misconduct, National Survey of Youth in Custody, 2008-09


Appendix Tables: 
svjfry09at01.csv	Appendix Table 1. Characteristics of juvenile facilities participating in the National Survey of Youth in Custody, 2008-09
svjfry09at02.csv	Appendix Table 2. Percent of youth reporting sexual victimization, by facility, National Survey of Youth in Custody, 2008-09 
svjfry09at03.csv	Appendix Table 3. Percent of youth reporting sexual victimization by another youth, by type of incident and facility, National Survey of Youth in Custody, 2008-09
svjfry09at04.csv	Appendix Table 4. Percent of youth reporting staff sexual misconduct, by type of incident and facility, National Survey of Youth in Custody, 2008-09
svjfry09at05.csv	Appendix Table 5. Percent of youth reporting staff sexual misconduct excluding touching, by use of force and facility, National Survey of Youth in Custody, 2008-09
