Sheriffs’ Offices Personnel, 2020   NCJ 305200																	
																	
This zip archive contains tables in individual  .csv spreadsheets																	
Sheriffs’ Offices Personnel, 2020   NCJ 305200.  The full report including text																	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/sheriffs-offices-personnel-2020																																	
This report is one in a series.  More recent editions																	
may be available.  To view a list of all in the series go to																	
https://bjs.ojp.gov/library/publications/list?series_filter=Sheriffs%E2%80%99%20Offices																	
																	
Filenames	Table titles																
sop20t01.csv	Table 1. Full-time personnel in sheriffs’ offices, 1997–2020																
sop20t02.csv	Table 2. Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2020																
sop20t03.csv	Table 3. Sheriffs’ offices and full-time personnel, by size of office, 2020																
sop20t04.csv	Table 4. Sex of full-time sworn officers in sheriffs’ offices, by size of office, 2016 and 2020																
sop20t05.csv	Table 5. Race or Hispanic origin of full-time sworn officers in sheriffs’ offices, by size of office, 2016 and 2020
sop20t06.csv	Table 6. Race or Hispanic origin of full-time sworn officers in sheriffs’ offices, 1997–2020																
sop20t07.csv	Table 7. Sex and race or Hispanic origin of full-time sworn officers in sheriffs’ offices, by size of office, 2020
sop20t08.csv	Table 8. Sheriffs, intermediate supervisors, and first-line supervisors in sheriffs’ offices who were female, by size of office, 2020
sop20t09.csv	Table 9. Race or Hispanic origin of sheriffs, intermediate supervisors, and first-line supervisors in sheriffs’ offices, by size of office, 2020
sop20t10.csv	Table 10. Primary job responsibility of full-time personnel in sheriffs’ offices, by size of office, 2020
sop20t11.csv	Table 11. Full-time personnel in sheriffs’ offices who were bilingual or multilingual, by size of office, 2020
sop20t12.csv	Table 12. Sheriffs’ offices with personnel designated to address specific crime-related issues, by size of office, 2020
sop20t13.csv	Table 13. Sheriffs’ offices with personnel designated to address specific functional areas, by size of office, 2020
sop20t14.csv	Table 14. Annual operating budgets of sheriffs’ offices, by size of office, 2020																
sop20t15.csv	Table 15. Base weights, nonresponse adjustments, and final weights for sheriffs’ offices, by stratum, 2020
sop20t16.csv	Table 16. Law Enforcement Management and Administrative Statistics survey response rates for sheriffs’ offices, by size of office, 2020	
																	
		Figures																
sop20f01.csv	Figure 1. Full-time personnel in sheriffs’ offices, 1997–2020																
sop20f02.csv	Figure 2. Percent of full-time sworn officers in sheriffs’ offices who were female, 1997–2020																
sop20f03.csv	Figure 3. Percent of sheriffs’ offices that adopted selected policies and procedures to address COVID-19, by size of office, yearend 2020
sop20f04.csv	Figure 4. Percent of sheriffs’ offices that reported a reduction in operations due to changes in policy or practice as a result of COVID-19, 2020 
																	
		Appendix tables																
sop20at01.csv	Appendix table 1. Standard errors for figure 1 and table 1: Full-time personnel in sheriffs’ offices, 1997–2020 					
sop20at02.csv	Appendix table 2. Standard errors for table 2: Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2020
sop20at03.csv	Appendix table 3. Standard errors for table 3: Sheriffs’ offices and full-time personnel, by size of office, 2020
sop20at04.csv	Appendix table 4. Standard errors for table 4: Sex of full-time sworn officers in sheriffs’ offices, by size of office, 2016 and 2020
sop20at05.csv	Appendix table 5. Estimates and standard errors for figure 2: Percent of full-time sworn officers in sheriffs’ offices who were female, 1997–2020
sop20at06.csv	Appendix table 6. Standard errors for table 5: Race or Hispanic origin of full-time sworn officers in sheriffs’ offices, by size of office, 2016 and 2020
sop20at07.csv	Appendix table 7. Standard errors for table 6: Race or Hispanic origin of full-time sworn officers in sheriffs’ offices, 1997–2020
sop20at08.csv	Appendix table 8. Standard errors for table 7: Sex and race or Hispanic origin of full-time sworn officers in sheriffs’ offices, by size of office, 2020
sop20at09.csv	Appendix table 9. Standard errors for table 8: Sheriffs, intermediate supervisors, and first-line supervisors in sheriffs’ offices who were female, by size of office, 2020
sop20at10.csv	Appendix table 10. Standard errors for table 9: Race or Hispanic origin of sheriffs, intermediate supervisors, and first-line supervisors in sheriffs’ offices, by size of office, 2020
sop20at11.csv	Appendix table 11. Estimates and standard errors for figure 3: Percent of sheriffs’ offices that adopted selected policies and procedures to address COVID-19, by size of office, yearend 2020
sop20at12.csv	Appendix table 12. Estimates and standard errors for figure 4: Percent of sheriffs’ offices that reported a reduction in operations due to changes in policy or practice as a result of COVID-19, 2020
sop20at13.csv	Appendix table 13. Standard errors for table 10: Primary job responsibility of full-time personnel, by size of office, 2020
sop20at14.csv	Appendix table 14. Standard errors for table 11: Full-time personnel in sheriffs’ offices who were bilingual or multilingual, by size of office, 2020
sop20at15.csv	Appendix table 15. Standard errors for table 12: Sheriffs’ offices with personnel designated to address specific crime-related issues, by size of office, 2020
sop20at16.csv	Appendix table 16. Standard errors for table 13: Sheriffs’ offices with personnel designated to address specific functional areas, by size of office, 2020
sop20at17.csv	Appendix table 17. Standard errors for table 14: Annual operating budgets of sheriffs’ offices, by size of office, 2020