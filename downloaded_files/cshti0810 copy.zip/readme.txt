Characteristics of Suspected Human Trafficking Incidents, 2008-2010		
		
This zip archive contains tables in individual  .csv spreadsheets from Characteristics of Suspected Human Trafficking Incidents, 2008-2010,  NCJ 233732.  The full report including text and graphics in pdf format are available from: http://www.bjs.gov//index.cfm?ty=pbdetail&iid=2372


This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=67


cshti0810t01.csv		Table 1. Human trafficking incidents opened for investigation between January 2008-June 2010, by type of trafficking
cshti0810t02.csv		Table 2. Human trafficking incident cases opened for investigation between January 2008 and June 2010, by type of trafficking and task force location
cshti0810t03.csv		Table 3. Agencies involved in human trafficking investigations between January 2008 and June 2010, by type of trafficking
cshti0810t04.csv		Table 4. Percent of incidents with valid information entered between January 2008 and June 2010, by quality of task force data
cshti0810t05.csv		Table 5. Victim characteristics in cases confirmed to be human trafficking by high-data quality task forces, by type of trafficking
cshti0810t06.csv		Table 6. Suspect characteristics in cases opened between and January 2008 and June 2009 and confirmed to be human trafficking by high data quality task forces, by type of trafficking
cshti0810t07.csv		Table 7. Outcome of human trafficking incidents opened for at least 12 months by high data quality task forces, by type of trafficking
cshti0810t08.csv		Table 8. Human trafficking incidents opened for at least 12 months by high dat quality task forces, by outcome
cshti0810t09.csv		Table 9. Victim and suspect outcomes in incidents opened between January 2008 and June 2009 and confirmed to be human trafficking by high data quality task forces, by type of trafficking
cshti0810t10.csv		Table 10. Human trafficking case characteristics by quality of task force data
		
cshti0810f01.csv		Figure 1. Cumulative number of incidents of human trafficking between January 2008 and June 2010, by suspected trafficking type and reported investigation start date
cshti0810f02.csv		Figure 2. Percentage of cases with valid data for critical variables, by number of months the cases were observed
 cshti0810f03.csv		Figure 3. Percentage of cases reaching confirmation outcome, by months observed and by task force data quality
cshti0810f04.csv		Figure 4. Percentage of cases reaching confirmation outcome, by months observed and ultimate confirmation status
cshti0810f05.csv		Figure 5. Suspected incidents of human trafficking, by reported investigation start date
