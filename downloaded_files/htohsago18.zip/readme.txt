Human-Trafficking Offenses Handled by State Attorneys General Offices, 2018 NCJ 254803		
		
This zip archive contains tables in individual  .csv spreadsheets from Human-Trafficking Offenses Handled by State Attorneys General Offices, 2018 NCJ 254803.  The full report including text and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=7266

This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=83		
		
Filenames		Table titles
htohsago18t01.csv	Table 1. Number of attorneys general offices that reported source of human-trafficking referrals, 2018
htohsago18t02.csv	Table 2. Number of attorneys general offices that handled human-trafficking cases, by type of case and victim, 2018
htohsago18t03.csv	Table 3. Number of attorneys general offices that pursued additional charges in human-trafficking cases, by type of case and charge, 2018
htohsago18t04.csv	Table 4. Number of attorneys general offices that closed criminal human-trafficking cases, by reason for closure, 2018
htohsago18t05.csv	Table 5. Number of attorneys general offices that had specialized support persons on staff or as consultants, by size of office and type of support person, 2018
htohsago18t06.csv	Table 6. Number of attorneys general offices that had specialized support persons on staff or as consultants, by type of human-trafficking jurisdiction and support person, 2018
htohsago18t07.csv	Table 7. Number of attorneys general offices that trained other entities in human-trafficking awareness, by size of office and type of entity trained, 2018
htohsago18t08.csv	Table 8. Number of attorneys general offices that trained other entities in human-trafficking awareness, by type of human-trafficking jurisdiction and entity trained, 2018
htohsago18t09.csv	Table 9. Number of attorneys general offices that participated in human-trafficking task forces, by size of office and type of task force, 2018
htohsago18t10.csv	Table 10. Number of attorneys general offices that participated in human-trafficking task forces, by type of human-trafficking jurisdiction and task force, 2018
htohsago18t11.csv	Table 11. Number of attorneys general offices that reported type of resource needed to improve human-trafficking prosecutions, by importance of resource, 2018
		
			Figure names
htohsago18f01.csv	Figure 1. Number of attorneys general offices that reported assistant attorneys general on staff, 2018
htohsago18f02.csv	Figure 2. Number of attorneys general offices that reported type of offender in human-trafficking cases, 2018
htohsago18f03.csv	Figure 3. Number of attorneys general offices that reported type of victim in human-trafficking cases, by type of case, 2018
htohsago18f04.csv	Figure 4. Number of attorneys general offices that offered victim services, 2018
		
			Appendix tables
htohsago18at01.csv	Appendix table 1. Jurisdiction of attorneys general offices over labor trafficking, 2018
htohsago18at02.csv	Appendix table 2. Jurisdiction of attorneys general offices over sex trafficking, 2018
htohsago18at03.csv	Appendix table 3. Number of attorneys general offices that reported assistant attorneys general on staff, 2018
		
		
		
