State and Local Law Enforcement Training Academies, 2013,  NCJ 249784			
			
This zip archive contains tables in individual  .csv spreadsheets			
from the reissue of State and Local Law Enforcement Training Academies, 2013, NCJ 249784.  The full report including text			
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/state-and-local-law-enforcement-training-academies-2013

This report is one in a series. There may be a more recent edition. For the full series go to https://bjs.ojp.gov/library/publications/list?series_filter=State%20and%20Local%20Law%20Enforcement%20Training%20Academies	

See https://bjs.ojp.gov/library/publications/data-corrections for notes on changes to this report.	
			
Filename			Table title
slleta13t01.csv			Table 1. Number of state and local law enforcement training academies providing basic training, by type of academy, 2013
slleta13t02.csv			Table 2. Training environment of state and local law enforcement training academies, by type of academy, 2013 
slleta13t03.csv			Table 3. Median number of basic training classes and average class size, by type of academy, 2011�13
slleta13t04.csv			Table 4. Average number of recruits starting basic training programs annually in state and local law enforcement training academies, by type of academy, 2011�13
slleta13t05.csv			Table 5. Duration of basic training programs in state and local law enforcement training academies, by type of academy, 2013
slleta13t06.csv			Table 6. Major subject areas included in basic training programs in state and local law enforcement training academies, 2013
slleta13t07.csv			Table 7. Instruction on how to identify and respond to excessive force used by other officers included in basic training programs in state and local law enforcement training academies, by type of academy, 2013
slleta13t08.csv			Table 8. Community policing topics in basic training programs in state and local law enforcement training academies, 2013
slleta13t09.csv			Table 9. Special topics included in basic training programs in state and local law enforcement training academies, 2013
slleta13t10.csv			Table 10. Types of instructors employed by state and local law enforcement training academies, 2013
slleta13t11.csv			Table 11. State and local law enforcement training academies and instructors, by size of academy, 2013
slleta13t12.csv			Table 12. Minimum years of law enforcement experience required for full-time instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13t13.csv			Table 13. College degree requirements for full-time instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13t14.csv			Table 14. Types of tests used to evaluate basic recruits in state and local law enforcement training academies, 2011�13
slleta13t15.csv			Table 15. Completion rates for recruits who started basic training programs in state and local law enforcement training academies, by type of academy, 2011�13
slleta13t16.csv			Table 16. Primary reason for failure of recruits to complete basic training programs in state and local law enforcement training academies by sex, 2011�13
slleta13t17.csv			Table 17. Response rates for the 2013 Census of Law Enforcement Training Academies, by type of academy
slleta13t18.csv			Table 18. Item response rates for the 2013 Census of Law Enforcement Training Academies

			
Figures			
slleta13f01.csv			Figure 1. Distribution of recruits in basic training programs in state and local law enforcement training academies, by type of training environment, 2011�13
slleta13f02.csv			Figure 2. Recruits entering basic training programs in state and local law enforcement training academies, by sex and race/Hispanic origin, 2005 and 2011�13 
slleta13f03.csv			Figure 3. Special types of firearms training provided in state and local law enforcement training academies, 2013
slleta13f04.csv			Figure 4. Techniques included in basic control/defensive tactics instruction in state and local law enforcement training academies, 2013
slleta13f05.csv			Figure 5. Types of reality-based (mock) scenarios used for basic use-of-force instruction in state and local law enforcement training academies, 2013
slleta13f06.csv			Figure 6. Types of reality-based (mock) scenarios used for basic use-of-force instruction in state and local law enforcement training academies, by stress level of training environment, 2013
slleta13f07.csv			Figure 7. Community policing topics covered in basic training programs in state and local law enforcement training academies, 2013 
slleta13f08.csv			Figure 8. Terrorism-related topics covered in basic training programs in state and local law enforcement training academies, 2013 
slleta13f09.csv			Figure 9. Average number of hours of basic training instruction required per recruit in state and local law enforcement training academies, 2006 and 2013
slleta13f10.csv			Figure 10. Curriculum development methods used by state and local law enforcement training academies, 2006 and 2013
slleta13f11.csv			Figure 11. Average number of full-time-equivalent instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13f12.csv			Figure 12. Completion rates for recruits in basic training programs in state and local law enforcement training academies, by sex and race/Hispanic origin, 2005�2006 and 2011�13
slleta13f13.csv			Figure 13. Primary reason for involuntary failure of recruits to complete basic training programs in state and local law enforcement training academies, by sex, 2011�13
			
Appendix tables			
slleta13at01.csv			Appendix table 1. Types of personnel trained by state and local law enforcement training academies, 2011�13
slleta13at02.csv			Appendix table 2. Facilities and resources of state and local law enforcement training academies, 2013
slleta13at03.csv			Appendix table 3. Special types of firearms training used in state and local law enforcement training academies, by type of academy, 2013
slleta13at04.csv			Appendix table 4. Types of control and defensive tactics instruction in basic training programs in state and local law enforcement training academies, by type of academy, 2013
slleta13at05.csv			Appendix table 5. Use of reality-based (mock) scenarios in state and local law enforcement training academies, by type of academy, 2013
slleta13at06.csv			Appendix table 6. Instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13at07.csv			Appendix table 7. Certification requirements for instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13at08.csv			Appendix table 8. Methods used to develop refresher training for instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13at09.csv			Appendix table 9. Methods used to evaluate instructors in state and local law enforcement training academies, by type of academy, 2013
slleta13at10.csv			Appendix table 10. Disciplinary actions that may be taken in response to violations of conduct rules in state and local law enforcement training academies, by type of academy, 2013
slleta13at11.csv			Appendix table 11. Standard errors for table 4: Average number of recruits starting basic training programs annually in state and local law enforcement training academies, by type of academy, 2011�13
slleta13at12.csv			Appendix table 12. Standard errors for table 10: Types of instructors employed by state and local law enforcement training academies, 2013
slleta13at13.csv			Appendix table 13. Standard errors for table 11: State and local law enforcement training academies and instructors, by size of academy, 2013
slleta13at14.csv			Appendix table 14. Standard errors for table 15: Completion rates for recruits who started basic training programs in state and local law enforcement training academies, by type of academy, 2011�13
slleta13at15.csv			Appendix table 15. Standard errors for table 16: Primary reason for failure of recruits to complete basic training programs in state and local law enforcement training academies, 2011�13
slleta13at16.csv			Appendix table 16. Estimates and standard errors for figure 1: Distribution of recruits in basic training programs in state and local law enforcement training academics, type of training environment, 2011�13
slleta13at17.csv			Appendix table 17. Estimates and standard errors for figure 2: Recruits entering basic training programs in state and local law enforcement training academies, by sex and race/Hispanic origin, 2005 and 2011�13
slleta13at18.csv			Appendix table 18. Estimates and standard errors for figure 12: Completion rates for recruits in basic training programs in state and local law enforcement training academies, by sex and race/Hispanic origin, 2005�2006 and 2011�13
slleta13at19.csv			Appendix table 19. Estimates and standard errors for figure 13: Primary reason for involuntary failures recruits to complete basic training programs in state and local law enforcement training academies, by sex, 2011�13
