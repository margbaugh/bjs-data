Sexual Victimization Reported by Adult Correctional Authorities, 2009-11 NCJ 243904	
	
This zip archive contains tables in individual .csv spreadsheets from		
Sexual Victimization Reported by Adult Correctional Authorities, 2009-11 NCJ 243904			
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4882		
		
		
Filename			Appendix table title
svraca0911at01.csv		Appendix table 1. Standard errors for table 1: National estimates of total allegations of sexual victimization, by type of facility, 2005�11
svraca0911at02.csv		Appendix table 2. Standard errors for table 2: Rates per 1,000 inmates of allegations of sexual victimization, by type of facility, 2005�11
svraca0911at03.csv		Appendix table 3. Standard errors for table 3: National estimates of total allegations of sexual victimization, by type of incident, 2005�11
svraca0911at04.csv		Appendix table 4. Standard errors for table 4: National estimates of outcomes of investigations into allegations of sexual violence, by type of facility, 2009�11
svraca0911at05.csv		Appendix table 5. Standard errors for table 5: National estimates of substantiated incidents of sexual victimization, by type of facility, 2005�11
svraca0911at06.csv		Appendix table 6. Standard errors for table 6: Rates per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2005�11
svraca0911at07.csv		Appendix table 7. Standard errors for table 7: National estimates of total substantiated incidents of sexual victimization, by type of incident, 2005�11
svraca0911at08.csv		Appendix table 8. Standard errors for table 8: Selected characteristics of  substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911at09.csv		Appendix table 9. Standard errors for table 9: Impact on victims and perpetrators of substantiated incidents of inmate-on-inmate sexual victimization, type of facility and incident, 2009�11
svraca0911at10.csv		Appendix table 10. Other characteristics of victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911at11.csv		Appendix table 11. Standard errors for appendix table 10: Other characteristics of victims and perpetrators in substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911at12.csv		Appendix table 12. Circumstances surrounding substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911at13.csv		Appendix table 13. Standard errors for appendix table 12: Circumstances surrounding substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911at14.csv		Appendix table 14. Standard errors for table 10: Selected characteristics of victims and staff involved in substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911at15.csv		Appendix table 15. Other characteristics of victims and staff involved in substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911at16.csv		Appendix table 16. Standard errors for appendix table 15: Other characteristics of victims and staff involved in substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911at17.csv		Appendix table 17. Standard errors for table 11: Characteristics of substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911at18.csv		Appendix table 18. Standard errors for table 12: Impact on victim and staff in substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911at19.csv		Appendix table 19. Standard errors for table 13: Selected characteristics of substantiated incidents of staff sexual misconduct and harassment, by sex of perpetrator, 2009-11
		
Filename		Figure title
svraca0911f01.csv		Figure 1. National estimates of total allegations and substantiated incidents of sexual victimization, 2005�11
		
Filename		Table title
svraca0911t01.csv		Table 1. National estimates of total allegations of sexual victimization, by type of facility, 2005�11
svraca0911t02.csv		Table 2. Rates per 1,000 inmates of allegations of sexual victimization, by type of facility, 2005�11
svraca0911t03.csv		Table 3. National estimates of total allegations of sexual victimization, by type of incident, 2005�11
svraca0911t04.csv		Table 4. National estimates of outcomes of investigations into allegations of sexual victimization, by type of facility, 2009�11
svraca0911t05.csv		Table 5. National estimates of substantiated incidents of sexual victimization, by type of facility, 2005�11
svraca0911t06.csv		Table 6. Rates per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2005�11
svraca0911t07.csv		Table 7. National estimates of total substantiated incidents of sexual victimization, by type of incident, 2005�11
svraca0911t08.csv		Table 8. Selected characteristics of  substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911t09.csv		Table 9. Impact on victims and perpetrators of substantiated incidents of inmate-on-inmate sexual victimization, by type of facility and incident, 2009�11
svraca0911t10.csv		Table 10. Selected characteristics of victims and staff involved in substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911t11.csv		Table 11. Characteristics of substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911t12.csv		Table 12. Impact on victim and staff in substantiated incidents of staff sexual misconduct and harassment, by type of facility and incident, 2009�11
svraca0911t13.csv		Table 13. Selected characteristics of substantiated incidents of staff sexual misconduct and harassment, by sex of perpetrator, 2009�11
