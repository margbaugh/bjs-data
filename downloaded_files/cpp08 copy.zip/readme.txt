Contacts between Police and the Public, 2008  NCJ 234599		
			
This zip archive contains tables in individual  .csv spreadsheets			
from Contacts between Police and the Public, 2008,  NCJ 234599.  The full report including text			
and graphics in pdf format is available from: 	http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2229
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=18
		
			
			
Filename			Table title
cpp08t01.csv			Table 1. Number of U.S. residents age 16 or older who had contact with police, by reason for contact, 2002, 2005, and 2008
cpp08t02.csv			Table 2. Reason for contact among U.S. residents age 16 or older who had contact with police, 2002, 2005, and 2008
cpp08t03.csv			Table 3. Percent of U.S. residents age 16 or older who had contact with police, by reason for contact, 2002, 2005, and 2008
cpp08t04.csv			Table 4. Number of U.S. residents age 16 or older who had contact with police, by demographic characteristics and reason for contact, 2002 and 2008
cpp08t05.csv			Table 5. Percent of U.S. residents age 16 or older who had contact with police, by demographic characteristics, 2002, 2005, and 2008
cpp08t06.csv			Table 6. Characteristics of U.S. residents age 16 or older with and without face-to-face police contact, 2002, 2005, and 2008
cpp08t07.csv			Table 7. Number of contacts between police and the public, by demographic characteristics, 2008
cpp08t08.csv			Table 8. Perceptions of police behavior during contact, by reason for contact and race/Hispanic origin of residents, 2008
cpp08t09.csv			Table 9. Drivers stopped by police, by demographic characteristics, 2002, 2005, and 2008
cpp08t10.csv			Table 10. Reasons police gave drivers for traffic stop, 2002, 2005, and 2008
cpp08t11.csv			Table 11. Drivers� perceptions of traffic stop legitimacy, by race/Hispanic origin and reason for stop, 2008
cpp08t12.csv			Table 12. Enforcement actions taken by police during traffic stops, by reason for stop, 2008
cpp08t13.csv			Table 13. Enforcement actions taken by police during traffic stops, by demographic characteristics of drivers, 2008
cpp08t14.csv			Table 14. Stopped drivers who were searched by police, by demographic characteristics, 2002, 2005, and 2008
cpp08t15.csv			Table 15. Type of search conducted by police during traffic stop and the outcome, 2008
cpp08t16.csv			Table 16. Actions taken by police during traffic stops, by time of day, 2008
cpp08t17.csv			Table 17. U.S. residents age 16 or older who experienced the use or threat of force by police at any time during the year, 2005 and 2008 
cpp08t18.csv			Table 18. Contacts with police in which force was used or threatened, by demographic characteristics, 2002, 2005, and 2008
cpp08t19.csv			Table 19. Persons who felt the threat or use of force against them by police was excessive, by demographic characteristics, 2008
cpp08t20.csv			Table 20. Types of force used or threatened by police, 2008   
cpp08t21.csv			Table 21. Persons who felt police threat or use of force against them was excessive, by type of force used or threatened, 2008
cpp08t22.csv			Table 22. Conduct of residents during police contacts in which force was used or threatened, 2008
cpp08t23.csv			Table 23. Reasons for contact with police in which force was used or threatened, 2008 
cpp08t24.csv			Table 24. Contacts with police in which force was used or threatened, by reason for contact, 2008
cpp08t25.csv			Table 25. Police actions during contacts with the public in which force was used or threatened, 2008
cpp08t26.csv			Table 26. Number of U.S. residents age 16 or older in the Police-Public Contact Survey, by demographic characteristics, 2002, 2005, and 2008
cpp08t26cont.csv		Table 26 (continued) Number of U.S. residents age 16 or older in the Police-Public Contact Survey, by demographic characteristics, 2002, 2005, and 2008cpp08t27.csv			Table 27. National estimates from the Police�Public Contact Survey, by demographic characteristics, 2002, 2005, and 2008
cpp08t27cont.csv		Table 27 (continued)  National estimates from the Police�Public Contact Survey, by demographic characteristics, 2002, 2005, and 2008
		
Figures			
cpp08f01.csv			Figure 1. Percent of U.S. residents age 16 or older who had face-toface contact with police, 1999�2008
			
Appendix tables			
cpp08at01.csv			Appendix table 1. Standard errors for number of U.S. residents age 16 or older who had contact with police, by reason for contact, 2002, 2005, and 2008			
cpp08at02.csv			Appendix table 2. Standard errors for reason for contact among U.S. residents age 16 or older who had contact with police, 2002, 2005, and 2008
cpp08at03.csv			Appendix table 3. Standard errors for percent of U.S. residents age 16 or older who had contact with police, by reason for contact, 2002, 2005, and 2008
cpp08at04.csv			Appendix table 4. Standard errors for number of U.S. residents age 16 or older who had contact with police, by demographic characteristics and reason for contact, 2002 and 2008
cpp08at05.csv			Appendix table 5. Standard errors for percent of U.S. residents age 16 or older who had contact with police, by demographic characteristics, 2002, 2005, and 2008
cpp08at06.csv			Appendix table 6. Standard errors for characteristics of U.S. residents age 16 or older with and without face-to-face police contact, 2002, 2005, and 2008
cpp08at07.csv			Appendix table 7. Standard errors for number of contacts between police and the public, by demographic characteristics, 2008
cpp08at08.csv			Appendix table 8. Standard errors for perceptions of police behavior during contact, by reason for contact and race/Hispanic origin of residents, 2008
cpp08at09.csv			Appendix table 9. Standard errors for drivers stopped by police, by demographic characteristics, 2002, 2005, and 2008
cpp08at10.csv			Appendix table 10. Standard errors for reasons police gave drivers for traffic stop, 2002, 2005, and 2008
cpp08at11.csv			Appendix table 11. Standard errors for drivers� perceptions of traffic stop legitimacy, by race/Hispanic origin and reason for stop, 2008
cpp08at12.csv			Appendix table 12. Standard errors for enforcement actions taken by police during traffic stops, by reason for stop, 2008
cpp08at13.csv			Appendix table 13. Standard errors for enforcement actions taken by police during traffic stops, by demographic characteristics of drivers, 2008
cpp08at14.csv			Appendix table 14. Standard errors for stopped drivers who were searched by police, by demographic characteristics, 2002, 2005, and 2008
cpp08at15.csv			Appendix table 15. Standard errors for type of search conducted by police during traffic stop and the outcome, 2008
cpp08at16.csv			Appendix table 16. Standard errors for actions taken by police during traffic stops, by time of day, 2008
cpp08at17.csv			Appendix table 17. Standard errors for U.S. residents age 16 or older who experienced the use or threat of force by police at any time during the year, 2005 and 2008 
cpp08at18.csv			Appendix table 18. Standard errors for contacts with police in which force was used or threatened, by demographic characteristics, 2002, 2005, and 2008
cpp08at19.csv			Appendix table 19. Standard errors for persons who felt the threat or use of force against them by police was excessive, by demographic characteristics, 2008
cpp08at20.csv			Appendix table 20. Standard errors for types of force used or threatened by police, 2008   
cpp08at21.csv			Appendix table 21. Standard errors for persons who felt police threat or use of force against them was excessive, by type of force used or threatened, 2008
cpp08at22.csv			Appendix table 22. Standard errors for conduct of residents during contacts with police in which force was used or threatened, 2008
cpp08at23.csv			Appendix table 23. Standard errors for reasons for contact with police in which force was used or threatened, 2008 
cpp08at24.csv			Appendix table 24. Standard errors for contacts with police in which force was used or threatened, by reason for contact, 2008
cpp08at25.csv			Appendix table 25. Standard errors for police actions during contacts with the public in which force was used or threatened, 2008
