Local Police Departments, 2016: Personnel   NCJ 252835		
		
This zip archive contains tables in individual  .csv spreadsheets		
Local Police Departments, 2016: Personnel   NCJ 252835  The full report including text		
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/local-police-departments-2016-personnel		
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
https://bjs.ojp.gov/library/publications/list?series_filter=Local%20Police%20Departments		
		
		
Filename		Tables
lpd16pt01.csv		Table 1. Full-time employees in local police departments, 1997-2016
lpd16pt02.csv		Table 2. Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2016
lpd16pt03.csv		Table 3. Local police departments and full-time employees, by size of agency, 2016
lpd16pt04.csv		Table 4. Local police departments and full-time employees, by size of population served, 2016
lpd16pt05.csv		Table 5. Sex of full-time sworn officers in local police departments, by size of population served, 2016
lpd16pt06.csv		Table 6. Race or ethnicity of full-time sworn officers in local police departments, by size of population served, 2016
lpd16pt07.csv		Table 7. Race or ethnicity among local police officers, 1997-2016
lpd16pt08.csv		Table 8. Sex and race or ethnicity of full-time sworn officers in local police departments, by size of population served, 2016
lpd16pt09.csv		Table 9. Percent of chiefs, intermediate supervisors, and first-line supervisors in local police departments who were female, by size of population served, 2016
lpd16pt10.csv		Table 10. Race or ethnicity of chiefs, intermediate supervisors, and first-line supervisors in local police departments, by size of population served, 2016
lpd16pt11.csv		Table 11. Full-time personnel in local police departments who were bilingual or multilingual, by size of population served, 2016
lpd16pt12.csv		Table 12. Full-time school resource officers in local police departments, by population served, 2016
lpd16pt13.csv		Table 13. Percent of local police departments with personnel designated to address specific crime-related issues, by size of population served, 2016
lpd16pt14.csv		Table 14. Percent of local police departments with personnel designated to specific functional areas, by size of population served, 2016
lpd16pt15.csv		Table 15. Base weights, non-response adjustments, and final weights for local police departments, by strata, 2016
lpd16pt16.csv		Table 16. Law Enforcement Management and Administrative Statistics survey response rates for local police departments, by size of agency, 2016
		
			Figures
lpd16pf01.csv		Figure 1. Full-time employees in local police departments, 1997-2016
lpd16pf02.csv		Figure 2. Average number of full-time-equivalent sworn local police officers per 1,000 residents, by size of population served, 2016
lpd16pf03.csv		Figure 3. Percent of full-time sworn local police officers who were female, 1997-2016
		
			Appendix tables
lpd16pat01.csv		Appendix table 1. Fifty largest local police departments in the United States, by number of full-time sworn officers, 2016
lpd16pat02.csv		Appendix table 2. Standard errors for figure 1 and table 1: Full-time employees in local police departments, 1997-2016
lpd16pat03.csv		Appendix table 3. Standard errors for table 2: Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2016
lpd16pat04.csv		Appendix table 4. Standard errors for table 3: Local police departments and full-time employees, by size of agency, 2016
lpd16pat05.csv		Appendix table 5. Standard errors for table 4: Local police departments and full-time employees, by size of population served, 2016
lpd16pat06.csv		Appendix table 6. Estimates and standard errors for figure 2: Average number of full-time-equivalent sworn local police officers per 1,000 residents, by size of population served, 2016
lpd16pat07.csv		Appendix table 7. Standard errors for table 5: Sex of full-time sworn officers in local police departments, by size of population served, 2016
lpd16pat08.csv		Appendix table 8. Estimates and standard errors for figure 3: Percent of full-time sworn local police officers who were female, 1997-2016
lpd16pat09.csv		Appendix table 9. Standard errors for table 6: Race or ethnicity of full-time sworn officers in local police departments, by size of population served, 2016
lpd16pat10.csv		Appendix table 10. Standard errors for table 7: Race or ethnicity among local police officers, 1997-2016
lpd16pat11.csv		Appendix table 11. Standard errors for table 8: Sex and race or ethnicity of full-time sworn officers in local police departments, by size of population served, 2016
lpd16pat12.csv		Appendix table 12. Standard errors for table 9: Percent of chiefs, intermediate supervisors, and first-line supervisors in local police departments who were female, by size of population served, 2016
lpd16pat13.csv		Appendix table 13. Standard errors for table 10: Race or ethnicity of chiefs, intermediate supervisors, and first-line supervisors in local police departments, by size of population served, 2016
lpd16pat14.csv		Appendix table 14. Standard errors for table 11: Full-time personnel in local police departments who were bilingual or multilingual, by size of population served, 2016
lpd16pat15.csv		Appendix table 15. Standard errors for table 12: Full-time school resource officers in local police departments, by population served, 2016
lpd16pat16.csv		Appendix table 16. Standard errors for table 13: Percent of local police departments with personnel designated to address specific crime-related issues, by size of population served, 2016
lpd16pat17.csv		Appendix table 17. Standard errors for table 14: Percent of local police departments with personnel designated to specific functional areas, by size of population served, 2016
