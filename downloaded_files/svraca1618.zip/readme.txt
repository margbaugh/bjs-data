Sexual Victimization Reported by Adult Correctional Authorities, 2016-2018  NCJ 255356	
	
This zip archive contains tables in individual .csv spreadsheets	
from Sexual Victimization Reported by Adult Correctional Authorities, 2016-2018  NCJ 255356	
The full report including text and graphics in pdf format is available from 	
https://bjs.ojp.gov/library/publications/sexual-victimization-reported-adult-correctional-authorities-2016-2018	
	
This report is one in a series.  More recent editions	
may be available. To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Data%20Collection%20Activities	
	
Filenames		Table titles
svraca1618t01.csv	Table 1. Allegations of sexual victimization, by type of facility, 2005 and 2010-2018
svraca1618t02.csv	Table 2. Rates per 1,000 inmates of allegations of sexual victimization, by type of facility, 2012-2018
svraca1618t03.csv	Table 3. Aggregated number of allegations, by type of victimization, outcome of investigation, and type of facility, 2016-2018
svraca1618t04.csv	Table 4. Aggregated percent of allegations, by type of victimization, outcome of investigation, and type of facility, 2016-18
svraca1618t05.csv	Table 5. Substantiated incidents of sexual victimization, by type of facility, 2012-2018
svraca1618t06.csv	Table 6. Rates per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2012-2018
svraca1618t07.csv	Table 7. Substantiated incidents of sexual victimization, by type of victimization, 2005 and 2010-2018
svraca1618t08.csv	Table 8. Aggregated number and rate of allegations and substantiated incidents of inmate-on-inmate sexual harassment, by type of facility, 2013-18
svraca1618t09.csv	Table 9. Aggregated allegations of inmate-on-inmate sexual harassment, by outcome of investigation and type of facility, 2016-18
	
			Figures
svraca1618f01.csv	Figure 1. Allegations and substantiated incidents of sexual victimization in adult correctional facilities, 2005-2018
svraca1618f02.csv	Figure 2. Allegations of sexual victimization in adult correctional facilities, by outcome of investigation, 2010-2018
svraca1618f03.csv	Figure 3. Allegations of sexual victimization in adult correctional facilities, by type of victimization, 2010-2018
svraca1618f04.csv	Figure 4. Allegations and substantiated incidents of inmate-on-inmate sexual harassment in adult correctional facilities, 2013-2018
	
			Appendix tables
svraca1618at01.csv	Appendix table 1. Nonresponding adult correctional facilities, by state, 2016-2018
svraca1618at02.csv	Appendix Table 2. Numbers and standard errors for figure 1: Allegations and substantiated incidents of sexual victimization in adult correctional facilities, 2005-2018
svraca1618at03.csv	Appendix Table 3. Numbers and standard errors for figure 2: Allegations of sexual victimization in adult correctional facilities, by outcome of investigation, 2010-2018
svraca1618at04.csv	Appendix Table 4. Standard errors for table 1: Allegations of sexual victimization, by type of facility, 2005 and 2010-2018
svraca1618at05.csv	Appendix Table 5. Standard errors for table 2: Rates per 1,000 inmates of allegations of sexual victimization, by type of facility, 2012-2018
svraca1618at06.csv	Appendix Table 6. Numbers and standard errors for figure 3: Allegations of sexual victimization in adult correctional facilities, by type of victimization, 2010-2018
svraca1618at07.csv	Appendix table 7. Standard errors for table 3: Aggregated number of allegations, by type of victimization, outcome of investigation, and type of facility, 2016-18
svraca1618at08.csv	Appendix Table 8. Standard errors for table 4: Aggregated percent of allegations, by type of victimization, outcome of investigation, and type of facility, 2016-18
svraca1618at09.csv	Appendix table 9. Standard errors for table 5: Substantiated incidents of sexual victimization, by type of facility, 2012-2018
svraca1618at10.csv	Appendix Table 10. Standard errors for table 6: Rates per 1,000 inmates of substantiated incidents of sexual victimization, by type of facility, 2012-2018
svraca1618at11.csv	Appendix Table 11. Standard errors for table 7: Substantiated incidents of sexual victimization, by type of victimization, 2005 and 2010-2018
svraca1618at12.csv	Appendix Table 12. Numbers and standard errors for figure 4: Allegations and substantiated incidents of inmate-on-inmate sexual harassment in adult correctional facilities, 2013-2018
svraca1618at13.csv	Appendix Table 13. Standard errors for table 8: Aggregated number and rate of allegations and substantiated incidents of inmate-on-inmate sexual harassment, by type of facility, 2013-18
svraca1618at14.csv	Appendix table 14. Standard errors for table 9: Aggregated allegations of inmate-on-inmate sexual harassment, by outcome of investigation and type of facility, 2016-18
