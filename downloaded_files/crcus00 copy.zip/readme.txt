Civil Rights Complaints in U.S. District Courts, 2000

This zip archive contains tables in individual .wk1 spreadsheets
from Civil Rights Complaints in U.S. District Courts, 2000, NCJ 193979.
 The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/crcus00.htm 
 
 
Table name           Table #
 
crc00t01.wk1         Table 1: Types of civil rights complaints filed in U.S. district courts, 1990-2000
crc00t02.wk1         Table 2.  Plantiff winners and awards in civil rights complaints terminated by trial in U.S. district courts, 1990-2000
crc00f01.wk1         Figure 1: Number of civil rights complaints as a portion of all civil cases filed in U.S. district courts, 1990-2000 
crc00f02.wk1         Figure 2: Plaintiff winners as percent of civil rights trials