Prison and Jail Inmates at Midyear 2006  NCJ 217675

This zip archive contains tables in individual .csv spreadsheets
from Prison and Jail Inmates at Midyear 2006  NCJ 217675
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/pjim05.htm


This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#pjmidyear
 
Tables	
pjim06t01.csv	Table 1: Number and percent change in prisoners under State or Federal jurisdiction
pjim06t02.csv	Table 2: Annual change in the number of prisoners under State or Federal jurisdiction, July 1-June 30 
pjim06t03.csv	Table 3: Number of State and Federal prisoners in the seven largest jurisdictions, June 30, 2006
pjim06t04.csv	Table 4: Increase in the number of State or Federal prisoners, by jurisdiction, July 1, 2005 to June 30, 2006
pjim06t05.csv	Table 5: Number of sentenced prisoners admitted and released from State or Federal jurisdiction, during calendar years 2000-2005
pjim06t06.csv	Table 6: Number of prisoners held in private facilities, June 30, 2000-2006
pjim06t07.csv	Table 7: Number of persons under age 18 held in State prisons, June 30, 2000-2006
pjim06t08.csv	Table 8: Prisoners under the jurisdiction of State or Federal correctional authorities, by gender, December 31, 2000, June 30, 2005, and 2006
pjim06t09.csv	Table 9: Number of inmates in local jails on June 30, 2000, 2005, and 2006
pjim06t10.csv	Table 10: Estimated number of jail inmates and jail incarceration rate, by gender, race, and Hispanic origin, June 30, 2006
pjim06t11.csv	Table 11: Gender, race, Hispanic origin, and conviction status of local jail inmates, June 30, 2000, 2005, and 2006
pjim06t12.csv	Table 12. Number of persons held in State or Federal prison or in local jails, 1995 and 2000-2006
pjim06t13.csv	Table 13. Number of inmates in State or Federal prisons and local jails by gender, race, Hispanic origin, and age, June 30, 2006
pjim06t14.csv	Table 14: Number of inmates in State or Federal prisons and local jails per 100,000 residents, by gender, race, Hispanic origin, and age, June 			30, 2006
	
Text tables	
pjim06tt02.csv	Text table 1. Jurisdictions with largest increases and decreases in prison population from June 30, 2005 to June 30, 2006
pjim06tt02.csv	Text table 2. State prison admissions, by type, 2000 to 2005
pjim06tt03.csv	Text table 3. Number of jail inmates and jail incarceration rate, 2000-2006 
	
Appendix tables	
pjim06at01.csv	Appendix table 1: Sentenced prisoners under the jurisdiction of State or Federal correctional authorities, June 30, 2005, to June 30, 2006
pjim06at02.csv	Appendix table 2: Prisoners under the jurisdiction of State or Federal correctional authorities, June 30, 2005, December 31, 2005, and June 30, 			2006
pjim06at03.csv	Appendix table 3: Number of sentenced prisoners admitted and released from State or Federal jurisdiction, by region and jurisdiction, 2000, and 			2004, and 2005
pjim06at04.csv	Appendix table 4: Prisoners held in private facilities, June 30, 2005 and 2006
pjim06at05.csv	Appendix table 5: Number of inmates under age 18 held in State prisons, by State and gender, June 30, 2005 and June 30, 2006
pjim06at06.csv	Appendix table 6: Number of noncitizens held in State or Federal prisons, by State and gender, June 30, 2005 and June 30, 2006
pjim06at07.csv	Appendix table 7: Rated capacity of local jails and percent of capacity occupied, 1995-2006
pjim06at08.csv	Appendix table 8: The 50 largest local jail jurisdictions: Number of inmates held, average daily population, and rated capacity, midyear 2004-06
pjim06at09.csv	Appendix table 9: Persons under jail supervision, by confinement status and type of program, midyear 2000, 2005, and 2006
pjim06at10.csv	Appendix table 10: Standard error estimates for the Annual Survey of Jails, 2006
pjim06at11.csv	Appendix table 11: Standard error estimates by selected characteristics, for the Annual Survey of Jails, 2006
pjim06at12.csv	Appendix table 12: Estimated percentages of local jail inmates having selected characteristics and ratio estimates of standard errors
	
Figures
pjim06hf01.csv	Highlight figure 1: Annual change in the total number of prison and jail inmates in custody and prison inmates in custody, 2000-2006
pjim06f01.csv	Figure 1: Annual percent change in the number of prisoners under State and Federal jurisdiction, June 30, 2000, to June 30, 2006
pjim06f02.csv	Figure 2. Percent change in the annual number of inmates in local jails, 2000-2006
pjim06f03.csv	Figure 3. Percent of capacity occupied, by size of jurisdiction, 2006
pjim06f04.csv	Figure 4. Annual change in rated capacity and in jail inmate population during the 12 months ending June 30, 2000-2006
pjim06f05.csv	Figure 5. Percent of total increase in custody due to jail inmates, 12-month period ending June 30, 2000-2006

 
 
