Household Burglary, 1994-2011  NCJ 241754		
		
This zip archive contains tables in individual .csv spreadsheets		
		
The full report including text and graphics in .pdf format are available from:		
http://www.bjs.gov//index.cfm?ty=pbdetail&iid=4657		
		
Filename		Table
		
hb9411t01.csv		Table 1. Items taken during completed household burglaries, by type of item, 1994, 2001, and 2011
hb9411t02.csv		Table 2. Police response to completed household burglary victimizations, 1994, 2001, and 2011
hb9411t03.csv		Table 3. Completed burglaries reported and not reported to police and an insurance company, by amount of loss, 1994, 2001, and 2011
hb9411t04.csv		Table 4. Households that experienced completed burglary, by head of household characteristics, 1994, 2001, and 2011
hb9411t05.csv		Table 5. Households that experienced completed burglary, by household characteristics, 1994, 2001, and 2011
hb9411t06.csv		Table 6. Households that experienced completed burglary, by household structural characteristics, 2004�2011
		
hb9411at01.csv		Appendix table 1. Household burglary, by type, 1994�2011
hb9411at02.csv		Appendix table 2. Standard errors for figure 1: Rate of household burglary, by type, 1994�2011
hb9411at03.csv		Appendix table 3. Standard errors for table 1: Items taken during completed household burglaries, by type of item, 1994, 2001, and 2011
hb9411at04.csv		Appendix table 4. Estimates and standard errors for figure 2: Dollar value of items and cash stolen during completed household burglaries resulting in loss of $1 or more, 1994�2011
hb9411at05.csv		Appendix table 5. Standard errors for table 2: Police responses to completed household burglary victimizations, 1994, 2001, and 2011
hb9411at06.csv		Appendix table 6. Estimates and standard errors for figure 3: Completed household burglaries reported to police, by amount of loss, 1994�2011
hb9411at07.csv		Appendix table 7. Estimates and standard errors for figure 4: Completed household burglaries reported to insurance companies, by amount of loss, 1994�2011
hb9411at08.csv		Appendix table 8. Standard errors for table 3: Completed burglaries reported and not reported to police and an insurance company, by amount of loss, 1994, 2001, and 2011
hb9411at09.csv		Appendix table 9. Standard errors for table 4: Households that experienced completed burglary, by head of household characteristics, 1994, 2001, and 2011
hb9411at10.csv		Appendix table 10. Standard errors for table 5: Households that experienced completed burglary, by household characteristics, 1994, 2001, and 2011
hb9411at11.csv		Appendix table 11. Standard errors for table 6: Households that experienced completed burglary, by household structural characteristics, 2004�2011
		
hb9411f01.csv		Figure 1. Rate of household burglary, by type, 1994�2011
hb9411f02.csv		Figure 2. Dollar value of items and cash stolen during completed household burglaries resulting in loss of $1 or more, 1994�2011
hb9411f03.csv		Figure 3. Completed household burglaries reported to police, by amount of loss, 1994�2011
hb9411f04.csv		Figure 4. Completed household burglaries reported to insurance companies, by amount of loss, 1994�2011
