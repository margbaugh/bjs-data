Jail Inmates at Midyear 2007  NCJ 221945

This zip archive contains tables in individual .csv spreadsheets
Jail Inmates at Midyear 2007  NCJ 221945
The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/jim07.htm

This report is one in a series. More recent editions may be available. To 
view a list of all in the series go to the http://www.ojp.usdoj.gov/bjs/pubalp2.htm#pjmidyear
 
Tables	
jim07t01.csv	Table 1: Number of jail jurisdictions, midyear 1999 and 2005
jim07t02.csv	Table 2: Change in number of jail jurisdictions reporting an average daily population of 1,000 or more inmates, 1999 and 2005
jim07t03.csv	Table 3: Number of inmates confined in local jails at midyear, by size of jurisdiction, 2000 and 2007  
jim07t04.csv	Table 4: Admissions by size of jurisdiction for week ending June 29, 2007
jim07t05.csv	Table 5: The 50 largest local jail jurisdictions: Number of inmates held, average daily population, and rated capacity, midyear 2005-07
jim07t06.csv	Table 6: Characteristics of inmates in local jails at midyear 2000 and 2005-2007
jim07t07.csv	Table 7: Inmate population in jurisdictions reporting on the number of confined non-U.S. citizens, midyear 1999-2007
jim07t08.csv	Table 8: Inmate population in jurisdictions reporting on confined person being held for U.S. Immigration and Customs Enforcement, midyear 2002-2007

Text tables	
jim07tt01.csv	Text table 1: Population at midyear 2007, as a percent of capacity

Appendix tables	
jim07at01.csv	Appendix table 1: Number of jail jurisdictions, midyear 1999-2007
jim07at02.csv	Appendix table 2: Number of inmates confined in local jails, by size of jurisdiction, midyear 1999-2007
jim07at03.csv	Appendix table 3: Rated capacity of local jails and percent of capacity occupied, 1995-2007
jim07at04.csv	Appendix table 4: Characteristics of inmates in local jails, midyear 2000 and 2005-2007
jim07at05.csv	Appendix table 5: Persons under jail supervision, by confinement status and type of program, midyear 2000, 2006, and 2007
jim07at06.csv	Appendix table 6: Estimated standard errors by confinement status, Annual Survey of Jails, 2007
jim07at07.csv	Appendix table 7: Estimated standard errors by selected characteristics, Annual Survey of Jails, 2007
jim07at08.csv	Appendix table 8: Estimated percentages of local jail inmates by selected characteristics and ratio estimates, 2007

Figures	
jim07f01.csv	Figure 1: Inmates confined in local jails at midyear, 2000-2007
jim07f02.csv	Figure 2: Rated capacity of local jails and percent of capacity occupied, 2000-2007
jim07f03.csv	Figure 3: Number of admissions in large jurisdictions between January 2003 and January 2004
jim07f04.csv	Figure 4: Number of jail inmates and jurisdictions, by size of jail jurisdiction, midyear 2007


 
 
