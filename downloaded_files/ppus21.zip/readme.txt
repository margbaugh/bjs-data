Probation and Parole in the United States, 2021  NCJ 305589	
	
This zip archive contains tables in individual .csv spreadsheets from	
Probation and Parole in the United States, 2021  NCJ 305589.  The full report including text	
and graphics in pdf format is available from https://bjs.ojp.gov/library/publications/probation-and-parole-united-states-2021	
	
This report is one in a series.  More recent editions may be available.	
To view a list of all in the series go to 	
https://bjs.ojp.gov/library/publications/list?series_filter=Probation%20and%20Parole%20Populations	
	
Filenames	Table titles
ppus21t01.csv	Table 1. Adults under community supervision, 2011–2021
ppus21t02.csv	Table 2. Decrease in probation population, by jurisdiction, 2021
ppus21t03.csv	Table 3. Decrease in parole population, by jurisdiction, 2021
ppus21t04.csv	Table 4. Community supervision rate of U.S. adult residents, 2011–2021
ppus21t05.csv	Table 5. Exits from probation, by type of exit, 2011–2021
ppus21t06.csv	Table 6. Exits from parole, by type of exit, 2011–2021
ppus21t07.csv	Table 7. Characteristics of adults on probation, 2011 and 2021
ppus21t08.csv	Table 8. Characteristics of adults on parole, 2011 and 2021
ppus21t09.csv	Table 9. Adults supervised on both parole and probation excluded from the January 1 and December 31 community supervision population, 2011–2021
ppus21t10.csv	Table 10. One-day difference based on reporting changes for probation and parole, 2011–2021
	
		Figures
ppus21f01.csv	Figure 1. Adults on probation or parole, 2011–2021
ppus21f02.csv	Figure 2. Annual percent change of adults on probation, 2011–2021
ppus21f03.csv	Figure 3. Annual percent change of adults on parole, 2011–2021
ppus21f04.csv	Figure 4. Estimated total probation movements, entries, and exits, 2011–2021
ppus21f05.csv	Figure 5. Estimated total parole movements, entries, and exits, 2011–2021
	
		Appendix tables
ppus21at01.csv	Appendix table 1. Estimates for figure 2: Annual percent change of adults on probation, 2011–2021
ppus21at02.csv	Appendix table 2. Estimates for figure 3: Annual percent change of adults on parole, 2011–2021
ppus21at03.csv	Appendix table 3. Estimates for figure 4: Estimated total probation movements, entries, and exits, 2011–2021
ppus21at04.csv	Appendix table 4. Estimates for figure 5: Estimated total parole movements, entries, and exits, 2011–2021
ppus21at05.csv	Appendix table 5. Adults under community supervision, by jurisdiction, 2021
ppus21at06.csv	Appendix table 6. Adults on probation, by jurisdiction, 2021
ppus21at07.csv	Appendix table 7. Adults exiting probation, by type of exit and jurisdiction, 2021
ppus21at08.csv	Appendix table 8. Adults on probation, by sex and race or ethnicity, 2011–2021
ppus21at09.csv	Appendix table 9: Select characteristics of adults on probation, by jurisdiction, 2021
ppus21at10.csv	Appendix table 10. Adults on parole, by jurisdiction, 2021
ppus21at11.csv	Appendix table 11. Adults exiting parole, by type of exit and jurisdiction, 2021
ppus21at12.csv	Appendix table 12. Adults on parole, by sex and race or ethnicity, 2011–2021
ppus21at13.csv	Appendix table 13. Select characteristics of adults on parole, by jurisdiction, 2021
