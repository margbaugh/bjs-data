Felony Sentences in State Courts, 2002   NCJ  206916
 
fss02fed.csv	Comparison of felony convictions in State and Federal courts, 2002
fssc0201.csv	Table 1:  Estimated number of felony convictions in State courts, 2002
fssc0202.csv	Table 2:  Distribution of types of felony sentences imposed in State courts, by offense, 2002
fssc0203.csv	Table 3:  Average felony sentence lengths in State courts, by offense and type of sentence, 2002
fssc0204.csv	Table 4:  Estimated time to be served in State prison, by offense, 2002  
fssc0205.csv	Table 5:  Demographic characteristics of persons convicted of felonies in State courts, by offense, 2002
fssc0206.csv	Table 6:  Distribution of the number of felony conviction offenses for persons sentenced in State courts, by most serious offense, 2002
fssc0207.csv	Table 7:  Convicted felons sentenced to prison in State courts, by number of conviction offenses, 2002
fssc0208.csv	Table 8:  Mean sentence lengths for State felony sentences imposed, by the number and category of the conviction offense, 2002
fssc0209.csv	Table 9:  Distribution of types of felony convictions in State courts, by offense, 2002
fssc0210.csv	Table 10:  Time beween arrest and sentencing for persons convicted of a felony in State courts, by offense, 2002
fssc0211.csv	Table 11:  Felons sentenced to an additional penalty in State courts, by offense, 2002

fss02se1.csv	Estimate of 1 standard error for table 1, 2002 
fss02se2.csv	Estimate of 1 standard error for table 2, 2002 
fss02se3.csv	Estimate of 1 standard error for table 3, 2002 
fss02se5.csv	Estimate of 1 standard error for table 5, 2002 
fss02se6.csv	Estimate of 1 standard error for table 6, 2002 
fss02se7.csv	Estimate of 1 standard error for table 7, 2002 
fss02se8.csv	Estimate of 1 standard error for table 8, 2002 
fss02se9.csv	Estimate of 1 standard error for table 9, 2002 
fs02se10.csv	Estimate of 1 standard error for table 10, 2002 
fs02se11.csv	Estimate of 1 standard error for table 11, 2002 
