Immigration, Citizenship, and the Federal Justice System, 2000-2020 – Supplemental Tables   NCJ 304628		
		
This zip archive contains tables in individual .csv spreadsheets		
from Immigration, Citizenship, and the Federal Justice System, 2000-2020 – Supplemental Tables   NCJ 304628		

The report including text and grahics in pdf format is available from: https://bjs.ojp.gov/library/publications/immigration-citizenship-and-federal-justice-system-2000-2020-supplemental		
		
The original report: Immigration, Citizenship, and the Federal Justice System, 1998–2018  NCJ 253116,		
is available from: https://bjs.ojp.gov/library/publications/immigration-citizenship-and-federal-justice-system-1998-2018		
		
Filenames		Table Titles	
icfjs0020stt15a.csv	Table 15a. Immigration suspects in matters concluded by federal prosecutors, by type of immigration offense and federal judicial districts, FY 2019	
icfjs0020stt15b.csv	Table 15b. Immigration suspects in matters concluded by federal prosecutors, by type of immigration offense and federal judicial districts, FY 2020	
icfjs0020stt17.csv	Table 17. Immigration suspects in matters concluded by federal prosecutors, by type of immigration offense, FY 2000–2020	
icfjs0020stt18.csv	Table 18. Among all immigration suspects who were federally prosecuted, percent prosecuted in U.S. district court, by type of immigration offense, FY 2000–2020	
