Capital Punishment, 2022 – Statistical Tables   NCJ 309498	
	
This zip archive contains tables in individual .csv spreadsheets for	
Capital Punishment, 2022 – Statistical Tables   NCJ 309498	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/capital-punishment-2022-statistical-tables
	
Filenames		Table names
cp22stt01.csv	Table 1. Number of executions and prisoners under sentence of death, by jurisdiction, 2022
cp22stt02.csv	Table 2. Prisoners under sentence of death, by region, jurisdiction, and race or ethnicity, 2021 and 2022
cp22stt03.csv	Table 3. Demographic characteristics of prisoners under sentence of death, 2022
cp22stt04.csv	Table 4. Criminal history of prisoners under sentence of death, by race or ethnicity, 2022
cp22stt05.csv	Table 5. Prisoners under sentence of death on December 31, 2022, by year of sentencing and jurisdiction
cp22stt06.csv	Table 6. Prisoners removed from under sentence of death, by region, jurisdiction, and method of removal, 2022
cp22stt07.csv	Table 7. Prisoners executed, by race or ethnicity, 1977–2022
cp22stt08.csv	Table 8. Number of executions, by method and jurisdiction, 1977–2022

			Figures
cp22stf01.csv	Figure 1. Number of prisoners under sentence of death, 1953–2022
cp22stf02.csv	Figure 2. Number of prisoners received and removed from under sentence of death, 1973–2022
cp22stf03.csv	Figure 3. Number of prisoners under sentence of death, by race, 1968–2022
cp22stf04.csv	Figure 4. Number of prisoners executed in the United States, 1930–2022
cp22stf05.csv	Figure 5. Advance count of executions, January 1, 2023–December 31, 2023
	
			Appendix tables
cp22stat01.csv	Appendix Table 1. Counts for figure 1: Number of prisoners under sentence of death, 1953–2022
cp22stat02.csv	Appendix Table 2. Counts for figure 2: Number of prisoners received and removed from under sentence of death, 1973–2022
cp22stat03.csv	Appendix Table 3. Counts for figure 3: Number of prisoners under sentence of death, by race, 1968–2022
cp22stat04.csv	Appendix Table 4. Counts for figure 4: Number of prisoners executed in the United States, 1930–2022
