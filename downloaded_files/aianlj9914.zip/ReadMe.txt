"American Indian and Alaska Natives in Local Jails, 1999-2014 -- Bulletin, NCJ 250652"	

This zip archive contains tables in individual .csv spreadsheets	
"from American Indian and Alaska Natives in Local Jails, 1999-2014 -- Bulletin, NCJ 250652"	
The full report including textand grahics in pdf format is available 
from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6066

The full report including text This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
http://www.bjs.gov/index.cfm?ty=pbse&sid=11	
	
Filename	        Title
Tables	
aianlj9914t01.csv	"Estimated number and percent of inmates in local jails, by race and Hispanic origin, 1999?2000 and 2005?2014"
aianlj9914t02.csv	"American Indian and Alaska Natives in local jails, by jurisdiction, 1999, 2005, and 2013"
aianlj9914t03.csv	"Local jail inmates per 100,000 U.S. residents, by race and Hispanic origin and jurisdiction, 1999, 2005, and 2013"
aianlj9914t04.csv	"Characteristics of adult inmates in local jails, by race and Hispanic origin, 2011"
aianlj9914t05.csv	"Characteristics of adult American Indian and Alaska Native jail inmates, 2011"
aianlj9914t06.csv	"American Indian and Alaska Natives in jail and prison, 1999, 2005, and 2014"
	
Figure	
aianlj9914f01.csv	"American Indian and Alaska Natives in local jails, 1999, 2005, and 2010?2014 "
aianlj9914f02.csv	"Inmates of races and Hispanic origin other than American Indians and Alaska Natives in local jails, 1999, 2005, and 2010-2014"
aianlj9914f03.csv	"American Indian and Alaska Natives in local jails, by region, 1999, 2005, and 2013"
aianlj9914f04.csv	"Geographic distribution of local jail facilities holding American Indian and Alaska Native inmates, December 31, 2013"
aianlj9914f05.csv	"Incarceration rates for American Indian and Alaska Native jail inmates, by region, 1999, 2005, and 2013"
	
Appendix tables	
aianlj9914at01.csv	"Reported data for table 1: Estimated number and percent of inmates in local jails, by race and Hispanic origin, 1999?2000 and 2005?2014"
aianlj9914at02.csv	"Standard errors for table 1: Estimated number and percent of inmates in local jails, by race and Hispanic origin, 1999?2000 and 2005?2014"
aianlj9914at03.csv	"Confidence intervals for table 1: Estimated number and percent of inmates in local jails, by race and Hispanic origin, 1999?2000 and 2005?2014"
aianlj9914at04.csv	"Standard errors for table 4: Characteristics of adult inmates in local jails, by race and Hispanic origin, 2011?2012"
aianlj9914at05.csv	"Standard errors for table 5: Characteristics of adult American Indian and Alaska Native jail inmates, 2011?2012"
	
	

