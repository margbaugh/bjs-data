Prison and Jail Deaths in Custody, 2000-2009 -Statistical Tables  NCJ 236219

This zip archive contains tables in individual .csv spreadsheets
Prison and Jail Deaths in Custody, 2000-2009 -Statistical Tables  NCJ 236219
The full report including text and graphics in .pdf format are available from: 
http://www.bjs.gov//index.cfm?ty=pbdetail&iid=1744

 
Tables	
pjdc0009stt01.csv 	Table 1: Number of local jail inmate deaths, by cause of death, 2000�2009
pjdc0009stt02.csv 	Table 2: Percent of local jail inmate deaths, by cause of death, 2000-2009
pjdc0009stt03.csv	Table 3: Mortality rate per 100,000 local jail inmates, by cause of death, 2000�2009
pjdc0009stt04.csv 	Table 4: Number of local jail inmate deaths, by selected characteristics, 2000-2009
pjdc0009stt05.csv 	Table 5: Percent of local jail inmate deaths, by selected characteristics, 2000-2009
pjdc0009stt06.csv 	Table 6: Mortality rate per 100,000 local jail inmates, by selected characteristics, 2000-2009
pjdc0009stt07.csv 	Table 7: Number of jail deaths, by state and year, 2000-2009
pjdc0009stt08.csv 	Table 8: Mortality rate per 100,000 local jail inmates, by state, 2000-2009
pjdc0009stt09.csv 	Table 9: Number of jail jurisdictions reporting to the Deaths in Custody Reporting Program, by state and year,2000-2009
pjdc0009stt10.csv 	Table 10: Number of local jail inmate deaths, by cause of death and selected characteristics, 2000-2009
pjdc0009stt11.csv 	Table 11: Percent of local jail inmate deaths, by cause of death and selected characteristics, 2000-2009
pjdc0009stt12.csv 	Table 12: Average annual mortality rate per 100,000 local jail inmates, by cause of death and selected characteristics, 2000-2009
pjdc0009stt13.csv 	Table 13: Number of state prisoner deaths, by cause of death, 2001-2009
pjdc0009stt14.csv 	Table 14: Percent of state prisoner deaths, by cause of death, 2001-2009
pjdc0009stt15.csv 	Table 15: Mortality rate per 100,000 state prisoners, by cause of death, 2001-2009
pjdc0009stt16.csv 	Table 16: Number of state prisoner deaths, by selected characteristics, 2001-2009
pjdc0009stt17.csv 	Table 17: Percent of state prisoner deaths, by selected characteristics, 2001-2009
pjdc0009stt18.csv 	Table 18: Estimated number of state prisoners in custody at midyear, by selected characteristics, 2001-2009
pjdc0009stt19.csv 	Table 19: Mortality rate per 100,000 state prisoners, by selected characteristics, 2001-2009
pjdc0009stt20.csv 	Table 20: Number of state prisoner deaths, by state, 2001-2009
pjdc0009stt21.csv 	Table 21: Mortality rate per 100,000 state prisoners, by state, 2001-2009
pjdc0009stt22.csv 	Table 22: Number of state prisoner deaths, by cause of death and selected characteristics, 2001-2009
pjdc0009stt23.csv 	Table 23: Percent of state prisoner deaths, by cause of death and selected characteristics, 2001-2009
pjdc0009stt24.csv 	Table 24: Mortality rate per 100,000 state prisoners, by cause of death and selected characteristics, 2001-2009
pjdc0009stt25.csv 	Table 25: Number of state prisoner deaths, by cause of death and state, 2001-2009
pjdc0009stt26.csv	Table 26: Mortality rate per 100,000 state prisoners, by cause of death and state, 2001-2009


Figures	
pjdc0009f01.csv	Figure 1: Jail inmate deaths in custody, 2000�2009
pjdc0009f02.csv	Figure 2: Prison inmate deaths in custody, 2001�2009



 
 