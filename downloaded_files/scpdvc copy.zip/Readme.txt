State Court Processing of Domestic Violence Cases		

This zip archive contains tables in individual .csv spreadsheets		
"from State Court Processing of Domestic Violence Cases, NCJ 214993."		
The full report including text and graphics in .pdf format are available at		
http://www.ojp.usdoj.gov/bjs/abstract/scpdvc.htm		

Filename		Table number
scpdvct01.csv		"Table 1. Domestic and non-domestic violence defendants charged in 15 large counties during May 2002, by arrest charge"
scpdvct02.csv		Table 2. Prosecution rates of domestic and non-domestic violence defendants charged in 15 large counties during May 2002
scpdvct03.csv		Table 3. Conviction rates of prosecuted domestic and non-domestic violence defendants charged in 15 large counties during May 2002
scpdvct04.csv		Table 4. Incarceration rates of convicted domestic and non-domestic violence offenders charged in 15 large counties during May 2002
scpdvct05.csv		Table 5. Incarceration sentence lengths of convicted domestic and non-domestic violent offenders charged in 15 large counties during May 2002
scpdvct06.csv		Table 6. Mode of conviction for domestic and non-domestic violence offenders charged in 15 large counties during May 2002
scpdvct07.csv		Table 7. Pretrial release of domestic and non-domestic violence defendants charged in 15 large counties during May 2002 who had a protection order as a condition of release
scpdvct08.csv		Table 8. Domestic and non-domestic violence offenders charged in 15 large counties during May 2002 whose sentence included a protection order
scpdvct09.csv		Table 9. Criminal justice status at time of arrest of domestic and non-domestic violence defendants charged in 15 large counties during May 2002
scpdvct10.csv		Table 10. Pretrial release or detention of domestic and non-domestic violence defendants charged in 15 large counties during May 2002
scpdvct11.csv		Table 11. Demographic characteristics of domestic and non-domestic violence defendants charged in 15 large counties during May 2002
scpdvct12.csv		Table 12. Weapon use by domestic and non-domestic violence arrestees in 29 states and the District of Columbia in 2004
scpdvct13.csv		Table 13. Demographic characteristics of domestic and non-domestic violence victims in 29 states and the District of Columbia in 2004

		Figure number
scpdvcf01.csv		Figure 1. Case processing outcomes for DV cases were the same as or more serious than the outcomes for non-DV cases.
