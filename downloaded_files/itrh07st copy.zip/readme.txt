Identity Theft Reported by Households, 2007 - Statistical Tables		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Identity Theft Reported by Households, 2007 - Statistical Tables, NCJ 230742		
The full report including text and graphics in pdf format is available at:              		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2294     		
		
This report is one in a series.  More recent editions            		
may be available.  To view a list of all in the series go to               		
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=60	
		
itrh07stf01.csv		Figure 1. Percent of households in which at least one member was a victim of one or more types of identity theft, by type of identity theft, 2005 and 2007
		
itrh07st01.csv		Table 1. Number and percent of households in which at least one member was a victim of one or more types of identity theft, by type of identity theft, 2005 and 2007
itrh07st02.csv		Table 2. Age, race, and Hispanic origin of head of households experiencing identity theft, 2007
itrh07st03.csv		Table 3. Income, marital status, and size of households that experienced identity theft, 2007'
itrh07st04.csv		Table 4. Amount of financial loss due to identity theft, by type of identity theft, 2007
itrh07St05.csv		Table 5. Number and percent of households in which at least one member was a victim of one or more types of identity theft during a 6-month period, 2007 and 2008
