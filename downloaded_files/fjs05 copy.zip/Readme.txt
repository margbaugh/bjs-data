Federal Justice Statistics, 2005

This zip archive contains tables in individual .csv spreadsheets		
from Federal Justice Statistics, 2005, NCJ 220383.		
The full report including text and graphics in .pdf format is available at		
http://www.ojp.usdoj.gov/bjs/abstract/fjs05.htm

Filename		Table number
fjs05t01.csv		Table 1.  Suspects arrested and booked by the U.S. Marshals Service, by offense and federal district at arrest, 1995-2005
fjs05t02.csv		Table 2.  Characteristics of suspects arrested by the Drug Enforcement Administration, by type of drug, 2005
fjs05t03.csv		Table 3.  Suspects in matters concluded by U.S. attorneys, by offense type, 2005 and 1995
fjs05t04.csv		Table 4.  Suspects in matters concluded by U.S. attorneys, by referring authority, 2004-2005 and 2001-2002
fjs05t05.csv		Table 5.  Suspects in matters concluded by U.S. attorneys by population size of judicial district, 1995-2005
fjs05t06.csv            Table 6.  Outcome and case processing time of suspects in matters concluded, 2005
fjs05t07.csv            Table 7.  Disposition and case processing time of defendants in cases concluded in U.S. district court, 2005
fjs05t08.csv            Table 8.  Verdict, disposition and sentence received in cases concluded in U.S. district court, 2005 and 1995
fjs05t09.csv            Table 9.  Defendants convicted and sentenced to a federal prison term, by type of offense, 2005 and 1995
fjs05t10.csv            Table 10. Felony defendants convicted in state and federal courts, 2004, 2000, and 1996
fjs05t11.csv            Table 11. Percent of criminal appeals filed in U.S. district court, 2005 and 1995.  

			Figure number
fjs05f01.csv		Figure 1. The percent of matters declined by U.S. attorneys was higher in smaller districts, 1995-2005
fjs05f02.csv		Figure 2. Federal courts handled 20% of the nation's felony weapon convictions in 2004--up from 9% in 1994

