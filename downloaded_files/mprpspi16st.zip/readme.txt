Medical Problems Reported by Prisoners: Survey of Prison Inmates, 2016  NCJ 252644		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Medical Problems Reported by Prisoners: Survey of Prison Inmates, 2016  NCJ 252644
		
The full report including text and graphics in pdf format is available from:		
https://bjs.ojp.gov/library/publications/medical-problems-reported-prisoners-survey-prison-inmates-2016		
		
Filenames		Table titles
mprpspi16stt01.csv	Table 1. Prevalence of ever having a chronic condition or infectious disease among all state and federal prisoners, 2016
mprpspi16stt02.csv	Table 2. Prevalence of ever having a chronic condition or infectious disease among state and federal prisoners, by selected conditions and diseases, 2016
mprpspi16stt03.csv	Table 3. Prevalence of having a current chronic condition or infectious disease among state and federal prisoners, by selected conditions and diseases, 2016
mprpspi16stt04.csv	Table 4. Prevalence of ever having a chronic condition or infectious disease among state and federal prisoners, by demographic characteristics, 2016
mprpspi16stt05.csv	Table 5. Body mass index of state and federal prisoners, 2016
mprpspi16stt06.csv	Table 6. Prevalence of medical visits since admission among state and federal prisoners, 2016
mprpspi16stt07.csv	Table 7. Pregnancy and prenatal healthcare among female state and federal prisoners, 2016
mprpspi16stt08.csv	Table 8. Prevalence of ever having a chronic condition or infectious disease among all state and federal prisoners, 2011-2012 and 2016
		
			Figure
mprpspi16stf01.csv	Figure 1. Prevalence of ever having a chronic condition or infectious disease among all state and federal prisoners, 2016
		
			Appendix table
mprpspi16stat01.csv	Appendix table 1. Estimated number of state and federal prisoners, by demographic characteristics, 2016
