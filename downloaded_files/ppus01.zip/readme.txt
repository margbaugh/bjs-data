Probation and Parole in the United States, 2001, NCJ 195669

This zip archive contains tables in individual .wk1 spreadsheets
from Probation and Parole in the United States, 2001, NCJ 195669.
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/ppus01.htm 

File Name           Table Titles

               ppus01high.wk1 Highlights.  Persons under adult correctional supervision, 1990, 1995,
               2000          
ppus0101.wk1   Table 1.  Community corrections among the States, yearend 2001   
ppus0102.wk1   Table 2.  Adults on probation, 2001
ppus0103.wk1   Table 3.  Change in the number of adults on probation, 1995-2001
ppus0104.wk1   Table 4.  Characteristics of adults on probation, 1990, 1995, 2001    
ppus0105.wk1   Table 5.  Adults on parole, 2001   
ppus0106.wk1   Table 6.  Change in the number of adults on parole, 1995-2001    
ppus0107.wk1   Table 7.  Characteristics of adults on parole, 1990, 1995, 2001
               ppus0108.wk1   Table 8.  Total under adult correctional supervision and number
               supervised per 100,000 adult residents, by jurisdiction, yearend 2001