Recidivism of Prisoners Released in 34 States in 2012: A 5-Year Follow-Up Period (2012–2017) NCJ 255947	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Recidivism of Prisoners Released in 34 States in 2012: A 5-Year Follow-Up Period (2012–2017) NCJ 255947.	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/recidivism-prisoners-released-34-states-2012-5-year-follow-period-2012-2017
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Recidivism%20of%20Prisoners%20Released	
	
Filenames			Table titles
rpr34s125yfup1217t01.csv	Table 1. Characteristics of state prisoners released in 34 states in 2012
rpr34s125yfup1217t02.csv	Table 2. Most serious commitment offense of state prisoners released in 34 states in 2012
rpr34s125yfup1217t03.csv	Table 3. Prior criminal history of state prisoners released in 34 states in 2012
rpr34s125yfup1217t04.csv	Table 4. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217t05.csv	Table 5. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by most serious commitment offense, type of prison admission, and year following release
rpr34s125yfup1217t06.csv	Table 6. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by number of prior arrests, age at first arrest, and year following release
rpr34s125yfup1217t07.csv	Table 7. Cumulative percent of state prisoners released in 31 states in 2012 who had an arrest after release that led to a conviction, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217t08.csv	Table 8. Cumulative percent of state prisoners released in 21 states in 2012 who returned to prison for a parole or probation violation or an arrest that led to a new sentence, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217t09.csv	Table 9. Post-release arrests of state prisoners released in 34 states in 2012, by year of arrest
rpr34s125yfup1217t10.csv	Table 10. Percent of state prisoners released in 34 states in 2012 who were arrested within 5 years following release, by type of post-release arrest offense
rpr34s125yfup1217t11.csv	Table 11. Percent of state prisoners released in 34 states in 2012 who were arrested within 5 years following release, by most serious commitment offense and type of post-release arrest offense
rpr34s125yfup1217t12.csv	Table 12. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release for a type of offense that was the same as or different from the most serious commitment offense
rpr34s125yfup1217t13.csv	Table 13. Time served before first release among state prisoners released in 34 states in 2012, by most serious commitment offense
rpr34s125yfup1217t14.csv	Table 14. Percent of state prisoners released in 34 states in 2012 who were arrested within 5 years, by most serious commitment offense and median time served in prison before first release
rpr34s125yfup1217t15.csv	Table 15. Percent of state prisoners released in 34 states in 2012 who were arrested within 5 years, by most serious commitment offense and time served in prison
rpr34s125yfup1217t16.csv	Table 16. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested outside of the state of release, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217t17.csv	Table 17. Annual arrest percentage of state prisoners released in 34 states in 2012, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217t18.csv	Table 18. Percent of state prisoners arrested during the year who had not been arrested since release in 34 states in 2012
rpr34s125yfup1217t19.csv	Table 19. Percent of state prisoners released in 19 states in 2005, 2008, and 2012, by sex, race or ethnicity, age at release, most serious commitment offense, and year of release
rpr34s125yfup1217t20.csv	Table 20. Cumulative percent of state prisoners released in 19 states in 2005, 2008, and 2012 who were arrested following release, by sex, race or ethnicity, age at release, most serious commitment offense, and year of release
rpr34s125yfup1217t21.csv	Table 21. Cumulative percent of state prisoners released in 19 states in 2005, 2008, and 2012 who were arrested for a violent offense following release, by sex, race or ethnicity, age at release, most serious commitment offense, and year of release
	
				Figures
rpr34s125yfup1217f01.csv	Figure 1. Cumulative percent of state prisoners released in 2012 who had a new arrest, conviction, or return to prison after release, by year following release
rpr34s125yfup1217f02.csv	Figure 2. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by age at release and year following release
rpr34s125yfup1217f03.csv	Figure 3. Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by number of prior arrests and year following release
rpr34s125yfup1217f04.csv	Figure 4. Annual arrest percentage of state prisoners released in 34 states in 2012
	
				Appendix tables
rpr34s125yfup1217at01.csv	Appendix Table 1. Number of state prisoners released in 34 states in 2012 who were included in the study sample and for whom criminal history data were collected, by state
rpr34s125yfup1217at02.csv	Appendix Table 2. Standard errors for table 4: Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217at03.csv	Appendix Table 3. Standard errors for table 5: Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by most serious commitment offense, type of prison admission, and year following release
rpr34s125yfup1217at04.csv	Appendix Table 4. Standard errors for table 6: Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release, by number of prior arrests, age at first arrest, and year following release
rpr34s125yfup1217at05.csv	Appendix Table 5. Standard errors for table 7: Cumulative percent of state prisoners released in 31 states in 2012 who had an arrest after release that led to a conviction, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217at06.csv	Appendix Table 6. Standard errors for table 8: Cumulative percent of state prisoners released in 21 states in 2012 who returned to prison, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217at07.csv	Appendix Table 7. Standard errors for table 11: Percent of state prisoners released in 34 states in 2012 who were arrested within 5 years following release, by most serious commitment offense and type of post-release arrest offense
rpr34s125yfup1217at08.csv	Appendix Table 8. Standard errors for table 12: Cumulative percent of state prisoners released in 34 states in 2012 who were arrested following release for a type of offense that was the same as or different from the most serious commitment offense
rpr34s125yfup1217at09.csv	Appendix Table 9. Standard errors for table 13: Time served before first release among state prisoners released in 34 states in 2012, by most serious commitment offense
rpr34s125yfup1217at10.csv	Appendix Table 10. Standard errors for table 15: Percent of state prisoners released in 34 states in 2012 who were arrested within 5 years, by most serious commitment offense and time served in prison
rpr34s125yfup1217at11.csv	Appendix Table 11. Standard errors for table 16: Cumulative percent of state prisoners released in 34 states in 2012 who were arrested outside of the state of release, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217at12.csv	Appendix Table 12. Standard errors for table 17: Annual arrest percentage of state prisoners released in 34 states in 2012, by sex, race or ethnicity, age at release, and year following release
rpr34s125yfup1217at13.csv	Appendix Table 13. Standard errors for table 18: Percent of state prisoners arrested during the year who had not been arrested since release in 34 states in 2012
rpr34s125yfup1217at14.csv	Appendix Table 14. Standard errors for table 20: Cumulative percent of state prisoners released in 19 states in 2005, 2008, and 2012 who were arrested following release, by sex, race or ethnicity, age at release, most serious commitment offense, and year of release
rpr34s125yfup1217at15.csv	Appendix Table 15. Standard errors for table 21: Cumulative percent of state prisoners released in 19 states in 2005, 2008, and 2012 who were arrested for a violent offense following release, by sex, race or ethnicity, age at release, most serious commitment offense, and year of release
