Sentencing Decisions for Persons in Federal Prison for Drug Offenses, 2013–2018   NCJ 305893	
	
This zip archive contains tables in individual  .csv spreadsheets               	
from Sentencing Decisions for Persons in Federal Prison for Drug Offenses, 2013–2018   NCJ 305893	
The full report including text and graphics in pdf format is available from:              	
https://bjs.ojp.gov/library/publications/sentencing-decisions-persons-federal-prison-drug-offenses-2013-2018
	
Filenames		Table titles
sdpfpdo1318t01.csv	Table 1. Persons in Federal Bureau of Prisons custody, by most serious offense, fiscal yearends 2013–2018
sdpfpdo1318t02.csv	Table 2. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved, fiscal yearends 2013–2018
sdpfpdo1318t03.csv	Table 3. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received, fiscal yearends 2013–2018
sdpfpdo1318t04.csv	Table 4. Persons in Federal Bureau of Prisons custody for drug offenses who received a sentence modification, by reason, fiscal yearends 2013–2018
sdpfpdo1318t05.csv	Table 5. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved and mandatory minimum penalty received, fiscal yearend 2018
sdpfpdo1318t06.csv	Table 6. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received and criminal history category, fiscal yearend 2018
sdpfpdo1318t07.csv	Table 7. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved and criminal history category, fiscal yearend 2018
sdpfpdo1318t08.csv	Table 8. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received and sentence enhancement for gun involvement, fiscal yearend 2018
sdpfpdo1318t09.csv	Table 9. Persons in Federal Bureau of Prisons custody for drug offenses, by average sentence and mandatory minimum penalty received, fiscal yearend 2018
sdpfpdo1318t10.csv	Table 10. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received and aggravating or mitigating role adjustment, fiscal yearend 2018
sdpfpdo1318t11.csv	Table 11. Persons in Federal Bureau of Prisons custody for drug offenses, by sex, sentence length, race or ethnicity, and primary drug involved, fiscal yearend 2018
sdpfpdo1318t12.csv	Table 12. Persons in Federal Bureau of Prisons custody, by linking of prison and sentencing records, fiscal yearend 2013–2018
sdpfpdo1318t13.csv	Table 13. Persons in Federal Bureau of Prisons custody, by linking of prison and sentencing records and most serious offense, fiscal yearend 2018
	
			Figures
sdpfpdo1318f01.csv	Figure 1. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved and mandatory minimum penalty received, fiscal yearend 2018
sdpfpdo1318f02.csv	Figure 2. Persons in Federal Bureau of Prisons custody for drug offenses, by sentencing year and mandatory minimum penalty received, fiscal yearend 2018
sdpfpdo1318f03.csv	Figure 3. Persons in Federal Bureau of Prisons custody for drug offenses, by sex and sentence length, fiscal yearend 2018
sdpfpdo1318f04.csv	Figure 4. Persons in Federal Bureau of Prisons custody for drug offenses sentenced to 20 years or more, by sex and race or ethnicity, fiscal yearend 2018
	
			Appendix tables
sdpfpdo1318at01.csv	Appendix table 1. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received and demographic characteristics, fiscal yearend 2018
sdpfpdo1318at02.csv	Appendix table 2. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received and demographic characteristics, fiscal yearend 2015
sdpfpdo1318at03.csv	Appendix table 3. Persons in Federal Bureau of Prisons custody for drug offenses, by mandatory minimum penalty received and demographic characteristics, fiscal yearend 2013
sdpfpdo1318at04.csv	Appendix table 4. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved, fiscal yearend 2018
sdpfpdo1318at05.csv	Appendix table 5. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved, fiscal yearend 2015
sdpfpdo1318at06.csv	Appendix table 6. Persons in Federal Bureau of Prisons custody for drug offenses, by primary drug involved, fiscal yearend 2013
