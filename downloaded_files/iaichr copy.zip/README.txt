ZIP file contents

This zip archive contains tables in individual .csv spreadsheets for Improving Access to and Integrity of Criminal History Records (Bureau of Justice Statistics, NCJ 200581).  

The full report including text and graphics in .pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/iaichr.htm

The following presents the filename and the title of the materials:


iaichrf2.csv  	Figure 2. States with high, medium, and low levels of criminal record automation, 1995-2001

iaichrf3.csv  	Figure 3. Estimated number of arresting agencies reporting dispositions by automated means, 1997-2001

iaichrf4.csv  	Figure 4. Estimated number of courts reporting dispositions by automated means, 1997-2001

iaichrf5.csv  	Figure 5. Average number of days required for repositories to receive and process information, 1995-2001

iaichrf6.csv  	Figure 6. Number of files in the National Protection Order File, 2000-03

iaichrf7.csv  	Figure 7. Number of records in the National Sex Offender Registry, 2000-03

iaichrf8.csv  	Figure 8. Average number of days required to repositories to receive criminal history information, 1995-2001

iaichrf9.csv  	Figure 9. Average number of days required for repositories to post information to a record, 1995-2001

iaichrf10.csv  	Figure 10. State repository backlog, by type of record, 1995-2001

iaichrf13.csv  	Figure 13. Number of State records included in NICS Index, January 2000-February 2003

iaichrf14.csv  	Figure 14. Number of State NCIC records, sex offender records, and protection orders, January 2000-February 2003

iaichrf15.csv  	Figure 15. Number of State records in four NCIC databases, January 2000-February 2003

iaichrt1.csv  	Text Table State policies for fingerprinting and conducting background checks  on Federal immigration detainees held in local jails, December 2001  

iaichrtt2.csv 	Text table. Number of records contributed to the FBI Mental Defectives File before February 2003

iaichrtt2.csv 	Text table. Number of States checking mental health records
















