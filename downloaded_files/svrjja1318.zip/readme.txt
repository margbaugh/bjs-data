Sexual Victimization Reported by Juvenile Justice Authorities, 2013-2018 NCJ 300029	
	
This zip archive contains tables in individual .csv spreadsheets	
from Sexual Victimization Reported by Juvenile Justice Authorities, 2013-2018 NCJ 300029	
The full report including text and graphics in pdf format is available from 	
https://bjs.ojp.gov/library/publications/sexual-victimization-reported-juvenile-justice-authorities-2013-2018	
	
This report is one in a series.  More recent editions	
may be available. To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Data%20Collection%20Activities	
	
Filenames		Table titles
svrjja1318t01.csv	Table 1. Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, 2013-2018
svrjja1318t02.csv	Table 2. Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, by type of victimization, 2013-18
svrjja1318t03.csv	Table 3. Allegations in state juvenile systems and local and private juvenile facilities, by type of victimization and outcome of investigation, 2013-18
svrjja1318t04.csv	Table 4. Substantiated incidents of sexual victimization in state juvenile systems and local and private juvenile facilities, 2013–2018
svrjja1318t05.csv	Table 5. Allegations of youth-on-youth sexual harassment in state juvenile systems and local and private juvenile facilities, by outcome of investigation, 2013-18
	
			Figures
svrjja1318f01.csv	Figure 1. Allegations and substantiated incidents of sexual victimization in state juvenile systems and local and private juvenile facilities, 2013-2018
svrjja1318f02.csv	Figure 2. Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, by type of victimization, 2013-2018
svrjja1318f03.csv	Figure 3. Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, by outcome of investigation, 2013-2018
svrjja1318f04.csv	Figure 4. Allegations and substantiated incidents of youth-on-youth sexual harassment in state juvenile systems and local and private juvenile facilities, 2013-2018
	
			Appendix tables
svrjja1318at01.csv	Appendix Table 1. Nonresponding juvenile justice facilities, by state, 2013-2018
svrjja1318at02.csv	Appendix Table 2. Standard errors for table 1: Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, 2013-2018
svrjja1318at03.csv	Appendix Table 3. Standard errors for table 2: Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, by type of victimization, 2013-18
svrjja1318at04.csv	Appendix Table 4. Numbers and standard errors for figure 2: Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, by type of victimization, 2013-2018
svrjja1318at05.csv	Appendix Table 5. Standard errors for table 3: Allegations in state juvenile systems and local and private juvenile facilities, by type of victimization and outcome of investigation, 2013-18
svrjja1318at06.csv	Appendix Table 6. Numbers and standard errors for figure 3: Allegations of sexual victimization in state juvenile systems and local and private juvenile facilities, by outcome of investigation, 2013-2018
svrjja1318at07.csv	Appendix Table 7. Standard errors for table 4: Substantiated incidents of sexual victimization in state juvenile systems and local and private juvenile facilities, 2013-2018
svrjja1318at08.csv	Appendix Table 8. Numbers and standard errors for figure 4: Allegations and substantiated incidents of youth-on-youth sexual harassment in state juvenile systems and local and private juvenile facilities, 2013-2018
svrjja1318at09.csv	Appendix Table 9. Standard errors for table 5: Allegations of youth-on-youth sexual harassment in state juvenile systems and local and private juvenile facilities, by outcome of investigation, 2013-18
