Veterans in Prison: Survey of Prison Inmates, 2016   NCJ 252646			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Veterans in Prison: Survey of Prison Inmates, 2016   NCJ 252646			
The full report including text and graphics in pdf format is available from:			
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7308			
			
			
Filenames		Table titles	
vpspi16stt01.csv	Table 1. Estimated number of all veterans in state or federal prison and number of all male veterans, by selected characteristics, 2016	
vpspi16stt02.csv	Table 2. Demographic characteristics of state and federal prisoners, by veteran status, 2016	
vpspi16stt03.csv	Table 3. Controlling offense, sentence length, and criminal history of male state and federal prisoners, by veteran status, 2016	
vpspi16stt04.csv	Table 4. Military characteristics of male veterans in state and federal prison, 2016	
			
			Figure titles	
vpspi16stf01.csv	Figure 1. Estimated number of all veterans in state or federal prison and number of all male veterans, by selected characteristics, 2016	
			
			Appendix tables	
vpspi16stat01.csv	Appendix table 1. Estimated number of state and federal prisoners, by sex and veteran status, 2016	
			
