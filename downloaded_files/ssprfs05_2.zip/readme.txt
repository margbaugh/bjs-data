Survey of State Procedures Related to Firearm Sales, 2005 NCJ 214645																

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .csv spreadsheets from the
Survey of State Procedures Related to Firearm Sales, 2005 NCJ 214645. 
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/ssprfs05.htm 

This report is one in a series.  Most recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#ssprfs
----------------------------------------------------------------------------
																	
Filename	Table																
																	
ssprfs0501.csv	Table 1.  Applications for firearm transfers and permits processed by States, 2005
ssprfs0502.csv	Table 2.  Applications for firearm permits processed by local agencies, 
grouped by population level of community served, 2005
ssprfs0503.csv	Table 3.  Transactions processed by the FBI for selected States, 2005
ssprfs0512.csv	Table 12. ATF investigation of NICS denials by FBI, 2005
