Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2010   NCJ 239911

This zip archive contains tables in individual .csv spreadsheets
Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2010   NCJ 239911
The full report including text and graphics in .pdf format are available from: 
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4558

 
Tables	
mljsp0010t01.csv	Table 1. Number of local jail inmate deaths, by cause of death, 2000�2010
mljsp0010t02.csv	Table 2. Percent of local jail inmate deaths, by cause of death, 2000�2010
mljsp0010t03.csv	Table 3. Mortality rate per 100,000 local jail inmates, by cause of death, 2000�2010
mljsp0010t04.csv	Table 4. Number of local jail inmate deaths, by selected decedent characteristics, 2000�2010
mljsp0010t05.csv	Table 5. Percent of local jail inmate deaths, by selected decedent characteristics, 2000�2010
mljsp0010t06.csv	Table 6. Mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2010
mljsp0010t07.csv	Table 7. Number of jail deaths, by state and year, 2000�2010
mljsp0010t08.csv	Table 8. Mortality rate per 100,000 local jail inmates, by state, 2000�2010
mljsp0010t09.csv	Table 9. Number of jail jurisdictions reporting to the Deaths in Custody Reporting Program, by state and year, 2000�2010
mljsp0010t10.csv	Table 10. Number of local jail inmate deaths, by cause of death and selected decedent characteristics, 2000�2010
mljsp0010t11.csv	Table 11. Average annual mortality rate per 100,000 local jail inmates, by cause of death and selected characteristics, 2000�2010
mljsp0010t12.csv	Table 12. Number of state prisoner deaths, by cause of death, 2001�2010
mljsp0010t13.csv	Table 13. Percent of state prisoner deaths, by cause of death, 2001�2010
mljsp0010t14.csv	Table 14. Mortality rate per 100,000 state prisoners, by cause of death, 2001�2010
mljsp0010t15.csv	Table 15. Number of state prisoner deaths, by selected characteristics, 2001�2010
mljsp0010t16.csv	Table 16. Percent of state prisoner deaths, by selected characteristics, 2001�2010
mljsp0010t17.csv	Table 17. Estimated number of state prisoners in custody at midyear, by selected characteristics, 2001�2010
mljsp0010t18.csv	Table 18. Mortality rate per 100,000 state prisoners, by selected characteristics, 2001�2010
mljsp0010t19.csv	Table 19. Number of state prisoner deaths, by state, 2001�2010
mljsp0010t20.csv	Table 20. Mortality rate per 100,000 state prisoners, by state, 2001�2010
mljsp0010t21.csv	Table 21. Number of state prisoner deaths, by cause of death and selected characteristics, 2001�2010
mljsp0010t22.csv	Table 22. Percent of state prisoner deaths, by cause of death and selected characteristics, 2001�2010
mljsp0010t23.csv	Table 23. Average Mortality rate per 100,000 state prisoners, by cause of death and selected characteristics, 2001�2010
mljsp0010t24.csv	Table 24. Number of state prisoner deaths, by cause of death and state, 2001�2010
mljsp0010t25.csv	Table 25. Average Mortality rate per 100,000 state prisoners, by cause of death and state, 2001�2010

Figures
mljsp0010f01.csv	Figure 1. Jail inmate deaths in custody, 2000�2010
mljsp0010f02.csv	Figure 2. State prison inmate deaths in custody, 2001�2010

 
 