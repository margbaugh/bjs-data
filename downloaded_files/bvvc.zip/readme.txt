					readme.txt
Black Victims of Violent Crime					

This zip archive contains tables in individual .csv spreadsheets from Black Victims of Violent Crime, NCJ 214258. 
The full report including text and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/bvvc.htm

File name					
		Tables 
bvvct01.csv	Table 1. Violent victimization rates of blacks/African Americans by gender, age, and location of residence, 1993, 2001, and 2005		
bvvct02.csv	Table 2. Average annual violent victimization rate by race/Hispanic origin and type of crime, 2001-2005	
bvvct03.csv	Table 3. Robbery victimization by gender, age, annual household income, and location of residence, by race/Hispanic origin, 2001-2005			
bvvct04.csv	Table 4. Weapons present and injuries sustained by victim during robbery, by victim race/Hispanic origin, 2001-2005	
bvvct05.csv	Table 5. Percent of violent victimization, by victim race/Hispanic origin and offender race, 2001-2005		
bvvct06.csv	Table 6. Victim/offender relationship of black/African American victims and other victims, by gender, 2001-2005			
bvvct07.csv	Table 7. Injury and treatment of black/African American victims of violent crime, 2001-2005
bvvct08.csv	Table 8. Treatment of injuries sustained by black/African American violent crime victims, by crime seriousness, 2001-2005
bvvct09.csv	Table 9. Percent of violent victimization reported to police by black/African American victims, by type of crime, 2001-2005
bvvct10.csv	Table 10. Violent crime against blacks/African Americans reported to police, by victim gender and age, 2001-2005
bvvct11.csv	Table 11. Services received by black/African American victims of violent crime from nonpolice victim agencies, by type of crime, 2001-2005

		Figures
bvvcf01.csv	Figure 1. Violent victimization of blacks/African Americans, by gender, 1993-2005
bvvcf02.csv	Figure 2. Violent victimization of blacks/African Americans by location of residence, 1993-2005
bvvcf03.csv	Figure 3. Homicide victims by race and gender of the victim, 1993-2005
bvvcf04.csv	Figure 4. Robbery victimization by victim race/Hispanic orgin, 1993-2005
bvvcf05.csv	Figure 5. Serious violent crime in which the offender had a weapon, by victim race/Hispanic origin, 1993-2005
bvvcf06.csv	Figure 6. Serious violent crime in which the victim was injured, by victim race/Hispanic origin, 1993-2005
bvvcf07.csv	Figure 7. Percent of violent crime against blacks/African Americans in which victim received services from nonpolice victim agencies, 1993-2005

		Text Tables
bvvctt01.csv	Text table 1. Serious violent crime as a percent of all nonfatal violent crime, 2001-2005 		
bvvctt02.csv	Text table 2. Rate per 1,000 persons age 12 or older of violent crime victims who perceived offender to be a gang member, 2001-2005	
bvvctt03.csv	Text table 3. Percent of violent crime against black victims who perceived offender to be a gang member, 2001-2005	
bvvctt04.csv	Text table 4. Percent of violent crime in which victim perceived offender to be under the influence of alcohol or drugs, by race/Hispanic origin, 2001-2005
bvvctt05.csv	Text table 5. Percent of violent crime in which a weapon was present and percent of violent crime in which a firearm was present, by race/Hispanic origin, 2001-2005
bvvctt06.csv	Text table 6. Percent of violent crime reported to police, by race/Hispanic origin, 2001-2005		
bvvctt07.csv	Text table 7. Percent of violent crime in which police responded within an hour, by race/Hispanic origin, 2001-2005
bvvctt08.csv    Text table 8. Percent of violent crime in which victims received help from nonpolice victim agencies, by race/Hispanic origin, 2001-2005

		Summary figure			
bvvcsf01.csv	Summary figure 1. Nonfatal violent victimization declined for blacks/African Americans, whites, and Hispanics age 12 or older between 1993 and 2005 	

		Appendix Tables
bvvcat01.csv	Appendix table 1. Violent victimization rate per 1,000 persons, by gender, age, and marital status, by race/Hispanic origin of victims, 2001-2005
bvvcat02.csv	Appendix table 2. Violent victimization rate per 1,000 persons, by annual household income, location of residence, and region, by race/Hispanic origin of victims, 2001-2005		
bvvcat03.csv	Appendix table 3. Serious violent victimization rate per 1,000 persons, by gender, age, annual household income, and location of residence, by race/Hispanic origin of victims, 2001-2005
bvvcat04.csv	Appendix table 4. Average annual number of violent victimizations against blacks/African Americans, by type of crime, 2001-2005		
bvvcat05.csv	Appendix table 5. Percentage of nonfatal violent victimization against blacks/African Americans, by type of crime, 2001-2005
