Race and Hispanic Origin of Victims and Offenders, 2012-15  NCJ 250747			
			
This zip archive contains tables in individual .csv spreadsheets from 			
Race and Hispanic Origin of Victims and Offenders, 2012-15  NCJ 250747			
from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6106			
		
			
Tables			Title
rhovo1215t01.csv			Table 1. Percent of violent victimizations, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t02.csv			Table 2. Race/Hispanic origin of violent victimization offenders, by type of victimization, 2012?2015
rhovo1215t03.csv			Table 3. Rate of violent victimization, by type of crime and race/Hispanic origin of victim and offender, 2012?2015
rhovo12153t04.csv			Table 4. Percent of violent victimizations, by victim-offender relationship and race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t05.csv			Table 5. Percent of nonfatal violent victimizations before and after changes to race/Hispanic origin offender categories, 2008?2015
rhovo1215t06.csv			Table 6. Percent of violent victimizations reported to police, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t07.csv			Table 7. Percent of violent victimizations involving a weapon, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t08.csv			Table 8. Percent of violent victimizations involving victim injury, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t09.csv			Table 9. Percent of violent victimizations, by victim characteristics and race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t10.csv			Table 10. Percent of violent victimizations, by location of residence and race/Hispanic origin of victim and offender, 2012?2015
rhovo1215t11.csv			Table 11. U.S. population of persons age 12 or older, by race/Hispanic origin, 2012?2015
			
Figures			
rhovo1215f01.csv			Figure 1. Percent of intraracial and interracial victims and offenders of violent victimizations, by type of crime, 2012?2015
rhovo1215f02.csv			Figure 2. Rate of nonfatal violent victimization, by race of offender and victim, 1993?2015
rhovo1215f03.csv			Figure 3. Rate of violent victimization, by race/Hispanic origin of offender, 2008?2015
			
Appendix Tbles			
rhovo1215at01.csv			Appendix Table 1. Estimates and standard errors for figure 1: Percent of intraracial and interracial victims and offenders of violent victimizations, by type of crime, 2012?2015
rhovo1215at02.csv			Appendix Table 2. Standard errors for table 1: Percent of violent victimizations, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at03.csv			Appendix Table 3. Standard errors for table 2: Race/Hispanic origin of violent victimization offenders, by type of victimization, 2012?2015
rhovo12153at04.csv			Appendix Table 4. Standard errors for table 3: Rate of violent victimization, by type of crime and race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at05.csv			Appendix Table 5. Estimates and standard errors for figure 2: Rate of nonfatal violent victimization, by race of offender and victim, 1993?2015
rhovo1215at06.csv			Appendix Table 6. Standard errors for table 4: Percent of violent victimizations, by victim-offender relationship and race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at07.csv			Appendix Table 7. Standard errors for table 5: Percent of nonfatal violent victimizations before and after changes to race/Hispanic origin offender categories, 2008?2015
rhovo1215at08.csv			Appendix Table 8. Estimates and standard errors for figure 3: Rate of violent victimization, by race/Hispanic origin of offender, 2008?2015
rhovo1215at09.csv			Appendix Table 9. Standard errors for table 6: Percent of violent victimizations reported to police, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at10.csv			Appendix Table 10. Standard errors for table 7: Percent of violent victimizations involving a weapon, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at11.csv			Appendix Table 11. Standard errors for table 8: Percent of violent victimizations involving victim injury, by race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at12.csv			Appendix Table 12. Standard errors for table 9: Percent of violent victimizations, by victim characteristics and race/Hispanic origin of victim and offender, 2012?2015
rhovo1215at13.csv			Appendix Table 13. Standard errors for table 10: Percent of violent victimizations, by location of residence and race/Hispanic origin of victim and offender, 2012?2015
