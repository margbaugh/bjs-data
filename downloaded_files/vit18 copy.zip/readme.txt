Victims of Identity Theft, 2018  NCJ 256085	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Victims of Identity Theft, 2018  NCJ 256085.  The full report including text	
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7326	
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://www.bjs.gov/index.cfm?ty=pbse&sid=60	
	
Filename	Table names
vit18t01.csv	Table 1. Percent of respondents who reported experiencing identity theft in the past 12 months, by most recent incident’s discovery and type of theft, 2018
vit18t02.csv	Table 2. The most recent incident of identity theft based on all reported incidents and restricted data, by type of theft, 2018
vit18t03.csv	Table 3. Victims of identity theft, by type of most recent incident of theft, 2018
vit18t04.csv	Table 4. Demographic characteristics of victims of identity theft and the U.S. residential population age 16 or older, 2018
vit18t05.csv	Table 5. Ways victims discovered identity theft, by type of theft, 2018
vit18t06.csv	Table 6. Victims of identity theft who knew how the offender obtained their personal information, by method offender used and type of theft, 2018
vit18t07.csv	Table 7. Financial loss from victims’ most recent incident of identity theft, by type of loss and theft, 2018
vit18t08.csv	Table 8. Financial loss for all incidents of identity theft, 2018
vit18t09.csv	Table 9. Victims of identity theft who had experienced emotional distress, by type of theft, 2018
vit18t10.csv	Table 10. Percent of victims of identity theft, by type of organization contacted, 2018
vit18t11.csv	Table 11. Actions persons age 16 or older took during the past 12 months to reduce the risk of identity theft, by victims and nonvictims of past-year identity theft, 2018
vit18t12.csv	Table 12. Actions victims of identity theft took in the past 12 months to reduce the risk of identity theft, by whether the action was in response to or independent of previous identity theft, 2018
vit18t13.csv	Table 13. Persons age 16 or older who experienced identity theft in their lifetime, by type of identity theft experienced outside of the past year and ongoing problems from identity theft, 2018 
	
		Figures
vit18f01.csv	Figure 1. Persons age 16 or older who had experienced at least one identity-theft incident in the past 12 months, by type of theft, 2018
vit18f02.csv	Figure 2. Percent of victims of identity theft who knew how the offender obtained their personal information, by type of theft, 2018
vit18f03.csv	Figure 3. Length of time that victims spent resolving financial and credit problems associated with identity theft, by type of theft, 2018
vit18f04.csv	Figure 4. Victims of identity theft who reported severe emotional distress due to the crime, by length of time spent resolving associated financial and credit problems, 2018
vit18f05.csv	Figure 5. Victims of identity theft who reported the theft to police, by type of theft, 2018
vit18f06.csv	Figure 6. Percent of victims of identity theft who contacted a credit bureau, by action taken, 2018
vit18f07.csv	Figure 7. Victims of identity theft who reported and who did not report the theft to police, by other type of organization contacted, 2018
	
		Appendix tables
vit18at01.csv	Appendix Table 1. Estimates and standard errors for figure 1: Persons age 16 or older who had experienced at least one identity-theft incident in the past 12 months, by type of theft, 2018
vit18at02.csv	Appendix Table 2. Standard errors for table 2: The most recent incident of identity theft based on all reported incidents and restricted data, by type of theft, 2018
vit18at03.csv	Appendix Table 3. Standard errors for table 3: Victims of identity theft, by type of most recent incident of theft, 2018
vit18at04.csv	Appendix Table 4. Standard errors for table 4: Demographic characteristics of victims of identity theft and the U.S. residential population age 16 or older, 2018
vit18at05.csv	Appendix Table 5. Standard errors for table 5: Ways victims discovered identity theft, by type of theft, 2018
vit18at06.csv	Appendix Table 6. Estimates and standard errors for figure 2: Percent of victims of identity theft who knew how the offender obtained their personal information, by type of theft, 2018
vit18at07.csv	Appendix table 7. Standard errors for table 6: Victims of identity theft who knew how the offender obtained their personal information, by method offender used and type of theft, 2018
vit18at08.csv	Appendix table 8. Standard errors for table 7: Financial loss from victims’ most recent incident of identity theft, by type of loss and theft, 2018
vit18at09.csv	Appendix Table 9. Standard errors for table 8: Financial loss for all incidents of identity theft, 2018
vit18at10.csv	Appendix Table 10. Standard errors for table 9: Victims of identity theft who had experienced emotional distress, by type of theft, 2018
vit18at11.csv	Appendix Table 11. Estimates and standard errors for figure 3: Length of time that victims spent resolving financial and credit problems associated with identity theft, by type of theft, 2018
vit18at12.csv	Appendix Table 12. Estimates and standard errors for figure 4: Victims of identity theft who reported severe emotional distress due to the crime, by length of time spent resolving associated financial and credit problems, 2018
vit18at13.csv	Appendix Table 13. Estimates and standard errors for figure 5: Victims of identity theft who reported the theft to police, by type of theft, 2018
vit18at14.csv	Appendix table 14. Standard errors for table 10: Percent of victims of identity theft, by type of organization contacted, 2018
vit18at15.csv	Appendix Table 15. Estimates and standard errors for figure 6: Percent of victims of identity theft who contacted a credit bureau, by action taken, 2018
vit18at16.csv	Appendix Table 16. Estimates and standard errors for figure 7: Victims of identity theft who reported and who did not report the theft to police, by other type of organization contacted, 2018
vit18at17.csv	Appendix Table 17. Standard errors for table 11: Actions persons age 16 or older took during the past 12 months to reduce the risk of identity theft, by victims and nonvictims of past-year identity theft, 2018
vit18at18.csv	Appendix Table 18. Standard errors for table 12: Actions victims of identity theft took in the past 12 months to reduce the risk of identity theft, by whether the action was in response to or independent of previous identity theft, 2018
vit18at19.csv	Appendix Table 19. Standard errors for table 13: Persons age 16 or older who experienced identity theft in their lifetime, by type of identity theft experienced outside of the past year and ongoing problems from identity theft, 2018
