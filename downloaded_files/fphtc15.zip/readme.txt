Federal Prosecution of Human-Trafficking Cases, 2015  				
This zip archive contains tables in individual .csv spreadsheets		
from Federal Prosecution of Human-Trafficking Cases, 2015  NCJ 251390.		
The full report including text and graphics in pdf format is available from 	
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6387		
		
		
Filename		Table title
fphtc15t01.csv		Table 1. Suspects referred to and prosecuted by U.S. attorneys for human-trafficking offenses, 2011�2015
fphtc15t02.csv		Table 2. Suspects referred to U.S. attorneys for a human-trafficking offense, by agency of referral, 2015
fphtc15t03.csv		Table 3. Suspects in human-trafficking matters concluded, by disposition of the matter, 2015
fphtc15t04.csv		Table 4. Suspects in human-trafficking matters U.S. attorneys declined to prosecute, by reason, 2015
fphtc15t05.csv		Table 5. Characteristics of human-trafficking defendants in cases charged in U.S. district court, 2015
fphtc15t06.csv		Table 6. Defendants in human-trafficking cases terminated, by verdict, 2015
fphtc15t07.csv		Table 7. Defendants in human-trafficking cases terminated, by mode of disposition, 2015
fphtc15t08.csv		Table 8. Type of sentence imposed following a conviction for a human-trafficking offense, 2015 
fphtc15t09.csv		Table 9. Human-trafficking defendants sentenced to prison, 2000�2015
		
		Figure title
fphtc15f01.csv		Figure 1. Suspects in matters referred to and prosecuted by U.S. attorneys for human trafficking, 2011�2015
fphtc15f02.csv		Figure 2. Human-trafficking defendants sentenced to prison, 2000�2015
fphtc15f03.csv		Figure 3. Median prison sentence imposed on human-trafficking defendants sentenced to prison, by offense type, 2000�2015
fphtc15f04.csv		Figure 4. Percent of human-trafficking suspects prosecuted, convicted, and sentenced to prison, 2000�2015
		
		Appendix table title
fphtc15at01.csv		Appendix table 1. Data for figure 3: Median prison sentence imposed on human-trafficking defendants sentenced to prison, by offense type, 2000�2015
fphtc15at02.csv		Appendix table 2. Data for figure 4: Percent of human-trafficking suspects prosecuted, convicted, and sentenced to prison, 2000�2015

