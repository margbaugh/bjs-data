CONTRACT TRIALS AND VERDICTS IN LARGE COUNTIES, 1996
Civil Justice Survey of State Courts, 1996   NCJ  179451

ctv9601.wk1	    Table 1.  Types of disposition by types of contract cases in State courts in the
                Nation's 75 largest counties, 1996

ctv9602.wk1     Table 2.  Types of plaintiffs or defendants, by types of contract cases in State
                courts in the Nation's 75 largest counties, 1996

ctv9603.wk1     Table 3.  Types of business plaintiffs and defendants, by types of contract cases in
                State courts in the Nation's 75 largest counties, 1996

ctv9604.wk1     Table 4.  Pairings of primary litigants in selected types of contract cases in State
                courts in the Nation's 75 largest counties, 1996

ctv9605.wk1     Table 5. Trial verdicts and final award amounts for contract cases with plaintiff
                winners in State courts in the Nation's 75 largest counties, 1996

ctv9606.wk1     Table 6. Pairings of primary types of litigants in contract trials in State courts
                in the Nation's 75 largest counties, 1996

ctv9607.wk1     Table 7. Plaintiff winner cases and final award amounts, by selected litigant
                pairings and selected case types in State courts in the Nation's 75 largest
				counties, 1996

ctv9608.wk1     Table 8. Case processing time from filing of complaint to final verdict or judgment
                in State courts in the Nation's 75 largest counties, 1996

ctv9609.wk1     Table 9. Case processing time from filing of complaint to final verdict or judgment
                for pairings of primary litigants in contract trials in State courts in the Nation's
                75 largest counties, 1996

ctv96a01.wk1    Appendix  A.  Contract trial cases and plaintiff winners by sampled counties, 1996

ctv96a02.wk1    Appendix B.  Final and punitive damage awards for plaintiff winners in  
                contract jury trials, by sampled counties, 1996

ctv96a03.wk1    Appendix C.  Final and punitive damage awards for plaintiff winners in contract
                bench trials, by sampled counties, 1996

ctv96b01.wk1    Box 1.  Pairings of primary litigants in contract jury trials, by plaintiff winners
                and award amounts in State courts in the Nation's 75 largest counties, 1992 and 1996

ctv96hi.wk1     Highlight: Percent of plaintiff winners in contract cases disposed of by trial in
                State general jurisdiction courts in the Nation's 75 largest counties, 1996

