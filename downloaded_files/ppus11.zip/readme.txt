Probation and Parole in the United States, 2011 NCJ 239686

 
This zip archive contains tables in individual .csv spreadsheets from
Probation and Parole in the United States, 2011 NCJ 239686
The full electronic report is available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4538


This report is one in a series. More recent editions may be
available. To view a list of all in the series go to
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=42



ppus11at01.csv	Appendix table 1. Adults under community supervision, 2011
ppus11at02.csv	Appendix table 2. Adults on probation, 2011
ppus11at03.csv	Appendix table 3. Characteristics of adults on probation, 2000, 2010-2011
ppus11at04.csv	Appendix table 4. Adults on parole, 2011
ppus11at05.csv	Appendix table 5. Adults entering parole, by type of entry, 2011
ppus11at06.csv	Appendix table 6. Appendix table 6. Characteristics of adults on parole, 2000, 2010-2011
ppus11f01.csv	Figure 1. Adults under community supervision at yearend, 1980-2011
ppus11f02.csv	Figure 2. Adults on probation at yearend, 1980-2011
ppus11f03.csv	Figure 3. Adults on parole at yearend, 1980-2011
ppus11f04.csv	Figure 4. Estimated percent of the at-risk probation population incarcerated, 2000-2011
ppus11f05.csv	Figure 5. Entries to parole, by type of entry, 2000-2011
ppus11f06.csv	Figure 6. Estimated percent of the at-risk parole population returned to incarceration, 2000-2011
ppus11t01.csv	Table 1. U.S. adult residents under community supervision, on probation, and on parole, 2000-2011
ppus11t02.csv	Table 2. Estimated probation entries and exits and annual change, 2000-2011
ppus11t03.csv	Table 3. Rate of probation exits, by type of exit, 2008-2011
ppus11t04.csv	Table 4. Probationers who exited supervision, by type of exit, 2008-2011
ppus11t05.csv	Table 5. Estimated parole entries and exits and annual change, 2000-2011
ppus11t06.csv	Table 6. Rate of parole exits, by type of exit, 2008-2011
ppus11t07.csv	Table 7. Parolees who exited supervision, by type of exit, 2008-2011
ppus11t08.csv	Table 8. Parolees on probation who were excluded from the January 1 and December 31 community supervision populations, 2008-2011
