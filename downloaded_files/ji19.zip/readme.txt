Jail Inmates in 2019   NCJ 255608		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Jail Inmates in 2019   NCJ 255608.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7267		
		
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to https://www.bjs.gov/index.cfm?ty=pbse&sid=38		
		
Filename		Table names
ji19t01.csv		Table 1. Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2005-2019
ji19t02.csv		Table 2. Jail incarceration rates, by sex and race or ethnicity, 2005, 2008, and 2010-2019
ji19t03.csv		Table 3. Number of confined inmates in local jails, by characteristics, 2005, 2008, 2010, and 2015-2019
ji19t04.csv		Table 4. Percent of confined inmates in local jails, by characteristics, 2005, 2008, 2010, and 2015-2019
ji19t05.csv		Table 5. Average daily jail population, by size of jurisdiction, 2019
ji19t06.csv		Table 6. Jail capacity, midyear population, and percent of capacity occupied in local jails, 2005-2019
ji19t07.csv		Table 7. Percent of jail capacity occupied at midyear, by size of jurisdiction, 2019
ji19t08.csv		Table 8. Inmate turnover rate and expected average length of stay, by size of jurisdiction, 2019
ji19t09.csv		Table 9. Persons under jail supervision, by confinement status, 2005-2019
ji19t10.csv		Table 10. Staff employed in local jails, by sex, 2013 and 2015-2019
		
			Figure
ji19f01.csv		Figure 1. Jail incarceration rates at midyear, by race or ethnicity, 2005-2019
		
			Appendix tables
ji19at01.csv		Appendix Table 1. Jail incarceration rates at midyear, by race or ethnicity, 2005-2019
ji19at02.csv		Appendix table 2. Standard errors for table 1: Inmates confined at midyear, average daily population, annual admissions, and incarceration rates, 2005-2019
ji19at03.csv		Appendix table 3. Standard errors for table 2: Jail incarceration rates, by sex and race or ethnicity, 2005, 2008, and 2010-2019
ji19at04.csv		Appendix Table 4. Standard errors for table 3: Number of confined inmates in local jails, by characteristics, 2005, 2008, 2010, and 2015-2019
ji19at05.csv		Appendix table 5. Standard errors for table 4: Percent of confined inmates in local jails, by characteristics, 2005, 2008, 2010, and 2015-2019
ji19at06.csv		Appendix table 6. Standard errors for table 6: Jail capacity, midyear population, and percent of capacity occupied in local jails, 2005-2019
ji19at07.csv		Appendix table 7. Standard errors for table 9: Persons under jail supervision, by confinement status, 2005-2019
ji19at08.csv		Appendix table 8. Standard errors for table 10: Staff employed in local jails, by sex, 2013 and 2015-2019
