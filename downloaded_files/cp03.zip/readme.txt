Capital Punishment, 2003   NCJ 206627

This zip archive contains tables in individual .csv spreadsheets
from Capital Punishment, 2003, NCJ 206627. The full report including text 
and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cp03.htm 

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojjp.usdoj.gov/bjs/pubalp2.htm#cp


cp0304.csv          Table #: 4  Prisoners under sentence of death, by region, State, and race, 2002 and 2003
cp0305.csv          Table #: 5  Demographic characteristics of prisoners  under sentence of death, 2003
cp0306.csv          Table #: 6  Hispanics and women under sentence of death, by State, 2002 and 2003
cp0307.csv          Table #: 7  Age at time of arrest for capital offense and  age of prisoners under sentence of death at yearend 2003
cp0308.csv          Table #: 8  Criminal history profile of prisoners under sentence of death, by race and Hispanic origin, 2003
cp0309.csv          Table #: 9  Number of persons  executed, by jurisdiction, 1930-2003 
cp0310.csv          Table #: 10  Executions and other dispositions of inmates sentenced to death, by race and Hispanic origin, 1977-2003
cp0311.csv          Table #: 11 Time under sentence of death and execution, by race, 1977-2003

                    Highlights tables
cp03ht01.csv        Highlights table #: 1 Executions during 2003, persons under sentence of death 12/31/03 and jurisdictions without the death penalty
cp03ht02.csv        Highlights table #: 2 Persons under sentence of death, 1993 and 2003

                    Figures
cp03f01.csv         Figure #: 1 Persons under sentence of death 1953-2003
cp03f02.csv         Figure #: 2 Persons under sentence of death, by race, 1968-2003
cp03f03.csv         Figure #: 3 Admissions to and release from a sentence of death, 1977-2003 
cp03f04.csv         Figure #: 4 Persons executed, 1930-2003

                    Text tables
cp03t01.csv         Text table #: 1 Women under sentence of death by race and state, 12/31/03
cp03t02.csv         Text table #: 2 Persons under sentence  of death, by sex, race, and Hispanic origin, 12/31/03
cp03t03.csv         Text table #: 3 Number of death sentences imposed on incoming inmates, 1988-2003
cp03t04.csv         Text table #: 4 Inmates received under sentence of death, 1994-2003
cp03t05.csv         Text table #: 5 Number of executions, 1977-2003
cp03t06.csv         Text table #: 6 Number of executions by race/ethnicity and method, 1977-2003
cp03t07.csv         Text table #: 7 Elapsed time since sentencing for inmates under sentence of death by gender and race/ethnicity

                    Appendix tables
cp03at02.csv        Appendix table #: 2  Prisoners sentenced to death and the outcome of the sentence, by year of sentencing, 1973-2003
cp03at03.csv        Appendix table #: 3  Prisoners under sentence of death on December 31, 2003, by State and year of sentencing
cp03at04.csv        Appendix table #: 4  Number sentenced to death and number of removals, by jurisdiction and reason for removal, 1973-2003
cp03at05.csv        Appendix table #: 5 Executions, by State and method, 1977-2003

          			Box table
cp03bt01.csv        Box table #: 1 Advance count of executions and method used by jurisdiction, January 1, 2004-September 21, 2004
