PROBATION AND PAROLE IN 1999
Annual Probation and Parole Data Surveys

pp9901.wk1   Table 1.  Adults under community supervision or in jail or prison, 1990-99

pp9902.wk1   Table 2.  Community corrections among the States, yearend 1999

pp9903.wk1   Table 3.  Adults on probation, 1999

pp9904.wk1   Table 4.  Adults on parole, 1999

pp9905.wk1   Table 5.  Characteristics of adults on probation, 1990 and 1999

pp9906.wk1   Table 6.  Characteristics of adults on parole, 1990 and 1999










