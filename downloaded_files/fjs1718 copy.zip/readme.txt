Federal Justice Statistics, 2017-2018   NCJ 254598																		
																		
This zip archive contains tables in individual  .csv spreadsheets
Federal Justice Statistics, 2017-2018   NCJ 254598  The full report including text
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=7346																										
This report is one in a series.  More recent editions																		
may be available.  To view a list of all in the series go to																		
https://www.bjs.gov/index.cfm?ty=pbse&sid=62																		
																		
																		
Filenames		Table names																
fjs1718t01.csv		Table 1. Offenders in federal confinement or under federal supervision in the community, Fiscal Year-end 2008, 2017, and 2018						fjs1718t02.csv		Table 2. Federal arrests, by most serious offense and federal judicial district, FY 2017 and FY 2018								
fjs1718t03.csv		Table 3. Suspects in matters opened by U.S. attorneys, by referring authority, FY 2008 and FY 2016-2018
fjs1718t04.csv		Table 4. Outcome and case-processing time of suspects in matters concluded, FY 2018	
fjs1718t05.csv		Table 5. Demographic characteristics of defendants charged in U.S. district court, by sex of defendant, FY 2018
fjs1718t06.csv		Table 6. Disposition and case-processing time of defendants in cases terminated in U.S. district court, FY 2018	
fjs1718t07.csv		Table 7. Type and length of sentence imposed for convicted offenders, by offense and district, FY 2018	
fjs1718t08.csv		Table 8. Admissions and releases of federal prisoners, by offense, FY 2018
fjs1718t09.csv		Table 9. Demographic characteristics of federally sentenced prisoners in the custody of the Federal Bureau of Prisons, Fiscal Year-end 2008 and 2018
fjs1718t10.csv		Table 10. Demographic characteristics of offenders under post-sentencing federal supervision, Fiscal Year-end 2018																									
			Figures																
fjs1718f01.csv		Figure 1. Suspects and defendants processed in the federal justice system, FY 1994-2018	
fjs1718f02.csv		Figure 2. Federal and state arrests by the Drug Enforcement Administration, by powder cocaine, crack cocaine, heroin, and other opioids, FY 2008-2018
fjs1718f03.csv		Figure 3. Federal and state arrests by the Drug Enforcement Administration, by marijuana, methamphetamine, and other non-opioids, FY 2008-2018
fjs1718f04.csv		Figure 4. Defendants in criminal cases filed in U.S. district court, by offense type, FY 2008-2018
fjs1718f05.csv		Figure 5. Defendants charged in U.S. district court, by sex and most serious offense, FY 2018
fjs1718f06.csv		Figure 6. Prisoners in the custody of the Federal Bureau of Prisons, by most serious commitment offense, Fiscal Year-end 2008 and 2018
fjs1718f07.csv		Figure 7. Race or ethnicity of federally sentenced offenders in the custody of the Federal Bureau of Prisons, by most serious commitment offense, Fiscal Year-end 2018
fjs1718f08.csv		Figure 8. Offenders under federal supervision in the community, by type of commitment offense, Fiscal Year-end 2008 and 2018
fjs1718f09.csv		Figure 9. Universe of prisoners held under the Federal Bureau of Prisons’ jurisdiction and federally sentenced prisoners in the bureau’s custody, Fiscal Year-end 2018																
																		
