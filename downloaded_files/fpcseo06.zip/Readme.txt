Federal Prosecution of Child Sex Exploitation Offenders, 2006 

This zip archive contains tables in individual .csv spreadsheets		
from Federal Prosecution of Child Sex Exploitation Offenders, NCJ 219412.		
The full report including text and graphics in .pdf format are available at		
http://www.ojp.usdoj.gov/bjs/abstract/fpcseo06.htm

Filename		Table number
fpcseo06t01.csv		Table 1. Suspects referred to U.S. attorneys with sex exploitation offense as lead charge, 1994 and 2006
fpcseo06t02.csv		Table 2. Suspects in matters concluded by U.S. attorneys with a sex exploitation offense as lead charge, 2006
fpcseo06t03.csv		Table 3. Sex exploitation suspects declined for prosecution by U.S. attorneys, by reason, 2006
fpcseo06t04.csv		Table 4. Federally recognized tribes and enrolled members, 2003
fpcseo06t05.csv		Table 5. American Indian or Alaska Native defendants arraigned in Federal Court for sex abuse, 2006
fpcseo06t06.csv		Table 6. Characteristics of Federal sex exploitation defendants at initial hearing, 2006
fpcseo06t07.csv		Table 7. Disposition and sentence received in cases concluded with a child exploitation offense, 1996 and 2006
fpcseo06t08.csv		Table 8. Offense characteristics of sentenced sex exploitation offenders, by type of offense


			Figure number
fpcseo06f01.csv		Figure 1. Federal prosecutions for child sex exploitation offenders
fpcseo06f02.csv		Figure 2. Number of suspects in sex offense matters referred
fpcseo06f03.csv		Figure 3. Percent of suspects prosecuted 
fpcseo06f04.csv		Figure 4. Percent of defendants released prior to trial
fpcseo06f05.csv		Figure 5. Percent of defendants terminating pretrial release by offense and outcome
fpcseo06f06.csv		Figure 6. Fifty-eight percent of Federal sex abuse suspects in matters concluded were in 4 Federal judicial districts, 2004-2006
fpcseo06f07.csv		Figure 7. Number of sex exploitation defendants sentenced to prison
fpcseo06f08.csv		Figure 8. Median prison sentence imposed in months