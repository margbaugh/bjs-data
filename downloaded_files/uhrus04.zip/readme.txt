This zip archive contains tables in individual .csv spreadsheets from Unidentified Human Remains in the United States, 1980-2004 NCJ 219533
The full report including text and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/uhrus04.htm.	


Spreadsheet:	

uhrust01.csv	Table 1. Number of unidentified human remains in 5-year periods from 1980 to 2004, by State 

Figure:

uhrusf01.csv	Figure 1: Number of unidentified human remains reported to the National Death Index, 1980-2004

