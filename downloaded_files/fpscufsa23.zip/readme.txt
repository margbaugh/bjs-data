Federal Prisoner Statistics Collected Under the First Step Act, 2023  NCJ 307305	
	
This zip archive contains tables in individual .csv spreadsheets for	
Federal Prisoner Statistics Collected Under the First Step Act, 2023  NCJ 307305	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/federal-prisoner-statistics-collected-under-first-step-act-2023	
	
This report is one in a series.  More recent editions may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Prisoner%20Statistics%20Collected%20Under%20the%20First%20Step%20Act	
	
Filenames		Table titles
fpscufsa23t01.csv	Table 1. Selected characteristics of federal prisoners, 2018–2022
fpscufsa23t02.csv	Table 2. Medical conditions, testing, and treatment of federal prisoners, 2018–2022
fpscufsa23t03.csv	Table 3. Selected characteristics of federal facilities, 2018–2022
fpscufsa23t04.csv	Table 4. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by security level of facility, 2022
fpscufsa23t05.csv	Table 5. Federal prisoners who were cited for prohibited acts that resulted in reductions in rewards, incentives, or time credits, by demographic characteristics, 2018–2022
fpscufsa23t06.csv	Table 6. Prohibited acts by federal prisoners that resulted in reductions in rewards, incentives, or time credits, by facility, 2022
fpscufsa23t07.csv	Table 7. Prisoner assaults on Federal Bureau of Prisons staff, by type of assault and prosecution status, 2022
fpscufsa23t08.csv	Table 8. Volunteer levels in Federal Bureau of Prisons facilities, by facility, December 31, 2022
fpscufsa23t09.csv	Table 9. Recidivism reduction partnerships in Federal Bureau of Prisons facilities, by facility, 2022
fpscufsa23t10.csv	Table 10. Recidivism risk classification of persons in federal prison, by demographic and sentence characteristics, 2022
fpscufsa23t11.csv	Table 11. Approved Evidence-Based Recidivism Reduction Programs and Productive Activities, by facility availability and prisoner needs met, 2022
	
*Not included in report	
fpscufsa23t12.csv	Table 12. Enrollment and completion of Evidence-Based Recidivism Reduction Programs and Productive Activities, by BOP facility, program or activity, and recidivism risk level, 2022
