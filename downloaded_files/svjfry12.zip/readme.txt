Sexual Victimization in Juvenile Facilities Reported by Youth, 2012 NCJ 241708		
		
 		
This zip archive contains tables in individual .csv spreadsheets from		
Sexual Victimization in Juvenile Facilities Reported by Youth, 2012 NCJ 241708		
		
The full electronic report is available at:		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4656		
		
		
Filename		Appendix table title
svjfy12at01.csv		Appendix table 1:  Characteristics of juvenile facilities participating in the National Survey of Youth in Custody, 2012
svjfy12at02.csv		Appendix table 2. Percent of youth reporting sexual victimization, by facility, National Survey of Youth in Custody, 2012
svjfy12at03.csv		Appendix table 3. Percent of youth reporting sexual victimization by another youth, by type of incident and facility, National Survey of Youth in Custody, 2012
svjfy12at04.csv		Appendix table 4. Percent of youth reporting staff sexual misconduct, by type of incident and facility, National Survey of Youth in Custody, 2012
svjfy12at05.csv		Appendix table 5. Percent of youth reporting staff sexual misconduct excluding touching, by use of force and facility, National Survey of Youth in Custody, 2012
svjfy12at06.csv		Appendix table 6. Characteristics of juvenile facilities used to provide state-level estimates, National Survey of Youth in Custody, 2012
svjfy12at07.csv		Appendix table 7. Percent of youth reporting sexual victimization, by type of incident and state, National Survey of Youth in Custody, 2012
		
Filename		Figure title
svjfy12f01.csv		Figure 1: Confidence intervals at the 95%-level for juvenile facilities with the highest rates of sexual victimization, National Survey of Youth in Custody, 2012
svjfy12f02.csv		Figure 2: Confidence intervals at the 95%-level for juvenile facilities with high rates of sexual victimization, by state, National Survey of Youth in Custody, 2012
		
Filename		Table title
svjfy12t01.csv		Table 1: Youth reporting sexual victimization, by type of incident, National Survey of Youth in Custody, 2012
svjfy12t02.csv		Table 2: Table 2: Youth reporting sexual victimization in state juvenile facilities, by type of incident and survey year, National Survey of Youth in Custody, 2008?09 and 2012
svjfy12t03.csv		Table 3: Percent of youth reporting sexual victimization, by youth opinions about facility and staff, facility size, and exposure time, National Survey of Youth in Custody, 2008?09 and 2012
svjfy12t04.csv		Table 4: Juvenile facilities with the highest rates of sexual victimization, National Survey of Youth in Custody, 2012
svjfy12t05.csv		Table 5: Juvenile facilities with the lowest rates of sexual victimization, National Survey of Youth in Custody, 2012
svjfy12t06.csv		Table 6: Juvenile facilities with the highest rates of sexual victimization, by type of contact, National Survey of Youth in Custody, 2012
svjfy12t07.csv		Table 7: Juvenile facilities with the highest rates of sexual victimization, by type of incident, National Survey of Youth in Custody, 2012
svjfy12t08.csv		Table 8: Juvenile facilities with the highest rates of staff sexual victimization, by use of force, National Survey of Youth in Custody, 2012
svjfy12t09.csv		Table 9: Prevalence of sexual victimization, by type of incident and selected facility characteristics, National Survey of Youth in Custody, 2012
svjfy12t10.csv		Table 10: Percent of youth reporting sexual victimization, by state, National Survey of Youth in Custody, 2012
svjfy12t11.csv		Table 11: Prevalence of sexual victimization, by type of incident and selected youth victim characteristics, National Survey of Youth in Custody, 2012
svjfy12t12.csv		Table 12: Experiences of youth-on-youth victims of sexual victimization, National Survey of Youth in Custody, 2012
svjfy12t13.csv		Table 13: Circumstances surrounding youth-on-youth sexual victimization, National Survey of Youth in Custody, 2012
svjfy12t14.csv		Table 14: Victims of staff sexual misconduct, by use of force and sex of youth and staff, National Survey of Youth in Custody, 2012
svjfy12t15.csv		Table 15: Circumstances surrounding incidents of staff sexual misconduct, National Survey of Youth in Custody, 2012
svjfy12t16.csv		Table 16: Victims of staff sexual misconduct, by relationship characteristic, National Survey of Youth in Custody, 2012
svjfy12t17.csv		Table 17: Estimated rates of sexual victimization and lower bounds of the 95%-confidence intervals among high-rate facilities, by exclusion criteria, National Survey of Youth in Custody, 2012
