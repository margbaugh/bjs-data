Bureau of Justice Statistics
Law Enforcement Management and Administrative Statistics, 1999:
Data for Individual State and Local Agencies with 100 or more Officers
By Brian A. Reaves, Ph.D. and Timothy C. Hart, BJS Statisticians

Contents of Zip archive lema994a.zip.  This file contains the tables from one section of the
report.  Additional tables are available at www.ojp.usdoj.gov/bjs/abstract/lemas99.htm.

LOCAL AGENCIES

IV.  COMPUTERS AND INFORMATION SYSTEMS

lem9914a.wk1 Selected functions of computers, 1999

lem9915a.wk1  Types of computerized files, 1999

lem9916a.wk1  Additional types of computerized files, 1999

lem9917a.wk1  Types of in-field computers/terminals used by patrol officers and primary 
method of transmitting field reports, 1999

lem9918a.wk1  Patrol officer access to information through the use of in-field computers, 1999
  

