Trends in State Parole, 1990-2000 NCJ 184735

This zip archive contains tables in individual .wk1 spreadsheets
from Trends in State Parole, 1990-2000 NCJ 184735 The full report including 
text and graphics in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/tsp00.htm 

File name:     Table name:
tsp0001.wk1    Table 1, Number of persons in State prison and on parole, yearend 1980, 1985, and 1990-2000
tsp0002.wk1    Table 2, Adults on parole, by State, yearend 1990, 1995, and 2000
tsp0003.wk1    Table 3, Method of release from State prison, for selected years, 1980-99
tsp0004.wk1    Table 4, Partitioning the growth in method of release from State prison, by offense, 1990-99
tsp0005.wk1    Table 5, Sentence length and time served for first releases from State prison, 1990 and 1999
tsp0006.wk1    Table 6, Time served, maximum sentence length, and percent of sentence served for Part 1 violent offenders, by State, 1993, 1996, and 1999 
tsp0007.wk1    Table 7, Sentence length and time served for first releases from State prison, by method of release, 1990 and 1999
tsp0008.wk1    Table 8, Mean time served in prison for first releases to State parole, by method of release, 1999
tsp0009.wk1    Table 9, Characteristics of State prisoners expected to be released by yearend 1999
tsp0010.wk1    Table 10, Substance abuse, mental illness, and homelessness among State prisoners expected to be released by yearend 1999
tsp0011.wk1    Table 11, State parole entries and discharges, 1980 and 1990-2000
tsp0012.wk1    Table 12, Criminal justice characteristics of State parole entries, 1990 and 1999
tsp0013.wk1    Table 13, Demographic characteristics of State parole entries, 1990 and 1999
tsp0014.wk1    Table 14, Most serious offense of first releases to State parole, 1990 and 1999
tsp0015.wk1    Table 15, Percent successful among State parole discharges, by State, 1990, 1995, and 1999
tsp0016.wk1    Table 16, Percent successful among State parole discharges, by method of release from prison, 1990-99
tsp0017.wk1    Table 17, Percent successful among State parole discharges, by type and method of release, 1990-99
tsp0018.wk1    Table 18, Percent successful among State parole discharges, by selected characteristics, 1990 and 1999
tsp0019.wk1    Table 19, Percent parole violators among admissions to State prison, 1990 and 1999
tsp0020.wk1    Table 20, Characteristics of parole violators in State prison, 1991 and 1997
tsp0021.wk1    Table 21, Reasons for revocation among parole violators in State prison, for all States, California, New York, and Texas, 1997
tsp0022.wk1    Table 22, Characteristics of parole violators in State prison for all States, California, New York, and Texas, 1997