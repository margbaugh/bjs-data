Stalking Victimization, 2019  NCJ 301735
														
This zip archive contains tables in individual  .csv spreadsheets													
from Stalking Victimization, 2019  NCJ 301735														
The full report including text and graphics in pdf format are available													
from: https://bjs.ojp.gov/library/publications/stalking-victimization-2019

This report is one in a series.  More recent editions may be available. 
To view a list of all in the series go to: 
https://bjs.ojp.gov/library/publications/list?series_filter=Stalking%20Victimization

Filename	Table titles
sv19t01.csv	Table 1. Persons age 16 or older who were victims of stalking, by type of stalking behavior, 2019
sv19t02.csv	Table 2. Percent of stalking victims, by type of stalking, reporting to police, and reason for not reporting, 2016 and 2019
sv19t03.csv	Table 3. Prevalence of cyberstalking, by type of cyberstalking behavior, 2019
sv19t04.csv	Table 4. Prevalence of stalking, by demographic characteristics of victims, 2019
sv19t05.csv	Table 5. Percent of stalking victims, by type of stalking and victim-offender relationship, 2019
sv19t06.csv	Table 6. Percent of stalking victims, by type of stalking and duration and frequency of stalking, 2019
sv19t07.csv	Table 7. Percent of stalking victims, by type of stalking and victim’s self-protective actions, 2019
sv19t08.csv	Table 8. Percent of stalking victims, by type of stalking and victim’s fears, 2019
sv19t09.csv	Table 9. Percent of stalking victims who sought and received victim services, by type of service received, 2019
sv19t10.csv	Table 10. Number and percent of stalking victims, by component of stalking definition, 2019
	
		Figures
sv19f01.csv	Figure 1. Prevalence of stalking, by type of stalking, 2016 and 2019
sv19f02.csv	Figure 2. Percent of stalking victims who reported to police, by type of stalking, 2016 and 2019
sv19f03.csv	Figure 3. Percent of stalking victims who sought victim services, by type of stalking, 2019
	
		Appendix tables
sv19tat01.csv	Appendix table 1. Number and percent of persons who were victims of stalking, by type of stalking, 2016 and 2019
sv19tat02.csv	Appendix table 2. Estimates and standard errors for figure 1: Prevalence of stalking, by type of stalking, 2016 and 2019
sv19tat03.csv	Appendix table 3. Standard errors for table 1: Persons age 16 or older who were victims of stalking, by type of stalking behavior, 2019
sv19tat04.csv	Appendix table 4. Estimates and standard errors for figure 2: Percent of stalking victims who reported to police, by type of stalking, 2016 and 2019
sv19tat05.csv	Appendix table 5. Standard errors for table 2: Percent of stalking victims, by type of stalking, reporting to police, and reason for not reporting, 2016 and 2019
sv19tat06.csv	Appendix table 6. Standard errors for table 3: Prevalence of cyberstalking, by type of cyberstalking behavior, 2019
sv19tat07.csv	Appendix table 7. Standard errors for table 4: Prevalence of stalking, by demographic characteristics of victims, 2019
sv19tat08.csv	Appendix table 8. Standard errors for table 5: Percent of stalking victims, by type of stalking and victim-offender relationship, 2019
sv19tat09.csv	Appendix table 9. Standard errors for table 6: Percent of stalking victims, by type of stalking and duration and frequency of stalking, 2019
sv19tat10.csv	Appendix table 10. Standard errors for table 7: Percent of stalking victims, by type of stalking and victim’s self-protective actions, 2019
sv19tat11.csv	Appendix table 11. Standard errors for table 8: Percent of stalking victims, by type of stalking and victim’s fears, 2019
sv19tat12.csv	Appendix table 12. Estimates and standard errors for figure 3: Percent of stalking victims who sought victim services, by type of stalking, 2019
sv19tat13.csv	Appendix table 13. Standard errors for table 9: Percent of stalking victims who sought and received victim services, by type of service received, 2019
sv19tat14.csv	Appendix table 14. Standard errors for table 10: Number and percent of stalking victims, by component of stalking definition, 2019
sv19tat15.csv	Appendix table 15. Standard errors for appendix table 1: Number and percent of persons who were victims of stalking, by type of stalking, 2016 and 2019