Felony Sentences in State Courts, 1998   NCJ  190103
 
This zip archive contains tables in individual .wk1 spreadsheets
from Felony Sentences in State Courts, 1998   NCJ  190103.
The full report and supporting materials in pdf and ascii format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/fssc98.htm 
 

Comparison of felony convictions in State and Federal courts, 1998
filename:  fssc98fed.wk1

Table 1:  Estimated number of felony convictions in State courts, 1998
filename:  fssc9801.wk1

Table 2:  Types of felony sentences imposed by State courts, by offense, 1998
filename:  fssc9802.wk1

Table 3:  Lengths of felony sentences imposed by State courts, by offense and type of sentence, 1998
filename:  fssc9803.wk1

Table 4:  Estimated time to be served in State prison, by offense, 1998
filename:  fssc9804.wk1

Table 5:  Demographic characteristics of persons convicted of felonies by State courts, by offense, 1998
filename:  fssc9805.wk1

Table 6:  Number of offenses for felons convicted and sentenced in 1998 in State courts, by most serious felony conviction offense, 1998
filename:  fssc9806.wk1

Table 7:  Convicted felons sentenced to prison by State courts, by number of conviction offenses, 1998
filename:  fssc9807.wk1

Table 8:  Mean sentence lengths for State felony sentences imposed, by the number and category of the conviction offense, 1998
filename:  fssc9808.wk1

Table 9:  Number of felony convictions in State courts, by offense and type of conviction, 1998
filename:  fssc9809.wk1

Table 10:  Percent of felons convicted in State courts, by offense and type of conviction, 1998
filename:  fssc9810.wk1

Table 11:  Mean and median number of days between arrest and sentencing for felony cases disposed by State courts, 1998
filename:  fssc9811.wk1

Table 12:  Felons sentenced to an additional penalty by State courts, by offense, 1998
filename:  fssc9812.wk1

Estimate of 1 standard error for table 1, 1998 
filename:  FSS98SE1.wk1

Estimate of 1 standard error for table 2, 1998 
filename:  FSS98SE2.wk1

Estimate of 1 standard error for table 3, 1998 
filename:  FSS98SE3.wk1

Estimate of 1 standard error for table 5, 1998 
filename:  FSS98SE5.wk1

Estimate of 1 standard error for table 6, 1998 
filename:  FSS98SE6.wk1

Estimate of 1 standard error for table 7, 1998 
filename:  FSS98SE7.wk1

Estimate of 1 standard error for table 8, 1998 
filename:  FSS98SE8.wk1

Estimate of 1 standard error for table 9, 1998 
filename:  FSS98SE9.wk1

Estimate of 1 standard error for table 10, 1998 
filename:  FS98SE10.wk1

Estimate of 1 standard error for table 11, 1998 
filename:  FS98SE11.wk1

Estimate of 1 standard error for table 12, 1998 
filename:  FS98SE12.wk1