State Court Sentencing of Convicted Felons, 2000, NCJ 198822
Chapter 1:  Felony sentences in State courts, 2000

This zip archive contains tables in individual .csv spreadsheets
from State Court Sentencing of Convicted Felons, 2000, NCJ 198822.
The full report including text and graphics in pdf format are available from:
https://bjs.ojp.gov/library/publications/state-court-sentencing-convicted-felons-2000-statistical-series  

These tables are part of a series. For a list of all in this series see:
https://bjs.ojp.gov/library/publications/list?series_filter=State%20Court%20Sentencing%20of%20Convicted%20Felons

File name		Title
scs0011.csv		Table 1.1 Estimated number of felony convictions in State courts, 2000
scs0012.csv		Table 1.2 Distribution of types of felony sentences imposed by State courts, by offense, 2000
scs0013.csv		Table 1.3 Average felony sentence lengths in State courts, by offense and type of sentence, 2000
scs0014.csv		Table 1.4 Estimated percent of felons sentenced to life in State prison, by offense, 2000
scs0015.csv		Table 1.5 Estimated time to be served in State prison, by offense, 2000
scs0016.csv		Table 1.6 Distribution of the number of felony conviction offenses for persons sentenced in State courts, by most serious offense, 2000
scs0017.csv		Table 1.7 Convicted felons sentenced to prison by State courts, by number of conviction offenses, 2000
scs0018.csv		Table 1.8 Mean sentence lengths for State felony sentences imposed, by the number and category of the conviction offense, 2000
scs0019.csv		Table 1.9 Felons sentenced to an additional penalty by State courts, by offense, 2000
