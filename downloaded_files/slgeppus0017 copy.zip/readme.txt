State and Local Government Expenditures on Police Protection in the U.S., 2000-2017   NCJ 254856	
	
This zip archive contains tables in individual  .csv spreadsheets	
from State and Local Government Expenditures on Police Protection in the U.S., 2000-2017   NCJ 254856.	
The full report including text and graphics in pdf format is available from:	
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6927	
	
Filename		Table name
slgeppus0017t01.csv	Table 1. Real (inflation-adjusted) state and local government expenditures on police protection in the U.S., 2000-2017
slgeppus0017t01a.csv	Table 1a. Real (inflation-adjusted) local government expenditures on police protection in the U.S., 2000-2017
slgeppus0017t02.csv	Table 2. Real (inflation-adjusted) local government spending on police protection in the 25 most-populous U.S. cities, 2000-2017
slgeppus0017t03.csv	Table 3. Nominal (not inflation-adjusted) state and local government expenditures on police protection in the U.S., 2000-2017
slgeppus0017t03a.csv	Table 3a. Nominal (not inflation-adjusted) local government expenditures on police protection in the U.S., 2000-2017
slgeppus0017t04.csv	Table 4. Nominal (not inflation-adjusted) local spending on police protection in the 25 most-populous U.S. cities, 2017
slgeppus0017t05.csv	Table 5. State and local government police-protection and direct general expenditures as a percent of U.S. Gross Domestic Product, 2000-2017
slgeppus0017t05a.csv	Table 5a. Local government police-protection and direct general expenditures as a percent of U.S. Gross Domestic Product, 2000-2017
slgeppus0017t06.csv	Table 6. Nominal expenditures on police protection as a percent of U.S. Gross Domestic Product in the 25 most-populous U.S. cities, 2000-2017
