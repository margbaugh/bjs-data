"Repeat Violent Victimization, 2005-14 � Special report, NCJ 250567

This zip archive contains tables in individual .csv spreadsheets			
from "Repeat Violent Victimization, 2005-14 � Special report, NCJ 250567. 
The full report including textand grahics in pdf format is available 
from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6046		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to
https://www.bjs.gov/index.cfm?ty=pbse&sid=22		
			
			
			
Filename	        Title

Tables

rvv0514t01.csv	        Months between the first and second victimization among repeat violent crime victims, 2005�2014

rvv0514t02.csv		Prevalence of violent crime, by single or repeat victimization and victim demographic characteristics, 2005�2014
	
rvv0514t03.csv		Percent of violent crime victims who experienced single or repeat victimization during the year, by victim-offender relationship, 2005�2014 
		
rvv0514t04.csv		Percent of violent crime victims who experienced repeat victimization, by victim-offender relationship and victim's sex, 2005�2014

		
rvv0514t05.csv		Percent of victimizations committed against repeat violent crime victims, by victim-offender relationship, 2005�2014

rvv0514t06.csv		Percent of violent crime victims who experienced single or repeat victimization during the year, by type of crime, 2005�2014 

rvv0514t07.csv		Percent of violent crime victims who experienced repeat victimization, by type of crime and victim's sex, 2005�2014

rvv0514t08.csv		Percent of victimizations committed against repeat violent crime victims, by type of crime, 2005�2014  

rvv0514t09.csv		Months between the first and second victimization among repeat violent crime victims, by number of interviews during the year, 2005�2014

rvv0514t10.csv		Prevalence of violent crime by number of interviews during the year, 2005�2014


Figure
	
rvv0514f01.csv		Percent of violent crime victims, by the number of victimizations they experienced during the year, 2005�2014 	

rvv0514f02.csv		Prevalence of violent crime, by single and repeat victimization, 1993�2014

rvv0514f03.csv		Prevalence of serious violent crime, by single and repeat victimization, 1993�2014

rvv0514f04.csv		Percent of violent crime victims and victimizations accounted for by repeat victims, 1993�2014 

rvv0514f05.csv		Percent of violent crime victims and victimizations accounted for by victims who experienced six or more violent victimizations during the year, 1993�2014

rvv0514f06.csv		Percent of violent crime victims and victimizations accounted for by repeat victims, by victim-offender relationship, 2005�2014

rvv0514f07.csv		Percent of violent crime victims and victimizations accounted for by repeat victims, by type of crime, 2005�2014
		

Appendix tables

rvv0514at01.csv		Standard errors for figure 1: Percent of violent crime victims, by number of victimizations they experienced during the year, 2005�2014
		
rvv0514at02.csv		Estimates and standard errors for figure 2: Prevalence of violent crime, by single and repeat victimization, 1993�2014
		
rvv0514at03.csv		Estimates and standard errors for figure 3: Prevalence of serious violent crime, by single and repeat victimization, 1993�2014
		
rvv0514at04.csv		Standard errors for table 1: Months between the first and second victimization among repeat violent crime victims, 2005�2014
		
rvv0514at05.csv		Estimates and standard errors for figure 4: Percent of violent crime victims and victimizations accounted for by repeat victims, 1993�2014
		
rvv0514at06.csv		Estimates and standard errors for figure 5: Percent of violent crime victims and victimizations accounted for by victims who experienced six or more violent victimizations during the year, 1993�2014
		
rvv0514at07.csv		Standard errors for table 2: Prevalence of violent crime, by single or repeat victimization and victim demographic characteristics, 2005�2014 
		
rvv0514at08.csv		Standard errors for table 3:  Percent of violent crime victims who experienced single or repeat victimization during the year, by victim-offender relationship, 2005�2014 
		
rvv0514at09.csv		Standard errors for table 4: Percent of violent crime victims who experienced repeat victimization, by victim-offender relationship and victim's sex, 2005�2014
		
rvv0514at10.csv		Estimates and standard errors for figure 6: Percent of violent crime victims and victimizations accounted for by repeat victims, by victim-offender relationship, 2005�2014	
		
rvv0514at11.csv		Standard errors for table 5: Percent of victimizations committed against repeat violent crime victims, by victim-offender relationship, 2005�2014

rvv0514at12.csv		Standard errors for table 6: Percent of violent crime victims who experienced single or repeat victimization during the year, by type of crime, 2005�2014

rvv0514at13.csv		Standard errors for table 7: Percent of violent crime victims who experienced repeat victimization, by type of crime and victim's sex, 2005�2014	

rvv0514at14.csv		Estimates and standard errors for figure 7: Percent of violent crime victims and victimizations accounted for by repeat victims, by type of crime, 2005�2014

rvv0514at15.csv		Standard errors for table 8: Percent of victimizations committed against repeat violent crime victims, by type of crime, 2005�2014  

rvv0514at16.csv		Standard errors for table 9: Months between the first and second victimization among repeat violent crime victims, by number of interviews during the year, 2005�2014

rvv0514at17.csv		Standard errors for table 10: Prevalence of violent crime by number of interviews during the year, 2005�2014


7/27/2017


