BACKGROUND CHECKS FOR FIREARM TRANSFERS, 2009 - Statistical Tables NCJ 231679															

----------------------------------------------------------------------------																	
This zip archive contains tables in individual .csv spreadsheets from the
Firearm Inquiry Statistics (FIST) program,Background Checks for
Firearm Transfers, 2009 - Statistical Tables NCJ 231679.
The full report including text and 
graphics in pdf format are available from:
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbdetail&iid=2214

To view a list of all in the series go to
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=13
----------------------------------------------------------------------------
																	
Filename		Table																
																	
bcft09st01.csv		Table 1.  Number of applications and estimates of denials for firearm transfers or permits since the inception of the Brady Act, 1994-2009
bcft09st02.csv		Table 2.  Number of applications and denials, by type of agency and type of check, 1999 - 2009
bcft09st03a.csv	        Table 3a. Number of firearm applications received and denied by selected state agencies, 1999-2009
bcft09st03b.csv 	Table 3b. Local denial rates by community size and type of permit, 1999-2009
bcft09st04.csv		Table 4.  Reasons for denial of firearm transfer applications by checking agencies, 1999-2009  
bcft09st05.csv		Table 5.  Changes in the number of applications, denials, and reasons for denials, 1999-2009
bcft09st06.csv		Table 6.  Appeals by type of checking agency, 2000-2009
bcft09st07.csv		Table 7.  Reported arrests of denied persons, 2000-2009
bcft09st08.csv		Table 8.  ATF investigation of National Instant Criminal Background Check System (NICS) denials by the FBI, 2009
bcft09st09.csv		Table 9.  Counts of National Instant Criminal Background Check System (NICS) Index prohibited person records, 2009


bcft09stat01.csv	Appendix table 1. Agencies conducting firearm background checks, December 31, 2009
bcft09stat02.csv	Appendix table 2. National Instant Criminal Background Check System (NICS):  Checking agencies -- FBI or State point of contact -- for firearm transfers, 2009
bcft09stat03.csv        Appendix table 3. Forums for appeals of denials, 2009
