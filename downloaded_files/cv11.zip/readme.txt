Criminal Victimization, 2011     NCJ  239437			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization,  2011,   NCJ  239437.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4494			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://bjs.gov/index.cfm?ty=pbse&sid=6			
			
			
Filename			Table title
cv11t01.csv			Table 1. Number of violent victimizations and percent change, by type of violent crime, 2002, 2010, and 2011
cv11t02.csv			Table 2. Rate of violent victimization and percent change, by type of violent crime, 2002, 2010, and 2011
cv11t03.csv			Table 3. Number of property victimizations and percent change, by type of property crime, 2002, 2010, and 2011
cv11t04.csv			Table 4. Rate of property victimization and percent change, by type of property crime, 2002, 2010, and 2011
cv11t05.csv			Table 5. Rate and percent change of violent victimization, by demographic characteristics of victim, 2002, 2010, and 2011
cv11t06.csv			Table 6. Rate and percent change of violent victimization, by household location, 2002, 2010, and 2011
cv11t07.csv			Table 7. Percent changes in the number of crimes reported in the UCR and the NCVS, 2010�2011
cv11t08.csv			Table 8. Percent and percent change of victimizations reported to the police, by type of crime, 2002, 2010, and 2011
cv11t09.csv			Table 9. Rate and percent change of victimizations reported and not reported to the police, by type of crime, 2002, 2010, and 2011
			
Figures			
cv11f01.csv			Figure 1. Percent change in rate of violent victimization since 1993
cv11f02.csv			Figure 2. Violent victimization with series included and excluded, 1993�2011
cv11f03.csv			Figure 3. Total violent and serious violent victimizations, by rolling quarters, 1993�2011
cv11f04.csv			Figure 4. Change in violent victimization rates, 1993-2011
			
Appendix tables			
cv11at01.csv			Appendix Table 1. Standard errors for table 1: Number of violent victimizations, by type of violent crime, 2002, 2010, and 2011 
cv11at02.csv			Appendix Table 2. Standard errors for table 2: Rate of violent victimization, by type of violent crime, 2002, 2010, and 2011
cv11at03.csv			Appendix Table 3. Standard errors for table 3: Number of property victimizations, by type of property crime, 2002, 2010, and 2011
cv11at04.csv			Appendix Table 4. Standard errors for table 4: Rate of property victimization, by type of property crime, 2002, 2010, and 2011
cv11at05.csv			Appendix Table 5. Standard errors for table 5: Rate of violent victimization, by demographic characteristics of victim, 2002, 2010, and 2011
cv11at06.csv			Appendix Table 6. Standard errors for table 6: Rate of violent victimization, by household location, 2002, 2010, and 2011
cv11at07.csv			Appendix Table 7. Standard errors for table 8: Percent of victimizations reported to the police, by type of crime, 2002, 2010, and 2011
cv11at08.csv			Appendix Table 8. Standard errors for table 9: Rate of victimizations reported and not reported to the police, by type of crime, 2002, 2010, and 2011
cv11at09.csv			Appendix Table 9. Standard errors for figure 2: Violent victimization with series included and excluded, 1993�2011
