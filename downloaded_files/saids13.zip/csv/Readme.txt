"State-Administered Indigent Defense Systems, 2013      NCJ 250249"		
		
This zip archive contains tables in individual  .csv spreadsheets		
"from State-Administered Indigent Defense Systems, 2013, NCJ 250249.  The full report including text"		
and graphics in pdf format is available from: http://bjs.gov/index.cfm?ty=pbdetail&iid=5826	
			
		
Filename	Table title	
said13t01.csv		"Table 1: Characteristics of state-administered indigent defense systems, by state, fiscal year 2013"
said13t02.csv		"Table 2: Cases closed by state indigent defense systems, by case type and state, fiscal year 2013"
said13t03.csv		"Table 3: Number of closed cases per full-time equivalent litigating attorney in state indigent defense systems, by selected case type, fiscal year 2013 "
said13t04.csv		"Table 4: Application fees and payment for legal representation and support services in state indigent defense systems, by requirements and state, fiscal year 2013"
said13t05.csv		"Table 5: Total revenue received by state indigent defense systems, by source and state, fiscal year 2013"
said13t06.csv		"Table 6: Factors used to determine client indigence in state indigent defense systems, by state, fiscal year 2013"
said13t07.csv		"Table 7: Full-time equivalent attorney staff paid by state indigent defense systems, by type of attorney and state, fiscal year 2013"
said13t08.csv		"Table 8: Regular performance reviews and personnel development offered to attorneys in state indigent defense systems,  by state, fiscal year 2013"
said13t09.csv		"Table 9: Public defender office full-time equivalent (FTE) support staff in state indigent defense systems, by state, fiscal year 2013"
said13t10.csv		"Table 10: Authority to appointment of chief executive in state indigent defense systems, by term of office, fiscal year 2013"
said13t11.csv		"Table 11: Trends in full-time equivalent public defender staffing in state indigent defense systems, fiscal year 2007 and 2013"
said13t12.csv		"Table 12: Advisory board or commission powers in state indigent defense systems, by state, fiscal year 2013"
said13t13.csv		"Table 13: Characteristics of contract counsel delivery method in state indigent defense systems, by state or office, fiscal year 2013"
said13t14.csv		"Table 14: General standards for assigned or appointed counsel in state indigent defense systems, by office maintaining list of eligible attorneys, fiscal year 2013"
		
Figure Tables		
said13f01.csv		"Figure 1: States that collected fees for indigent defense, fiscal year 2013"
said13f02.csv		"Figure 2: Caseload standards and guidelines for attorney representation in criminal and juvenile cases in state indigent defense systems, fiscal year 2013"
said13f03.csv		"Figure 3: How conflicts of interest were managed by state indigent defense systems, by office, fiscal year 2013"
said13f04.csv		"Figure 4: Attorneys reimbursed for out of pocket expenses in state indigent defense systems, by delivery method, fiscal year 2013"
		
Appendix tables		
said13at01.csv		"Appendix Table 1: Delivery methods to provide indigent defense, by state, fiscal year 2013"
said13at02.csv		"Appendix table 2: Cases closed by state indigent defense systems, by delivery method and state, fiscal year 2013"
said13at03.csv		"Appendix table 3: Guidelines and standards in state indigent defense systems, by state, fiscal year 2013"
said13at04.csv		"Appendix table 4: Types of continuing legal education or professional development offered to attorneys in state indigent defense systems, by state, fiscal year 2013"
said13at05.csv		"Appendix table 5: Full-time equivalent support staff in state indigent defense systems, by state, fiscal year 2013"
said13at06.csv		"Appendix table 6: Appointing members of the advisory board in state indigent defense systems, by state, fiscal year 2013"
