Bureau of Justice Statistics
Civil Trial Cases and Verdicts in Large Counties, 1996 - NCJ  173426
Contents of Zip archive,  ctcvlc96.zip
 
 
 
 
Filename          Table titles
 
ctcvlchi.wk1      Highlights: Tracking tort, contract, and real property cases disposed of by trial in State courts in the Nation's 75 largest 
                   counties, 1996
ctcvlc01.wk1      Table 1:  Civil trial case types disposed of in State Courts in the Nation's 75 largest counties, 1996
ctcvlc02.wk1      Table 2. Type of plaintiffs or defendants, by disposition of civil trial cases in State courts in the Nation's 75 largest 
                   counties, 1996
ctcvlc03.wk1      Table 3. Type of plaintiffs or defendants, by selected types of civil trial cases in State courts in the Nation's 75 largest 
                   counties, 1996
ctcvlc04.wk1      Table 4. Pairings of primary litigants in civil trial cases, by selected case types in State courts in the Nation's 75 largest 
                   counties, 1996
ctcvlc05.wk1      Table 5. Trial award winners in the Nation's 75 largest counties, 1996
ctcvlc06.wk1      Table 6. Final award amounts for civil trial cases with plaintiff winners in State courts in the Nation's 75 largest counties, 
                   1996
ctcvlc07.wk1      Table 7. Final award amounts for civil jury and bench trial cases with plaintiff winners in State courts in the Nation's 75 
                   largest counties, 1996
ctcvlc08.wk1      Table 8. Punitive damage awards in civil trial cases for plaintiff winners in the Nation's 75 largest counties, 1996
ctcvlc09.wk1      Table 9. Punitive damages awarded to plaintiff winners in jury and bench trials in the Nation's 75 largest counties, 1996
ctcvlc10.wk1      Table 10. Compensatory and total award amounts for plaintiff winners who were awarded punitive damages in civil trials in 
                   State courts in the Nation's 75 largest counties, 1996
ctcvlc11.wk1      Table 11. Case processing time from filing of complaint to final verdict  or judgment in State courts in the Nation's 75 
                   largest counties, 1996
ctcvlc12.wk1      Table 12.  Case processing time from filing of complaint to final verdict or judgment in State courts in the Nation's 75 
                   largest counties, 1996
ctcvlcf1.wk1      figure 1: Tort, contract, and real property cases disposed of by jury or bench trial in the Nation's 75 largest counties, 1996
ctcvlcf2.wk1      figure 2: During 1996, 70% of bench cases and 56% of jury cases were disposed of within 2 years of being filed
ctcvlp12.wk1      Box p.12:  Federal tort, contract and real property trial cases terminated in U.S. district courts, 1996
ctcvlp16.wk1      Box p.16: Final award amounts and punitive damage amounts for jury trial cases with plaintiff winners in State courts in the 
                   Nation's 75 largest counties, 1992
ctcvlcaa.wk1      Appendix A.  Civil trial juries:  size and verdict rules in State courts of general jurisdiction
ctcvlcab.wk1      Appendix B.  Selected characteristics of sampled counties
ctcvlcac.wk1      Appendix C.  Trial cases and plaintiff winners by sampled counties, 1996
ctcvlcad.wk1      Appendix D.  Final and punitive damage awards for plaintiff winners in jury trials, by sampled counties, 1996
ctcvlcae.wk1      Appendix E.  Final and punitive damage awards for plaintiff winners in bench trials, by sampled counties, 1996
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
