Criminal Victimization, 2016: Revised     NCJ 252121		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Criminal Victimization, 2016: Revised     NCJ 252121.  The full report including text		
and graphics in pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6427		
		
This report is one in a series.  More recent editions may be available.		
To view a list of all in the series go to		
https://www.bjs.gov/index.cfm?ty=pbse&sid=6		
		
Filename		Table title
cv16ret01.csv		Table 1. Violent victimization, by type of crime, 2015 and 2016
cv16ret02.csv		Table 2. Property victimization, by type of crime, 2015 and 2016
cv16ret03.csv		Table 3. Rate of crime reported to police in the Uniform Crime Reporting Program and National Crime Victimization Survey, 2016
cv16ret04.csv		Table 4. Percent and rate of victimizations reported to police, by type of crime, 2015 and 2016
cv16ret05.csv		Table 5. Rate of violent victimization, by demographic characteristics of victims, 2015 and 2016
cv16ret06.csv		Table 6. Violent victimization, by type of crime and sex of victim, 2015 and 2016
cv16ret07.csv		Table 7. Violent victimization, by sex and age of victim, 2015 and 2016
cv16ret08.csv		Table 8. Rate of serious violent victimization, by demographic characteristics of victims, 2015 and 2016
cv16ret09.csv		Table 9. Number of victims and prevalence rate, by type of crime, 2015 and 2016
cv16ret10.csv		Table 10. Prevalence of violent crime, by demographic characteristics of victims, 2015 and 2016
cv16ret11.csv		Table 11. Completed unweighted 2015 and 2016 National Crime Victimization Survey household interviews used to create revised 2016 data file, by county status
cv16ret12.csv		Table 12. Unweighted and weighted distribution of revised file household interviews from 2015 and 2016
		
cv16ref01.csv		Figure 1. Rate of violent victimization, 2015 and 2016
cv16ref02.csv		Figure 2. Rate of violent victimization, 1993-2016
		
cv16reat01.csv		Appendix table 1. Estimates and standard errors for figure 1: Rate of violent victimization, 2015 and 2016
cv16reat02.csv		Appendix table 2. Estimates and standard errors for figure 2: Rate of violent victimization, 1993�2016
cv16reat03.csv		Appendix table 3. Standard errors for table 1: Violent victimization, by type of crime, 2015 and 2016
cv16reat04.csv		Appendix table 4. Standard errors for table 2: Property victimization, by type of crime, 2015 and 2016
cv16reat05.csv		Appendix table 5. Standard errors for table 3: Rate of crime reported to police in the Uniform Crime Reporting Program and National Crime Victimization Survey, 2016
cv16reat06.csv		Appendix table 6. Standard errors for table 4: Percent and rate of victimizations reported to police, by type of crime, 2015 and 2016
cv16reat07.csv		Appendix table 7. Standard errors for table 5: Rate of violent victimization, by demographic characteristics of victims, 2015 and 2016
cv16reat08.csv		Appendix table 8. Standard errors for table 6: Violent victimization, by type of crime and sex of victim, 2015 and 2016
cv16reat09.csv		Appendix table 9. Standard errors for table 7: Violent victimization, by sex and age of victim, 2015 and 2016
cv16reat10.csv		Appendix table 10. Standard errors for table 8: Rate of serious violent victimization, by demographic characteristics of victims, 2015 and 2016
cv16reat11.csv		Appendix table 11. Standard errors for table 9: Number of victims and prevalence rate, by type of crime, 2015 and 2016
cv16reat12.csv		Appendix table 12. Standard errors for table 10: Prevalence of violent crime, by demographic characteristics of victims, 2015 and 2016
cv16reat13.csv		Appendix table 13. Firearm violence, 2015 and 2016
cv16reat14.csv		Appendix table 14. Standard errors for appendix table 13: Firearm violence, 2015 and 2016
cv16reat15.csv		Appendix table 15. Percent of violent victimizations in which victims received assistance from a victim service agency, by type of crime, 2015 and 2016
cv16reat16.csv		Appendix table 16. Standard errors for appendix table 15: Percent of violent victimizations in which victims received assistance from a victim service agency, by type of crime, 2015 and 2016
cv16reat17.csv		Appendix table 17. Rate of victimization, by type of crime and household location, 2015 and 2016
cv16reat18.csv		Appendix table 18. Standard errors for appendix table 17: Rate of victimization, by type of crime and household location, 2015 and 2016
cv16reat19.csv		Appendix table 19. Percent of victimizations reported to police, by type of crime and household location, 2015 and 2016
cv16reat20.csv		Appendix table 20. Standard errors for appendix table 19: Percent of victimizations reported to police, by type of crime and household location, 2015 and 2016
