"Sexual Violence Reported by Correctional Authorities, 2005          NCJ   214646"				


This zip archive contains tables in individual .csv spreadsheets				
"from Sexual Violence Reported by Correctional Authorities,  2005   NCJ  214646.  The full report including text"				
and graphics in pdf format are available from:				
http://www.ojp.usdoj.gov/bjs/abstract/svrca05.htm				



svrca0501.csv			Table #:  1	"  Facilities selected for the Survey on Sexual Violence, 2005"
svrca0502.csv			Table #:  2	"  Reporting capabilities of correctional authorities to provide data on sexual violence, 2004 and 2005"
svrca0503.csv			Table #:  3	"  Allegations of sexual violence in Federal and State prisons, local jails, and private prisons and jails, 2005"
svrca0504.csv			Table #:  4	"  Characteristics of victims in substantiated incidents of inmate-on-inmate sexual violence, by type, 2005"
svrca0505.csv			Table #:  5	"  Characteristics of perpetrators in substantiated incidents of inmate-on-inmate sexual violence, by type, 2005"
svrca0506.csv			Table #:  6	"  Circumstances surrounding substantiated incidents of inmate-on-inmate sexual violence, by type, 2005"
svrca0507.csv			Table #:  7	"  Impact on victims and perpetrators in substantiated incidents of inmate-on-inmate sexual violence, by type, 2005"	
svrca0508.csv			Table #:  8	"  Characteristics of substantiated incidents of staff sexual misconduct and harassment, by type of facility, 2005"	
svrca0509.csv			Table #:  9	"  Circumstances surrounding substantiated incidents of staff sexual misconduct and harassment, by type of facility, 2005"	
svrca0510.csv			Table #: 10	"  Characteristics of staff involved in staff sexual misconduct and harassment, by type of facility, 2005"	
svrca0511.csv			Table #: 11	"  Characteristics of inmates involved in staff sexual misconduct and harassment, by type of facility, 2005"	
svrca0512.csv			Table #: 12	"  Type of staff involved in staff sexual misconduct and harassment, by type of facility, 2005"	
svrca0513.csv			Table #: 13	"  Impact on inmate and staff in substantiated incidents of staff sexual misconduct and harassment, 2005"	

			Highlights tables		
svrca05hi1.csv			Highlights table #:  1		" Number of allegations of sexual violence, by type of facility, 2004 and 2005"
svrca05hi2.csv			Highlights table #:  2		" Number and rate of substantiated incidents of sexual violence, by type of facility, 2005"
svrca05hi3.csv			Highlights table #:  3		" Percent of substantiated inmate-on-inmate incidents of sexual violence, by characteristic of incident, 2005"


			Appendix tables		
svrca05ap1a.csv			Appendix table #:  1a		" Allegations of inmate-on-inmate sexual violence reported by State or Federal prison authorities, by type, 2005"
svrca05ap1b.csv			Appendix table #:  1b		" Allegations of staff sexual misconduct with inmates reported by State and Federal prison authorities, by type, 2005"
svrca05ap2a.csv			Appendix table #:  2a		" Allegations of inmate-on-inmate sexual violence reported by local jail authorities,  by type, 2005"
svrca05ap2b.csv			Appendix table #:  2b		" Allegations of staff sexual misconduct with inmates  reported by local jail authorities, by type, 2005"
svrca05ap3a.csv			Appendix table #:  3a		" Allegations of inmate-on-inmate sexual violence reported in private prisons and jails, by type, 2005"
svrca05ap3b.csv			Appendix table #:  3b		" Allegations of staff sexual misconduct with inmates reported in private prisons and jails, by type, 2005"
svrca05ap4a.csv			Appendix table #:  4a		" Allegations of inmate-on-inmate sexual violence reported in other correctional facilities, by type, 2005"
svrca05ap4b.csv			Appendix table #:  4b		" Allegations of staff sexual misconduct with inmates reported in other correctional facilities, by type, 2005"
