Criminal Victimization, 2023 NCJ 309335	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Criminal Victimization, 2023 NCJ 309335.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/criminal-victimization-2023	
	
This report is one in a series.  More recent editions	
may be available. To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Criminal%20Victimization	
	
Filenames		Table titles
cv23t01.csv		Table 1. Number and rate of violent victimizations, by type of crime, 2019–2023
cv23t02.csv		Table 2. Number and rate of property victimizations, by type of crime, 2019–2023
cv23t03.csv		Table 3. Rate of violent victimization, by type of crime and demographic characteristics of victims, 2022 and 2023
cv23t04.csv		Table 4. Percent of victimizations reported to police, by type of crime, 2022 and 2023
cv23t05.csv		Table 5. Percent and rate of violent victimizations reported to police, by demographic characteristics of victims, 2022 and 2023
cv23t06.csv		Table 6. Rate of victimizations reported and not reported to police, by type of crime, 2022 and 2023
cv23t07.csv		Table 7. Number and rate of violent victimizations, by veteran and citizenship status of victims, 2022 and 2023
cv23t08.csv		Table 8. Rate of victimization, by type of crime and location of residence, 2022 and 2023
cv23t09.csv		Table 9. Percent of violent victimizations for which victims received assistance from a victim service provider, by type of crime, 2022 and 2023
cv23t10.csv		Table 10. Firearm violence, 2022 and 2023
cv23t11.csv		Table 11. Number and percent of violent incidents, by demographic characteristics of population, victims, and offenders, 2023
cv23t12.csv		Table 12. Number of violent incidents, by sex of victims and offenders, 2023
cv23t13.csv		Table 13. Number of violent incidents, by race or Hispanic origin of victims and offenders, 2023
cv23t14.csv		Table 14. Number and percent of persons who were victims of violent crime, by type of crime, 2019–2023
cv23t15.csv		Table 15. Number and percent of persons who were victims of violent crime, by demographic characteristics of victims, 2022 and 2023
cv23t16.csv		Table 16. Number and percent of households that experienced property crime, by type of crime, 2019–2023
	
			Figures
cv23f01.csv		Figure 1. Rate of violent victimization and violent victimization reported to police, 1993–2023
cv23f02.csv		Figure 2. Percent of persons age 12 or older who were victims of violent crime and violent crime excluding simple assault, 1993–2023
	
			Appendix tables
cv23at01.csv	Appendix table 1. Estimates, standard errors, and 95% confidence intervals for figure 1: Rate of violent victimization and violent victimization reported to police, 1993–2023
cv23at02.csv	Appendix table 2. Standard errors for table 1: Number and rate of violent victimizations, by type of crime, 2019–2023
cv23at03.csv	Appendix table 3. Standard errors for table 2: Number and rate of property victimizations, by type of crime, 2019–2023
cv23at04.csv	Appendix table 4. Standard errors for table 3: Rate of violent victimization, by type of crime and demographic characteristics of victims, 2022 and 2023
cv23at05.csv	Appendix table 5. Standard errors for table 4: Percent of victimizations reported to police, by type of crime, 2022 and 2023
cv23at06.csv	Appendix table 6. Standard errors for table 5: Percent and rate of violent victimizations reported to police, by demographic characteristics of victims, 2022 and 2023
cv23at07.csv	Appendix table 7. Standard errors for table 6: Rate of victimizations reported and not reported to police, by type of crime, 2022 and 2023
cv23at08.csv	Appendix table 8. Standard errors for table 7: Number and rate of violent victimizations, by veteran and citizenship status of victims, 2022 and 2023
cv23at09.csv	Appendix table 9. Standard errors for table 8: Rate of victimization, by type of crime and location of residence, 2022 and 2023
cv23at10.csv	Appendix table 10. Standard errors for table 9: Percent of violent victimizations for which victims received assistance from a victim service provider, by type of crime, 2022 and 2023
cv23at11.csv	Appendix table 11. Standard errors for table 10: Firearm violence, 2022 and 2023
cv23at12.csv	Appendix table 12. Standard errors for table 11: Number and percent of violent incidents, by demographic characteristics of population, victims, and offenders, 2023
cv23at13.csv	Appendix table 13. Standard errors for table 12: Number of violent incidents, by sex of victims and offenders, 2023
cv23at14.csv	Appendix table 14. Standard errors for table 13: Number of violent incidents, by race or Hispanic origin of victims and offenders, 2023
cv23at15.csv	Appendix table 15. Estimates, standard errors, and 95% confidence intervals for figure 2: Percent of persons age 12 or older who were victims of violent crime and violent crime excluding simple assault, 1993–2023
cv23at16.csv	Appendix table 16. Standard errors for table 14: Number and percent of persons who were victims of violent crime, by type of crime, 2019–2023
cv23at17.csv	Appendix table 17. Standard errors for table 15: Number and percent of persons who were victims of violent crime, by demographic characteristics of victims, 2022 and 2023
cv23at18.csv	Appendix table 18. Standard errors for table 16: Number and percent of households that experienced property crime, by type of crime, 2019–2023
cv23at19.csv	Appendix table 19. Population of persons age 12 or older, by demographic characteristics, 2019–2023
cv23at20.csv	Appendix table 20. Population of households, 2019–2023
