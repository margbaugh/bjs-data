Violence in the Workplace, 1993-99  NCJ 190076
 
This zip archive contains tables in individual .wk1 spreadsheets
from Violence in the Workplace, 1993-99  NCJ 190076
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/vw99.htm
 
 
vw9901.wk1         Table 1. Average annual number, rate, and percent of workplace victimization by type of crime, 1993-99
vw9902.wk1         Table 2. Workplace violence victimization rate per 1,000 persons in the workforce, by crime category, 1993-99
vw9903.wk1         Table 3.   Average annual rate of workplace victimization, by  demographic characteristics of the victims, 1993-99
vw9904.wk1         Table 4. Average annual rate and percentage of workplace crime, by gender, race, and crime category, 1993-99
vw9905.wk1         Table 5. Rate of violent victimization in the workplace, by occupational field, 1993-99
vw9906.wk1         Table 6. Average annual rate of violent victimization in the workplace, by occupation of the victim, 1993-99
vw9907.wk1         Table 7. Average annual rates of aggravated and simple assault in the workplace, by occupation, 1993-99
vw9908.wk1         Table 8. Average annual rate of robbery in the workplace, by occupation, 1993-99
vw9909.wk1         Table 9. Employers of workplace violence victims, 1993-99
vw9910.wk1         Table 10.  Time of violent victimization in the workplace, by occupation of victim,  1993-99
vw9911.wk1         Table 11. Injury from workplace violence and type of treatment received,  1993-99
vw9912.wk1         Table 12. Weapon present during victimizations in the  workplace, 1993-99
vw9913.wk1         Table 13.  Demograpic characteristics of offender(s) committing workplace violence, as reported by victims, 1993-99
vw9914.wk1         Table 14. Perceived offender use of drugs and alcohol, by occupation of victims of violence in the workplace, 1993-99
vw9915.wk1         Table 15. Victim-offender relationship in violent victimizations in the workplace by victim occupation,  1993-99
vw9916.wk1         Table 16. Workplace violence reported to the police, by victim characteristics ,  1993-99
vw9917.wk1         Table 17. Reasons for not reporting workplace victimization to the police,  1993-99
vw9918.wk1         Table 18.  Reporting violent crime in the workplace to the police, by job category and reasons for not reporting  1993-99
vw9919.wk1         Table 19. Average annual workplace homicide, by victim characteristics,  1993-99
vw9920.wk1         Table 20. Average annual workplace homicide, by victim-offender association,  1993-99
vw9921.wk1         Table 21. Average annual number of workplace homicide by type incident and time of victimization,  1993-99
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
