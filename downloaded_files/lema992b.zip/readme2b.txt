Bureau of Justice Statistics
Law Enforcement Management and Administrative Statistics, 1999:
Data for Individual State and Local Agencies with 100 or more Officers
By Brian A. Reaves, Ph.D. and Timothy C. Hart, BJS Statisticians

Contents of Zip archive lema992b.zip.  This file contains the tables from one section of the
report.  Additional tables are available at www.ojp.usdoj.gov/bjs/abstract/lemas99.htm.

STATE AGENCIES

II..  COMMUNITY POLICING            
     
lem9905b.wk1  Community policing plans, training, personnel, and facilities, 1999
  
lem9906b.wk1  Community policing activities and policies, 1999     

lem9907b.wk1 Citizen access to crime statistics or crime maps, 1999 

