Medical Causes of Death in State Prisons, 2001-2004, NCJ 216340
 
 
This zip archive contains tables in individual .csv spreadsheets
from Medical Causes of Death in State Prisons, 2001-2004, NCJ 216340.
The full report including text and graphics in pdf format
are available from: http://www.ojp.usdoj.gov/bjs/abstract/mcdsp04.htm
 
Text tables
mcdsp04tt01.csv Text table 1. Average annual mortality rate, per 100,000 State prisoners, by age
mcdsp04tt02.csv Text table 2. Average annual mortality rate, per 100,000 State prisoners, by time served since admission, 2001-2004 
mcdsp04tt03.csv Text table 3. Illness mortality rate, per 100,000 State inmates, 2001-2004

Figures
mcdsp04f01.csv Exhibit table 1. Ten leading causes of State prisoner deaths, 2001-2004
mcdsp04f02.csv Exhibit table 2. Cancer deaths in State prison, 2001-2004
mcdsp04f03.csv Exhibit table 3. Mortality rate per 100,000 State prisoners, 1991-2004

Appendix tables
mcdsp04at01.csv Table 1. Causes of death in State prisons, with annual average mortality rate per 100,000 inmates, 2001-2004
mcdsp04at02.csv Table 2. Profile of cancer deaths in State prisons, 2001-2004
mcdsp04at03.csv Table 3. Average annual mortality rate, per 100,000 State prison inmates, from leading causes of deaths, by selected characteristics, 2001-2004
mcdsp04at04.csv Table 4. Average annual mortality rate of State prisoners age 55 or older, by cause of death, 2001-2004
mcdsp04at05.csv Table 5. Time served since admission for deaths in State prison, age 65 or older, 2001-2004
mcdsp04at06.csv Table 6. Average annual mortality rate for leading causes of illness deaths in State prison, by time served, 2001-2004
mcdsp04at07.csv Table 7. Average annual mortality rate for selected communicable diseases in State prisons, by time served, 2001-2004
mcdsp04at08.csv Table 8. Leading causes of illness deaths in State prisons, by pre-existing status at time of admission and medical treatment provided, 2001-2004
mcdsp04at09.csv Table 9. Average annual mortality rate of State prison inmates, per 100,000 inmates, from leading causes of illness deaths, by State, 2001-2004
mcdsp04at10.csv Table 10. Average annual mortality rate from leading causes of illness deaths, per 100,000 State prison inmates, among the States, 2001-2004
mcdsp04at11.csv Table 11. Average annual mortality rate, per 100,000 residents, of State prisoners and U.S. residents, by selected characteristics
mcdsp04at12.csv Table 12. Causes of death in State prisons, with International Classification of Disease, 10th revision (ICD-10) codes and average annual mortality rate per 100,000 inmates, 2001-2004
