Local Police Departments, 2013: Equipment and Technology		
		
This zip archive contains tables in individual  .csv spreadsheets		
Local Police Departments, 2013: Equipment and Technology,   NCJ 248767.  The full report including text		
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5321	
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.bjs.gov/index.cfm?ty=pbse&sid=34		
		
lpd13etat01.csv		Appendix table 1. Local police departments and full-time employees, by size of population served, 2013
lpd13etat02.csv		Appendix table 2. Standard errors for appendix table 1: Local police departments and full-time employees, by size of population served, 2013
lpd13etat03.csv		Appendix table 3. Additional nonlethal weapons or actions authorized by local police departments, by size of population served, 2013
lpd13etat04.csv		Appendix table 4. Standard errors for appendix table 3: Additional nonlethal weapons or actions authorized by local police departments, by size of population served, 2013
lpd13etat05.csv		Appendix table 5. Number of 4-wheel motorized vehicles operated by local police departments, by size of population served, 2013
lpd13etat06.csv		Appendix table 6. Standard errors for appendix table 5: Number of 4-wheel motorized vehicles operated by local police departments, by size of population served, 2013
lpd13etat07.csv		Appendix table 7. Vehicles other than automobiles operated by local police departments, by size of population served, 2013
lpd13etat08.csv		Appendix table 8. Standard errors for appendix table 7: Vehicles other than automobiles operated by local police departments, by size of population served, 2013
lpd13etat09.csv		Appendix table 9. Base weights, nonresponse adjustment factors, and final analytical weights for local police departments, Law Enforcement Management and Administrative Statistics Survey, 2013
lpd13etat10.csv		Appendix table 10. Item nonresponse rates for the 2013 Law Enforcement Management and Administrative Statistics Survey
lpd13etat11.csv		Appendix table 11. Estimates and standard errors for figure 1: Local police departments authorizing the use of conducted energy weapons by size of population served, 2000, 2007, and 2013
lpd13etat12.csv		Appendix table 12. Standard errors for table 1: Selected nonlethal weapons authorized by local police departments, by size of population served, 2013
lpd13etat13.csv		Appendix table 13. Standard errors for table 2: Body armor wear requirements for patrol officers in local police departments, by size of population served, 2013
lpd13etat14.csv		Appendix table 14. Estimates and standard errors for figure 2: Local police officers employed by a department with body armor requirements for patrol officers, 1990�2013
lpd13etat15.csv		Appendix table 15. Estimates and standard errors for figure 3: Use of in-car video cameras by local police departments, by size of population served, 2000, 2007, and 2013
lpd13eta16.csv		Appendix table 16. Standard errors for table 3: Use of selected video technologies by local police departments, by size of population served, 2013
lpd13etat17.csv		Appendix table 17. Standard errors for table 4: Use of gunshot detection systems by local police departments, by size of population served, 2013
lpd13etat18.csv		Appendix table 18. Standards errors for table 5: Types of computerized information accessible to in-field officers in local police departments, by size of population served, 2013
lpd13etat19.csv		Appendix table 19. Estimates and standard errors for figure 4: Local police officers employed by a department providing in-field computer access to information, 2000, 2007, and 2013
lpd13etat20.csv		Appendix table 20. Estimates and standard errors for figure 5:  Local police departments using electronic methods for transmitting criminal incident reports to a central information system, by size of population served, 2000, 2007, and 2013
lpd13etat21.csv		Appendix table 21. Standard errors for table 6: Methods used by local police departments for transmitting criminal incident reports to their central information system, by size of population served, 2013
lpd13etat22.csv		Appendix table 22. Standard errors for table 7: Local police departments using  websites and social media, by size of population served, 2013
lpd13etat23.csv		Appendix table 23. Standard errors for table 8: Local police departments using electronic methods to exchange information with citizens, by size of population served, 2013
lpd13etat24.csv		Appendix table 24. Estimates and standard errors for figure 6: Level of crime statistics provided on local police department websites, by size of population served, 2013
