Census of State and Local Law Enforcement Agencies, 2018 – Statistical Tables  NCJ 302187	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Census of State and Local Law Enforcement Agencies, 2018 – Statistical Tables  NCJ 302187.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/census-state-and-local-law-enforcement-agencies-2018-statistical-tables
	
This report is one in a series.  More recent editions may be available. To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Census%20of%20State%20and%20Local%20Law%20Enforcement%20Agencies	
	
Filenames		Table titles
csllea18stt01.csv	Table 1. State and local law enforcement employees, by type of agency, 2018
csllea18stt02.csv	Table 2. Full-time state and local law enforcement employees, by type of agency, 2018 
csllea18stt03.csv	Table 3. State and local law enforcement agencies and full-time employees, by state, 2018
csllea18stt04.csv	Table 4. State and local law enforcement employees, by size of agency, 2018
csllea18stt05.csv	Table 5. Percent of full-time sworn state and local law enforcement officers who were female, by type and size of agency, 2018
csllea18stt06.csv	Table 6. Number of full-time sworn special jurisdiction personnel and percent who were female, by jurisdiction of agency, 2018
csllea18stt07.csv	Table 7. Local police department employees, by size of department, 2018
csllea18stt08.csv	Table 8. Local police department employees, by size of population served, 2018
csllea18stt09.csv	Table 9. Tribal police department employees, by size of department, 2018
csllea18stt10.csv	Table 10. Largest tribal police departments, by number of full‑time sworn personnel, 2018
csllea18stt11.csv	Table 11. Sheriff’s office employees, by size of office, 2018
csllea18stt12.csv	Table 12. Full-time primary state law enforcement agency employees, by size of agency, 2018
csllea18stt13.csv	Table 13. Full-time sworn personnel, by primary state law enforcement agency, 2018
csllea18stt14.csv	Table 14. Special jurisdiction law enforcement agencies and full-time sworn personnel, by type of jurisdiction, 2018
csllea18stt15.csv	Table 15. Special jurisdiction law enforcement agencies and full-time sworn personnel, by jurisdiction detail, 2018
csllea18stt16.csv	Table 16. Largest law enforcement agencies serving public colleges and universities, by number of full-time sworn personnel, 2018
csllea18stt17.csv	Table 17. Largest law enforcement agencies serving public school districts, by number of full-time sworn personnel, 2018
csllea18stt18.csv	Table 18. Largest state and local natural resource law enforcement agencies, by number of full-time sworn personnel, 2018
csllea18stt19.csv	Table 19. Largest state and local law enforcement agencies with transportation-related jurisdictions, by number of full-time sworn personnel, 2018
csllea18stt20.csv	Table 20. Response rates for the Census of State and Local Law Enforcement Agencies, by type of agency, 2018
	
			Figures
csllea18stf01.csv	Figure 1. Full-time state and local law enforcement employees, 1996, 2008, and 2018
csllea18stf02.csv	Figure 2. Full-time state and local law enforcement employees per 100,000 U.S. residents, 1996, 2008, and 2018
csllea18stf03.csv	Figure 3. Percent of state and local law enforcement agencies, by size of agency, 1996, 2008, and 2018
csllea18stf04.csv	Figure 4. Full-time employees in local police departments, 1996, 2008, and 2018
csllea18stf05.csv	Figure 5. Full-time employees in sheriffs’ offices, 1996, 2008, and 2018
	
			Appendix tables
csllea18stat01.csv	Appendix table 1. Estimates and standard errors for figure 1: Full-time state and local law enforcement employees, 1996, 2008, and 2018
csllea18stat02.csv	Appendix table 2. Standard errors for table 1: State and local law enforcement employees, by type of agency, 2018
csllea18stat03.csv	Appendix table 3. Standard errors for table 3: State and local law enforcement agencies and full-time employees, by state, 2018
csllea18stat04.csv	Appendix table 4. Estimates for figure 2: Full-time state and local law enforcement employees per 100,000 U.S. residents, 1996, 2008, and 2018
csllea18stat05.csv	Appendix table 5. Standard errors for table 4: State and local law enforcement employees, by size of agency, 2018
csllea18stat06.csv	Appendix table 6. Estimates and standard errors for figure 3: Percent of state and local law enforcement agencies, by size of agency, 1996, 2008, and 2018
csllea18stat07.csv	Appendix table 7. Standard errors for table 5: Percent of full-time sworn state and local law enforcement officers who were female, by type and size of agency, 2018
csllea18stat08.csv	Appendix table 8. Estimates for map 2: Percent of full-time sworn state law enforcement officers who were female, by state, 2018
csllea18stat09.csv	Appendix table 9. Standard errors for table 6: Number of full-time sworn special jurisdiction personnel and percent who were female, by jurisdiction of agency, 2018
csllea18stat10.csv	Appendix table 10. Standard errors for table 7: Local police department employees, by size of department, 2018
csllea18stat11.csv	Appendix table 11. Standard errors for table 8: Local police department employees, by size of population served, 2018
csllea18stat12.csv	Appendix table 12. Estimates and standard errors for figure 4: Full-time employees in local police departments, 1996, 2008, and 2018
csllea18stat13.csv	Appendix table 13. Standard errors for table 9: Tribal police department employees, by size of department, 2018
csllea18stat14.csv	Appendix table 14. Standard errors for table 11: Sheriff’s office employees, by size of office, 2018
csllea18stat15.csv	Appendix table 15. Estimates for figure 5: Full-time employees in sheriffs’ offices, 1996, 2008, and 2018
csllea18stat16.csv	Appendix table 16. Standard errors for table 15: Special jurisdiction law enforcement agencies and full-time sworn personnel, by jurisdiction detail, 2018
