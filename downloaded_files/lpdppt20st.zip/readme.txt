Local Police Departments, Procedures, Policies, and Technology, 2020 – Statistical Tables   NCJ 307405
																							
This zip archive contains tables in individual  .csv spreadsheets
Local Police Departments, Procedures, Policies, and Technology, 2020 – Statistical Tables   NCJ 307405.
The full report including text and graphics in pdf format is available from:
https://bjs.ojp.gov/library/publications/local-police-departments-procedures-policies-and-technology-2020-statistical
																	
This report is one in a series. More recent editions may be available.
To view a list of all in the series go to:
https://bjs.ojp.gov/library/publications/list?series_filter=Local%20Police%20Departments
																							
Filenames		Table titles
lpdppt20stt01.csv	Table 1. Percent of local police departments that authorized less-lethal equipment, by size of population served, type of equipment, and authorization level, 2020
lpdppt20stt02.csv	Table 2. Percent of local police departments that authorized less-lethal techniques, by size of population served, type of technique, and authorization level, 2020
lpdppt20stt03.csv	Table 3. Percent of local police departments that authorized selected firearms, by duty status of officers and size of population served, 2020
lpdppt20stt04.csv	Table 4. Percent of local police departments that used selected types of video cameras, by size of population served, 2020
lpdppt20stt05.csv	Table 5. Percent of local police departments that used K-9 units and number of handlers and K-9s, by selected functions and size of population served, 2020
lpdppt20stt06.csv	Table 6. Percent of local police departments that required annual in-service training of nonprobationary patrol and field officers, by size of population served, 2020
lpdppt20stt07.csv	Table 7. Percent of local police departments with written policies or procedural directives, by selected topic and size of population served, 2020
lpdppt20stt08.csv	Table 8. Percent of local police departments that regularly checked immigration status in selected circumstances, 2020
lpdppt20stt09.csv	Table 9. Percent of local police departments that required external investigations for selected situations, by size of population served, 2020
lpdppt20stt10.csv	Table 10. Percent of local police departments that engaged in selected community policing activities, by size of population served, 2020
lpdppt20stt11.csv	Table 11. Percent of local police departments that solicited feedback from the community for selected topics, by size of population served, 2020
lpdppt20stt12.csv	Table 12. Percent of local police departments with informal problem-solving partnerships or formal written agreements with selected groups, by size of population served, 2020
lpdppt20stt13.csv	Table 13. Percent of local police departments that used data for selected activities, by size of population served, 2020
lpdppt20stt14.csv	Table 14. Percent of local police departments that regularly used selected technologies, by size of populations served, 2020
																							
			Figures
lpdppt20stf01.csv	Figure 1. Percent of local police departments that authorized selected less-lethal equipment and techniques, by authorization level, 2020
lpdppt20stf02.csv	Figure 2. Percent of local police departments that used body-worn cameras, by size of population served, 2016 and 2020
lpdppt20stf03.csv	Figure 3. Ratio of officers to body-worn cameras in local police departments, by size of population served, 2020
lpdppt20stf04.csv	Figure 4. Selected reasons local police departments did not regularly check immigration status, 2020
lpdppt20stf05.csv	Figure 5. Percent of local police departments with a computerized early warning system or early intervention system for monitoring problematic officer behavior, by size of population served, 2016 and 2020
lpdppt20stf06.csv	Figure 6. Percent of local police departments with a civilian complaint review board or agency, by size of population served, 2016 and 2020
lpdppt20stf07.csv	Figure 7. Percent of local police departments that maintained a written community policing plan or conducted a citizen police academy, 2016 and 2020
lpdppt20stf08.csv	Figure 8. Percent of local police departments with a website, by size of population served, 2016 and 2020
lpdppt20stf09.csv	Figure 9. Percent of local police departments that used social media, by size of population served, 2016 and 2020
																							
			Appendix tables	
lpdppt20stat01.csv	Appendix Table 1. Standard errors for table 1: Percent of local police departments that authorized less-lethal equipment, by size of population served, type of equipment, and authorization level, 2020
lpdppt20stat02.csv	Appendix Table 2. Standard errors for table 2: Percent of local police departments that authorized less-lethal techniques, by size of population served, type of technique, and authorization level, 2020
lpdppt20stat03.csv	Appendix Table 3. Standard errors for table 3: Percent of local police departments that authorized selected firearms, by duty status of officers and size of population served, 2020
lpdppt20stat04.csv	Appendix Table 4. Standard errors for table 4: Percent of local police departments that used selected types of video cameras, by size of population served, 2020
lpdppt20stat05.csv	Appendix Table 5. Estimates and standard errors for figure 2: Percent of local police departments that used body-worn cameras, by size of population served, 2016 and 2020
lpdppt20stat06.csv	Appendix Table 6. Estimates and standard errors for figure 3: Ratio of officers to body-worn cameras in local police departments, by size of population served, 2020
lpdppt20stat07.csv	Appendix Table 7. Standard errors for table 5: Percent of local police departments that used K-9 units and number of handlers and K-9s, by selected functions and size of population served, 2020
lpdppt20stat08.csv	Appendix Table 8. Standard errors for table 6: Percent of local police departments that required annual in-service training of nonprobationary patrol and field officers, by size of population served, 2020
lpdppt20stat09.csv	Appendix Table 9. Standard errors for table 7: Percent of local police departments with written policies or procedural directives, by selected topic and  size of population served, 2020
lpdppt20stat10.csv	Appendix Table 10. Standard errors for table 8: Percent of local police departments that regularly checked immigration status in selected circumstances, 2020
lpdppt20stat11.csv	Appendix Table 11. Estimates and standard errors for figure 4: Selected reasons local police departments did not regularly check immigration status, 2020
lpdppt20stat12.csv	Appendix Table 12. Estimates and standard errors for figure 5: Percent of local police departments with a computerized early warning system or early intervention system for monitoring problematic officer behavior, by size of population served, 2016 and 2020
lpdppt20stat13.csv	Appendix Table 13. Estimates and standard errors for figure 6: Percent of local police departments with a civilian complaint review board or agency, by size of population served, 2016 and 2020
lpdppt20stat14.csv	Appendix Table 14. Standard errors for table 9: Percent of local police departments that required external investigations for selected situations, by size of population served, 2020
lpdppt20stat15.csv	Appendix Table 15. Standard errors for table 10: Percent of local police departments that engaged in selected community policing activities, by size of population served, 2020
lpdppt20stat16.csv	Appendix Table 16. Estimates and standard errors for figure 7: Percent of local police departments that maintained a written community policing plan or conducted a citizen police academy, 2016 and 2020
lpdppt20stat17.csv	Appendix Table 17. Standard errors for table 11: Percent of local police departments that solicited feedback from the community for selected topics, by size of population served, 2020
lpdppt20stat18.csv	Appendix Table 18. Standard errors for table 12: Percent of local police departments with informal problem-solving partnerships or formal written agreements with selected groups, by size of population served, 2020
lpdppt20stat19.csv	Appendix Table 19. Standard errors for table 13: Percent of local police departments that used data for selected activities, by size of population served, 2020
lpdppt20stat20.csv	Appendix Table 20. Estimates and standard errors for figure 8: Percent of local police departments with a website, by size of population served, 2016 and 2020
lpdppt20stat21.csv	Appendix Table 21. Estimates and standard errors for figure 9: Percent of local police departments that used social media, by size of population served, 2016 and 2020
lpdppt20stat22.csv	Appendix Table 22. Standard errors for table 14: Percent of local police departments that regularly used selected technologies, by size of populations served, 2020