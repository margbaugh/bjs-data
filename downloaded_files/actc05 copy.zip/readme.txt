Civil Justice Survey Trials on Appeal		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Appeals of Civil Trials Concluded in 2005, NCJ 235187		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=1753		

		
actc05f01.csv		Figure 1. Civil trials concluded in 2005 appealed to an intermediate appellate court or court of last resort
actc05f02.csv		Figure 2. Appeals decided on the merits, with trial court outcome reversed or modified
		
actc05t01.csv		Table 1. Appeals of civil trials concluded in 2005, by case characteristics and party filing the appeal
actc05t02.csv		Table 2. Appellate court disposition of civil trials concluded in 2005, by case characteristics
actc05t03.csv		Table 3. Case processing time of civil trials appealed between 2005 and 2010
		
actc05at01.csv		Appendix table 1. Standard error and confidence interval estimates for appeals of civil trials concluded in 2005, by case characteristics and party filing the appeal
actc05at02.csv		Appendix table 2. Standard error and confidence interval estimates for appellate court disposition of civil trials concluded in 2005, by case characteristics
actc05at03.csv		Appendix table 3. Standard error and confidence interval estimates for civil trial outcomes subsequently reversed or modified on the merits on appeal
actc05at04.csv		Appendix table 4. Standard errors and confidence interval estimates for case processing time of civil trials appealed between 2005 and 2010
