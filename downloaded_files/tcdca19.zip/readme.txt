Tribal Crime Data-Collection Activities, 2019   NCJ 252983	
	
This .zip archive contains tables in individual  .csv spreadsheets	
Tribal Crime Data-Collection Activities, 2019   NCJ 252983  The full report including text	
and graphics in .pdf format is available from: https://www.bjs.gov/index.cfm?ty=pbdetail&iid=6646 
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to:	
https://www.bjs.gov/index.cfm?ty=pbse&sid=77	
	
Filename	Table title
tcdca19t01.csv	Table 1. Universe for the Census of Tribal Law Enforcement Agencies, 2019
tcdca19t02.csv	Table 2. Cognitive testing of the Census of Tribal Law Enforcement Agencies, by responding agency, 2018
tcdca19t03.csv	Table 3. Projects on tribal lands funded through the Bureau of Justice Statistics� National Criminal History Improvement Program (NCHIP) and National Instant Criminal Background Check System (NICS) Act Record Improvement Program (NARIP), FY 2016 � FY 2018
tcdca19t04.csv	Table 4. American Indians and Alaska Natives in the federal justice system, FY 2012 � FY 2016
	
		Figure title
tcdca19f01.csv	Figure 1. American Indians and Alaska Natives admitted to and released from federal prison, FY 2012 � FY 2016
