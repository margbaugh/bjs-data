Hate Crime, 2003-2009											
											
This zip archive contains tables in individual  .csv spreadsheets		
from Hate Crime, 2003-2009 NCJ 234085.  The full report including 
text and graphics in pdf format is available at: 
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=1760											
											
This report is one in a series. More recent editions may be 
available. To view a list of all in the series go to 
http://bjs.ojp.usdoj.gov/index.cfm?ty=dcdetail&iid=72					
											
hc0309f01.csv		Figure 1. Rate of violent hate crime victimizations, 2003-2009						
hc0309f02.csv		Figure 2. Victims' account of suspected hate crime motivation, 2003-2009
hc0309f03.csv		Figure 3. Perceived motivation of hate crime victimizations reported to the police, 2003-2009	
hc0309f04.csv		Figure 4. Hate crime incidents and victimizations recoded in official police records, 2003-2009	
hc0309t01.csv		Table 1. Hate crime victimizations, 2003-2009 									
hc0309t02.csv		Table 2. Annual average for hate crime incidents and victimizations, 2003-2009	
hc0309t03.csv		Table 3. Victims� evidence that a hate crime occurred, 2003-2009		
hc0309t04.csv		Table 4. Hate and nonhate crime victimizations, by type of crime, 2003-2009	
hc0309t05.csv		Table 5. Presence of weapons and injuries sustained in violent hate and nonhate crime victimizations, 2003-2009		
hc0309t06.csv		Table 6. Hate and nonhate crime victimizations, by location, 2003-2009									
hc0309t07.csv		Table 7. Hate and nonhate crime victimizations reported to police, 2003-2009		
hc0309t08.csv		Table 8. Most important reason why victimization was not reported to police, 2003-2009	
hc0309t09.csv		Table 9. Characteristics of hate crime victims, 2003-2009									
hc0309t10.csv		Table 10. Victims� account of suspected hate crime motivation, by race/Hispanic origin, 2003-2009	
hc0309t11.csv		Table 11. Victims� account of suspected hate crime motivation, by sex, 2003-2009	
hc0309t12.csv		Table 12. Characteristics of violent offenders as reported by victims of hate and nonhate crime, 2003-2009
hc0309t13.csv		Table 13. Race and Hispanic origin of victims and race of offenders, by type of violent victimization, 2003-2009
hc0309t14.csv		Table 14. Perceived hate crime motivation as reported to the NCVS and UCR, 2003-2009		
hc0309t15.csv		Table 15. Hate crime victimizations recorded by the NCVS and UCR, by offense, 2003-2009	
hc0309a01.csv		Appendix Table 1. Population and total criminal victimization counts, 2003-2009		
hc0309a02.csv		Appendix Table 2. Standard errors for number, percent, and rate of hate crime victimizations, 2003-2009 
hc0309a03.csv		Appendix Table 3. Standard errors for annual average of hate crime incidents and victimizations, 2003-2009
hc0309a04.csv		Appendix Table 4. Standard errors for victim�s evidence for hate crime, 2003�2009		
hc0309a05.csv		Appendix Table 5. Standard error for hate and nonhate crime victimizations, 2003-2009	
hc0309a06.csv		Appendix Table 6. Standard errors for presense of weapons and injury sustained in hate and nonhate crime victimizations, 2003-2009
hc0309a07.csv		Appendix Table 7. Standard errors for hate and nonhate crime victimizations, by location, 2003-2009		
hc0309a08.csv		Appendix Table 8. Standard errors for hate and nonhate crime victimizations reported to police, 2003-2009	
hc0309a09.csv		Appendix table 9. Standard errors for most important reason why victimization was not reported to the police, 2003-2009	
hc0309a10.csv		Appendix table 10. Standard errors for characteristics of hate crime victims, 2003-2009				
hc0309a11.csv		Appendix table 11. Standard errors for victims� perceptions of hate crime motivation, by race/Hispanic origin, 2003-2009
hc0309a12.csv		Appendix table 12. Standard error for victims� perceptions of hate crime motivation, by sex, 2003�2009		
hc0309a13.csv		Appendix table 13. Standard errors for characteristics of violent offenders as reported by victims of hate crime, 2003-2009	
hc0309a14.csv		Appendix table 14. Standard errors for race and Hispanic origin of victims and race of offenders, by type of violent victimization, 2003-2009									
hc0309a15.csv		Appendix table 15. Standard errors for perceived hate crime motivation as reported to the NCVS and UCR, 2003-2009
hc0309a16.csv		Appendix table 16. Standard errors for hate crime victimizations recorded by the NCVS and UCR, 2003-2009	
hc0309a17.csv		Appendix table 17. Standard errors for figure 1: rate of violent hate crime victimizations, 2003-2009		
hc0309a18.csv		Appendix table 18. Standard errors for figure 2: victims� perceptions of hate crime motivation, 2003-2009	
hc0309a19.csv		Appendix table 19. Standard errors for figure 3: perceived motivation of hate crime victimizations reported to the police, 2003-2009									
