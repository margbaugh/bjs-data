"Capital Punishment, 2014 - Statistical Tables  NCJ 250638"		
		
This zip archive contains tables in individual .csv spreadsheets		
"from Capital Punishment, 2014-2015   NCJ 250638."		
The full electronic report is available at:		
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=5908		
		
These statistical tables are in a series.  More recent editions		
may be available.  To view a list of all in the series go to:		
https://www.bjs.gov/index.cfm?ty=pbse&sid=1		
		
cp1415sbf01		"Figure 1. Number of persons executed, 1930-2015"
cp1415sbf02		"Figure 2. Number of persons under sentence of death, 1953-2015"
cp1415sbf03		"Figure 3. Status of the death penalty, 2014-2015"
cp1415sbf04		"Figure 4. Admissions to and removals from under sentence of death, 1973-2015"
cp1415sbf05		"Figure 5. Advance count of executions, January 1, 2016-December 31, 2016"
