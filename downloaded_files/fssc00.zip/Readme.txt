Felony Sentences in State Courts, 2000   NCJ  198821
 
This zip archive contains tables in individual .wk1 spreadsheets
from Felony Sentences in State Courts, 2000   NCJ 198821.
The full report and supporting materials in pdf and ascii format are 
available from: http://www.ojp.isdoj.gov/bjs/abstract/fssc00.htm 
 

Comparison of felony convictions in State and Federal courts, 2000
filename:  fssc00fed.wk1

Table 1:  Estimated number of felony convictions in State courts, 2000
filename:  fssc0001.wk1

Table 2:  Distribution of types of felony sentences imposed by State 
	    courts, by offense, 2000
filename:  fssc0002.wk1

Table 3:  Average felony sentence lengths in Stste courts, by offense 
	    and type of sentence, 2000
filename:  fssc0003.wk1

Table 4:  Estimated time to be served in State prison, by offense, 2000
filename:  fssc0004.wk1

Table 5:  Demographic characteristics of persons convicted of felonies 
	    by State courts, by offense, 2000
filename:  fssc0005.wk1

Table 6:  Distribution of the number of felony conviction offenses for 
	    persons sentenced in State courts, by most serious offense, 
	    2000
filename:  fssc0006.wk1

Table 7:  Convicted felons sentenced to prison by State courts, by 
	    number of conviction offenses, 2000
filename:  fssc0007.wk1

Table 8:  Mean sentence lengths for State felony sentences imposed, by 
	    the number and category of the conviction offense, 2000
filename:  fssc0008.wk1

Table 9:  Estimated number of felony convictions in State courts, by 
	    offense and type of conviction, 2000
filename:  fssc0009.wk1

Table 10:  Distribution of types of felony convictions in State courts, 
	     by offense, 2000
filename:  fssc0010.wk1

Table 11:  Time beween arrest and sentencing for persons convicted of a 
	     felony in State courts, by offense, 2000
filename:  fssc0011.wk1

Table 12:  Felons sentenced to an additional penalty by State courts, by 
	     offense, 2000
filename:  fssc0012.wk1

Estimate of 1 standard error for table 1, 2000 
filename:  FSS00SE1.wk1

Estimate of 1 standard error for table 2, 2000 
filename:  FSS00SE2.wk1

Estimate of 1 standard error for table 3, 2000 
filename:  FSS00SE3.wk1

Estimate of 1 standard error for table 5, 2000 
filename:  FSS00SE5.wk1

Estimate of 1 standard error for table 6, 2000 
filename:  FSS00SE6.wk1

Estimate of 1 standard error for table 7, 2000 
filename:  FSS00SE7.wk1

Estimate of 1 standard error for table 8, 2000 
filename:  FSS00SE8.wk1

Estimate of 1 standard error for table 9, 2000 
filename:  FSS00SE9.wk1

Estimate of 1 standard error for table 10, 2000 
filename:  FS00SE10.wk1

Estimate of 1 standard error for table 11, 2000 
filename:  FS00SE11.wk1

Estimate of 1 standard error for table 12, 2000 
filename:  FS00SE12.wk1