Federal Deaths in Custody and During Arrest, 2022 – Statistical Tables  NCJ 309427	
	
This zip archive contains tables in individual .csv spreadsheets from	
Federal Deaths in Custody and During Arrest, 2022 – Statistical Tables  NCJ 309427	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/federal-deaths-custody-and-during-arrest-2022-statistical-tables	
	
This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:	
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Deaths%20in%20Custody%20and%20During%20Arrest
	
Filenames		Table titles
fdcda22stt01.csv	Table 1. Number of deaths reported, by type of death and federal agency, FY 2022
fdcda22stt02.csv	Table 2. Arrest-related deaths, by manner of death and weapon causing death, FY 2022
fdcda22stt03.csv	Table 3. Arrest-related deaths, by decedent characteristics, FY 2022
fdcda22stt04.csv	Table 4. Arrest-related deaths, by reason for law enforcement contact and alleged decedent offense, FY 2022
fdcda22stt05.csv	Table 5. Arrest-related deaths, by decedent condition and actions during the incident, FY 2022 
fdcda22stt06.csv	Table 6. Arrest-related deaths, by law enforcement actions, FY 2022
fdcda22stt07.csv	Table 7. Arrest-related deaths, by law enforcement weapon use, FY 2022
fdcda22stt08.csv	Table 8. Deaths in custody, by manner and location of death, FY 2022
fdcda22stt09.csv	Table 9. Deaths in custody, by decedent characteristics, FY 2022
fdcda22stt10.csv	Table 10. Deaths in custody, by decedent offense, legal status, and time served, FY 2022
fdcda22stt11.csv	Table 11. Responses to the Federal Law Enforcement Agency Deaths in Custody Reporting Program, FY 2022
	
			Figures
fdcda22stf01.csv	Figure 1. Number of arrest-related deaths and deaths in custody, FY 2016–2022
	
			Appendix tables
fdcda22stat01.csv	Appendix table 1. Counts for figure 1: Number of arrest-related deaths and deaths in custody, FY 2016–2022