Characteristics of Drivers Stopped by Police, 2002, NCJ 211471

This zip archive contains tables in individual .csv spreadsheets
from Characteristics of Drivers Stopped by Police, 2002, NCJ 211471.
The full report including text and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cdsp02.htm  

cdsp02apa.csv		Appendix A Of the U.S. population, the percent and number of drivers in the United States, 2002: Gender, age, and race/Hispanic origin
cdsp02apa.csv		Appendix B Of the U.S. population, the percent and number of drivers in the United States, 2002: Combined categories of gender, age, and race/Hispanic origin
cdsp02bx1.csv		Box 1 Likelihood of finding criminal evidence in a traffic stop search 
cdsp0201.csv		Table 1 Characteristics of drivers stopped by police compared to characteristics of drivers in the United States, 2002: Gender, age, and race/Hispanic origin  
cdsp0202.csv		Table 2 Characteristics of drivers stopped by police compared to characteristics of drivers in the United States, 2002: Combined categories of gender, age, and race/Hispanic origin  
cdsp0203.csv		Table 3 Of all drivers in the United States, percent stopped by police in 2002: Combined categories of gender, age, and race/Hispanic origin
cdsp0204.csv		Table 4 Driver opinion on being stopped by police, 2002: Combined categories of gender, age, and race/Hispanic origin
cdsp0205.csv		Table 5 Of drivers stopped by police in 2002, percent not given a reason for the traffic stop: Gender, age, and race/Hispanic origin 
cdsp0206.csv		Table 6 Drivers who reported speeding as the reason for the traffic stop, 2002: Gender, age, and race/Hispanic origin
cdsp0207.csv		Table 7 Of drivers stopped for speeding by police in 2002, percent who were ticketed: Gender, age, and race/Hispanic origin
cdsp0208.csv		Table 8 Of drivers stopped, percent who experienced a search, 2002: Combined categories of gender, age, and race/Hispanic origin
cdsp0209.csv		Table 9 Of the total number of persons searched, percent of drivers who were also arrested, 2002: Gender, age and race/Hispanic origin
cdsp0210.csv		Table 10 Among arrested and nonarrested drivers, percent who experienced a search, 2002: Gender, age, and race/Hispanic origin
cdsp0211.csv		Table 11 Among arrested and nonarrested drivers, percent who experienced a search, 2002: Combined categories of race/Hispanic origin and gender
cdsp0212.csv		Table 12 Among persons age 16 or older who had contact with police in 2002, percent whose contact involved police use of force, by reason for contact
cdsp0213.csv		Table 13 Reason for contact with police among persons age 16 or older whose contact involved police use of force in 2002: Gender, age, and race/Hispanic origin 
cdsp0214.csv		Table 14 Demographic characteristics of persons age 16 or older whose contact involved police use of force in 2002, by reason for contact
cdsp0215.csv		Table 15 Among persons age 16 or older who argued with, cursed at, insulted, or verbally threatened the police in 2002, percent whose contact involved police use of force, by reason for contact
cdsp0216.csv		Table 16 Among persons age 16 or older whose contact involved police use of force in 2002, percent who felt the force used or threatened was "excessive," by reason for contact
cdsp0217.csv		Table 17 Among persons age 16 or older who had contact with police in 2002, percent whose contact involved police use of excessive force, by reason for contact


