Federal Law Enforcement Officers, 2020 - Statistical Tables   NCJ 304752
																							
This zip archive contains tables in individual  .csv spreadsheets
Federal Law Enforcement Officers, 2020 - Statistical Tables   NCJ 304752.  The full report including text
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/federal-law-enforcement-officers-2020-statistical-tables	
																							
This report is one in a series.  More recent editions																							
may be available.  To view a list of all in the series go to																							
https://bjs.ojp.gov/library/publications/list?series_filter=Federal%20Law%20Enforcement%20Officers
																							
																							
Filenames		Table names																						
fleo20st01.csv		Table 1. Full-time federal law enforcement officers in agencies other than Offices of Inspectors General, by agency, FY 2016 and FY 2020
fleo20st02.csv		Table 2. Full-time federal law enforcement officers in Offices of Inspectors General, by agency, FY 2016 and FY 2020
fleo20st03.csv		Table 3. Full-time federal law enforcement officers in agencies other than Offices of Inspectors General employing 50 or more officers, by demographic characteristics, FY 2020	
fleo20st04.csv		Table 4. Full-time federal law enforcement officers in Offices of Inspectors General employing 50 or more officers, by demographic characteristics, FY 2020
fleo20st05.csv		Table 5. Hires and separations at federal law enforcement agencies, by size of agency, FY 2020
fleo20st06.csv		Table 6. Percent of federal law enforcement agencies using targeted hiring practices and military service exemptions for education, by size of agency, FY 2020
fleo20st07.csv		Table 7. Percent of federal law enforcement agencies with selected screening techniques for new officer hires, by size of agency, FY 2020
fleo20st08.csv		Table 8. Percent of federal law enforcement agencies authorizing weapons, by duty status, type of weapon, and size of agency, FY 2020
fleo20st09.csv		Table 9. Percent of federal law enforcement agencies authorizing selected equipment and techniques, by size of agency, FY 2020
																							
			Figures																						
fleo20stf01.csv		Figure 1. Distribution of full-time federal law enforcement officers, by Government Branch or Department, FY 2020
fleo20stf02.csv		Figure 2. Percent of full-time federal law enforcement officers, by primary function, FY 2020
fleo20stf03.csv		Figure 3. Percent of full-time federal law enforcement officers, by demographic characteristics, FY 2016 and FY 2020
fleo20stf04.csv		Figure 4. Percent of supervisory law enforcement personnel in federal law enforcement agencies, by demographic characteristics, FY 2020
																							
			Appendix tables																						
fleo20stat01.csv	Appendix table 1. Counts and percentages for figure 1: Distribution of full-time federal law enforcement officers, by Government Branch or Department, FY 2020
fleo20stat02.csv	Appendix table 2. Counts and percentages for figure 2: Percent of full-time federal law enforcement officers, by primary function, FY 2020
fleo20stat03.csv	Appendix table 3. Percentages for figure 3: Percent of full-time federal law enforcement officers, by demographic characteristics, FY 2016 and FY 2020
fleo20stat04.csv	Appendix table 4. Percentages for figure 4: Percent of supervisory law enforcement personnel in federal law enforcement agencies, by demographic characteristics, FY 2020