Criminal Victimization, 2020  NCJ 301775	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Criminal Victimization, 2020  NCJ 301775.  The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/criminal-victimization-2020
	
This report is one in a series.  More recent editions	
may be available.  To view a list of all in the series go to	
https://bjs.ojp.gov/library/publications/list?series_filter=Criminal%20Victimization	
	
Filenames	Table titles
cv20t01.csv	Table 1. Number and rate of violent victimizations, by type of crime, 2016–2020
cv20t02.csv	Table 2. Number and rate of property victimizations, by type of crime, 2016–2020
cv20t03.csv	Table 3. Rate of crime reported to police in the Uniform Crime Reporting program and National Crime Victimization Survey, 2019–2020
cv20t04.csv	Table 4. Percent of victimizations reported to police, by type of crime, 2019–2020
cv20t05.csv	Table 5. Rate of victimization reported and not reported to police, by type of crime, 2019–2020
cv20t06.csv	Table 6. Rate of violent victimization, by type of crime and demographic characteristics of victims, 2019–2020
cv20t07.csv	Table 7. Rate of victimization, by type of crime and location of residence, 2019–2020
cv20t08.csv	Table 8. Firearm violence, 2019–2020
	
		Figures
cv20f01.csv	Figure 1. Rate of victimization, by type of crime, 2019–2020
cv20f02.csv	Figure 2. National Crime Victimization Survey field operation procedures, 2020
cv20f03.csv	Figure 3. Monthly household response rates for the National Crime Victimization Survey, 2019–2020
	
	
		Appendix tables
cv20at01.csv	Appendix table 1. Estimates and standard errors for figure 1: Rate of victimization, by type of crime, 2019–2020
cv20at02.csv	Appendix table 2. Standard errors for table 1: Number and rate of violent victimizations, by type of crime, 2016–2020
cv20at03.csv	Appendix table 3. Estimates for figure 3: Monthly household response rates for the National Crime Victimization Survey, 2019–2020
cv20at04.csv	Appendix table 4. Standard errors for table 2: Number and rate of property victimizations, by type of crime, 2016–2020
cv20at05.csv	Appendix table 5. Standard errors for table 3: Rate of crime reported to police in the Uniform Crime Reporting program and National Crime Victimization Survey, 2019–2020
cv20at06.csv	Appendix table 6. Standard errors for table 4: Percent of victimizations reported to police, by type of crime, 2019–2020
cv20at07.csv	Appendix table 7. Standard errors for table 5: Rate of victimization reported and not reported to police, by type of crime, 2019–2020
cv20at08.csv	Appendix table 8. Standard errors for table 6: Rate of violent victimization, by type of crime and demographic characteristics of victims, 2019–2020
cv20at09.csv	Appendix table 9. Standard errors for table 7: Rate of victimization, by type of crime and location of residence, 2019–2020
cv20at10.csv	Appendix table 10. Standard errors for table 8: Firearm violence, 2019–2020
cv20at11.csv	Appendix table 11. Population of persons age 12 or older in the U.S., by demographic characteristics, 2016–2020
cv20at12.csv	Appendix table 12. Population of households in the U.S., 2016–2020
