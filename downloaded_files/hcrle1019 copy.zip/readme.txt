Hate Crime Recorded by Law Enforcement, 2010–2019   NCJ 301554		
		
This zip archive contains tables in individual .csv spreadsheets		
from Hate Crime Recorded by Law Enforcement, 2010–2019   NCJ 301554		
The full report including text and graphics in .pdf format is available at		
https://bjs.ojp.gov/library/publications/hate-crime-recorded-law-enforcement-2010-2019
		
This report is one in a series.  More recent editions may be available. 		
To view a list of all in the series go to 		
https://bjs.ojp.gov/library/publications/list?series_filter=Hate%20Crime		
		
Filenames		Table titles	
hcrle1019t01.csv	Table 1. Number of incidents and victims of hate crime recorded by law enforcement, by category of bias motivation, 2010–2019	
hcrle1019t02.csv	Table 2. Law enforcement agency participation in the FBI's Uniform Crime Reporting Program and Hate Crime Statistics Program, 2010–2019	
		
			Figures	
hcrle1019f01.csv	Figure 1. Number of hate crime incidents and victims recorded by law enforcement, 2010–2019 	
hcrle1019f02.csv	Figure 2. Number of violent and property crimes recorded by law enforcement, 2010–2019 	
hcrle1019f03.csv	Figure 3. Number of incidents and victims of hate crime motivated by race, ethnicity, or ancestry bias recorded by law enforcement, 2010–2019	
hcrle1019f04.csv	Figure 4. Percent of incidents and victims of hate crime motivated by race, ethnicity, or ancestry bias recorded by law enforcement, by type of bias, 2015–19	
hcrle1019f05.csv	Figure 5. Number of victims of hate crime motivated by race, ethnicity, or ancestry bias recorded by law enforcement, by type of bias, 2015–2019	
		
			Appendix tables	
hcrle1019at01.csv	Appendix table 1. Number of hate crime incidents recorded by law enforcement, by type of bias motivation, 2010–2019	
hcrle1019at02.csv	Appendix table 2. Number of victims of hate crime recorded by law enforcement, by type of bias motivation, 2010–2019	
hcrle1019at03.csv	Appendix table 3. Counts for figure 1: Number of hate crime incidents and victims recorded by law enforcement, 2010–2019 	
hcrle1019at04.csv	Appendix table 4. Estimates for figure 2: Number of violent and property crimes recorded by law enforcement, 2010–2019	
hcrle1019at05.csv	Appendix table 5. Counts for figure 3: Number of incidents and victims of hate crime motivated by race, ethnicity, or ancestry bias recorded by law enforcement, 2010–2019	
hcrle1019at06.csv	Appendix table 6. Percentages for figure 4: Percent of incidents and victims of hate crime motivated by race, ethnicity, or ancestry bias recorded by law enforcement, by type of bias, 2015–19	
hcrle1019at07.csv	Appendix table 7. Counts for figure 5: Number of victims of hate crime motivated by race, ethnicity, or ancestry bias recorded by law enforcement, by type of bias, 2015–2019	
		
		
		
