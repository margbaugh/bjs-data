Census of Jails 1999   NCJ  186633
 
This zip archive contains tables in individual .wk1 spreadsheets
from Census of Jails, 1999 NCJ  186633. The full report including 
text and graphics in pdf format are available from:
http://www.ojp.isdoj.gov/bjs/abstract/cj99.htm 

 
Filename          Table
 
cj99t1.wk1        Table 1.  Jail inmates and their number per 100,000  U.S. residents, selected years, 1983-99
cj99t2.wk1        Table 2.  Average daily population and the number of men, women,  and juveniles held in jails, Census of Jails, 1983, 1988, 1993, and 1999
cj99t3.wk1        Table 3.  Jail facilities and number of inmates per 100,000 population,  by region and State, Census of Jails, 1983, 1993, and 1999
cj99t4.wk1        Table 4.  Jail inmates and facilities, by size of facility, Census of Jails, 1993 and 1999
cj99t5.wk1        Table 5. Gender, race, and Hispanic origin of jail inmates, Census of Jails, 1983, 1988, 1993, and 1999
cj99t6.wk1        Table 6.  Conviction status of adult jail inmates, by gender, Census of Jails, 1983, 1988, 1993, and 1999
cj99t7.wk1        Table 7.  Rated capacity of jails and percent of capacity occupied, 1983, 1988, and 1993-99
cj99t8.wk1        Table 8.  Percent of rated capacity occupied by size of jail facility, midyear 1983, 1988, 1993, and 1999
cj99t9.wk1        Table 9.  Characteristics of privately operated jails, June 30, 1999
cj99t10.wk1       Table 10.  Inmate deaths in jails, by cause, during the annual periods ending June 30, 1993 and 1999
cj99t11.wk1       Table 11.  Number of deaths per 100,000 inmates in jails, by cause, 1983, 1988, 1993, 1999
cj99t12.wk1       Table 12.  Jail staff, by occupational category, midyear 1983, 1988, 1993, and 1999
cj99t13.wk1       Table 13.  Total jail staff and correctional officers, by gender and race/Hispanic origin, midyear 1999
cj99t14.wk1       Table 14.  Jail staff and the number of inmates per jail employee, by ocupational category and region, midyear 1983, 1988, 1993, and 1999
cj99t15.wk1       Table 15.  Jail policies and programs for education, counseling, health delivery and mental health services, June 30, 1999
 
Appendix tables
cj99at1.wk1       Appendix table 1.  Jails and inmates, percent of capacity occupied, and inmates per 100,000 population, June 30, 1999
cj99at2.wk1       Appendix table 2.  Jails for men only, women only, or both, June 30, 1999
cj99at3.wk1       Appendix table 3.  Jails under court order or consent decree to limit population  or for specific conditions of confinement, June 30, 1999
cj99at4.wk1       Appendix table 4.  Jails, by size of average daily population, June 30, 1999
cj99at5.wk1       Appendix table 5.  Inmates, by size of jail, June 30, 1999
cj99at6.wk1       Appendix table 6.  Jail population under community supervision,  June 30, 1999
cj99at7.wk1       Appendix table 7.  Non-U.S. citizens in jail, June 30, 1999
cj99at8.wk1       Appendix table 8.  New admissions to jail, June 24-30, 1999
cj99at9.wk1       Appendix table 9.  Confined jail inmates, by gender, race, and Hispanic origin, June 30, 1999
cj99at10.wk1      Appendix table 10.  Nonconfined jail population, by type of alternative program, June 30, 1999
cj99at11.wk1      Appendix table 11.  Average daily fees charged by jails  to house an inmate for other correctional authorities,  June 30, 1999
cj99at12.wk1      Appendix table 12.  Jail staff, by occupational category, June 30, 1999
cj99at13.wk1      Appendix table 13.  Total jail staff and correctional officers, by gender, June 30, 1999
cj99at14.wk1      Appendix table 14.  Jail staff, by race and Hispanic origin, June 30, 1999
cj99at15.wk1      Appendix table 15.  Number of jail inmates  per employee and per correctional officer,  June 30, 1999
cj99at16.wk1      Appendix table 16.  Number of privately operated jails and jail inmates, June 30, 1999
cj99at17.wk1      Appendix table 17.  Staff of privately operated jails, by gender, June 30, 1999
cj99at18.wk1      Appendix table 18.  Jails providing information on inmate assaults  on staff and number of staff deaths from assaults,  July 1, 1998 - June 30, 1999
cj99at19.wk1      Appendix table 19.  Methods of providing health care to jail inmates, June 30, 1999
cj99at20.wk1      Appendix table 20.  Jails charging inmates for health care, June 30, 1999
cj99at21.wk1      Appendix table 21.  Jails providing information on health-related screening policies for tuberculosis among inmates and staff, June 30, 1999
cj99at22.wk1      Appendix table 22.  Jails with non-health-related screening policies for tuberculosis  among inmates and staff, June 30, 1999
cj99at23.wk1      Appendix table 23.  Jail inmates who were suspected of having tuberculosis,  who had a TB-positive skin test, or who had confirmed TB disease
cj99at24.wk1      Appendix table 24.  Testing policies among jail inmates for the HIV virus, July 1, 1998 - June 30, 1999
cj99at25.wk1      Appendix table 25.  Number of jail inmates who tested positive for HIV,  by symptom level, June 30, 1999
cj99at26.wk1      Appendix table 26.  Jail policies and procedures relating to inmate mental health, June 30, 1999
cj99at27.wk1      Appendix table 27.  Jail inmates who were receiving mental health services, June 30, 1999
cj99at28.wk1      Appendix table 28.  Jail procedures for suicide prevention, June 30, 1999
cj99at29.wk1      Appendix table 29.  Jail inmate deaths, by cause and gender,  during the annual period ending June 30, 1999
cj99at30.wk1      Appendix table 30.  Jail providing work assignments and number of inmates  with work assignments, June 30, 1999
cj99at31.wk1      Appendix table 31.  Jails providing educational programs for inmates and number  of inmates participating in educational programs, June 30, 1999
cj99at32.wk1      Appendix table 32.  Jails providing counseling or special programs for inmates, June 30, 1999
cj99at33.wk1      Appendix table 33.  Jail boot camp and work release programs,  June 30, 1999
cj99at34.wk1      Appendix table 34.  Jail functions, June 30, 1999
cj99at35.wk1      Appendix table 35.  Selected jail characteristics, June 30, 1999
 
 
 
 
 
 
