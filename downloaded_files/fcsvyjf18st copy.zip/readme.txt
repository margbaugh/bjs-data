Facility Characteristics of Sexual Victimization of Youth in Juvenile Facilities, 2018 – Statistical Tables NCJ 305074	
	
This zip archive contains tables in individual .csv spreadsheets for	
Facility Characteristics of Sexual Victimization of Youth in Juvenile Facilities, 2018 – Statistical Tables NCJ 305074	
The full electronic report is available at: https://bjs.ojp.gov/library/publications/facility-characteristics-sexual-victimization-youth-juvenile-facilities-2018

This report is one in a series.  More recent editions may be available. 	
To view a list of all in the series go to:
https://bjs.ojp.gov/library/publications/list?series_filter=PREA%20Publications	

	
Filenames		Table titles
fcsvyjf18stt1.1.csv	Table 1.1. Screening for potential new hires of frontline staff in juvenile facilities, by type of facility, 2018 
fcsvyjf18stt1.2.csv	Table 1.2. General and PREA-related training required for frontline staff in juvenile facilities, by type of facility, 2018 
fcsvyjf18stt1.3.csv	Table 1.3. PREA education and grievance processes for youth in juvenile facilities, by type of facility, 2018
fcsvyjf18stt2.1.csv	Table 2.1. Sexual victimization in juvenile facilities, by type of incident and facility organizational structure, 2018 
fcsvyjf18stt2.2.csv	Table 2.2. Sexual victimization in juvenile facilities, by type of incident and selected facility characteristics, 2018 
fcsvyjf18stt2.3.csv	Table 2.3. Sexual victimization in juvenile facilities, by type of incident and selected frontline staff characteristics, 2018 
fcsvyjf18stt2.4.csv	Table 2.4. Sexual victimization in juvenile facilities, by type of incident and facility staff turnover and vacancies, 2018 
fcsvyjf18stt3.1.csv	Table 3.1. Sexual victimization in juvenile facilities, by type of incident and youth-reported PREA education in facility, 2018 
fcsvyjf18stt3.2.csv	Table 3.2. Sexual victimization in juvenile facilities, by type of incident and youth perceptions of facility policies and fairness, 2018 
fcsvyjf18stt3.3.csv	Table 3.3. Sexual victimization in juvenile facilities, by type of incident and youth perceptions of facility staff, 2018 
fcsvyjf18stt3.4.csv	Table 3.4. Sexual victimization in juvenile facilities, by type of incident and youth-reported facility atmosphere and living conditions, 2018 
fcsvyjf18stt3.5.csv	Table 3.5. Sexual victimization in juvenile facilities, by type of incident and selected youth characteristics, 2018 
	
			Figures
fcsvyjf18stf1.csv	Figure 1. Youth reporting sexual victimization in juvenile facilities, by sex of youth housed in facility, 2018
	
	
