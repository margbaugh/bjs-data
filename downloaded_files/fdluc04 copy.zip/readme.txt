Felony Defendants in Large Urban Counties, 2004           		


This zip archive contains tables in individual  .csv spreadsheets               	
from Felony Defendants in Large Urban Counties, 2004,  NCJ 221152 
The full report including text and graphics in pdf format are available from:              		
http://www.ojp.usdoj.gov/bjs/abstract/fdluc04.htm           		


This report is one in a series.  More recent editions            		
may be available.  To view a list of all in the series go to               		
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#fdluc 

fdluc04t01.csv		Table 1.  Race and Hispanic origin of felony defendants,by most serious arrest charge, 2004
fdluc04tt01.csv		Table 1.  Percent of trials resulting in a conviction, 2004  

fdluc04f01.csv		Figure 1. More than 1 in 5 felony defendants were convicted and sentenced to prison in 2004
fdluc04f02.csv		Figure 2. More than a third of felony defendants in the nation's 75 most populous counties charged with drug offenses, 2004
fdluc04f03.csv		Figure 3. Two-thirds of felony defendants in the nation's 75 largest counties were released through surety bond or recognizance, 2004
fdluc04f04.csv		Figure 4. Over half of felony defendants with more than 1 prior felony conviction sentenced to prison, 2004
fdluc04f05.csv		Figure 5. Since 1994 more than a third of felony defendants were charged with a drug offense, 2004