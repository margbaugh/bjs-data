"Federal Criminal Case Processing, 2002:  Reconciled Data 1982-2002"		

This zip archive contains tables in individual .csv spreadsheets		
"from Federal Criminal Case Processing, 2002:  Reconciled Data 1982-2002. The full report including "		
The full report including text and graphics in pdf format are available from:		
http://www.ojp.usdoj.gov/bjs/abstract/fccp02.htm		

This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.ojjp.usdoj.gov/bjs/pubalp2.htm#fccprd		


Filenames		Tables
fccp02t1.csv		Table 1.  Arrests for Federal offenses by offense October 1 2001 - September 30 2002
fccp02t2.csv		Table 2.  Suspects in criminal matters investigated by U.S. attorneys by offense October 1 2001 - September 30 2002
fccp02t3.csv		Table 3.  Disposition of suspects in matters concluded by U.S. attorneys by offense October 1 2001 - September 30 2002
fccp02t4.csv		Table 4.  Defendants in cases proceeded against in U.S. district courts by offense October 1 2001 - September 30 2002
fccp02t5.csv		Table 5.  Disposition of defendants in cases terminated in U.S. district courts by offense October 1 2001 - September 30 2002
fccp02t6.csv		Table 6. Sanctions imposed on offenders convicted and sentenced in U.S. district courts by offense October 1 2001 - September 30 2002
fccp02t7.csv		Table 7.  Criminal appeals filed by type of criminal case and offense October 1 2001 - September 30 2002
fccp02t8.csv		Table 8. Offenders under Federal supervision by offense October 1 2001 - September 30 2002
fccp02t9.csv		Table 9.  Federal prison admissions and releases  by offense October 1 2001 - September 30 2002



		Appendix tables
fccp02a01.csv		Table A.1.  Arrests for Federal offenses by offense 1994-2002
fccp02a02.csv		Table A.2.  Suspects in criminal matters investigated by U.S. attorneys by offense 1994-2002
fccp02a03.csv		Table A.3.  Suspects in criminal matters concluded by U.S. attorneys by offense 1994-2002
fccp02a04.csv		Table A.4.  Suspects in criminal matters concluded by U.S. attorneys:  Number prosecuted before U.S. district court judge by offense 1994-2002
fccp02a05.csv		Table A.5.  Suspects in criminal matters concluded by U.S. magistrates by offense 1994-2002
fccp02a06.csv		Table A.6.  Suspects in criminal matters concluded by U.S. attorneys:  Number declined prosecution by offense 1994-2002
fccp02a07.csv		Table A.7.  Defendants in cases proceeded against in U.S. district courts by offense 1994-2002
fccp02a08.csv		Table A.8.  Defendants in cases terminating in U.S. district courts by offense 1994-2002
fccp02a09.csv		Table A.9.  Defendants in cases terminating in U.S. district courts:  Percent convicted by offense 1994-2002
fccp02a10.csv		Table A.10.  Offenders convicted and sentenced in U.S. district courts by offense 1994-2002
fccp02a11.csv		Table A.11.  Offenders convicted and sentenced in U.S. district courts:  Number sentenced to prison by offense 1994-2002
fccp02a12.csv		Table A.12.  Criminal appeals filed by offense 1994-2002
fccp02a13.csv		Table A.13.  Offenders convicted and sentenced in U.S. district courts:  Number sentenced to probation only by offense 1994-2002
fccp02a14.csv		Table A.14.  Offenders convicted and sentenced in U.S. district courts:  Mean number of months of imprisonment imposed by offense 1994-2002
fccp02a15.csv		Table A.15.  Offenders under Federal supervision by offense 1994-2002
fccp02a16.csv		Table A.16.   Population at the end of the year in Federal prisons by offense 1994-2002


		Figures
		Cover figure.  Federal criminal case processing 1994-2002
fccp02f1.csv		Figure 1.  Number of suspects in criminal matters investigated by U.S. attorneys by selected offenses 1982-2002
fccp02f2.csv		Figure 2.  Number of defendants in criminal cases terminated in U.S. district court by selected offenses 1982-2002
fccp02f3.csv		Figure 3.  Defendants convicted in U.S. district court:  Percentage sentenced to prison by selected offenses 1982-2002
fccp02f4.csv		Figure 4.  Number of offenders under Federal supervision by type of supervision 1987-2002
fccp02f.csv5		Figure 5.  U.S. district court commitments and first releases from Federal prison by expected or actual time in prison 1986-2002

		Highlights
fccp02h1.csv		Figure H.1.  Federal criminal case processing October 1 2001 - September 30 2002
fccp02h2.csv		Figure H.2.  Number of offenders under Federal correctional supervision September 30 2002
