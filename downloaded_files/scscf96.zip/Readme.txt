						readme.txt

Contents of zip archive scs96.zip
Tables from State Court Sentencing of Convicted Felons, 1996, NCJ 175708
File name		Title
scs9611.wk1		Table 1.1 Estimated number of felony convictions in State courts, 1996
scs9612.wk1		Table 1.2 Type of felony sentences imposed by State courts, by offense 1996
scs9613.wk1		Table 1.3 Length of felony sentence imposed by State courts, by offense and type
                   of sentence, 1996
scs9614.wk1		Table 1.4 Estimated percent of felons sentenced to life in prison, by offense, 1996
scs9615.wk1		Table 1.5 Estimated time to be served in State prison, by offense, 1996
scs9616.wk1		Table 1.6 Number of offenses for felons convicted and sentenced in State courts, by
                   most serious felony conviction offense, 1996
scs9617.wk1		Table 1.7 Convicted felons sentenced to prison by State courts, by number of
                   conviction offenses, 1996
scs9618.wk1		Table 1.8 Mean sentence lengths for felony sentences imposed, by the number and
                   category of the conviction offense, 1996
scs9619.wk1		Table 1.9 Felons sentenced to an additional penalty by State courts, by offense,
                   1996

scs9621.wk1		Table 2.1 Demographic characteristics of persons convicted of felonies by State
                   courts,  by offense, 1996
scs9622.wk1		Table 2.2 Gender, race, and age of felons convicted in State courts, by offense,
                   1996
scs9623.wk1		Table 2.3 Average age of convicted felons in State courts, by offense, 1996
scs9624.wk1		Table 2.4 Offense and gender of felons, by type of sentence imposed, 1996
scs9625.wk1		Table 2.5 Offense and race of felons, by type of sentence imposed, 1996
scs9626.wk1		Table 2.6 Mean length of felony State court sentences imposed, by offense and gender
                   of felons, 1996
scs9627.wk1		Table 2.7 Mean length of felony State court sentences imposed, by offense and race
                   of felons, 1996
scs9628.wk1		Table 2.8 Gender and race of felons sentenced to incarceration or prison by State
                   courts, by offense, 1996
scs9629.wk1		Table 2.9 Gender and race of felons sentenced to jail or probation by State courts,
                   by offense, 1996
scs96210.wk1	Table 2.10 Percent of convicted felons sentenced by State courts to incarceration or
                   prison, by gender, race, and offense, 1996
scs96211.wk1	Table 2.11 Percent of convicted felons sentenced by State courts to jail or
                   probation, by gender, race, and offense, 1996
scs96212.wk1	Table 2.12 Mean length of State felony sentences to incarceration or prison, by
                   gender and race of felons, 1996 
scs96213.wk1	Table 2.13 Mean length of State felony sentences to jail or probation, by gender and
                   race of felons, 1996
scs9631.wk1		Table 3.1 Estimated number of felony convictions in State courts, by whether
                   sentenced to probation and by offense, 1996
scs9632.wk1 	Table 3.2 Felony convictions in State courts, by type of sentence to probation or
                   incarceration and offense, 1996
scs9633.wk1		Table 3.3 Average probation sentence of felons convicted in State courts, by
                   offense, 1996
scs9634.wk1		Table 3.4 Average State court sentence to incarceration for felons receiving
                   sentences with or without probation, by offense, 1996
scs9635.wk1		Table 3.5 Percent of conviction offenses for felons sentenced to probation in State
                   courts, by offense, 1996
scs9636.wk1		Table 3.6 Gender of felons sentenced to probation or to incarceration without
                    probation in State courts, by offense, 1996
scs9637.wk1		Table	3.7 Offense of felons sentenced to probation or to incarceration without
                    probation in State courts, by gender, 1996
scs9638.wk1		Table 3.8 Offense of felons sentenced to probation or to incarceration without
                    probation in State courts, by race, 1996
scs9639.wk1		Table 3.9 Race of felons sentenced to probation or to incarceration without
                    probation in State courts, by offense, 1996
scs96310.wk1 	Table 3.10 Average age of felons sentenced to probation or to incarceration without
                    probation in State courts, by offense, 1996
scs96311.wk1	Table 3.11 Felons sentenced to probation in State courts, by offense and age at
                    sentencing, 1996
scs9641.wk1		Table 4.1 Number of felony convictions in State courts, by offense and type of
                    conviction, 1996
scs9642.wk1		Table 4.2 Percent of felons convicted in State courts, by offense and type of
                    conviction, 1996
scs9643.wk1		Table 4.3 Type of conviction of felons convicted in State courts, by offense, 1996
scs9644.wk1		Table 4.4 Offense of felons convicted in State courts, by the type of conviction and
                    type of sentence imposed, 1996
scs9645.wk1		Table 4.5 Average felony sentence length in State courts, by the type of conviction,
                    type of sentence imposed, and offense, 1996
scs9646.wk1		Table 4.6 Type of conviction in State courts, by the type of sentence imposed on
                    felons convicted of murder or nonnegligent manslaughter, 1996
scs9647.wk1		Table 4.7 Type of conviction in State courts, by number of felony conviction
                    offenses, 1996
scs9648.wk1		Table 4.8 Percent of conviction offenses of felons convicted in State courts, by
                    type of conviction and type of sentence imposed, 1996
scs9649.wk1		Table 4.9 Average number of days between arrest and conviction for felony cases in
                    State courts, by type of conviction, 1996
scs96410.wk1	Table 4.10 Average number of days between conviction and sentencing for felony cases
                    in State courts, by type of conviction, 1996
scs96411.wk1      Table 4.11 Mean and median number of days between arrest and sentencing for felony
                    cases disposed by State courts, 1996
scs9651.wk1		Table 5.1 Transferred juveniles compared to adults by State definition: most serious
                     offense of felons convicted in State courts, 1996
scs9652.wk1		Table 5.2 Transferred juveniles compared to adults by State definition: most serious
                    offense, by the type of felony sentence imposed in State courts, 1996
scs9653.wk1		Table 5.3 Transferred juveniles compared to adults by State definition: mean length
                     of felony sentence imposed in State courts, by the type of sentence and most
                     serious offense, 1996