Felony Defendants in Large Urban Counties, 2002           


This zip archive contains tables in individual  .csv spreadsheets               
from Felony Defendants in Large Urban Counties, 2002,  NCJ 210818.  The full report
including text               
and graphics in pdf format are available from:              
http://www.ojp.usdoj.gov/bjs/abstract/fdluc02.htm           


This report is one in a series.  More recent editions            
may be available.  To view a list of all in the series go to               
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#fdluc              


fdluc02t01.csv           Table: 1    Felony defendants, by most serious arrest charge, 2002
fdluc02t02.csv           Table: 2    Level of second most serious charge of felony defendants,  by most serious arrest charge, 2002
fdluc02t03.csv           Table: 3    Race and Hispanic origin of felony defendants, by most serious arrest charge, 2002
fdluc02t04.csv           Table: 4    Gender of felony defendants, by most serious arrest charge, 2002
fdluc02t05.csv           Table: 5    Age at arrest of felony defendants, by most serious arrest charge, 2002
fdluc02t06.csv           Table: 6    Gender and race/ethnicity of felony defendants, by age at arrest, 2002
fdluc02t07.csv           Table: 7    Criminal justice status of felony defendants at time of arrest, by most serious arrest charge, 2002
fdluc02t08.csv           Table: 8    Number of prior arrest charges of felony defendants, by most serious current arrest charge, 2002
fdluc02t09.csv           Table: 9    Number of prior felony arrest charges of felony defendants, by most serious current arrest charge, 2002
fdluc02t10.csv           Table: 10   Number of prior convictions of felony defendants, by most serious current arrest charge, 2002
fdluc02t11.csv           Table: 11   Number of prior felony convictions of felony defendants, by most serious current arrest charge, 2002
fdluc02t12.csv           Table: 12   Most serious prior conviction of felony defendants, by most serious current arrest charge, 2002
fdluc02t13.csv           Table: 13   Felony defendants released before or detained until case disposition, by most serious arrest charge, 2002
fdluc02t14.csv           Table: 14   Type of pretrial release or detention of felony defendants, by most serious arrest charge, 2002
fdluc02t15.csv           Table: 15   Bail amount set for felony defendants, by most serious arrest charge, 2002
fdluc02t16.csv           Table: 16   Median and mean bail amounts set for felony defendants, by pretrial release/detention outcome and most serious arrest charge, 2002
fdluc02t17.csv           Table: 17   Time from arrest to release for felony defendants released before case disposition, by most serious arrest charge, 2002
fdluc02t18.csv           Table: 18   Percent of felony defendants who were released prior to case disposition, by criminal history, 2002
fdluc02t19.csv           Table: 19   Released felony defendants committing misconduct, by most serious arrest charge, 2002 
fdluc02t20.csv           Table: 20   Released felony defendants who failed to make a scheduled court appearance, by most serious arrest charge, 2002
fdluc02t21.csv           Table: 21   Released felony defendants who were rearrested prior to case disposition, by most serious arrest charge, 2002
fdluc02t22.csv           Table: 22   Time from arrest to adjudication for felony defendants, by most serious arrest charge, 2002
fdluc02t23.csv           Table: 23   Adjudication outcome for felony defendants,by most serious arrest charge, 2002  
fdluc02t24.csv           Table: 24   Adjudication outcome for felony defendants,by detention-release outcome and most serious arrest charge, 2002
fdluc02t25.csv           Table: 25   Adjudication outcome for felony defendants,by number and type of arrest charges, 2002
fdluc02t26.csv           Table: 26   Conviction offense of defendants arrested for a violent offense and subsequently convicted, by most serious arrest charge, 2002
fdluc02t27.csv           Table: 27   Conviction offense of defendants arrested for a nonviolent offense and subsequently convicted, by most serious arrest charge, 2002
fdluc02t28.csv           Table: 28   Felony defendants, by conviction offense, 2002
fdluc02t29.csv           Table: 29   Time from conviction to sentencing for convicted defendants, by most serious conviction offense, 2002
fdluc02t30.csv           Table: 30   Most severe type of sentence received by convicted defendants,  by most serious conviction offense, 2002
fdluc02t31.csv           Table: 31   Length of prison sentence received by defendants convicted of a felony, by most serious conviction offense, 2002
fdluc02t32.csv           Table: 32   Length of jail sentence received by convicted defendants, by most serious conviction offense, 2002
fdluc02t33.csv           Table: 33   Length of probation sentence received by convicted defendants,  by most serious conviction offense, 2002
fdluc02t34.csv           Table: 34   Conditions of probation sentence received most often by convicted defendants, by most serious conviction offense, 2002
fdluc02t35.csv           Table: 35   Most severe type of sentence received by defendants convicted of a felony, by prior conviction record, 2002

fdluc02fg1.csv      	 Figure 1.   The most frequently charged offenses of felony defendants in the 75 largest counties, 2002
fdluc02fg2.csv      	 Figure 2.   Most serious arrest charge of felony defendants in the 75 largest counties, 1990 to 2002
fdluc02fg3.csv      	 Figure 3.   Most serious arrest charge of felony defendants, by race and Hispanic orgin, 2002
fdluc02fg4.csv      	 Figure 4.   Felony defendants under age 25 and age 21 in the 75 largest counties, by most serious arrest charge, 2002
fdluc02fg5.csv      	 Figure 5.   Race and gender of felony defendants in the 75 largest counties, by age at arrest, 2002
fdluc02fg6.csv      	 Figure 6.   Criminal justice status of felony defendants in the 75 largest counties, 2002
fdluc02fg7.csv      	 Figure 7.   Number of prior arrest charges of felony defendants in the 75 largest counties, by age of arrest, 2002
fdluc02fg8.csv      	 Figure 8.   Most serious prior conviction of felony defendants in the 75 largest counties, by age at arrest, 2002
fdluc02fg9.csv      	 Figure 9.   Most serious prior conviction of felony defendants in the 75 largest counties, 2002
fdluc02fg10.csv     	 Figure 10. Pretrial detention of felony defendants in the 75 largest counties, by most serious arrest charge, 2002
fdluc02fg11.csv          Figure 11. Pretrial release of felony defendants in the 75 largest counties, 2002
fdluc02fg12.csv          Figure 12. Probability of release for felony defendants in the 75 largest counties, by bail amount set, 2002
fdluc02fg13.csv          Figure 13. Misconduct prior to case disposition by released felony defendants in the 75 largest counties, 2002
fdluc02fg14.csv          Figure 14. Median time from arrest to adjudication for felony defendants in the 75 largest counties, by pretrial detention-release outcome, 2002
fdluc02fg15.csv          Figure 15. Plea rate for felony defendants in the 75 largest counties, by most serious arrest charge, 2002    
fdluc02fg16.csv          Figure 16. Trial rates for felony defendants in the 75 largest counties, by most serious arrest charge, 2002    
fdluc02fg17.csv          Figure 17. Conviction probabilities for felony defendants in the 75 largest counties, by most serious arrest charge, 2002 
fdluc02fg18.csv          Figure 18. Method of felony cases filed in May 2002 and disposed within 1 year in the 75 largest counties     
fdluc02fg19.csv          Figure 19. Method of conviction of felony cases filed in May 2002 and disposed within 1 year in the 75 largest counties  
fdluc02fg20.csv          Figure 20. Probability of being convicted and sentenced to incarceration for felony defendants in the 75 largest counties, 2002 
fdluc02fg21.csv          Figure 21. Median prison sentence received by defendants convicted of a felony in the 75 largest counties, 2002     
fdluc02fg22.csv          Figure 22. Type of sentence received for a felony conviction in the 75 largest counties, by prior conviction record, 2002 

fdluc02hg1.csv           Highlight graph 1.  Age at arrest, felony defendants in the 75 largest counties, 1990-2002
fdluc02hg2.csv           Highlight graph 2.  Most severe sentence received by defendants convicted of a felony in the 75 largest counties, 1990-2002
fdluc02hg3.csv           Highlight graph 3.  Probability of being convicted and sentenced to incarceration for felony defendants in the largest counties, 2002

Appendix tables
fdluc02ata.csv           Appendix table A:  Population, sampling weights, and number of cases, by SCPS jurisdiction, 2002
fdluc02atb.csv           Appendix table B:  Most serious arrest charge of felony defendants, by SCPS jurisdiction, 2002
fdluc02atc.csv           Appendix table C:  Gender and age of felony defendants, by SCPS jurisdiction, 2002
fdluc02atd.csv           Appendix table D:  Race and Hispanic/Latino origin, by SCPS jurisdiction, 2002
fdluc02ate.csv           Appendix table E:  Felony defendants released before or detained until case disposition, by SCPS jurisdiction, 2002
fdluc02atf.csv           Appendix table F:  Failure-to-appear and rearrest rates of defendants released prior to case disposition, by SCPS jurisdiction, 2002
fdluc02atg.csv           Appendix table G:  Adjudication outcome for felony defendants, by SCPS jurisdiction, 2002
fdluc02ath.csv           Appendix table H:  Most severe type of sentence received by defendants convicted of a felony, by SCPS jurisdiction, 2002
