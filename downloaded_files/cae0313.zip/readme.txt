Crimes Against the Elderly, 2003-2013      NCJ 248339			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Crimes Against the Elderly, 2003-2013, NCJ 248339.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5136.		
			
			
			
			
Filename			Table title
cae0313t01.csv			Table 1. Number and rate of property victimization, by type of crime and age of head of household, 2003�2013
cae0313t02.csv			Table 2. Number and rate of violent victimization, by type of crime and age of victim, 2003�2013
cae0313t03.csv			Table 3. Rate of violent victimization, by age of victim and location of residence, 2003�2013
cae0313t04.csv			Table 4. Rate of property victimization, by age of head of household and location of residence, 2003�2013
cae0313t05.csv			Table 5. Location of violent victimization, by age of victim, 2003�2013
cae0313t06.csv			Table 6. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft and age of victim, 2012
cae0313t07.csv			Table 7. Violent victimization, by age of victim and victim�offender relationship, 2003�2013
cae0313t08.csv			Table 8. Percent of violent victimization, by victim�offender relationship and age of victim, 2003�2013
cae0313t09.csv			Table 9. Rate of violent victimization, by age of victim and victim characteristics, 2003�2013
cae0313t10.csv			Table 10. Number and rate of violent victimization for persons age 65 or older, by type of crime and victim�s disability status, 2008�2012
cae0313t11.csv			Table 11. Rates of violent and property victimization, by employment status and age, 2003�2013
cae0313t12.csv			Table 12. Percent of violent victimizations involving a weapon, by age of victim, 2003�2013
cae0313t13.csv			Table 13. Percent of violent victimizations resulting in injury and medical treatment, by age of victim, 2003�2013
cae0313t14.csv			Table 14. Percentage of victimizations reported to police, by type of crime and age of victim, 2003�2013
cae0313t15.csv			Table 15. Violent crime victims who received assistance from a victim service agency, by age of victim, 2003�2013
			
Figures			
cae0313f01.csv			Figure 1. Rate of violent victimization, by type of crime and age of victim, 2003�2013
cae0313f02.csv			Figure 2. Distribution of the population age 65 or older, 1990�2020
cae0313f03.csv			Figure 3. Rate of violent victimization, by age of victim, 1993�2013
cae0313f04.csv			Figure 4. Rate of homicide, by age of victim, 1993�2011
cae0313f05.csv			Figure 5. Rate of firearm homicide, by age of victim, 1993�2011
cae0313f06.csv			Figure 6. Rate of nonfirearm homicide, by age of victim, 1993�2011
cae0313f07.csv			Figure 7. Rate of property victimization, by age of head of household, 1993�2013
			
Appendix tables			
cae0313at01.csv			Appendix table 1. Standard errors for figure 1 and table 2: Number and rate of violent victimization, by type of crime and age of victim, 2003-2013
cae0313at02.csv			Appendix table 2. Estimates for figure 2: Distribution of the population age 65 or older, 1990�2020
cae0313at03.csv			Appendix table 3. Standard errors for table 1: Number and rate of property victimization, by type of crime and age of head of household, 2003�2013
cae0313at04.csv			Appendix table 4. Rates and standard errors for figure 3: Rate of violent victimization, by age of victim, 1993�2013
cae0313at05.csv			Appendix table 5. Rates for figure 4: Rate of homicide, by age of victim, 1993�2011
cae0313at06.csv			Appendix table 6. Rates for figure 5: Rate of firearm homicide, by age of victim, 1993�2011
cae0313at07.csv			Appendix table 7. Rates for figure 6: Rate of nonfirearm homicide, by age of victim, 1993�2011
cae0313at08.csv			Appendix table 8. Rates and standard errors for figure 7: Rate of property victimization, by age of head of household, 1993�2013
cae0313at09.csv			Appendix table 9. Standard errors for table 3: Rate of violent victimization, by age of victim and location of residence, 2003�2013
cae0313at10.csv			Appendix table 10. Standard errors for table 4: Rate of property victimization, by age of head of household and location of residence, 2003�2013
cae0313at11.csv			Appendix table 11. Standard errors for table 5: Location of violent victimization, by age of victim, 2003�2013
cae0313at12.csv			Appendix table 12. Standard errors for table 6: Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft and age of victim, 2012
cae0313at13.csv			Appendix table 13. Standard errors for table 7: Violent victimization, by age of victim and victim�offender relationship, 2003�2013
cae0313at14.csv			Appendix table 14. Standard errors for table 8: Percent of violent victimization, by victim�offender relationship and age of victim, 2003�2013
cae0313at15.csv			Appendix table 15. Standard errors for table 9: Rate of violent victimization, by age of victim and victim characteristics, 2003�2013
cae0313at16.csv			Appendix table 16. Standard errors for table 10: Number and rate of violent victimization for persons age 65 or older, by type of crime and victim�s disability status, 2008�2012
cae0313at17.csv			Appendix table 17. Standard errors for table 11: Rates of violent and property victimization, by employment status and age, 2003�2013
cae0313at18.csv			Appendix table 18. Standard errors for table 12: Percent of violent victimizations involving a weapon, by age of victim, 2003�2013
cae0313at19.csv			Appendix table 19. Standard errors for table 13: Percent of violent victimizations resulting in injury and medical treatment, by age of victim, 2003�2013
cae0313at20.csv			Appendix table 20. Standard errors for table 14: Percentage of victimizations reported to police, by type of crime and age, 2003�2013
cae0313at21.csv			Appendix table 21. Standard errors for table 15: Violent crime victims who received assistance from a victim service agency, by age of victim, 2003�2013
cae0313at22.csv			Appendix table 22. Rate of violent and property victimization against the elderly, by type of crime and age, 2003�2013
cae0313at23.csv			Appendix table 23. Standard errors for appendix table 22: Rate of violent and property victimization against the elderly, by type of crime and age, 2003�2013
