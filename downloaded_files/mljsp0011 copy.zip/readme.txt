Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2011   NCJ 242186

This zip archive contains tables in individual .csv spreadsheets
Mortality in Local Jails and State Prisons - Statistical Tables, 2000-2011   NCJ 242186
The full report including text and graphics in .pdf format are available at:
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4757

 
Filenames		Tables
mljsp0010t01.csv	Table 1. Number of local jail inmate deaths, by cause of death, 2000�2011
mljsp0010t02.csv	Table 2. Percent of local jail inmate deaths, by cause of death, 2000�2011
mljsp0010t03.csv	Table 3. Mortality rate per 100,000 local jail inmates, by cause of death, 2000�2011
mljsp0010t04.csv	Table 4. Number of local jail inmate deaths, by selected decedent characteristics, 2000�2011
mljsp0010t05.csv	Table 5. Percent of local jail inmate deaths, by selected decedent characteristics, 2000�2011
mljsp0010t06.csv	Table 6. Mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000�2011
mljsp0010t07.csv	Table 7. Number of local jail inmate deaths, by cause of death and selected decedent characteristics, 2000-2011
mljsp0010t08.csv	Table 8. Average annual mortality rate per 100,000 local jail inmates, by cause of death and selected decedent characteristics, 2000-2011
mljsp0010t09.csv	Table 9. Number and percent of local jail jurisdictions reporting to the Deaths in Custody Reporting Program, by number of deaths reported each year, 2000-2011
mljsp0010t10.csv	Table 10. Number of local jail deaths, by state, 2000�2011
mljsp0010t11.csv	Table 11. Mortality rate per 100,000 local jail inmates, by state, 2000-2011
mljsp0010t12.csv	Table 12. Number of local jail inmates held on an average day, by state, 2000-2011
mljsp0010t13.csv	Table 13. Percent of local jail jurisdictions reporting one or more deaths to the Deaths in Custody Reporting Program, by state, 2000-2011
mljsp0010t14.csv	Table 14. Number of state prisoner deaths, by cause of death, 2001-2011
mljsp0010t15.csv	Table 15. Percent of state prisoner deaths, by cause of death, 2001-2011
mljsp0010t16.csv	Table 16. Mortality rate per 100,000 state prisoners, by cause of death, 2001�2011
mljsp0010t17.csv	Table 17. Number of state prisoner deaths, by selected decedent characteristics, 2001�2011
mljsp0010t18.csv	Table 18. Percent of state prisoner deaths, by selected decedent characteristics, 2001-2011
mljsp0010t19.csv	Table 19. Estimated number of state prisoners in custody, by selected characteristics, 2001�2011
mljsp0010t20.csv	Table 20. Mortality rate per 100,000 state prisoners, by selected decedent characteristics, 2001�2011
mljsp0010t21.csv	Table 21. Number of state prisoner deaths, by cause of death and selected decedent characteristics, 2001�2011
mljsp0010t22.csv	Table 22. Average annual mortality rate per 100,000 state prisoners, by cause of death and selected decedent characteristics, 2001�2011
mljsp0010t23.csv	Table 23. Number of state and federal prisoner deaths, by location, 2001�2011
mljsp0010t24.csv	Table 24. Mortality rate per 100,000 state prisoners, by location, 2001�2011
mljsp0010t25.csv	Table 25. Number of state prisoner deaths, by cause of death and location, 2001�2011
mljsp0010t26.csv	Table 26. Average annual mortality rate per 100,000 state prisoners, by cause of death and location

Figures
mljsp0010f01.csv	Figure 1. Moving average mortality rate per 100,000 local jail inmates, by selected causes of death, 2000-2011
mljsp0010f02.csv	Figure 2. Moving average mortality rate per 100,000 state prisoners, be selected cause of death, 2001-2011

Appendix tables
mljsp0011at01.csv	Appendix table 1. Illness mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000-2011
mljsp0011at02.csv	Appendix table 2. Heart disease mortality rate per 100,000 local jial inmates, by selected decedent characteristics, 2000-2011
mljsp0011at03.csv	Appendix table 3. All other illnesses mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2000-2011
mljsp0011at04.csv	Appendix table 4. Suicide mortality rate per 100,000 local jail inmates, by selected decedent characteristics, 2001-2011
mljsp0011at05.csv	Appendix table 5. Illness mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2000-2011
mljsp0011at06.csv	Appendix table 6. Cancer mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2001-2011
mljsp0011at07.csv	Appendix table 7. Heart disease mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2001-2011
mljsp0011at08.csv	Appendix table 8. Liver disease mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2001-2011
mljsp0011at09.csv	Appendix table 9. Respiratory disease mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2001-2011
mljsp0011at10.csv	Appendix table 10. All other illnesses mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2001-2011
mljsp0011at11.csv	Appendix table 11. Suicide mortality rate per 100,000 state prison inmates, by selected decedent characteristics, 2001-2011

 




