"American Indians and Crime, 1992-2002     NCJ  203097"			


This zip archive contains tables in individual .csv spreadsheets			
"from American Indians and Crime, 1992-2002,   NCJ  203097.  The full report including text"			
and graphics in pdf format are available from:			
http://www.ojp.usdoj.gov/bjs/abstract/aic02.htm			

This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#aic			



aic0201.csv		Table #:   01  	" U.S. population 2000,  by race "
aic0202.csv		Table #:   02	" The 10 largest American Indian tribal groupings in the  United States, 2000 "
aic0203.csv		Table #:   03	" States with 1 of the 10  largest American Indian populations, Census 2000 "
aic0204.csv		Table #:   04	" Median age of single-race  U. S. residents, by race, Census 2000 "
aic0205.csv		Table #:   05	" Annual average violent victimization rates  for persons age 12 or older, by race, 1992-2001 "
aic0206.csv		Table #:   06	" Survey population and victims of violence, by race,  1992-2001  "
aic0207.csv		Table #:   07	" Annual average rates of rape/sexual assault, robbery, aggravated assault, and simple assault, by race of victim, 1992-2001 "
aic0208.csv		Table #:   08	" Violent crime, by type of crime and race of victim, 1992-2001 "
aic0209.csv		Table #:   09	" Violent crime rates for persons age 12 or older,  by race, age, gender, and location of residence, 1992-2001"
aic0210.csv		Table #:   10	" Percent of violent victimizations, by age, gender, and race of victim, 1992-2001 "
aic0211.csv		Table #:   11	" Violent victimization of American Indians, by victim-offender relationship and type of victimization, 1992-2001"
aic0212.csv		Table #:   12	" Percent of violent victimizations,  by race of victim and offender, 1992-2001"
aic0213.csv		Table #:   13	" Violent victimization of American Indians, by race of offender and type of victimization, 1992-2001"
aic0214.csv		Table #:   14	" Violent victimization, by the perceived drug or alcohol use of the offender and by race of victim, 1992-2001"
aic0215.csv		Table #:   15	" Violent victimization, by use of weapon  and race of victim, 1992-2001"
aic0216.csv		Table #:   16	" Murders of American Indians, as a percent of all American Indians and of all murder victims, by State, 1976-99"
aic0217.csv		Table #:   17	" Murders, by race of offender and victim, 1976-99"
aic0218.csv		Table #:   18	" Murders, by victim-offender relationship and race, 1976-99"
aic0219.csv		Table #:   19	" Murders by a relative or acquaintance, by race of victim  and offender, 1976-99"
aic0220.csv		Table #:   20	" Violent crime arrests, by race, 1991-2001 "
aic0221.csv		Table #:   21	" Arrests, by violent crime and age, 2001 "
aic0222.csv		Table #:   22	" Arrests, by alcohol violations, race, and age, 2001 "
aic0223.csv		Table #:   23	" Suspects in matters investigated by U.S. Attorneys,  by offense, 2000"
aic0224.csv		Table #:   24	" Criminal cases filed in U.S. district courts, by type of offense, 2000"
aic0225.csv		Table #:   25	" Offenders entering Federal prison, by race and offense type, 1994 and 2001 "
aic0226.csv		Table #:   26	" Prisoners released from prison in 12 States in 1994,  by race and offense "
aic0227.csv		Table #:   27	" Recidivism of American Indian prisoners released  in 1994 from prison in 12 States, by time after release "
aic0228.csv		Table #:   28	" Prisoners released in 1994, by offense, race, arrest, and conviction "
aic0229.csv		Table #:   29	 Prisoners released in 1994 and returned to prison by race 
aic0230.csv		Table #:   30	" American Indians under sentence of death, 1973-2002"
aic0231.csv		Table #:   31	" Capital punishment among American Indians,  by State and status, 1973-2002"
aic0232.csv		Table #:   32	" The 5 largest tribally operated law enforcement agencies,  by number of full-time personnel and land area, 2000 "
aic0233.csv		Table #:   33	" Tribal adult jail capacity and staff, by State and tribe, 2002 "
aic0234.csv		Table #:   34	" Tribal juvenile jail capacity, number in custody,  offense seriousness, and staff, by State and tribe, 2002  "
aic0235.csv		Table #:   35	" CTUIR violent victimization respondents, by tribal affiliation, 2001 "	
aic0236.csv		Table #:   36	" Violent victimizations of CTUIR American Indians  age 18 or older, by gender, age, residence, and tribal affiliation, 2001"	
aic0237.csv		Table #:   37	" CTUIR violent victimizations, by offense type and tribal affiliation, 2001"	
aic0238.csv		Table #:   38	" Southern Ute Indian Reservation violent victimizations,  by tribal affiliation, 2001"	
aic0239.csv		Table #:   39	" Southern Ute Indian Reservation violent victimizations  against American Indians, by gender, age, and residence"	
aic0240.csv		Table #:   40	" Southern Ute Indian Reservation total of violent victimizations,  by offense type and tribal affiliation"	


		Highlights tables		
aic02ht01.csv		Highlights table #:   01 		"Number of violent victimizations per 1,000 persons age 12 or older"
aic02ht02.csv		Highlights table #:   02 		"Rate of murder victims per 100,000 American Indians"
aic02ht03.csv		Highlights table #:   03		"Rate of violent victimization per 1,000 persons in each group"
aic02ht04.csv		Highlights table #:   04		"Number of violent victimizations per 1,000 persons age 12 or older"
aic02ht05.csv		Highlights table #:   05		Percent of victimizations of American Indians
aic02ht06.csv		Highlights table #:   06		Percent of violent victimizations with a white offender
aic02ht07.csv		Highlights table #:   07		Percent of violent victimizations with offender alcohol/drug use
aic02ht08.csv		Highlights table #:   08		Percent of murder victims by type of weapon used
aic02ht09.csv		Highlights table #:   09		"Number of arrestees (per 100,000 population)"
aic02ht10.csv		Highlights table #:   10		Percent of suspects investigation by U.S. attorneys
aic02ht11.csv		Highlights table #:   11		Recidivism among American Indians: Time after release from prison
aic02htcv01.csv		Highlights tribal criminal victimization table #:   01		Number of violent victimizations
aic02htcv02.csv		Highlights tribal criminal victimization table #:   02		Percent of violent victimizations
aic02htcv03.csv		Highlights tribal criminal victimization table #:   03		Percent of domestic partner violence reported by Zuni Pueblo


		Figures		
aic02f01.csv		Figure #:  01	" Annual average rate of violent victimization among American Indians and all races, by type of violent crime, 1992-2001"	
aic02f02.csv		Figure #:  02	" Violent victimization of American Indians, by race of offender and type of victimization, 1992-2001"	
aic02f03.csv		Figure #:  03	" Annual number of murders of American Indians, 1976-2001"	
aic02f04.csv		Figure #:  04	" American Indian percent of State murder victims and resident population, 1997-99"	
aic02f05.csv		Figure #:  05	" Number of American Indian murder victims per 100,000 persons, 1990-2001"	
aic02f06.csv		Figure #:  06	" Arrests of American Indians for violent crime by State and local law enforcement, 1992-2001"	
aic02f08.csv		Figure #:  08	" Percent of criminal cases filed in U.S. district courts, by most serious offense charge, 2000"
aic02f09.csv		Figure #:  09	" American Indians as percent of all violent offenders entering Federal prisons, 1994-2001"
aic02f10.csv		Figure #:  10	" Violent victimizations and alcohol involvement, by tribal affiliation"
aic02f11.csv		Figure #:  11	" Violent victimizations involving drugs and alcohol related victimization, by tribal grouping"

aic02cv.csv		Cover graph	" American Indians experienced violence at a rate (101) violent crimes per 1,000 American Indians) (41 per 1,000 persons), 1992-2001"
