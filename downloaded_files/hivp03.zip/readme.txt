HIV in Prison, 2003   NCJ 210344	

This zip archive contains tables in individual .csv spreadsheets from HIV in Prison, 2003   NCJ 210344			
The full report including text and graphics in .pdf format are available from: http://www.ojp.usdoj.gov/bjs/abstract/hivp03.htm		

Filename		    Table name
hivp0301.csv		Table 1.  Inmates in custody of State or Federal prison authorities and known to be positive for the human immunodeficiency virus, 2001-03
hivp0302.csv		Table 2.  Inmates in custody of State or Federal prison authorities known to be positive for the human immunodeficiency virus, by gender, yearend 2003 
hivp0303.csv		Table 3.  Inmates in custody of State or Federal prison authorities and known to have confirmed AIDS, yearend 2002-03
hivp0304.csv		Table 4.  Inmate deaths in State prisons, by cause, 1995 and 2003
hivp0305.csv		Table 5.  Inmate deaths in Federal prisons, by cause, 2002 and 2003
hivp0306.csv		Table 6.  Deaths of State prisoners, 2003
hivp0307.csv		Table 7.  Profile of inmates who died in State prisons, 2002 and 2003

		            Text tables
hivp03t01.csv		Text table 1. Number of HIV-positive inmates
hivp03t02.csv		Text table 2. Percent of custody population known to be HIV positive
hivp03t03.csv		Text table 3. State prison inmates known to be HIV positive by gender
hivp03t04.csv		Text table 4. Number of confirmed AIDS cases in State and Federal Prisons
hivp03t05.csv		Text table 5. Percent of the general population and prison population with confirmed AIDS
hivp03t06.csv		Text table 6. AIDS-related deaths in State prisons
hivp03t07.csv		Text table 7. AIDS-related deaths as a percent of all deaths

		            Highlights
hivp03h01.csv		Highlights table 1.  Number and percent of HIV-positive State and Federal inmates
hivp03h02.csv		Highlights table 2.  Number and percent of HIV-positive inmates by jurisdiction
hivp03h03.csv		Highlights table 3. AIDS-related deaths in State Prisons

		            Figures
hivp03f01.csv		Figure 1. Rate of confirmed AIDS cases comparing the general population to State and Federal prisoners, 1991-2003
hivp03f02.csv		Figure 2. Rate of State prison inmate death, by cause, 1991-2003
