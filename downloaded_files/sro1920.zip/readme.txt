School Resource Officers, 2019–2020   NCJ 307334	
	
This zip archive contains tables in individual  .csv spreadsheets	
School Resource Officers, 2019–2020   NCJ 307334.	
The full report including text and graphics in pdf format is available from:	
https://bjs.ojp.gov/library/publications/school-resource-officers-2019-2020
	
Filenames		Table titles
sro1920t01.csv		Table 1. Number and percent of sworn SROs, by type of agency, 2019–2020
sro1920t02.csv		Table 2. Sex and race or ethnicity of sworn SROs, by type of agency, 2019–2020
sro1920t03.csv		Table 3. Years worked as a sworn SRO, by type of agency, 2019–2020
sro1920t04.csv		Table 4. Percent of sworn SROs certified by a national or state SRO association, by type of agency, 2019–2020
sro1920t05.csv		Table 5. Number of schools to which sworn SROs were assigned, by type of agency and size of SRO program, 2019–2020
sro1920t06.csv		Table 6. Recent patrol and response activities performed by sworn SROs, by type of agency, 2019–2020
sro1920t07.csv		Table 7. Recent security activities performed by sworn SROs, by type of agency, 2019–2020
sro1920t08.csv		Table 8. Recent mentoring activities performed by sworn SROs, by type of agency, 2019–2020
sro1920t09.csv		Table 9. Recent teaching activities performed by sworn SROs, by type of agency, 2019–2020
sro1920t10.csv		Table 10. Role of school administration in arrest decisions by sworn SROs, by type of agency, 2019–2020
sro1920t11.csv		Table 11. Offenses for which sworn SROs arrested any student(s) during the past 12 months, by type of agency, 2019–2020
sro1920t12.csv		Table 12. Equipment sworn SROs usually carried in the school to which they were primarily assigned, by type of agency, 2019–2020
sro1920t13.csv		Table 13. Percent of sworn SROs who received training on use of force and de-escalation, by tenure as a sworn law enforcement officer, 2019–2020
sro1920t14.csv		Table 14. Sworn SRO frame counts and sampling rates, 2019–2020
sro1920t15.csv		Table 15. Sworn SRO sample allocation, 2019–2020
	
			Figures
sro1920f01.csv		Figure 1. Number of sworn SROs, by type of agency, 2019–2020
sro1920f02.csv		Figure 2. Age of sworn SROs, by type of agency, 2019–2020
sro1920f03.csv		Figure 3. Percent of sworn SROs who spoke another language and found it useful when interacting with students, by type of agency, 2019–2020
sro1920f04.csv		Figure 4. Type of school to which sworn SROs were primarily assigned, by type of agency, 2019–2020
sro1920f05.csv		Figure 5. Recent investigative activities performed by sworn SROs, by type of agency, 2019–2020
sro1920f06.csv		Figure 6. Recent criminal enforcement activities performed by sworn SROs, by type of agency, 2019–2020
sro1920f07.csv		Figure 7. Percent of sworn SROs who received training on selected topics, 2019–2020
	
			Appendix tables
sro1920at01.csv		Appendix table 1. Standard errors for table 1: Number and percent of sworn SROs, by type of agency, 2019–2020
sro1920at02.csv		Appendix table 2. Standard errors for table 2: Sex and race or ethnicity of sworn SROs, by type of agency, 2019–2020
sro1920at03.csv		Appendix table 3. Estimates and standard errors for figure 2: Age of sworn SROs, by type of agency, 2019–2020
sro1920at04.csv		Appendix table 4. Standard errors for table 3: Years worked as a sworn SRO, by type of agency, 2019–2020
sro1920at05.csv		Appendix table 5. Standard errors for table 4: Percent of sworn SROs certified by a national or state SRO association, by type of agency, 2019–2020
sro1920at06.csv		Appendix table 6. Estimates and standard errors for figure 3: Percent of sworn SROs who spoke another language and found it useful when interacting with students, by type of agency, 2019–2020
sro1920at07.csv		Appendix table 7. Standard errors for table 5: Number of schools to which sworn SROs were assigned, by type of agency and size of SRO program, 2019–2020
sro1920at08.csv		Appendix table 8. Estimates and standard errors for figure 4: Type of school to which sworn SROs were primarily assigned, by type of agency, 2019–2020
sro1920at09.csv		Appendix table 9. Standard errors for table 6: Recent patrol and response activities performed by sworn SROs, by type of agency, 2019–2020
sro1920at10.csv		Appendix table 10. Estimates and standard errors for figure 5: Recent investigative activities performed by sworn SROs, by type of agency, 2019–2020
sro1920at11.csv		Appendix table 11. Standard errors for table 7: Recent security activities performed by sworn SROs, by type of agency, 2019–2020
sro1920at12.csv		Appendix table 12. Estimates and standard errors for figure 6: Recent criminal enforcement activities performed by sworn SROs, by type of agency, 2019–2020
sro1920at13.csv		Appendix table 13. Standard errors for table 8: Recent mentoring activities performed by sworn SROs, by type of agency, 2019–2020
sro1920at14.csv		Appendix table 14. Standard errors for table 9: Recent teaching activities performed by sworn SROs, by type of agency, 2019–2020
sro1920at15.csv		Appendix table 15. Standard errors for table 10: Role of school administration in arrest decisions by sworn SROs, by type of agency, 2019–2020
sro1920at16.csv		Appendix table 16. Standard errors for table 11: Offenses for which sworn SROs arrested any student(s) during the past 12 months, by type of agency, 2019–2020
sro1920at17.csv		Appendix table 17. Standard errors for table 12: Equipment sworn SROs usually carried in the school to which they were primarily assigned, by type of agency, 2019–2020
sro1920at18.csv		Appendix table 18. Standard errors for table 13: Percent of sworn SROs who received training on use of force and de-escalation, by tenure as a sworn law enforcement officer, 2019–2020
sro1920at19.csv		Appendix table 19. Estimates and standard errors for figure 7: Percent of sworn SROs who received training on selected topics, 2019–2020