Punitive Damage Awards in Large Counties, 2001    NCJ 208445			


This zip archive contains tables in individual .csv spreadsheets			
from Punitive Damage Awards in Large Counties, 2001 NCJ 208445.  The full report including text			
and graphics in pdf format are available from:			
http://www.ojp.usdoj.gov/bjs/abstract/pdalc01.htm			


Filename			Tables
pdalc0101.csv		Table 1.	Punitive damage awards in civil trials with plaintiff winners in State courts the Nation's 75 larges counties, 2001
pdalc0102.csv		Table 2.	Punitive damage awards in civil trials with plaintiff winners in State courts in the Nation's 75 largest counties, 2001
pdalc0103.csv		Table 3.	Comparing compensatory to punitive damage awards in civil trials with plaintiff winners in State courts in the Nation's 75 largest counties, 2001
pdalc0104.csv		Table 4.	Comparing bench and jury trials in which plaintiff winners received punitive damage awards in State courts in the Nation's 75 largest counties, 2001
pdalc0105.csv		Table 5.	Pairings of primary litigants in civil trials with punitive damages in State courts  in the Nation's 75 largest counties, 2001 
pdalc0106.csv		Table 6.	Type of post trial relief sought by litigants in civil trials with punitive damages awarded to plaintiff winners in State courts in the Nation's 75 largest counties, 2001 
pdalc0107.csv		Table 7.	Type of post trial relief granted to litigants in civil trials with punitive damages awarded to plaintiff winners in State courts in the Nation's 75 largest counties, 2001 
pdalc0108.csv		Table 8.	Civil trials with punitive damages in which the litigants gave notice of appeal in State courts in the Nation's 75 largest counties, 2001
pdalc0109.csv		Table 9.	Comparing civil jury trials in which plaintiff winners received punitive damages in State courts in the Nation's 75 largest counties, 1992 and 2001

					Appendix table	
pdalc01ap.csv		Appendix table 1.	Punitive damage awards for plaintiff winners in civil trials, by sampled counties, 2001
