Non-U.S. Citizens in the Federal Criminal Justice System, 1998–2018   NCJ 252647	
	
This zip archive contains tables in individual  .csv spreadsheets	
from Non-U.S. Citizens in the Federal Criminal Justice System, 1998–2018   NCJ 252647. The full report including text	
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/non-us-citizens-federal-criminal-justice-system-1998-2018
	
Filename		Table title
ncfcjs9818t01.csv	Table 1. Persons prosecuted in U.S. district courts, by demographic characteristics and citizenship status, fiscal year 2018
ncfcjs9818t02.csv	Table 2. Persons prosecuted in U.S. district courts, by prior federal or state convictions and citizenship status, fiscal year 2018
ncfcjs9818t03.csv	Table 3. Persons prosecuted in U.S. district courts, by offense type and citizenship status, fiscal year 2018
ncfcjs9818t04.csv	Table 4. Persons prosecuted in U.S. district courts, by offense type and citizenship status, fiscal years 1998, 2008, and 2018
ncfcjs9818t05.csv	Table 5. Persons receiving pretrial release, by citizenship status, fiscal year 2018
ncfcjs9818t06.csv	Table 6. Persons sentenced to prison in U.S. district courts, by citizenship status and offense type, fiscal year 2018 
ncfcjs9818t07.csv	Table 7. Persons sentenced in U.S. district courts for drug trafficking, by citizenship status and drug type, fiscal years 2016–2018
ncfcjs9818t08.csv	Table 8. Persons admitted to federal prisons, by commitment offense and citizenship status, fiscal year 2018
ncfcjs9818t09.csv	Table 9. Persons in federal prisons, by country of birth and citizenship status, fiscal year 2018
ncfcjs9818t10.csv	Table 10. Persons in federal prisons, by country of citizenship, fiscal years 1998, 2008, and 2018
	
			Figures
ncfcjs9818f01.csv	Figure 1. Persons prosecuted in U.S. district courts, by citizenship status, fiscal years 1998–2018
ncfcjs9818f02.csv	Figure 2. Non-U.S. citizens incarcerated in federal prisons at fiscal year-end, by selected offense type, fiscal years 1998–2018
	
			Appendix tables
ncfcjs9818at01.csv	Appendix table 1. Counts for figure 1: Persons prosecuted in U.S. district courts, by citizenship status, fiscal years 1998–2018
ncfcjs9818at02.csv	Appendix table 2. Counts for figure 2: Non-U.S. citizens incarcerated in federal prisons at fiscal year-end, by selected offense type, fiscal years 1998–2018
	
	
