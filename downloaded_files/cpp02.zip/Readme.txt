Contacts between Police and the Public: Findings from the 2002 National Survey   NCJ  207845


This zip archive contains tables in individual .csv spreadsheets
from Contacts between Police and the Public: Findings from the 2002 
National Survey , NCJ 207845.  The full report including text 
and graphics in pdf format are available from:
http://www.ojp.usdoj.gov/bjs/abstract/cpp02.htm 

This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cpp

 
cpp02ap.csv	Appendix table. Number of survey respondents in the 2002 Police-Public Contact Survey, by demographic characteristics of resident
cpp0201.csv	Table 1: Rate of face-to-face contact between police and persons age 16 or older, by demographic characteristics of residents, 2002
cpp0202.csv	Table 2: Annual number of face-to-face contacts between police and persons age 16 or older, by demographic characteristics of residents, 2002
cpp0203.csv	Table 3: Characteristics of persons with and without face-to-face police contact, 2002
cpp0204.csv	Table 4: Number of residents age 16 or older with police contact, by type of and reason for contact, 2002
cpp0205.csv	Table 5: What police did during the contact, by type of and reason for contact, 2002
cpp0206.csv	Table 6: Gender, race/Hispanic origin, and age of drivers stopped by police, 2002
cpp0207.csv	Table 7: Gender, race/Hispanic origin, and age of all drivers compared to drivers stopped by police, 2002
cpp0208.csv	Table 8: Reasons police gave for stopping vehicle, by gender, race/Hispanic origin, and age of stopped drivers, 2002
cpp0209.csv	Table 9: What police did during the traffic stop, by gender, race/Hispanic origin, and age of stopped drivers, 2002
cpp0210.csv	Table 10: Type of search of vehicle or driver and the outcome, 2002
cpp0211.csv	Table 11: Type and outcome of searches conducted by police during traffic stops, 2002
cpp0212.csv	Table 12: Among drivers arrested by police, percent searched, 2002
cpp0213.csv	Table 13: Among drivers arrested and searched by police, percent of searches that occurred before or after the arrest, 2002
cpp0214.csv	Table 14: Among drivers arrested and searched by police, type and outcome of searches, by whether the search occurred before or after the arrest, 2002
cpp0215.csv	Table 15: Demographic characteristics of residents age 16 or older whose contact involved police use of force in 2002
cpp0216.csv	Table 16: Among residents age 16 or older who had contact with police in 2002, percent whose contact involved police use of force, by demographic characteristics of residents	
cpp0217.csv	Table 17: Among residents age 16 or older who had contact with police in 2002, percent whose contact involved police use of force, by type of and reason for contact
cpp0218.csv	Table 18: Type of contact and reason for contact with police among residents age 16 or older whose contact involved police use of force in 2002
cpp0219.csv	Table 19: Type of force police used or threatened against residents age 16 or older during face-to-face contact in 2002
cpp0220.csv	Table 20: Among residents age 16 or older whose contact involved police use of force in 2002, percent who felt the force used or threatened was "excessive," by race/Hispanic origin of residents
cpp0221.csv	Table 21: Among residents age 16 or older whose contact involved police use of force in 2002, percent who were injured, by race/Hispanic origin of residents
cpp0222.csv	Table 22: Type of criminal evidence found on or near residents age 16 or older during contact that involved police use of force in 2002
cpp0223.csv	Table 23: Type of charge filed against residents age 16 or older whose contact involved police use of force in 2002
cpp0224.csv	Table 24: Conduct of residents age 16 or older during contact that involved police use of force in 2002
cpp0225.csv	Table 25: Among residents age 16 or older who had contact with police in 2002, percent whose contact involved police use of force, by conduct of residents during contact
cpp0226.csv	Table 26: Among residents age 16 or older whose contact involved police use of force in 2002, characteristics of force incident, by race/Hispanic origin of residents
cpp0227.csv	Table 27: Type of formal action taken against police by residents age 16 or older whose contact involved police use of force in 2002

