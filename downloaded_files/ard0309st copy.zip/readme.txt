Arrest-Related Deaths,2003-2009 - Statistical Tables NCJ 235385		
		
This zip archive contains tables in individual  .csv spreadsheets		
from Arrest-Related Deaths,2003-2009- Statistical Tables  NCJ 235385.  

The full report including text and graphics in pdf format are available
 at: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2228

This reports is one in s series. More recent editions may be available. 
To view a list of all repots in the series go to
http://www.bjs.gov/index.cfm?ty=dcdetail&iid-74

		
		
Filename		Table titles

ard0309t01.csv		Table 1. Number of reported arrest-related deaths, by manner of death, 2003-2009
ard0309t02.csv		Table 2. Percent of reported arrest-related deaths, by mannerof death, 2003-200
ard0309t03.csv		Table 3. Number of reported arrest-related deaths, by demographic characteristics, 2003-2009
ard0309t04.csv		Table 4. Percent of reported arrest-related deaths, by demographic characteristics, 2003-2009
ard0309t05.csv		Table 5. Number of reported arrest-related deaths, by manner of death and demographic characteristics, 2003-2009
ard0309t06.csv		Table 6. Percent of reported arrest-related deaths, by manner of death and demographic characteristics, 2003-2009
ard0309t07.csv		Table 7. Percent of reported arrest-related deaths, by demographic characteristics and manner of death, 2003-2009
ard0309t08.csv		Table 8. Number of reported arrest-related deaths, by jurisdiction, 2003-2009
ard0309t09.csv		Table 9. Number of reported arrest-related deaths, by jurisdiction and manner of death, 2003-2009
ard0309t10.csv		Table 10. Percent of reported arrest-related deaths, by jurisdiction and manner of death, 2003-2009
ard0309t11.csv		Table 11. Number of arresting agencies with at least one reported arrest-related death, by jurisdiction, 2003-2009
ard0309t12.csv		Table 12. Demographic characteristics of all reported arrests and persons who died in the process of arrest, 2003-2009
ard0309t13.csv		Table 13. Reported arrest-related deaths, by incident circumstances, 2003-2009
ard0309t14.csv		Table 14. Percent of reported arrest-related deaths, by incident circumstances and manner of death, 2003-2009
ard0309t15.csv		Table 15. Number of law enforcement agencies, full-time sworn personnel, and reported arrest-related deaths, by agency characteristics, 2003-2009
ard0309t16.csv		Table 16. Number of reported arrest-related deaths, by characteristics of the law enforcement agency involved and
manner of death, 2003-2009
ard0309t17.csv		Table 17. Percent of reported arrest-related deaths, by characteristics of the law enforcement agency involved and manner of death, 2003-2009
		
			Appendix Tables

ard0309at1.csv		Table 1. Agencies reporting arrest-releated death  records, 2006
ard0309at2.csv		Table 2. States not reporting arrest-related deaths in all years, 2003-2009