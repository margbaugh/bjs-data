Local Police Departments Personnel, 2020  NCJ 305187
																		
This zip archive contains tables in individual  .csv spreadsheets
Local Police Departments Personnel, 2020  NCJ 305187.  The full report including text
and graphics in pdf format is available from: https://bjs.ojp.gov/library/publications/local-police-departments-personnel-2020
																		
This report is one in a series.  More recent editions
may be available.  To view a list of all in the series go to
https://bjs.ojp.gov/library/publications/list?series_filter=Local%20Police%20Departments																		
																		
Filenames	Table titles																	
lpdp20t01.csv	Table 1. Full-time personnel in local police departments, 1997-2020																	
lpdp20t02.csv	Table 2. Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2020	
lpdp20t03.csv	Table 3. Local police departments and full-time personnel, by size of agency, 2020
lpdp20t04.csv	Table 4. Local police departments and full-time personnel, by size of population served, 2020
lpdp20t05.csv	Table 5. Sex of full-time sworn officers in local police departments, by size of population served, 2016 and 2020
lpdp20t06.csv	Table 6. Race or Hispanic origin of full-time sworn officers in local police departments, by size of population served, 2016 and 2020	
lpdp20t07.csv	Table 7. Race or Hispanic origin of full-time sworn officers in local police departments, 1997–2020
lpdp20t08.csv	Table 8. Sex and race or Hispanic origin of full-time sworn officers in local police departments, by size of population served, 2020
lpdp20t09.csv	Table 9. Chiefs, intermediate supervisors, and first-line supervisors in local police departments who were female, by size of population served, 2020
lpdp20t10.csv	Table 10. Race or Hispanic origin of chiefs, intermediate supervisors, and first-line supervisors in local police departments, by size of population served, 2020
lpdp20t11.csv	Table 11. Primary job responsibility of full-time personnel in local police departments, by size of population served, 2020
lpdp20t12.csv	Table 12. Full-time personnel in local police departments who were bilingual or multilingual, by size of population served, 2020
lpdp20t13.csv	Table 13. Local police departments with personnel designated to address specific crime-related issues, by size of population served, 2020
lpdp20t14.csv	Table 14. Local police departments with personnel designated to address specific functional areas, by size of population served, 2020
lpdp20t15.csv	Table 15. Annual operating budgets of local police departments, by size of population served, 2020
lpdp20t16.csv	Table 16. Base weights, nonresponse adjustments, and final weights for local police departments, by stratum, 2020
lpdp20t17.csv	Table 17. Law Enforcement Management and Administrative Statistics survey response rates for local police departments, by size of agency, 2020
																		
		Figures																	
lpdp20f01.csv	Figure 1. Full-time personnel in local police departments, 1997-2020
lpdp20f02.csv	Figure 2. Average number of full-time-equivalent sworn officers in local police departments per 1,000 residents, by size of population served, 2020
lpdp20f03.csv	Figure 3. Percent of full-time sworn officers in local police departments who were female, 1997–2020
lpdp20f04.csv	Figure 4. Percent of local police departments that reported adopting practices or policies to address the COVID-19 pandemic, by size of population served, 2020	
																		
		Appendix tables																	
lpdp20at01.csv	Appendix Table 1. Standard errors for figure 1 and table 1: Full-time personnel in local police departments, 1997–2020
lpdp20at02.csv	Appendix Table 2. Standard errors for table 2: Personnel in general-purpose state and local law enforcement agencies, by type of agency, 2020
lpdp20at03.csv	Appendix Table 3. Standard errors for table 3: Local police departments and full-time personnel, by size of agency, 2020
lpdp20at04.csv	Appendix Table 4. Standard errors for table 4: Local police departments and full-time personnel, by size of population served, 2020
lpdp20at05.csv	Appendix Table 5. Estimates and standard errors for figure 2: Average number of full-time-equivalent sworn officers in local police departments per 1,000 residents, by size of population served, 2020
lpdp20at06.csv	Appendix Table 6. Standard errors for table 5: Sex of full-time sworn officers in local police departments, by size of population served, 2016 and 2020
lpdp20at07.csv	Appendix Table 7. Estimates and standard errors for figure 3: Percent of full-time sworn officers in local police departments who were female, 1997–2020
lpdp20at08.csv	Appendix Table 8. Standard errors for table 6: Race or Hispanic origin of full-time sworn officers in local police departments, by size of population served, 2016 and 2020
lpdp20at09.csv	Appendix Table 9. Standard errors for table 7: Race or Hispanic origin of full-time sworn officers in local police departments, 1997–2020
lpdp20at10.csv	Appendix Table 10. Standard errors for table 8: Sex and race or Hispanic origin of full-time sworn officers in local police departments, by size of population served, 2020
lpdp20at11.csv	Appendix Table 11. Standard errors for table 9: Chiefs, intermediate supervisors, and first-line supervisors in local police departments who were female, by size of population served, 2020
lpdp20at12.csv	Appendix Table 12. Standard errors for table 10: Race or Hispanic origin of chiefs, intermediate supervisors, and first-line supervisors in local police departments, by size of population served, 2020
lpdp20at13.csv	Appendix Table 13. Estimates and standard errors for figure 4: Percent of local police departments that reported adopting practices or policies to address the COVID-19 pandemic, by size of population served, 2020
lpdp20at14.csv	Appendix Table 14. Estimates and standard errors for figure 5: Percent of local police departments that reported a reduction in operations due to policies or practices to address the COVID-19 pandemic, 2020
lpdp20at15.csv	Appendix Table 15. Standard errors for table 11: Primary job responsibility of full-time personnel in local police departments, by size of population served, 2020
lpdp20at16.csv	Appendix Table 16. Standard errors for table 12: Full-time personnel in local police departments who were bilingual or multilingual, by size of population served, 2020
lpdp20at17.csv	Appendix Table 17. Standard errors for table 13: Local police departments with personnel designated to address specific crime-related issues, by size of population served, 2020
lpdp20at18.csv	Appendix Table 18. Standard errors for table 14: Local police departments with personnel designated to address specific functional areas, by size of population served, 2020
lpdp20at19.csv	Appendix Table 19. Standard errors for table 15: Annual operating budgets of local police departments, by size of population served, 2020