Tribal Crime Data Collection Activities, 2015		
		
This zip archive contains tables in individual  .csv spreadsheets		
Tribal Crime Data Collection Activities, 2015  NCJ 248785  The full report including text		
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=5323	
		
This report is one in a series.  More recent editions		
may be available.  To view a list of all in the series go to		
http://www.bjs.gov/index.cfm?ty=pbse&sid=77		
		
		
Filename		Appendix Tables
tcdca15at01.csv		Appendix table 1. Violent crimes known to tribal law enforcement, by jurisdiction, 2013
tcdca15at02.csv		Appendix table 2. Property crimes known to tribal law enforcement, by jurisdiction, 2013
tcdca15at03.csv		Appendix table 3. American Indian tribes that received Edward Byrne Memorial Justice Assistance Grant (JAG) awards, 2008�2015
		
			Figures
tcdca15f01.csv		Figure 1. Tribal law enforcement agencies reporting to the Uniform Crime Reporting Program that submitted 12 months of complete data, 2008�2013
tcdca15f02.csv		Figure 2. Total Edward Byrne Memorial Justice Assistance Grant allocations to American Indian tribes, 2008�2015
