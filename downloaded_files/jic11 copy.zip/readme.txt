Jails in Indian Country, 2011 NCJ 238978	
	
This zip archive contains tables in individual .csv spreadsheets	
from Jails in Indian Country, 2011, NCJ 238978. The full report 	
including text and graphics in .pdf format are available from: 	
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4492	
	
This report is one in a series. More recent editions may be available. To 	
view a list of all in the series go to the http://www.bjs.gov/index.cfm?ty=pbse&sid=32	
 	
Tables	
jic11t01.csv	Table 1. American Indians and Alaska Natives in custody or under community supervision, 2010 and 2011
jic11t02.csv	Table 2. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, 2000, 2004, and 2007�2011
jic11t03.csv	Table 3. Jails in Indian country that held the majority of inmates in 2011 compared to 2010, by facility
jic11t04.csv	Table 4. Indian country jails and percent of inmate population, by facility size, June 2011
jic11t05.csv	Table 5. Number of Indian country jails, by population measures and percent of rated capacity occupied, June 2011
jic11t06.csv	Table 6. Jails in Indian country operating above 150% of capacity on their peak day, June 2011
jic11t07.csv	Table 7. Admissions and expected length of stay in Indian country jails, by facility size, June 2011
jic11t08.csv	Table 8. Admissions and expected length of stay in 73 operating Indian country jails, by facility size based on the rated capacity midyear 2010, June 2010 and 2011
jic11t09.csv	Table 9. Inmates confined in Indian country jails, by demographic characteristics, conviction status, and offense, midyear 2000, 2002, 2004, and 2007�2011
jic11t10.csv	Table 10. Persons employed in Indian country jails, by job function, midyear 2010 and 2011
jic11t11.csv	Table 11. Jails in Indian country with medical and mental health services and policies, by type, June 2011 
jic11t12.csv	Table 12. Jails in Indian country that provided inmate treatment, counseling, and special programs, June 2011
	
Appendix tables	
jic11at01.csv	Appendix table 1. Inmates, rated capacity, and percent of capacity occupied in Indian country jails, by facility, June 2011
jic11at02.csv	Appendix table 2. Inmates in Indian country jails, by type of offense, June 2011
jic11at03.csv	Appendix table 3. Inmates in Indian country jails, by conviction status, June 2011
jic11at04.csv	Appendix table 4. Adults and juveniles in the custody of Indian country jails, by sex, June 2011
jic11at05.csv	Appendix table 5. Jails in Indian country that provided medical services to inmates, by facility, June 2011
jic11at06.csv	Appendix table 6. Jails in Indian country with policies for screening inmates for HIV infection, by facility, June 2011
jic11at07.csv	Appendix table 7. Jails in Indian country with policies for testing inmates for hepatitis B, by facility, June 2011
jic11at08.csv	Appendix table 8. Jails in Indian country with policies for testing inmates for hepatitis C, by facility, June 2011
jic11at09.csv	Appendix table 9. Jails in Indian country with policies for testing inmates for tuberculosis, by facility, June 2011
jic11at10.csv	Appendix table 10. Jails in Indian country with policies to provide mental health care for inmates, by facility, June 2011
jic11at11.csv	Appendix table 11. Jails in Indian country with suicide prevention procedures, by facility, June 2011
jic11at12.csv	Appendix table 12. Jails in Indian country that provided treatment, counseling, and special programs on or off facility grounds for inmates, by facility, June 2011
jic11at13.csv	Appendix table 13. Jails in Indian country that provide education programs on or off facility grounds for inmates, by facility, June 2011
jic11at14.csv	Appendix table 14: Jails in Indian country that provided work assignments for inmates, by facility, June 2011
	
Figures	
jic11f01.csv	Figure 1. Inmates confined in Indian country jails, midyear 2000�2004 and 2007�2011
jic11f02.csv	Figure 2. American Indians and Alaska Natives under correctional supervision in the United States, 2000�2011
jic11f03.csv	Figure 3. Percent of rated capacity occupied, by facility size, June 2011
